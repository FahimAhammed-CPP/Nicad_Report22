package b.a.a;

import android.os.IBinder;
import android.os.Parcel;

public class b implements d {
  public IBinder e;
  
  public b(IBinder paramIBinder) {
    this.e = paramIBinder;
  }
  
  public boolean U(long paramLong) {
    Parcel parcel1 = Parcel.obtain();
    Parcel parcel2 = Parcel.obtain();
    try {
      parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
      parcel1.writeLong(paramLong);
      IBinder iBinder = this.e;
      boolean bool = false;
      iBinder.transact(2, parcel1, parcel2, 0);
      parcel2.readException();
      int i = parcel2.readInt();
      if (i != 0)
        bool = true; 
      return bool;
    } finally {
      parcel2.recycle();
      parcel1.recycle();
    } 
  }
  
  public IBinder asBinder() {
    return this.e;
  }
  
  public boolean y(a parama) {
    Parcel parcel1 = Parcel.obtain();
    Parcel parcel2 = Parcel.obtain();
    try {
      parcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
      parcel1.writeStrongBinder((IBinder)parama);
      IBinder iBinder = this.e;
      boolean bool = false;
      iBinder.transact(3, parcel1, parcel2, 0);
      parcel2.readException();
      int i = parcel2.readInt();
      if (i != 0)
        bool = true; 
      return bool;
    } finally {
      parcel2.recycle();
      parcel1.recycle();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\b\a\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */