package b.a.a;

import android.os.Binder;

public abstract class c extends Binder implements d {}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\b\a\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */