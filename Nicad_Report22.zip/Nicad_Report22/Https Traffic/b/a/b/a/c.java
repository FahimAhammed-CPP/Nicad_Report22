package b.a.b.a;

import android.os.Parcel;
import android.os.Parcelable;

public class c implements Parcelable.Creator<e> {
  public Object createFromParcel(Parcel paramParcel) {
    return new e(paramParcel);
  }
  
  public Object[] newArray(int paramInt) {
    return (Object[])new e[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\b\a\b\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */