package c.a;

import java.util.concurrent.CopyOnWriteArrayList;

public abstract class d {
  public boolean a;
  
  public CopyOnWriteArrayList<a> b = new CopyOnWriteArrayList<a>();
  
  public d(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public abstract void a();
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */