package c.a;

import androidx.activity.ComponentActivity;

public class b implements Runnable {
  public b(ComponentActivity paramComponentActivity) {}
  
  public void run() {
    ComponentActivity.n(this.e);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */