package c.b.d.a;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.SparseArray;
import android.util.TypedValue;
import c.b.h.z1;
import java.util.WeakHashMap;

public abstract class a {
  public static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  public static final WeakHashMap<Context, SparseArray<Object>> b = new WeakHashMap<Context, SparseArray<Object>>(0);
  
  public static final Object c = new Object();
  
  public static Drawable a(Context paramContext, int paramInt) {
    return z1.d().f(paramContext, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\d\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */