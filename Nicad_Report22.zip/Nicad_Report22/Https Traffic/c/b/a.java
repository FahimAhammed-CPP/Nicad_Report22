package c.b;

import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import c.b.h.q2;
import c.f.b.e;
import c.f.b.l.c;
import c.f.b.l.d;
import c.f.b.l.e;
import c.f.b.l.f;
import c.f.b.l.h;
import c.f.b.l.k.q;
import java.lang.reflect.Field;
import java.util.ArrayList;

public abstract class a {
  public static Field a;
  
  public static boolean b;
  
  public static Class<?> c;
  
  public static boolean d;
  
  public static Field e;
  
  public static boolean f;
  
  public static Field g;
  
  public static boolean h;
  
  public static void a(e parame, e parame1, ArrayList<d> paramArrayList, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: astore #21
    //   3: getstatic c/f/b/l/d$a.g : Lc/f/b/l/d$a;
    //   6: astore #20
    //   8: iconst_2
    //   9: istore #9
    //   11: iload_3
    //   12: ifne -> 35
    //   15: aload #21
    //   17: getfield s0 : I
    //   20: istore #7
    //   22: aload #21
    //   24: getfield v0 : [Lc/f/b/l/b;
    //   27: astore #26
    //   29: iconst_0
    //   30: istore #11
    //   32: goto -> 52
    //   35: aload #21
    //   37: getfield t0 : I
    //   40: istore #7
    //   42: aload #21
    //   44: getfield u0 : [Lc/f/b/l/b;
    //   47: astore #26
    //   49: iconst_2
    //   50: istore #11
    //   52: iconst_0
    //   53: istore #8
    //   55: aload_2
    //   56: astore #25
    //   58: aload_0
    //   59: astore #24
    //   61: iload #8
    //   63: iload #7
    //   65: if_icmpge -> 4040
    //   68: aload #26
    //   70: iload #8
    //   72: aaload
    //   73: astore #31
    //   75: aload #31
    //   77: getfield t : Z
    //   80: istore #19
    //   82: aconst_null
    //   83: astore #33
    //   85: iload #19
    //   87: ifne -> 920
    //   90: aload #31
    //   92: getfield o : I
    //   95: iload #9
    //   97: imul
    //   98: istore #12
    //   100: aload #31
    //   102: getfield a : Lc/f/b/l/d;
    //   105: astore #21
    //   107: aload #21
    //   109: astore #22
    //   111: iconst_0
    //   112: istore #9
    //   114: iload #9
    //   116: ifne -> 772
    //   119: aload #31
    //   121: aload #31
    //   123: getfield i : I
    //   126: iconst_1
    //   127: iadd
    //   128: putfield i : I
    //   131: aload #21
    //   133: getfield h0 : [Lc/f/b/l/d;
    //   136: astore #23
    //   138: aload #31
    //   140: getfield o : I
    //   143: istore #10
    //   145: aload #23
    //   147: iload #10
    //   149: aconst_null
    //   150: aastore
    //   151: aload #21
    //   153: getfield g0 : [Lc/f/b/l/d;
    //   156: iload #10
    //   158: aconst_null
    //   159: aastore
    //   160: aload #21
    //   162: getfield b0 : I
    //   165: bipush #8
    //   167: if_icmpeq -> 658
    //   170: aload #31
    //   172: aload #31
    //   174: getfield l : I
    //   177: iconst_1
    //   178: iadd
    //   179: putfield l : I
    //   182: aload #21
    //   184: iload #10
    //   186: invokevirtual j : (I)Lc/f/b/l/d$a;
    //   189: aload #20
    //   191: if_acmpeq -> 252
    //   194: aload #31
    //   196: getfield m : I
    //   199: istore #13
    //   201: aload #31
    //   203: getfield o : I
    //   206: istore #10
    //   208: iload #10
    //   210: ifne -> 223
    //   213: aload #21
    //   215: invokevirtual q : ()I
    //   218: istore #10
    //   220: goto -> 242
    //   223: iload #10
    //   225: iconst_1
    //   226: if_icmpne -> 239
    //   229: aload #21
    //   231: invokevirtual k : ()I
    //   234: istore #10
    //   236: goto -> 242
    //   239: iconst_0
    //   240: istore #10
    //   242: aload #31
    //   244: iload #13
    //   246: iload #10
    //   248: iadd
    //   249: putfield m : I
    //   252: aload #31
    //   254: getfield m : I
    //   257: istore #10
    //   259: aload #21
    //   261: getfield K : [Lc/f/b/l/c;
    //   264: iload #12
    //   266: aaload
    //   267: invokevirtual d : ()I
    //   270: iload #10
    //   272: iadd
    //   273: istore #13
    //   275: aload #31
    //   277: iload #13
    //   279: putfield m : I
    //   282: aload #21
    //   284: getfield K : [Lc/f/b/l/c;
    //   287: astore #23
    //   289: iload #12
    //   291: iconst_1
    //   292: iadd
    //   293: istore #10
    //   295: aload #31
    //   297: aload #23
    //   299: iload #10
    //   301: aaload
    //   302: invokevirtual d : ()I
    //   305: iload #13
    //   307: iadd
    //   308: putfield m : I
    //   311: aload #31
    //   313: getfield n : I
    //   316: istore #13
    //   318: aload #21
    //   320: getfield K : [Lc/f/b/l/c;
    //   323: iload #12
    //   325: aaload
    //   326: invokevirtual d : ()I
    //   329: iload #13
    //   331: iadd
    //   332: istore #13
    //   334: aload #31
    //   336: iload #13
    //   338: putfield n : I
    //   341: aload #31
    //   343: aload #21
    //   345: getfield K : [Lc/f/b/l/c;
    //   348: iload #10
    //   350: aaload
    //   351: invokevirtual d : ()I
    //   354: iload #13
    //   356: iadd
    //   357: putfield n : I
    //   360: aload #31
    //   362: getfield b : Lc/f/b/l/d;
    //   365: ifnonnull -> 375
    //   368: aload #31
    //   370: aload #21
    //   372: putfield b : Lc/f/b/l/d;
    //   375: aload #31
    //   377: aload #21
    //   379: putfield d : Lc/f/b/l/d;
    //   382: aload #21
    //   384: getfield N : [Lc/f/b/l/d$a;
    //   387: astore #23
    //   389: aload #31
    //   391: getfield o : I
    //   394: istore #10
    //   396: aload #23
    //   398: iload #10
    //   400: aaload
    //   401: aload #20
    //   403: if_acmpne -> 658
    //   406: aload #21
    //   408: getfield n : [I
    //   411: astore #27
    //   413: aload #27
    //   415: iload #10
    //   417: iaload
    //   418: ifeq -> 445
    //   421: aload #27
    //   423: iload #10
    //   425: iaload
    //   426: iconst_3
    //   427: if_icmpeq -> 445
    //   430: aload #27
    //   432: iload #10
    //   434: iaload
    //   435: iconst_2
    //   436: if_icmpne -> 442
    //   439: goto -> 445
    //   442: goto -> 648
    //   445: aload #31
    //   447: aload #31
    //   449: getfield j : I
    //   452: iconst_1
    //   453: iadd
    //   454: putfield j : I
    //   457: aload #21
    //   459: getfield f0 : [F
    //   462: astore #28
    //   464: aload #28
    //   466: iload #10
    //   468: faload
    //   469: fstore #4
    //   471: fload #4
    //   473: fconst_0
    //   474: fcmpl
    //   475: ifle -> 497
    //   478: aload #31
    //   480: aload #31
    //   482: getfield k : F
    //   485: aload #28
    //   487: iload #10
    //   489: faload
    //   490: fadd
    //   491: putfield k : F
    //   494: goto -> 497
    //   497: aload #21
    //   499: getfield b0 : I
    //   502: bipush #8
    //   504: if_icmpeq -> 540
    //   507: aload #23
    //   509: iload #10
    //   511: aaload
    //   512: aload #20
    //   514: if_acmpne -> 540
    //   517: aload #27
    //   519: iload #10
    //   521: iaload
    //   522: ifeq -> 534
    //   525: aload #27
    //   527: iload #10
    //   529: iaload
    //   530: iconst_3
    //   531: if_icmpne -> 540
    //   534: iconst_1
    //   535: istore #10
    //   537: goto -> 543
    //   540: iconst_0
    //   541: istore #10
    //   543: iload #10
    //   545: ifeq -> 601
    //   548: fload #4
    //   550: fconst_0
    //   551: fcmpg
    //   552: ifge -> 564
    //   555: aload #31
    //   557: iconst_1
    //   558: putfield q : Z
    //   561: goto -> 570
    //   564: aload #31
    //   566: iconst_1
    //   567: putfield r : Z
    //   570: aload #31
    //   572: getfield h : Ljava/util/ArrayList;
    //   575: ifnonnull -> 590
    //   578: aload #31
    //   580: new java/util/ArrayList
    //   583: dup
    //   584: invokespecial <init> : ()V
    //   587: putfield h : Ljava/util/ArrayList;
    //   590: aload #31
    //   592: getfield h : Ljava/util/ArrayList;
    //   595: aload #21
    //   597: invokevirtual add : (Ljava/lang/Object;)Z
    //   600: pop
    //   601: aload #31
    //   603: getfield f : Lc/f/b/l/d;
    //   606: ifnonnull -> 616
    //   609: aload #31
    //   611: aload #21
    //   613: putfield f : Lc/f/b/l/d;
    //   616: aload #31
    //   618: getfield g : Lc/f/b/l/d;
    //   621: astore #23
    //   623: aload #23
    //   625: ifnull -> 641
    //   628: aload #23
    //   630: getfield g0 : [Lc/f/b/l/d;
    //   633: aload #31
    //   635: getfield o : I
    //   638: aload #21
    //   640: aastore
    //   641: aload #31
    //   643: aload #21
    //   645: putfield g : Lc/f/b/l/d;
    //   648: aload #31
    //   650: getfield o : I
    //   653: istore #10
    //   655: goto -> 658
    //   658: aload #22
    //   660: aload #21
    //   662: if_acmpeq -> 678
    //   665: aload #22
    //   667: getfield h0 : [Lc/f/b/l/d;
    //   670: aload #31
    //   672: getfield o : I
    //   675: aload #21
    //   677: aastore
    //   678: aload #21
    //   680: getfield K : [Lc/f/b/l/c;
    //   683: iload #12
    //   685: iconst_1
    //   686: iadd
    //   687: aaload
    //   688: getfield f : Lc/f/b/l/c;
    //   691: astore #22
    //   693: aload #22
    //   695: ifnull -> 739
    //   698: aload #22
    //   700: getfield d : Lc/f/b/l/d;
    //   703: astore #22
    //   705: aload #22
    //   707: getfield K : [Lc/f/b/l/c;
    //   710: astore #23
    //   712: aload #23
    //   714: iload #12
    //   716: aaload
    //   717: getfield f : Lc/f/b/l/c;
    //   720: ifnull -> 739
    //   723: aload #23
    //   725: iload #12
    //   727: aaload
    //   728: getfield f : Lc/f/b/l/c;
    //   731: getfield d : Lc/f/b/l/d;
    //   734: aload #21
    //   736: if_acmpeq -> 742
    //   739: aconst_null
    //   740: astore #22
    //   742: aload #22
    //   744: ifnull -> 750
    //   747: goto -> 757
    //   750: aload #21
    //   752: astore #22
    //   754: iconst_1
    //   755: istore #9
    //   757: aload #21
    //   759: astore #23
    //   761: aload #22
    //   763: astore #21
    //   765: aload #23
    //   767: astore #22
    //   769: goto -> 114
    //   772: aload #31
    //   774: getfield b : Lc/f/b/l/d;
    //   777: astore #22
    //   779: aload #22
    //   781: ifnull -> 806
    //   784: aload #31
    //   786: aload #31
    //   788: getfield m : I
    //   791: aload #22
    //   793: getfield K : [Lc/f/b/l/c;
    //   796: iload #12
    //   798: aaload
    //   799: invokevirtual d : ()I
    //   802: isub
    //   803: putfield m : I
    //   806: aload #31
    //   808: getfield d : Lc/f/b/l/d;
    //   811: astore #22
    //   813: aload #22
    //   815: ifnull -> 842
    //   818: aload #31
    //   820: aload #31
    //   822: getfield m : I
    //   825: aload #22
    //   827: getfield K : [Lc/f/b/l/c;
    //   830: iload #12
    //   832: iconst_1
    //   833: iadd
    //   834: aaload
    //   835: invokevirtual d : ()I
    //   838: isub
    //   839: putfield m : I
    //   842: aload #31
    //   844: aload #21
    //   846: putfield c : Lc/f/b/l/d;
    //   849: aload #31
    //   851: getfield o : I
    //   854: ifne -> 875
    //   857: aload #31
    //   859: getfield p : Z
    //   862: ifeq -> 875
    //   865: aload #31
    //   867: aload #21
    //   869: putfield e : Lc/f/b/l/d;
    //   872: goto -> 885
    //   875: aload #31
    //   877: aload #31
    //   879: getfield a : Lc/f/b/l/d;
    //   882: putfield e : Lc/f/b/l/d;
    //   885: aload #31
    //   887: getfield r : Z
    //   890: ifeq -> 907
    //   893: aload #31
    //   895: getfield q : Z
    //   898: ifeq -> 907
    //   901: iconst_1
    //   902: istore #19
    //   904: goto -> 910
    //   907: iconst_0
    //   908: istore #19
    //   910: aload #31
    //   912: iload #19
    //   914: putfield s : Z
    //   917: goto -> 920
    //   920: aload #31
    //   922: iconst_1
    //   923: putfield t : Z
    //   926: aload #25
    //   928: ifnull -> 958
    //   931: aload #25
    //   933: aload #31
    //   935: getfield a : Lc/f/b/l/d;
    //   938: invokevirtual contains : (Ljava/lang/Object;)Z
    //   941: ifeq -> 947
    //   944: goto -> 958
    //   947: iload #8
    //   949: istore #9
    //   951: iload #7
    //   953: istore #8
    //   955: goto -> 4020
    //   958: aload #31
    //   960: getfield a : Lc/f/b/l/d;
    //   963: astore #29
    //   965: aload #31
    //   967: getfield c : Lc/f/b/l/d;
    //   970: astore #35
    //   972: aload #31
    //   974: getfield b : Lc/f/b/l/d;
    //   977: astore #28
    //   979: aload #31
    //   981: getfield d : Lc/f/b/l/d;
    //   984: astore #27
    //   986: aload #31
    //   988: getfield e : Lc/f/b/l/d;
    //   991: astore #22
    //   993: aload #31
    //   995: getfield k : F
    //   998: fstore #4
    //   1000: aload #24
    //   1002: getfield N : [Lc/f/b/l/d$a;
    //   1005: iload_3
    //   1006: aaload
    //   1007: getstatic c/f/b/l/d$a.f : Lc/f/b/l/d$a;
    //   1010: if_acmpne -> 1019
    //   1013: iconst_1
    //   1014: istore #14
    //   1016: goto -> 1022
    //   1019: iconst_0
    //   1020: istore #14
    //   1022: iload_3
    //   1023: ifne -> 1074
    //   1026: aload #22
    //   1028: getfield d0 : I
    //   1031: istore #12
    //   1033: iload #12
    //   1035: ifne -> 1044
    //   1038: iconst_1
    //   1039: istore #10
    //   1041: goto -> 1047
    //   1044: iconst_0
    //   1045: istore #10
    //   1047: iload #12
    //   1049: iconst_1
    //   1050: if_icmpne -> 1059
    //   1053: iconst_1
    //   1054: istore #9
    //   1056: goto -> 1062
    //   1059: iconst_0
    //   1060: istore #9
    //   1062: iload #12
    //   1064: iconst_2
    //   1065: if_icmpne -> 1071
    //   1068: goto -> 1128
    //   1071: goto -> 1154
    //   1074: aload #22
    //   1076: getfield e0 : I
    //   1079: istore #12
    //   1081: iload #12
    //   1083: ifne -> 1092
    //   1086: iconst_1
    //   1087: istore #9
    //   1089: goto -> 1095
    //   1092: iconst_0
    //   1093: istore #9
    //   1095: iload #12
    //   1097: iconst_1
    //   1098: if_icmpne -> 1107
    //   1101: iconst_1
    //   1102: istore #10
    //   1104: goto -> 1110
    //   1107: iconst_0
    //   1108: istore #10
    //   1110: iload #12
    //   1112: iconst_2
    //   1113: if_icmpne -> 1142
    //   1116: iload #9
    //   1118: istore #12
    //   1120: iload #10
    //   1122: istore #9
    //   1124: iload #12
    //   1126: istore #10
    //   1128: iconst_1
    //   1129: istore #15
    //   1131: iload #10
    //   1133: istore #13
    //   1135: iload #9
    //   1137: istore #12
    //   1139: goto -> 1165
    //   1142: iload #9
    //   1144: istore #12
    //   1146: iload #10
    //   1148: istore #9
    //   1150: iload #12
    //   1152: istore #10
    //   1154: iconst_0
    //   1155: istore #15
    //   1157: iload #9
    //   1159: istore #12
    //   1161: iload #10
    //   1163: istore #13
    //   1165: aload #29
    //   1167: astore #23
    //   1169: iconst_0
    //   1170: istore #9
    //   1172: iload #9
    //   1174: ifne -> 1573
    //   1177: aload #23
    //   1179: getfield K : [Lc/f/b/l/c;
    //   1182: iload #11
    //   1184: aaload
    //   1185: astore #21
    //   1187: iload #15
    //   1189: ifeq -> 1198
    //   1192: iconst_1
    //   1193: istore #10
    //   1195: goto -> 1201
    //   1198: iconst_4
    //   1199: istore #10
    //   1201: aload #21
    //   1203: invokevirtual d : ()I
    //   1206: istore #18
    //   1208: aload #23
    //   1210: getfield N : [Lc/f/b/l/d$a;
    //   1213: iload_3
    //   1214: aaload
    //   1215: aload #20
    //   1217: if_acmpne -> 1236
    //   1220: aload #23
    //   1222: getfield n : [I
    //   1225: iload_3
    //   1226: iaload
    //   1227: ifne -> 1236
    //   1230: iconst_1
    //   1231: istore #17
    //   1233: goto -> 1239
    //   1236: iconst_0
    //   1237: istore #17
    //   1239: aload #21
    //   1241: getfield f : Lc/f/b/l/c;
    //   1244: astore #25
    //   1246: iload #18
    //   1248: istore #16
    //   1250: aload #25
    //   1252: ifnull -> 1276
    //   1255: iload #18
    //   1257: istore #16
    //   1259: aload #23
    //   1261: aload #29
    //   1263: if_acmpeq -> 1276
    //   1266: aload #25
    //   1268: invokevirtual d : ()I
    //   1271: iload #18
    //   1273: iadd
    //   1274: istore #16
    //   1276: iload #15
    //   1278: ifeq -> 1302
    //   1281: aload #23
    //   1283: aload #29
    //   1285: if_acmpeq -> 1302
    //   1288: aload #23
    //   1290: aload #28
    //   1292: if_acmpeq -> 1302
    //   1295: bipush #8
    //   1297: istore #10
    //   1299: goto -> 1302
    //   1302: aload #21
    //   1304: getfield f : Lc/f/b/l/c;
    //   1307: astore #25
    //   1309: aload #25
    //   1311: ifnull -> 1401
    //   1314: aload #23
    //   1316: aload #28
    //   1318: if_acmpne -> 1342
    //   1321: aload_1
    //   1322: aload #21
    //   1324: getfield i : Lc/f/b/k;
    //   1327: aload #25
    //   1329: getfield i : Lc/f/b/k;
    //   1332: iload #16
    //   1334: bipush #6
    //   1336: invokevirtual f : (Lc/f/b/k;Lc/f/b/k;II)V
    //   1339: goto -> 1360
    //   1342: aload_1
    //   1343: aload #21
    //   1345: getfield i : Lc/f/b/k;
    //   1348: aload #25
    //   1350: getfield i : Lc/f/b/k;
    //   1353: iload #16
    //   1355: bipush #8
    //   1357: invokevirtual f : (Lc/f/b/k;Lc/f/b/k;II)V
    //   1360: iload #17
    //   1362: ifeq -> 1376
    //   1365: iload #15
    //   1367: ifne -> 1376
    //   1370: iconst_5
    //   1371: istore #10
    //   1373: goto -> 1376
    //   1376: aload_1
    //   1377: aload #21
    //   1379: getfield i : Lc/f/b/k;
    //   1382: aload #21
    //   1384: getfield f : Lc/f/b/l/c;
    //   1387: getfield i : Lc/f/b/k;
    //   1390: iload #16
    //   1392: iload #10
    //   1394: invokevirtual d : (Lc/f/b/k;Lc/f/b/k;II)Lc/f/b/c;
    //   1397: pop
    //   1398: goto -> 1401
    //   1401: iload #14
    //   1403: ifeq -> 1491
    //   1406: aload #23
    //   1408: getfield b0 : I
    //   1411: bipush #8
    //   1413: if_icmpeq -> 1462
    //   1416: aload #23
    //   1418: getfield N : [Lc/f/b/l/d$a;
    //   1421: iload_3
    //   1422: aaload
    //   1423: aload #20
    //   1425: if_acmpne -> 1462
    //   1428: aload #23
    //   1430: getfield K : [Lc/f/b/l/c;
    //   1433: astore #21
    //   1435: aload_1
    //   1436: aload #21
    //   1438: iload #11
    //   1440: iconst_1
    //   1441: iadd
    //   1442: aaload
    //   1443: getfield i : Lc/f/b/k;
    //   1446: aload #21
    //   1448: iload #11
    //   1450: aaload
    //   1451: getfield i : Lc/f/b/k;
    //   1454: iconst_0
    //   1455: iconst_5
    //   1456: invokevirtual f : (Lc/f/b/k;Lc/f/b/k;II)V
    //   1459: goto -> 1462
    //   1462: aload_1
    //   1463: aload #23
    //   1465: getfield K : [Lc/f/b/l/c;
    //   1468: iload #11
    //   1470: aaload
    //   1471: getfield i : Lc/f/b/k;
    //   1474: aload #24
    //   1476: getfield K : [Lc/f/b/l/c;
    //   1479: iload #11
    //   1481: aaload
    //   1482: getfield i : Lc/f/b/k;
    //   1485: iconst_0
    //   1486: bipush #8
    //   1488: invokevirtual f : (Lc/f/b/k;Lc/f/b/k;II)V
    //   1491: aload #23
    //   1493: getfield K : [Lc/f/b/l/c;
    //   1496: iload #11
    //   1498: iconst_1
    //   1499: iadd
    //   1500: aaload
    //   1501: getfield f : Lc/f/b/l/c;
    //   1504: astore #21
    //   1506: aload #21
    //   1508: ifnull -> 1552
    //   1511: aload #21
    //   1513: getfield d : Lc/f/b/l/d;
    //   1516: astore #21
    //   1518: aload #21
    //   1520: getfield K : [Lc/f/b/l/c;
    //   1523: astore #25
    //   1525: aload #25
    //   1527: iload #11
    //   1529: aaload
    //   1530: getfield f : Lc/f/b/l/c;
    //   1533: ifnull -> 1552
    //   1536: aload #25
    //   1538: iload #11
    //   1540: aaload
    //   1541: getfield f : Lc/f/b/l/c;
    //   1544: getfield d : Lc/f/b/l/d;
    //   1547: aload #23
    //   1549: if_acmpeq -> 1555
    //   1552: aconst_null
    //   1553: astore #21
    //   1555: aload #21
    //   1557: ifnull -> 1567
    //   1560: aload #21
    //   1562: astore #23
    //   1564: goto -> 1570
    //   1567: iconst_1
    //   1568: istore #9
    //   1570: goto -> 1172
    //   1573: iload #7
    //   1575: istore #10
    //   1577: aload #27
    //   1579: ifnull -> 1777
    //   1582: aload #35
    //   1584: getfield K : [Lc/f/b/l/c;
    //   1587: astore #21
    //   1589: iload #11
    //   1591: iconst_1
    //   1592: iadd
    //   1593: istore #9
    //   1595: aload #21
    //   1597: iload #9
    //   1599: aaload
    //   1600: getfield f : Lc/f/b/l/c;
    //   1603: ifnull -> 1777
    //   1606: aload #27
    //   1608: getfield K : [Lc/f/b/l/c;
    //   1611: iload #9
    //   1613: aaload
    //   1614: astore #21
    //   1616: aload #27
    //   1618: getfield N : [Lc/f/b/l/d$a;
    //   1621: iload_3
    //   1622: aaload
    //   1623: aload #20
    //   1625: if_acmpne -> 1644
    //   1628: aload #27
    //   1630: getfield n : [I
    //   1633: iload_3
    //   1634: iaload
    //   1635: ifne -> 1644
    //   1638: iconst_1
    //   1639: istore #7
    //   1641: goto -> 1647
    //   1644: iconst_0
    //   1645: istore #7
    //   1647: iload #7
    //   1649: ifeq -> 1699
    //   1652: iload #15
    //   1654: ifne -> 1699
    //   1657: aload #21
    //   1659: getfield f : Lc/f/b/l/c;
    //   1662: astore #23
    //   1664: aload #23
    //   1666: getfield d : Lc/f/b/l/d;
    //   1669: aload #24
    //   1671: if_acmpne -> 1699
    //   1674: aload_1
    //   1675: aload #21
    //   1677: getfield i : Lc/f/b/k;
    //   1680: aload #23
    //   1682: getfield i : Lc/f/b/k;
    //   1685: aload #21
    //   1687: invokevirtual d : ()I
    //   1690: ineg
    //   1691: iconst_5
    //   1692: invokevirtual d : (Lc/f/b/k;Lc/f/b/k;II)Lc/f/b/c;
    //   1695: pop
    //   1696: goto -> 1743
    //   1699: iload #15
    //   1701: ifeq -> 1743
    //   1704: aload #21
    //   1706: getfield f : Lc/f/b/l/c;
    //   1709: astore #23
    //   1711: aload #23
    //   1713: getfield d : Lc/f/b/l/d;
    //   1716: aload #24
    //   1718: if_acmpne -> 1743
    //   1721: aload_1
    //   1722: aload #21
    //   1724: getfield i : Lc/f/b/k;
    //   1727: aload #23
    //   1729: getfield i : Lc/f/b/k;
    //   1732: aload #21
    //   1734: invokevirtual d : ()I
    //   1737: ineg
    //   1738: iconst_4
    //   1739: invokevirtual d : (Lc/f/b/k;Lc/f/b/k;II)Lc/f/b/c;
    //   1742: pop
    //   1743: aload_1
    //   1744: aload #21
    //   1746: getfield i : Lc/f/b/k;
    //   1749: aload #35
    //   1751: getfield K : [Lc/f/b/l/c;
    //   1754: iload #9
    //   1756: aaload
    //   1757: getfield f : Lc/f/b/l/c;
    //   1760: getfield i : Lc/f/b/k;
    //   1763: aload #21
    //   1765: invokevirtual d : ()I
    //   1768: ineg
    //   1769: bipush #6
    //   1771: invokevirtual g : (Lc/f/b/k;Lc/f/b/k;II)V
    //   1774: goto -> 1777
    //   1777: iload #14
    //   1779: ifeq -> 1836
    //   1782: aload #24
    //   1784: getfield K : [Lc/f/b/l/c;
    //   1787: astore #21
    //   1789: iload #11
    //   1791: iconst_1
    //   1792: iadd
    //   1793: istore #7
    //   1795: aload #21
    //   1797: iload #7
    //   1799: aaload
    //   1800: getfield i : Lc/f/b/k;
    //   1803: astore #21
    //   1805: aload #35
    //   1807: getfield K : [Lc/f/b/l/c;
    //   1810: astore #23
    //   1812: aload_1
    //   1813: aload #21
    //   1815: aload #23
    //   1817: iload #7
    //   1819: aaload
    //   1820: getfield i : Lc/f/b/k;
    //   1823: aload #23
    //   1825: iload #7
    //   1827: aaload
    //   1828: invokevirtual d : ()I
    //   1831: bipush #8
    //   1833: invokevirtual f : (Lc/f/b/k;Lc/f/b/k;II)V
    //   1836: aload #31
    //   1838: getfield h : Ljava/util/ArrayList;
    //   1841: astore #23
    //   1843: aload #20
    //   1845: astore #21
    //   1847: aload #23
    //   1849: ifnull -> 2363
    //   1852: aload #23
    //   1854: invokevirtual size : ()I
    //   1857: istore #7
    //   1859: aload #20
    //   1861: astore #21
    //   1863: iload #7
    //   1865: iconst_1
    //   1866: if_icmple -> 2363
    //   1869: aload #31
    //   1871: getfield q : Z
    //   1874: ifeq -> 1896
    //   1877: aload #31
    //   1879: getfield s : Z
    //   1882: ifne -> 1896
    //   1885: aload #31
    //   1887: getfield j : I
    //   1890: i2f
    //   1891: fstore #4
    //   1893: goto -> 1896
    //   1896: aconst_null
    //   1897: astore #24
    //   1899: fconst_0
    //   1900: fstore #6
    //   1902: iconst_0
    //   1903: istore #9
    //   1905: fload #4
    //   1907: fstore #5
    //   1909: aload #20
    //   1911: astore #21
    //   1913: iload #9
    //   1915: iload #7
    //   1917: if_icmpge -> 2363
    //   1920: aload #23
    //   1922: iload #9
    //   1924: invokevirtual get : (I)Ljava/lang/Object;
    //   1927: checkcast c/f/b/l/d
    //   1930: astore #21
    //   1932: aload #21
    //   1934: getfield f0 : [F
    //   1937: iload_3
    //   1938: faload
    //   1939: fstore #4
    //   1941: fload #4
    //   1943: fconst_0
    //   1944: fcmpg
    //   1945: ifge -> 1997
    //   1948: aload #31
    //   1950: getfield s : Z
    //   1953: ifeq -> 1991
    //   1956: aload #21
    //   1958: getfield K : [Lc/f/b/l/c;
    //   1961: astore #21
    //   1963: aload_1
    //   1964: aload #21
    //   1966: iload #11
    //   1968: iconst_1
    //   1969: iadd
    //   1970: aaload
    //   1971: getfield i : Lc/f/b/k;
    //   1974: aload #21
    //   1976: iload #11
    //   1978: aaload
    //   1979: getfield i : Lc/f/b/k;
    //   1982: iconst_0
    //   1983: iconst_4
    //   1984: invokevirtual d : (Lc/f/b/k;Lc/f/b/k;II)Lc/f/b/c;
    //   1987: pop
    //   1988: goto -> 2041
    //   1991: fconst_1
    //   1992: fstore #4
    //   1994: goto -> 1997
    //   1997: fload #4
    //   1999: fconst_0
    //   2000: fcmpl
    //   2001: istore #14
    //   2003: iload #14
    //   2005: ifne -> 2044
    //   2008: aload #21
    //   2010: getfield K : [Lc/f/b/l/c;
    //   2013: astore #21
    //   2015: aload_1
    //   2016: aload #21
    //   2018: iload #11
    //   2020: iconst_1
    //   2021: iadd
    //   2022: aaload
    //   2023: getfield i : Lc/f/b/k;
    //   2026: aload #21
    //   2028: iload #11
    //   2030: aaload
    //   2031: getfield i : Lc/f/b/k;
    //   2034: iconst_0
    //   2035: bipush #8
    //   2037: invokevirtual d : (Lc/f/b/k;Lc/f/b/k;II)Lc/f/b/c;
    //   2040: pop
    //   2041: goto -> 2354
    //   2044: aload #24
    //   2046: ifnull -> 2346
    //   2049: aload #24
    //   2051: getfield K : [Lc/f/b/l/c;
    //   2054: astore #25
    //   2056: aload #25
    //   2058: iload #11
    //   2060: aaload
    //   2061: getfield i : Lc/f/b/k;
    //   2064: astore #24
    //   2066: iload #11
    //   2068: iconst_1
    //   2069: iadd
    //   2070: istore #16
    //   2072: aload #25
    //   2074: iload #16
    //   2076: aaload
    //   2077: getfield i : Lc/f/b/k;
    //   2080: astore #25
    //   2082: aload #21
    //   2084: getfield K : [Lc/f/b/l/c;
    //   2087: astore #32
    //   2089: aload #32
    //   2091: iload #11
    //   2093: aaload
    //   2094: getfield i : Lc/f/b/k;
    //   2097: astore #30
    //   2099: aload #32
    //   2101: iload #16
    //   2103: aaload
    //   2104: getfield i : Lc/f/b/k;
    //   2107: astore #32
    //   2109: aload_1
    //   2110: invokevirtual m : ()Lc/f/b/c;
    //   2113: astore #34
    //   2115: aload #34
    //   2117: fconst_0
    //   2118: putfield b : F
    //   2121: fload #5
    //   2123: fconst_0
    //   2124: fcmpl
    //   2125: ifeq -> 2283
    //   2128: fload #6
    //   2130: fload #4
    //   2132: fcmpl
    //   2133: ifne -> 2139
    //   2136: goto -> 2283
    //   2139: fload #6
    //   2141: fconst_0
    //   2142: fcmpl
    //   2143: ifne -> 2176
    //   2146: aload #34
    //   2148: getfield d : Lc/f/b/b;
    //   2151: aload #24
    //   2153: fconst_1
    //   2154: invokeinterface g : (Lc/f/b/k;F)V
    //   2159: aload #34
    //   2161: getfield d : Lc/f/b/b;
    //   2164: aload #25
    //   2166: ldc -1.0
    //   2168: invokeinterface g : (Lc/f/b/k;F)V
    //   2173: goto -> 2208
    //   2176: iload #14
    //   2178: ifne -> 2211
    //   2181: aload #34
    //   2183: getfield d : Lc/f/b/b;
    //   2186: aload #30
    //   2188: fconst_1
    //   2189: invokeinterface g : (Lc/f/b/k;F)V
    //   2194: aload #34
    //   2196: getfield d : Lc/f/b/b;
    //   2199: aload #32
    //   2201: ldc -1.0
    //   2203: invokeinterface g : (Lc/f/b/k;F)V
    //   2208: goto -> 2337
    //   2211: fload #6
    //   2213: fload #5
    //   2215: fdiv
    //   2216: fload #4
    //   2218: fload #5
    //   2220: fdiv
    //   2221: fdiv
    //   2222: fstore #6
    //   2224: aload #34
    //   2226: getfield d : Lc/f/b/b;
    //   2229: aload #24
    //   2231: fconst_1
    //   2232: invokeinterface g : (Lc/f/b/k;F)V
    //   2237: aload #34
    //   2239: getfield d : Lc/f/b/b;
    //   2242: aload #25
    //   2244: ldc -1.0
    //   2246: invokeinterface g : (Lc/f/b/k;F)V
    //   2251: aload #34
    //   2253: getfield d : Lc/f/b/b;
    //   2256: aload #32
    //   2258: fload #6
    //   2260: invokeinterface g : (Lc/f/b/k;F)V
    //   2265: aload #34
    //   2267: getfield d : Lc/f/b/b;
    //   2270: aload #30
    //   2272: fload #6
    //   2274: fneg
    //   2275: invokeinterface g : (Lc/f/b/k;F)V
    //   2280: goto -> 2337
    //   2283: aload #34
    //   2285: getfield d : Lc/f/b/b;
    //   2288: aload #24
    //   2290: fconst_1
    //   2291: invokeinterface g : (Lc/f/b/k;F)V
    //   2296: aload #34
    //   2298: getfield d : Lc/f/b/b;
    //   2301: aload #25
    //   2303: ldc -1.0
    //   2305: invokeinterface g : (Lc/f/b/k;F)V
    //   2310: aload #34
    //   2312: getfield d : Lc/f/b/b;
    //   2315: aload #32
    //   2317: fconst_1
    //   2318: invokeinterface g : (Lc/f/b/k;F)V
    //   2323: aload #34
    //   2325: getfield d : Lc/f/b/b;
    //   2328: aload #30
    //   2330: ldc -1.0
    //   2332: invokeinterface g : (Lc/f/b/k;F)V
    //   2337: aload_1
    //   2338: aload #34
    //   2340: invokevirtual c : (Lc/f/b/c;)V
    //   2343: goto -> 2346
    //   2346: aload #21
    //   2348: astore #24
    //   2350: fload #4
    //   2352: fstore #6
    //   2354: iload #9
    //   2356: iconst_1
    //   2357: iadd
    //   2358: istore #9
    //   2360: goto -> 1909
    //   2363: aload #21
    //   2365: astore #30
    //   2367: iconst_4
    //   2368: istore #14
    //   2370: aload #28
    //   2372: ifnull -> 2580
    //   2375: aload #28
    //   2377: aload #27
    //   2379: if_acmpeq -> 2387
    //   2382: iload #15
    //   2384: ifeq -> 2580
    //   2387: aload #29
    //   2389: getfield K : [Lc/f/b/l/c;
    //   2392: iload #11
    //   2394: aaload
    //   2395: astore #20
    //   2397: aload #35
    //   2399: getfield K : [Lc/f/b/l/c;
    //   2402: astore #21
    //   2404: iload #11
    //   2406: iconst_1
    //   2407: iadd
    //   2408: istore #7
    //   2410: aload #21
    //   2412: iload #7
    //   2414: aaload
    //   2415: astore #21
    //   2417: aload #20
    //   2419: getfield f : Lc/f/b/l/c;
    //   2422: astore #20
    //   2424: aload #20
    //   2426: ifnull -> 2439
    //   2429: aload #20
    //   2431: getfield i : Lc/f/b/k;
    //   2434: astore #20
    //   2436: goto -> 2442
    //   2439: aconst_null
    //   2440: astore #20
    //   2442: aload #21
    //   2444: getfield f : Lc/f/b/l/c;
    //   2447: astore #21
    //   2449: aload #21
    //   2451: ifnull -> 2464
    //   2454: aload #21
    //   2456: getfield i : Lc/f/b/k;
    //   2459: astore #21
    //   2461: goto -> 2467
    //   2464: aconst_null
    //   2465: astore #21
    //   2467: aload #28
    //   2469: getfield K : [Lc/f/b/l/c;
    //   2472: iload #11
    //   2474: aaload
    //   2475: astore #24
    //   2477: aload #27
    //   2479: getfield K : [Lc/f/b/l/c;
    //   2482: iload #7
    //   2484: aaload
    //   2485: astore #23
    //   2487: aload #20
    //   2489: ifnull -> 2573
    //   2492: aload #21
    //   2494: ifnull -> 2573
    //   2497: iload_3
    //   2498: ifne -> 2511
    //   2501: aload #22
    //   2503: getfield Y : F
    //   2506: fstore #4
    //   2508: goto -> 2518
    //   2511: aload #22
    //   2513: getfield Z : F
    //   2516: fstore #4
    //   2518: aload #24
    //   2520: invokevirtual d : ()I
    //   2523: istore #9
    //   2525: aload #23
    //   2527: invokevirtual d : ()I
    //   2530: istore #14
    //   2532: aload #24
    //   2534: getfield i : Lc/f/b/k;
    //   2537: astore #22
    //   2539: aload #23
    //   2541: getfield i : Lc/f/b/k;
    //   2544: astore #23
    //   2546: iload #8
    //   2548: istore #7
    //   2550: aload_1
    //   2551: aload #22
    //   2553: aload #20
    //   2555: iload #9
    //   2557: fload #4
    //   2559: aload #21
    //   2561: aload #23
    //   2563: iload #14
    //   2565: bipush #7
    //   2567: invokevirtual b : (Lc/f/b/k;Lc/f/b/k;IFLc/f/b/k;Lc/f/b/k;II)V
    //   2570: goto -> 2577
    //   2573: iload #8
    //   2575: istore #7
    //   2577: goto -> 3719
    //   2580: aload #27
    //   2582: astore #34
    //   2584: aload #28
    //   2586: astore #21
    //   2588: iload #13
    //   2590: ifeq -> 3126
    //   2593: aload #21
    //   2595: ifnull -> 3126
    //   2598: aload #31
    //   2600: getfield j : I
    //   2603: istore #7
    //   2605: iload #7
    //   2607: ifle -> 2626
    //   2610: aload #31
    //   2612: getfield i : I
    //   2615: iload #7
    //   2617: if_icmpne -> 2626
    //   2620: iconst_1
    //   2621: istore #14
    //   2623: goto -> 2629
    //   2626: iconst_0
    //   2627: istore #14
    //   2629: aload #21
    //   2631: astore #22
    //   2633: aload #22
    //   2635: astore #23
    //   2637: iload #8
    //   2639: istore #7
    //   2641: aload #23
    //   2643: ifnull -> 2577
    //   2646: aload #23
    //   2648: getfield h0 : [Lc/f/b/l/d;
    //   2651: iload_3
    //   2652: aaload
    //   2653: astore #24
    //   2655: aload #24
    //   2657: ifnull -> 2682
    //   2660: aload #24
    //   2662: getfield b0 : I
    //   2665: bipush #8
    //   2667: if_icmpne -> 2682
    //   2670: aload #24
    //   2672: getfield h0 : [Lc/f/b/l/d;
    //   2675: iload_3
    //   2676: aaload
    //   2677: astore #24
    //   2679: goto -> 2655
    //   2682: aload #24
    //   2684: ifnonnull -> 2704
    //   2687: aload #23
    //   2689: aload #34
    //   2691: if_acmpne -> 2697
    //   2694: goto -> 2704
    //   2697: bipush #8
    //   2699: istore #7
    //   2701: goto -> 3102
    //   2704: aload #23
    //   2706: getfield K : [Lc/f/b/l/c;
    //   2709: iload #11
    //   2711: aaload
    //   2712: astore #31
    //   2714: aload #31
    //   2716: getfield i : Lc/f/b/k;
    //   2719: astore #36
    //   2721: aload #31
    //   2723: getfield f : Lc/f/b/l/c;
    //   2726: astore #20
    //   2728: aload #20
    //   2730: ifnull -> 2743
    //   2733: aload #20
    //   2735: getfield i : Lc/f/b/k;
    //   2738: astore #25
    //   2740: goto -> 2746
    //   2743: aconst_null
    //   2744: astore #25
    //   2746: aload #22
    //   2748: aload #23
    //   2750: if_acmpeq -> 2771
    //   2753: aload #22
    //   2755: getfield K : [Lc/f/b/l/c;
    //   2758: iload #11
    //   2760: iconst_1
    //   2761: iadd
    //   2762: aaload
    //   2763: getfield i : Lc/f/b/k;
    //   2766: astore #20
    //   2768: goto -> 2830
    //   2771: aload #25
    //   2773: astore #20
    //   2775: aload #23
    //   2777: aload #21
    //   2779: if_acmpne -> 2830
    //   2782: aload #25
    //   2784: astore #20
    //   2786: aload #22
    //   2788: aload #23
    //   2790: if_acmpne -> 2830
    //   2793: aload #29
    //   2795: getfield K : [Lc/f/b/l/c;
    //   2798: astore #20
    //   2800: aload #20
    //   2802: iload #11
    //   2804: aaload
    //   2805: getfield f : Lc/f/b/l/c;
    //   2808: ifnull -> 2827
    //   2811: aload #20
    //   2813: iload #11
    //   2815: aaload
    //   2816: getfield f : Lc/f/b/l/c;
    //   2819: getfield i : Lc/f/b/k;
    //   2822: astore #20
    //   2824: goto -> 2830
    //   2827: aconst_null
    //   2828: astore #20
    //   2830: aload #31
    //   2832: invokevirtual d : ()I
    //   2835: istore #15
    //   2837: aload #23
    //   2839: getfield K : [Lc/f/b/l/c;
    //   2842: astore #25
    //   2844: iload #11
    //   2846: iconst_1
    //   2847: iadd
    //   2848: istore #16
    //   2850: aload #25
    //   2852: iload #16
    //   2854: aaload
    //   2855: invokevirtual d : ()I
    //   2858: istore #9
    //   2860: aload #24
    //   2862: ifnull -> 2898
    //   2865: aload #24
    //   2867: getfield K : [Lc/f/b/l/c;
    //   2870: iload #11
    //   2872: aaload
    //   2873: astore #32
    //   2875: aload #32
    //   2877: getfield i : Lc/f/b/k;
    //   2880: astore #25
    //   2882: aload #23
    //   2884: getfield K : [Lc/f/b/l/c;
    //   2887: iload #16
    //   2889: aaload
    //   2890: getfield i : Lc/f/b/k;
    //   2893: astore #31
    //   2895: goto -> 2945
    //   2898: aload #35
    //   2900: getfield K : [Lc/f/b/l/c;
    //   2903: iload #16
    //   2905: aaload
    //   2906: getfield f : Lc/f/b/l/c;
    //   2909: astore #32
    //   2911: aload #32
    //   2913: ifnull -> 2926
    //   2916: aload #32
    //   2918: getfield i : Lc/f/b/k;
    //   2921: astore #25
    //   2923: goto -> 2929
    //   2926: aconst_null
    //   2927: astore #25
    //   2929: aload #23
    //   2931: getfield K : [Lc/f/b/l/c;
    //   2934: iload #16
    //   2936: aaload
    //   2937: getfield i : Lc/f/b/k;
    //   2940: astore #31
    //   2942: goto -> 2895
    //   2945: iload #9
    //   2947: istore #7
    //   2949: aload #32
    //   2951: ifnull -> 2964
    //   2954: iload #9
    //   2956: aload #32
    //   2958: invokevirtual d : ()I
    //   2961: iadd
    //   2962: istore #7
    //   2964: iload #15
    //   2966: istore #9
    //   2968: aload #22
    //   2970: ifnull -> 2989
    //   2973: iload #15
    //   2975: aload #22
    //   2977: getfield K : [Lc/f/b/l/c;
    //   2980: iload #16
    //   2982: aaload
    //   2983: invokevirtual d : ()I
    //   2986: iadd
    //   2987: istore #9
    //   2989: aload #36
    //   2991: ifnull -> 3098
    //   2994: aload #20
    //   2996: ifnull -> 3098
    //   2999: aload #25
    //   3001: ifnull -> 3098
    //   3004: aload #31
    //   3006: ifnull -> 3098
    //   3009: aload #23
    //   3011: aload #21
    //   3013: if_acmpne -> 3029
    //   3016: aload #21
    //   3018: getfield K : [Lc/f/b/l/c;
    //   3021: iload #11
    //   3023: aaload
    //   3024: invokevirtual d : ()I
    //   3027: istore #9
    //   3029: aload #23
    //   3031: aload #34
    //   3033: if_acmpne -> 3052
    //   3036: aload #34
    //   3038: getfield K : [Lc/f/b/l/c;
    //   3041: iload #16
    //   3043: aaload
    //   3044: invokevirtual d : ()I
    //   3047: istore #7
    //   3049: goto -> 3052
    //   3052: iload #14
    //   3054: ifeq -> 3064
    //   3057: bipush #8
    //   3059: istore #15
    //   3061: goto -> 3067
    //   3064: iconst_5
    //   3065: istore #15
    //   3067: bipush #8
    //   3069: istore #16
    //   3071: aload_1
    //   3072: aload #36
    //   3074: aload #20
    //   3076: iload #9
    //   3078: ldc 0.5
    //   3080: aload #25
    //   3082: aload #31
    //   3084: iload #7
    //   3086: iload #15
    //   3088: invokevirtual b : (Lc/f/b/k;Lc/f/b/k;IFLc/f/b/k;Lc/f/b/k;II)V
    //   3091: iload #16
    //   3093: istore #7
    //   3095: goto -> 3102
    //   3098: bipush #8
    //   3100: istore #7
    //   3102: aload #23
    //   3104: getfield b0 : I
    //   3107: iload #7
    //   3109: if_icmpeq -> 3119
    //   3112: aload #23
    //   3114: astore #22
    //   3116: goto -> 3119
    //   3119: aload #24
    //   3121: astore #23
    //   3123: goto -> 2637
    //   3126: iload #8
    //   3128: istore #7
    //   3130: iload #12
    //   3132: ifeq -> 3719
    //   3135: iload #8
    //   3137: istore #7
    //   3139: aload #21
    //   3141: ifnull -> 3719
    //   3144: aload #31
    //   3146: getfield j : I
    //   3149: istore #7
    //   3151: iload #7
    //   3153: ifle -> 3172
    //   3156: aload #31
    //   3158: getfield i : I
    //   3161: iload #7
    //   3163: if_icmpne -> 3172
    //   3166: iconst_1
    //   3167: istore #9
    //   3169: goto -> 3175
    //   3172: iconst_0
    //   3173: istore #9
    //   3175: aload #21
    //   3177: astore #22
    //   3179: aload #22
    //   3181: astore #23
    //   3183: iload #14
    //   3185: istore #7
    //   3187: aload #23
    //   3189: ifnull -> 3539
    //   3192: aload #23
    //   3194: getfield h0 : [Lc/f/b/l/d;
    //   3197: iload_3
    //   3198: aaload
    //   3199: astore #20
    //   3201: aload #20
    //   3203: ifnull -> 3228
    //   3206: aload #20
    //   3208: getfield b0 : I
    //   3211: bipush #8
    //   3213: if_icmpne -> 3228
    //   3216: aload #20
    //   3218: getfield h0 : [Lc/f/b/l/d;
    //   3221: iload_3
    //   3222: aaload
    //   3223: astore #20
    //   3225: goto -> 3201
    //   3228: aload #23
    //   3230: aload #21
    //   3232: if_acmpeq -> 3515
    //   3235: aload #23
    //   3237: aload #34
    //   3239: if_acmpeq -> 3515
    //   3242: aload #20
    //   3244: ifnull -> 3515
    //   3247: aload #20
    //   3249: aload #34
    //   3251: if_acmpne -> 3260
    //   3254: aconst_null
    //   3255: astore #20
    //   3257: goto -> 3260
    //   3260: aload #23
    //   3262: getfield K : [Lc/f/b/l/c;
    //   3265: iload #11
    //   3267: aaload
    //   3268: astore #24
    //   3270: aload #24
    //   3272: getfield i : Lc/f/b/k;
    //   3275: astore #36
    //   3277: aload #22
    //   3279: getfield K : [Lc/f/b/l/c;
    //   3282: astore #25
    //   3284: iload #11
    //   3286: iconst_1
    //   3287: iadd
    //   3288: istore #15
    //   3290: aload #25
    //   3292: iload #15
    //   3294: aaload
    //   3295: getfield i : Lc/f/b/k;
    //   3298: astore #37
    //   3300: aload #24
    //   3302: invokevirtual d : ()I
    //   3305: istore #16
    //   3307: aload #23
    //   3309: getfield K : [Lc/f/b/l/c;
    //   3312: iload #15
    //   3314: aaload
    //   3315: invokevirtual d : ()I
    //   3318: istore #14
    //   3320: aload #20
    //   3322: ifnull -> 3370
    //   3325: aload #20
    //   3327: getfield K : [Lc/f/b/l/c;
    //   3330: iload #11
    //   3332: aaload
    //   3333: astore #25
    //   3335: aload #25
    //   3337: getfield i : Lc/f/b/k;
    //   3340: astore #31
    //   3342: aload #25
    //   3344: getfield f : Lc/f/b/l/c;
    //   3347: astore #24
    //   3349: aload #24
    //   3351: ifnull -> 3364
    //   3354: aload #24
    //   3356: getfield i : Lc/f/b/k;
    //   3359: astore #24
    //   3361: goto -> 3419
    //   3364: aconst_null
    //   3365: astore #24
    //   3367: goto -> 3419
    //   3370: aload #34
    //   3372: getfield K : [Lc/f/b/l/c;
    //   3375: iload #11
    //   3377: aaload
    //   3378: astore #32
    //   3380: aload #32
    //   3382: ifnull -> 3395
    //   3385: aload #32
    //   3387: getfield i : Lc/f/b/k;
    //   3390: astore #25
    //   3392: goto -> 3398
    //   3395: aconst_null
    //   3396: astore #25
    //   3398: aload #23
    //   3400: getfield K : [Lc/f/b/l/c;
    //   3403: iload #15
    //   3405: aaload
    //   3406: getfield i : Lc/f/b/k;
    //   3409: astore #24
    //   3411: aload #25
    //   3413: astore #31
    //   3415: aload #32
    //   3417: astore #25
    //   3419: aload #25
    //   3421: ifnull -> 3437
    //   3424: aload #25
    //   3426: invokevirtual d : ()I
    //   3429: iload #14
    //   3431: iadd
    //   3432: istore #14
    //   3434: goto -> 3437
    //   3437: aload #22
    //   3439: getfield K : [Lc/f/b/l/c;
    //   3442: iload #15
    //   3444: aaload
    //   3445: invokevirtual d : ()I
    //   3448: istore #17
    //   3450: iload #9
    //   3452: ifeq -> 3462
    //   3455: bipush #8
    //   3457: istore #15
    //   3459: goto -> 3466
    //   3462: iload #7
    //   3464: istore #15
    //   3466: aload #36
    //   3468: ifnull -> 3512
    //   3471: aload #37
    //   3473: ifnull -> 3512
    //   3476: aload #31
    //   3478: ifnull -> 3512
    //   3481: aload #24
    //   3483: ifnull -> 3512
    //   3486: aload_1
    //   3487: aload #36
    //   3489: aload #37
    //   3491: iload #17
    //   3493: iload #16
    //   3495: iadd
    //   3496: ldc 0.5
    //   3498: aload #31
    //   3500: aload #24
    //   3502: iload #14
    //   3504: iload #15
    //   3506: invokevirtual b : (Lc/f/b/k;Lc/f/b/k;IFLc/f/b/k;Lc/f/b/k;II)V
    //   3509: goto -> 3512
    //   3512: goto -> 3515
    //   3515: aload #23
    //   3517: getfield b0 : I
    //   3520: bipush #8
    //   3522: if_icmpeq -> 3532
    //   3525: aload #23
    //   3527: astore #22
    //   3529: goto -> 3532
    //   3532: aload #20
    //   3534: astore #23
    //   3536: goto -> 3187
    //   3539: aload #21
    //   3541: getfield K : [Lc/f/b/l/c;
    //   3544: iload #11
    //   3546: aaload
    //   3547: astore #20
    //   3549: aload #29
    //   3551: getfield K : [Lc/f/b/l/c;
    //   3554: iload #11
    //   3556: aaload
    //   3557: getfield f : Lc/f/b/l/c;
    //   3560: astore #22
    //   3562: aload #34
    //   3564: getfield K : [Lc/f/b/l/c;
    //   3567: astore #23
    //   3569: iload #11
    //   3571: iconst_1
    //   3572: iadd
    //   3573: istore #7
    //   3575: aload #23
    //   3577: iload #7
    //   3579: aaload
    //   3580: astore #23
    //   3582: aload #35
    //   3584: getfield K : [Lc/f/b/l/c;
    //   3587: iload #7
    //   3589: aaload
    //   3590: getfield f : Lc/f/b/l/c;
    //   3593: astore #24
    //   3595: aload #22
    //   3597: ifnull -> 3673
    //   3600: aload #21
    //   3602: aload #34
    //   3604: if_acmpeq -> 3631
    //   3607: aload_1
    //   3608: aload #20
    //   3610: getfield i : Lc/f/b/k;
    //   3613: aload #22
    //   3615: getfield i : Lc/f/b/k;
    //   3618: aload #20
    //   3620: invokevirtual d : ()I
    //   3623: iconst_5
    //   3624: invokevirtual d : (Lc/f/b/k;Lc/f/b/k;II)Lc/f/b/c;
    //   3627: pop
    //   3628: goto -> 3673
    //   3631: aload #24
    //   3633: ifnull -> 3673
    //   3636: aload_1
    //   3637: aload #20
    //   3639: getfield i : Lc/f/b/k;
    //   3642: aload #22
    //   3644: getfield i : Lc/f/b/k;
    //   3647: aload #20
    //   3649: invokevirtual d : ()I
    //   3652: ldc 0.5
    //   3654: aload #23
    //   3656: getfield i : Lc/f/b/k;
    //   3659: aload #24
    //   3661: getfield i : Lc/f/b/k;
    //   3664: aload #23
    //   3666: invokevirtual d : ()I
    //   3669: iconst_5
    //   3670: invokevirtual b : (Lc/f/b/k;Lc/f/b/k;IFLc/f/b/k;Lc/f/b/k;II)V
    //   3673: iload #8
    //   3675: istore #7
    //   3677: aload #24
    //   3679: ifnull -> 3719
    //   3682: iload #8
    //   3684: istore #7
    //   3686: aload #21
    //   3688: aload #34
    //   3690: if_acmpeq -> 3719
    //   3693: aload_1
    //   3694: aload #23
    //   3696: getfield i : Lc/f/b/k;
    //   3699: aload #24
    //   3701: getfield i : Lc/f/b/k;
    //   3704: aload #23
    //   3706: invokevirtual d : ()I
    //   3709: ineg
    //   3710: iconst_5
    //   3711: invokevirtual d : (Lc/f/b/k;Lc/f/b/k;II)Lc/f/b/c;
    //   3714: pop
    //   3715: iload #8
    //   3717: istore #7
    //   3719: iload #13
    //   3721: ifne -> 3741
    //   3724: iload #7
    //   3726: istore #9
    //   3728: iload #10
    //   3730: istore #8
    //   3732: aload #30
    //   3734: astore #20
    //   3736: iload #12
    //   3738: ifeq -> 4020
    //   3741: iload #7
    //   3743: istore #9
    //   3745: iload #10
    //   3747: istore #8
    //   3749: aload #30
    //   3751: astore #20
    //   3753: aload #28
    //   3755: ifnull -> 4020
    //   3758: iload #7
    //   3760: istore #9
    //   3762: iload #10
    //   3764: istore #8
    //   3766: aload #30
    //   3768: astore #20
    //   3770: aload #28
    //   3772: aload #27
    //   3774: if_acmpeq -> 4020
    //   3777: aload #28
    //   3779: getfield K : [Lc/f/b/l/c;
    //   3782: astore #25
    //   3784: aload #25
    //   3786: iload #11
    //   3788: aaload
    //   3789: astore #23
    //   3791: aload #27
    //   3793: getfield K : [Lc/f/b/l/c;
    //   3796: astore #20
    //   3798: iload #11
    //   3800: iconst_1
    //   3801: iadd
    //   3802: istore #12
    //   3804: aload #20
    //   3806: iload #12
    //   3808: aaload
    //   3809: astore #24
    //   3811: aload #23
    //   3813: getfield f : Lc/f/b/l/c;
    //   3816: astore #20
    //   3818: aload #20
    //   3820: ifnull -> 3833
    //   3823: aload #20
    //   3825: getfield i : Lc/f/b/k;
    //   3828: astore #21
    //   3830: goto -> 3836
    //   3833: aconst_null
    //   3834: astore #21
    //   3836: aload #24
    //   3838: getfield f : Lc/f/b/l/c;
    //   3841: astore #20
    //   3843: aload #20
    //   3845: ifnull -> 3858
    //   3848: aload #20
    //   3850: getfield i : Lc/f/b/k;
    //   3853: astore #20
    //   3855: goto -> 3861
    //   3858: aconst_null
    //   3859: astore #20
    //   3861: aload #35
    //   3863: aload #27
    //   3865: if_acmpeq -> 3904
    //   3868: aload #35
    //   3870: getfield K : [Lc/f/b/l/c;
    //   3873: iload #12
    //   3875: aaload
    //   3876: getfield f : Lc/f/b/l/c;
    //   3879: astore #22
    //   3881: aload #33
    //   3883: astore #20
    //   3885: aload #22
    //   3887: ifnull -> 3897
    //   3890: aload #22
    //   3892: getfield i : Lc/f/b/k;
    //   3895: astore #20
    //   3897: aload #20
    //   3899: astore #22
    //   3901: goto -> 3908
    //   3904: aload #20
    //   3906: astore #22
    //   3908: aload #28
    //   3910: aload #27
    //   3912: if_acmpne -> 3929
    //   3915: aload #25
    //   3917: iload #11
    //   3919: aaload
    //   3920: astore #23
    //   3922: aload #25
    //   3924: iload #12
    //   3926: aaload
    //   3927: astore #24
    //   3929: iload #7
    //   3931: istore #9
    //   3933: iload #10
    //   3935: istore #8
    //   3937: aload #30
    //   3939: astore #20
    //   3941: aload #21
    //   3943: ifnull -> 4020
    //   3946: iload #7
    //   3948: istore #9
    //   3950: iload #10
    //   3952: istore #8
    //   3954: aload #30
    //   3956: astore #20
    //   3958: aload #22
    //   3960: ifnull -> 4020
    //   3963: aload #23
    //   3965: invokevirtual d : ()I
    //   3968: istore #8
    //   3970: aload #27
    //   3972: getfield K : [Lc/f/b/l/c;
    //   3975: iload #12
    //   3977: aaload
    //   3978: invokevirtual d : ()I
    //   3981: istore #9
    //   3983: aload_1
    //   3984: aload #23
    //   3986: getfield i : Lc/f/b/k;
    //   3989: aload #21
    //   3991: iload #8
    //   3993: ldc 0.5
    //   3995: aload #22
    //   3997: aload #24
    //   3999: getfield i : Lc/f/b/k;
    //   4002: iload #9
    //   4004: iconst_5
    //   4005: invokevirtual b : (Lc/f/b/k;Lc/f/b/k;IFLc/f/b/k;Lc/f/b/k;II)V
    //   4008: aload #30
    //   4010: astore #20
    //   4012: iload #10
    //   4014: istore #8
    //   4016: iload #7
    //   4018: istore #9
    //   4020: iload #9
    //   4022: iconst_1
    //   4023: iadd
    //   4024: istore #10
    //   4026: iconst_2
    //   4027: istore #9
    //   4029: iload #8
    //   4031: istore #7
    //   4033: iload #10
    //   4035: istore #8
    //   4037: goto -> 55
    //   4040: return
  }
  
  public static q b(d paramd, int paramInt, ArrayList<q> paramArrayList, q paramq) {
    q q1;
    int i;
    q q2;
    if (paramInt == 0) {
      i = paramd.i0;
    } else {
      i = paramd.j0;
    } 
    boolean bool = false;
    if (i != -1 && (paramq == null || i != paramq.b)) {
      int j = 0;
      while (true) {
        q2 = paramq;
        if (j < paramArrayList.size()) {
          q2 = paramArrayList.get(j);
          if (q2.b == i) {
            if (paramq != null) {
              paramq.d(paramInt, q2);
              paramArrayList.remove(paramq);
            } 
            break;
          } 
          j++;
          continue;
        } 
        break;
      } 
    } else {
      q2 = paramq;
      if (i != -1)
        return paramq; 
    } 
    paramq = q2;
    if (q2 == null) {
      paramq = q2;
      if (paramd instanceof h) {
        h h = (h)paramd;
        i = 0;
        while (true) {
          if (i < h.l0) {
            d d1 = h.k0[i];
            if (paramInt == 0) {
              int j = d1.i0;
              if (j != -1) {
                i = j;
                break;
              } 
            } 
            if (paramInt == 1) {
              int j = d1.j0;
              if (j != -1) {
                i = j;
                break;
              } 
            } 
            i++;
            continue;
          } 
          i = -1;
          break;
        } 
        q1 = q2;
        if (i != -1) {
          int j = 0;
          while (true) {
            q1 = q2;
            if (j < paramArrayList.size()) {
              q1 = paramArrayList.get(j);
              if (q1.b == i)
                break; 
              j++;
              continue;
            } 
            break;
          } 
        } 
      } 
      q2 = q1;
      if (q1 == null)
        q2 = new q(paramInt); 
      paramArrayList.add(q2);
      q1 = q2;
    } 
    if (q1.a(paramd)) {
      if (paramd instanceof f) {
        f f = (f)paramd;
        c c = f.n0;
        i = bool;
        if (f.o0 == 0)
          i = 1; 
        c.b(i, paramArrayList, q1);
      } 
      if (paramInt == 0) {
        paramd.i0 = q1.b;
        paramd.C.b(paramInt, paramArrayList, q1);
        paramd.E.b(paramInt, paramArrayList, q1);
      } else {
        paramd.j0 = q1.b;
        paramd.D.b(paramInt, paramArrayList, q1);
        paramd.G.b(paramInt, paramArrayList, q1);
        paramd.F.b(paramInt, paramArrayList, q1);
      } 
      paramd.J.b(paramInt, paramArrayList, q1);
    } 
    return q1;
  }
  
  public static q c(ArrayList<q> paramArrayList, int paramInt) {
    int j = paramArrayList.size();
    for (int i = 0; i < j; i++) {
      q q = paramArrayList.get(i);
      if (paramInt == q.b)
        return q; 
    } 
    return null;
  }
  
  public static void d(Object paramObject) {
    Class<?> clazz1;
    if (!d) {
      try {
        c = Class.forName("android.content.res.ThemedResourceCache");
      } catch (ClassNotFoundException classNotFoundException) {
        Log.e("ResourcesFlusher", "Could not find ThemedResourceCache class", classNotFoundException);
      } 
      d = true;
    } 
    Class<?> clazz2 = c;
    if (clazz2 == null)
      return; 
    if (!f) {
      try {
        Field field1 = clazz2.getDeclaredField("mUnthemedEntries");
        e = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("ResourcesFlusher", "Could not retrieve ThemedResourceCache#mUnthemedEntries field", noSuchFieldException);
      } 
      f = true;
    } 
    Field field = e;
    if (field == null)
      return; 
    clazz2 = null;
    try {
      paramObject = field.get(paramObject);
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("ResourcesFlusher", "Could not retrieve value from ThemedResourceCache#mUnthemedEntries", illegalAccessException);
      clazz1 = clazz2;
    } 
    if (clazz1 != null)
      clazz1.clear(); 
  }
  
  public static InputConnection e(InputConnection paramInputConnection, EditorInfo paramEditorInfo, View paramView) {
    if (paramInputConnection != null && paramEditorInfo.hintText == null)
      for (ViewParent viewParent = paramView.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()); 
    return paramInputConnection;
  }
  
  public static void f(View paramView, CharSequence paramCharSequence) {
    q2 q21;
    if (Build.VERSION.SDK_INT >= 26) {
      paramView.setTooltipText(paramCharSequence);
      return;
    } 
    q2 q22 = q2.n;
    if (q22 != null && q22.e == paramView)
      q2.c(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      q21 = q2.o;
      if (q21 != null && q21.e == paramView)
        q21.b(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new q2(paramView, (CharSequence)q21);
  }
  
  public static boolean g(d.a parama1, d.a parama2, d.a parama3, d.a parama4) {
    boolean bool1;
    boolean bool2;
    d.a a1 = d.a.h;
    d.a a2 = d.a.f;
    d.a a3 = d.a.e;
    if (parama3 == a3 || parama3 == a2 || (parama3 == a1 && parama1 != a2)) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (parama4 == a3 || parama4 == a2 || (parama4 == a1 && parama2 != a2)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    return !bool1 ? (bool2) : true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */