package c.b.e.a;

import android.animation.TimeInterpolator;
import android.graphics.drawable.AnimationDrawable;

public class f implements TimeInterpolator {
  public int[] a;
  
  public int b;
  
  public int c;
  
  public f(AnimationDrawable paramAnimationDrawable, boolean paramBoolean) {
    int k = paramAnimationDrawable.getNumberOfFrames();
    this.b = k;
    int[] arrayOfInt = this.a;
    if (arrayOfInt == null || arrayOfInt.length < k)
      this.a = new int[k]; 
    arrayOfInt = this.a;
    int i = 0;
    int j = 0;
    while (i < k) {
      if (paramBoolean) {
        m = k - i - 1;
      } else {
        m = i;
      } 
      int m = paramAnimationDrawable.getDuration(m);
      arrayOfInt[i] = m;
      j += m;
      i++;
    } 
    this.c = j;
  }
  
  public float getInterpolation(float paramFloat) {
    int j = (int)(paramFloat * this.c + 0.5F);
    int k = this.b;
    int[] arrayOfInt = this.a;
    int i;
    for (i = 0; i < k && j >= arrayOfInt[i]; i++)
      j -= arrayOfInt[i]; 
    if (i < k) {
      paramFloat = j / this.c;
    } else {
      paramFloat = 0.0F;
    } 
    return i / k + paramFloat;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */