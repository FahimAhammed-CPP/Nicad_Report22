package c.b.e.a;

import android.graphics.drawable.Drawable;

public class j implements Drawable.Callback {
  public Drawable.Callback e;
  
  public void invalidateDrawable(Drawable paramDrawable) {}
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong) {
    Drawable.Callback callback = this.e;
    if (callback != null)
      callback.scheduleDrawable(paramDrawable, paramRunnable, paramLong); 
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable) {
    Drawable.Callback callback = this.e;
    if (callback != null)
      callback.unscheduleDrawable(paramDrawable, paramRunnable); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */