package c.b.e.a;

import android.content.res.Resources;
import android.util.StateSet;

public abstract class n extends k {
  public int[][] J;
  
  public n(n paramn, o paramo, Resources paramResources) {
    super(paramn, paramo, paramResources);
    if (paramn != null) {
      this.J = paramn.J;
      return;
    } 
    this.J = new int[this.g.length][];
  }
  
  public int g(int[] paramArrayOfint) {
    int[][] arrayOfInt = this.J;
    int j = this.h;
    for (int i = 0; i < j; i++) {
      if (StateSet.stateSetMatches(arrayOfInt[i], paramArrayOfint))
        return i; 
    } 
    return -1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */