package c.b.e.a;

import android.animation.ObjectAnimator;
import android.graphics.drawable.AnimationDrawable;

public class e extends g {
  public final ObjectAnimator a;
  
  public final boolean b;
  
  public e(AnimationDrawable paramAnimationDrawable, boolean paramBoolean1, boolean paramBoolean2) {
    super(null);
    boolean bool;
    int i = paramAnimationDrawable.getNumberOfFrames();
    if (paramBoolean1) {
      bool = i - 1;
    } else {
      bool = false;
    } 
    if (paramBoolean1) {
      i = 0;
    } else {
      i--;
    } 
    f f = new f(paramAnimationDrawable, paramBoolean1);
    ObjectAnimator objectAnimator = ObjectAnimator.ofInt(paramAnimationDrawable, "currentIndex", new int[] { bool, i });
    objectAnimator.setAutoCancel(true);
    objectAnimator.setDuration(f.c);
    objectAnimator.setInterpolator(f);
    this.b = paramBoolean2;
    this.a = objectAnimator;
  }
  
  public boolean a() {
    return this.b;
  }
  
  public void b() {
    this.a.reverse();
  }
  
  public void c() {
    this.a.start();
  }
  
  public void d() {
    this.a.cancel();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */