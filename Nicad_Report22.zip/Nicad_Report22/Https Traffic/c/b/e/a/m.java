package c.b.e.a;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import c.b.b;
import d.a.a.a.a;

public class m extends Drawable {
  public static final float m = (float)Math.toRadians(45.0D);
  
  public final Paint a;
  
  public float b;
  
  public float c;
  
  public float d;
  
  public float e;
  
  public boolean f;
  
  public final Path g;
  
  public final int h;
  
  public boolean i;
  
  public float j;
  
  public float k;
  
  public int l;
  
  public m(Context paramContext) {
    Paint paint = new Paint();
    this.a = paint;
    this.g = new Path();
    this.i = false;
    this.l = 2;
    paint.setStyle(Paint.Style.STROKE);
    paint.setStrokeJoin(Paint.Join.MITER);
    paint.setStrokeCap(Paint.Cap.BUTT);
    paint.setAntiAlias(true);
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(null, b.m, 2130903332, 2131820720);
    int i = typedArray.getColor(3, 0);
    if (i != paint.getColor()) {
      paint.setColor(i);
      invalidateSelf();
    } 
    float f = typedArray.getDimension(7, 0.0F);
    if (paint.getStrokeWidth() != f) {
      paint.setStrokeWidth(f);
      double d = (f / 2.0F);
      this.k = (float)(Math.cos(m) * d);
      invalidateSelf();
    } 
    boolean bool = typedArray.getBoolean(6, true);
    if (this.f != bool) {
      this.f = bool;
      invalidateSelf();
    } 
    f = Math.round(typedArray.getDimension(5, 0.0F));
    if (f != this.e) {
      this.e = f;
      invalidateSelf();
    } 
    this.h = typedArray.getDimensionPixelSize(4, 0);
    this.c = Math.round(typedArray.getDimension(2, 0.0F));
    this.b = Math.round(typedArray.getDimension(0, 0.0F));
    this.d = typedArray.getDimension(1, 0.0F);
    typedArray.recycle();
  }
  
  public static float a(float paramFloat1, float paramFloat2, float paramFloat3) {
    return a.a(paramFloat2, paramFloat1, paramFloat3, paramFloat1);
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getBounds : ()Landroid/graphics/Rect;
    //   4: astore #16
    //   6: aload_0
    //   7: getfield l : I
    //   10: istore #15
    //   12: iconst_0
    //   13: istore #14
    //   15: iload #14
    //   17: istore #13
    //   19: iload #15
    //   21: ifeq -> 65
    //   24: iload #15
    //   26: iconst_1
    //   27: if_icmpeq -> 62
    //   30: iload #15
    //   32: iconst_3
    //   33: if_icmpeq -> 51
    //   36: iload #14
    //   38: istore #13
    //   40: aload_0
    //   41: invokevirtual getLayoutDirection : ()I
    //   44: iconst_1
    //   45: if_icmpne -> 65
    //   48: goto -> 62
    //   51: iload #14
    //   53: istore #13
    //   55: aload_0
    //   56: invokevirtual getLayoutDirection : ()I
    //   59: ifne -> 65
    //   62: iconst_1
    //   63: istore #13
    //   65: aload_0
    //   66: getfield b : F
    //   69: fstore #6
    //   71: fload #6
    //   73: fload #6
    //   75: fmul
    //   76: fconst_2
    //   77: fmul
    //   78: f2d
    //   79: invokestatic sqrt : (D)D
    //   82: d2f
    //   83: fstore #6
    //   85: aload_0
    //   86: getfield c : F
    //   89: fload #6
    //   91: aload_0
    //   92: getfield j : F
    //   95: invokestatic a : (FFF)F
    //   98: fstore #10
    //   100: aload_0
    //   101: getfield c : F
    //   104: aload_0
    //   105: getfield d : F
    //   108: aload_0
    //   109: getfield j : F
    //   112: invokestatic a : (FFF)F
    //   115: fstore #8
    //   117: fconst_0
    //   118: aload_0
    //   119: getfield k : F
    //   122: aload_0
    //   123: getfield j : F
    //   126: invokestatic a : (FFF)F
    //   129: invokestatic round : (F)I
    //   132: i2f
    //   133: fstore #9
    //   135: fconst_0
    //   136: getstatic c/b/e/a/m.m : F
    //   139: aload_0
    //   140: getfield j : F
    //   143: invokestatic a : (FFF)F
    //   146: fstore #11
    //   148: iload #13
    //   150: ifeq -> 159
    //   153: fconst_0
    //   154: fstore #6
    //   156: goto -> 163
    //   159: ldc -180.0
    //   161: fstore #6
    //   163: iload #13
    //   165: ifeq -> 175
    //   168: ldc 180.0
    //   170: fstore #7
    //   172: goto -> 178
    //   175: fconst_0
    //   176: fstore #7
    //   178: fload #6
    //   180: fload #7
    //   182: aload_0
    //   183: getfield j : F
    //   186: invokestatic a : (FFF)F
    //   189: fstore #6
    //   191: fload #10
    //   193: f2d
    //   194: dstore_2
    //   195: fload #11
    //   197: f2d
    //   198: dstore #4
    //   200: dload #4
    //   202: invokestatic cos : (D)D
    //   205: dload_2
    //   206: dmul
    //   207: invokestatic round : (D)J
    //   210: l2f
    //   211: fstore #7
    //   213: dload #4
    //   215: invokestatic sin : (D)D
    //   218: dload_2
    //   219: dmul
    //   220: invokestatic round : (D)J
    //   223: l2f
    //   224: fstore #10
    //   226: aload_0
    //   227: getfield g : Landroid/graphics/Path;
    //   230: invokevirtual rewind : ()V
    //   233: aload_0
    //   234: getfield e : F
    //   237: fstore #11
    //   239: aload_0
    //   240: getfield a : Landroid/graphics/Paint;
    //   243: invokevirtual getStrokeWidth : ()F
    //   246: fload #11
    //   248: fadd
    //   249: aload_0
    //   250: getfield k : F
    //   253: fneg
    //   254: aload_0
    //   255: getfield j : F
    //   258: invokestatic a : (FFF)F
    //   261: fstore #11
    //   263: fload #8
    //   265: fneg
    //   266: fconst_2
    //   267: fdiv
    //   268: fstore #12
    //   270: aload_0
    //   271: getfield g : Landroid/graphics/Path;
    //   274: fload #12
    //   276: fload #9
    //   278: fadd
    //   279: fconst_0
    //   280: invokevirtual moveTo : (FF)V
    //   283: aload_0
    //   284: getfield g : Landroid/graphics/Path;
    //   287: fload #8
    //   289: fload #9
    //   291: fconst_2
    //   292: fmul
    //   293: fsub
    //   294: fconst_0
    //   295: invokevirtual rLineTo : (FF)V
    //   298: aload_0
    //   299: getfield g : Landroid/graphics/Path;
    //   302: fload #12
    //   304: fload #11
    //   306: invokevirtual moveTo : (FF)V
    //   309: aload_0
    //   310: getfield g : Landroid/graphics/Path;
    //   313: fload #7
    //   315: fload #10
    //   317: invokevirtual rLineTo : (FF)V
    //   320: aload_0
    //   321: getfield g : Landroid/graphics/Path;
    //   324: fload #12
    //   326: fload #11
    //   328: fneg
    //   329: invokevirtual moveTo : (FF)V
    //   332: aload_0
    //   333: getfield g : Landroid/graphics/Path;
    //   336: fload #7
    //   338: fload #10
    //   340: fneg
    //   341: invokevirtual rLineTo : (FF)V
    //   344: aload_0
    //   345: getfield g : Landroid/graphics/Path;
    //   348: invokevirtual close : ()V
    //   351: aload_1
    //   352: invokevirtual save : ()I
    //   355: pop
    //   356: aload_0
    //   357: getfield a : Landroid/graphics/Paint;
    //   360: invokevirtual getStrokeWidth : ()F
    //   363: fstore #7
    //   365: aload #16
    //   367: invokevirtual height : ()I
    //   370: i2f
    //   371: fstore #9
    //   373: aload_0
    //   374: getfield e : F
    //   377: fstore #8
    //   379: fload #9
    //   381: ldc 3.0
    //   383: fload #7
    //   385: fmul
    //   386: fsub
    //   387: fconst_2
    //   388: fload #8
    //   390: fmul
    //   391: fsub
    //   392: f2i
    //   393: iconst_4
    //   394: idiv
    //   395: iconst_2
    //   396: imul
    //   397: i2f
    //   398: fstore #9
    //   400: aload_1
    //   401: aload #16
    //   403: invokevirtual centerX : ()I
    //   406: i2f
    //   407: fload #7
    //   409: ldc 1.5
    //   411: fmul
    //   412: fload #8
    //   414: fadd
    //   415: fload #9
    //   417: fadd
    //   418: invokevirtual translate : (FF)V
    //   421: aload_0
    //   422: getfield f : Z
    //   425: ifeq -> 460
    //   428: aload_0
    //   429: getfield i : Z
    //   432: iload #13
    //   434: ixor
    //   435: ifeq -> 444
    //   438: iconst_m1
    //   439: istore #13
    //   441: goto -> 447
    //   444: iconst_1
    //   445: istore #13
    //   447: aload_1
    //   448: fload #6
    //   450: iload #13
    //   452: i2f
    //   453: fmul
    //   454: invokevirtual rotate : (F)V
    //   457: goto -> 471
    //   460: iload #13
    //   462: ifeq -> 471
    //   465: aload_1
    //   466: ldc 180.0
    //   468: invokevirtual rotate : (F)V
    //   471: aload_1
    //   472: aload_0
    //   473: getfield g : Landroid/graphics/Path;
    //   476: aload_0
    //   477: getfield a : Landroid/graphics/Paint;
    //   480: invokevirtual drawPath : (Landroid/graphics/Path;Landroid/graphics/Paint;)V
    //   483: aload_1
    //   484: invokevirtual restore : ()V
    //   487: return
  }
  
  public int getIntrinsicHeight() {
    return this.h;
  }
  
  public int getIntrinsicWidth() {
    return this.h;
  }
  
  public int getOpacity() {
    return -3;
  }
  
  public void setAlpha(int paramInt) {
    if (paramInt != this.a.getAlpha()) {
      this.a.setAlpha(paramInt);
      invalidateSelf();
    } 
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.a.setColorFilter(paramColorFilter);
    invalidateSelf();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */