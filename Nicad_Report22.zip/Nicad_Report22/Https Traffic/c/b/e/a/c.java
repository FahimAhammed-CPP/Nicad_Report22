package c.b.e.a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import c.e.f;
import c.e.j;

public class c extends n {
  public f<Long> K;
  
  public j<Integer> L;
  
  public c(c paramc, h paramh, Resources paramResources) {
    super(paramc, paramh, paramResources);
    if (paramc != null) {
      this.K = paramc.K;
      this.L = paramc.L;
      return;
    } 
    this.K = new f();
    this.L = new j(10);
  }
  
  public static long h(int paramInt1, int paramInt2) {
    long l = paramInt1;
    return paramInt2 | l << 32L;
  }
  
  public void e() {
    this.K = this.K.c();
    this.L = this.L.b();
  }
  
  public int i(int paramInt) {
    return (paramInt < 0) ? 0 : ((Integer)this.L.e(paramInt, Integer.valueOf(0))).intValue();
  }
  
  public Drawable newDrawable() {
    return new h(this, null);
  }
  
  public Drawable newDrawable(Resources paramResources) {
    return new h(this, paramResources);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */