package c.b.e.a;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import org.xmlpull.v1.XmlPullParser;

public class h extends o {
  public c t;
  
  public g u;
  
  public int v = -1;
  
  public int w = -1;
  
  public boolean x;
  
  public h(c paramc, Resources paramResources) {
    super(null);
    d(new c(paramc, this, paramResources));
    onStateChange(getState());
    jumpToCurrentState();
  }
  
  public static h e(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.useAs(TypeTransformer.java:868)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:668)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e2expr(TypeTransformer.java:629)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:716)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void d(k paramk) {
    this.e = paramk;
    int i = this.k;
    if (i >= 0) {
      Drawable drawable = paramk.d(i);
      this.g = drawable;
      if (drawable != null)
        b(drawable); 
    } 
    this.h = null;
    this.r = (n)paramk;
    if (paramk instanceof c)
      this.t = (c)paramk; 
  }
  
  public boolean isStateful() {
    return true;
  }
  
  public void jumpToCurrentState() {
    super.jumpToCurrentState();
    g g1 = this.u;
    if (g1 != null) {
      g1.d();
      this.u = null;
      c(this.v);
      this.v = -1;
      this.w = -1;
    } 
  }
  
  public Drawable mutate() {
    if (!this.x) {
      super.mutate();
      this.t.e();
      this.x = true;
    } 
    return this;
  }
  
  public boolean onStateChange(int[] paramArrayOfint) {
    // Byte code:
    //   0: aload_0
    //   1: getfield t : Lc/b/e/a/c;
    //   4: astore #12
    //   6: aload #12
    //   8: aload_1
    //   9: invokevirtual g : ([I)I
    //   12: istore_2
    //   13: iload_2
    //   14: iflt -> 20
    //   17: goto -> 29
    //   20: aload #12
    //   22: getstatic android/util/StateSet.WILD_CARD : [I
    //   25: invokevirtual g : ([I)I
    //   28: istore_2
    //   29: aload_0
    //   30: getfield k : I
    //   33: istore_3
    //   34: iconst_1
    //   35: istore #9
    //   37: iload_2
    //   38: iload_3
    //   39: if_icmpeq -> 441
    //   42: aload_0
    //   43: getfield u : Lc/b/e/a/g;
    //   46: astore #12
    //   48: aload #12
    //   50: ifnull -> 113
    //   53: iload_2
    //   54: aload_0
    //   55: getfield v : I
    //   58: if_icmpne -> 66
    //   61: iconst_1
    //   62: istore_3
    //   63: goto -> 418
    //   66: iload_2
    //   67: aload_0
    //   68: getfield w : I
    //   71: if_icmpne -> 103
    //   74: aload #12
    //   76: invokevirtual a : ()Z
    //   79: ifeq -> 103
    //   82: aload #12
    //   84: invokevirtual b : ()V
    //   87: aload_0
    //   88: aload_0
    //   89: getfield w : I
    //   92: putfield v : I
    //   95: aload_0
    //   96: iload_2
    //   97: putfield w : I
    //   100: goto -> 61
    //   103: aload_0
    //   104: getfield v : I
    //   107: istore_3
    //   108: aload #12
    //   110: invokevirtual d : ()V
    //   113: aload_0
    //   114: aconst_null
    //   115: putfield u : Lc/b/e/a/g;
    //   118: aload_0
    //   119: iconst_m1
    //   120: putfield w : I
    //   123: aload_0
    //   124: iconst_m1
    //   125: putfield v : I
    //   128: aload_0
    //   129: getfield t : Lc/b/e/a/c;
    //   132: astore #12
    //   134: aload #12
    //   136: iload_3
    //   137: invokevirtual i : (I)I
    //   140: istore #4
    //   142: aload #12
    //   144: iload_2
    //   145: invokevirtual i : (I)I
    //   148: istore #5
    //   150: iload #5
    //   152: ifeq -> 416
    //   155: iload #4
    //   157: ifne -> 163
    //   160: goto -> 416
    //   163: iload #4
    //   165: iload #5
    //   167: invokestatic h : (II)J
    //   170: lstore #10
    //   172: aload #12
    //   174: getfield K : Lc/e/f;
    //   177: lload #10
    //   179: ldc2_w -1
    //   182: invokestatic valueOf : (J)Ljava/lang/Long;
    //   185: invokevirtual f : (JLjava/lang/Object;)Ljava/lang/Object;
    //   188: checkcast java/lang/Long
    //   191: invokevirtual longValue : ()J
    //   194: l2i
    //   195: istore #6
    //   197: iload #6
    //   199: ifge -> 205
    //   202: goto -> 416
    //   205: iload #4
    //   207: iload #5
    //   209: invokestatic h : (II)J
    //   212: lstore #10
    //   214: aload #12
    //   216: getfield K : Lc/e/f;
    //   219: lload #10
    //   221: ldc2_w -1
    //   224: invokestatic valueOf : (J)Ljava/lang/Long;
    //   227: invokevirtual f : (JLjava/lang/Object;)Ljava/lang/Object;
    //   230: checkcast java/lang/Long
    //   233: invokevirtual longValue : ()J
    //   236: ldc2_w 8589934592
    //   239: land
    //   240: lconst_0
    //   241: lcmp
    //   242: ifeq -> 251
    //   245: iconst_1
    //   246: istore #7
    //   248: goto -> 254
    //   251: iconst_0
    //   252: istore #7
    //   254: aload_0
    //   255: iload #6
    //   257: invokevirtual c : (I)Z
    //   260: pop
    //   261: aload_0
    //   262: getfield g : Landroid/graphics/drawable/Drawable;
    //   265: astore #13
    //   267: aload #13
    //   269: instanceof android/graphics/drawable/AnimationDrawable
    //   272: ifeq -> 345
    //   275: iload #4
    //   277: iload #5
    //   279: invokestatic h : (II)J
    //   282: lstore #10
    //   284: aload #12
    //   286: getfield K : Lc/e/f;
    //   289: lload #10
    //   291: ldc2_w -1
    //   294: invokestatic valueOf : (J)Ljava/lang/Long;
    //   297: invokevirtual f : (JLjava/lang/Object;)Ljava/lang/Object;
    //   300: checkcast java/lang/Long
    //   303: invokevirtual longValue : ()J
    //   306: ldc2_w 4294967296
    //   309: land
    //   310: lconst_0
    //   311: lcmp
    //   312: ifeq -> 321
    //   315: iconst_1
    //   316: istore #8
    //   318: goto -> 324
    //   321: iconst_0
    //   322: istore #8
    //   324: new c/b/e/a/e
    //   327: dup
    //   328: aload #13
    //   330: checkcast android/graphics/drawable/AnimationDrawable
    //   333: iload #8
    //   335: iload #7
    //   337: invokespecial <init> : (Landroid/graphics/drawable/AnimationDrawable;ZZ)V
    //   340: astore #12
    //   342: goto -> 392
    //   345: aload #13
    //   347: instanceof c/z/a/a/e
    //   350: ifeq -> 370
    //   353: new c/b/e/a/d
    //   356: dup
    //   357: aload #13
    //   359: checkcast c/z/a/a/e
    //   362: invokespecial <init> : (Lc/z/a/a/e;)V
    //   365: astore #12
    //   367: goto -> 392
    //   370: aload #13
    //   372: instanceof android/graphics/drawable/Animatable
    //   375: ifeq -> 416
    //   378: new c/b/e/a/b
    //   381: dup
    //   382: aload #13
    //   384: checkcast android/graphics/drawable/Animatable
    //   387: invokespecial <init> : (Landroid/graphics/drawable/Animatable;)V
    //   390: astore #12
    //   392: aload #12
    //   394: invokevirtual c : ()V
    //   397: aload_0
    //   398: aload #12
    //   400: putfield u : Lc/b/e/a/g;
    //   403: aload_0
    //   404: iload_3
    //   405: putfield w : I
    //   408: aload_0
    //   409: iload_2
    //   410: putfield v : I
    //   413: goto -> 61
    //   416: iconst_0
    //   417: istore_3
    //   418: iload #9
    //   420: istore #7
    //   422: iload_3
    //   423: ifne -> 444
    //   426: aload_0
    //   427: iload_2
    //   428: invokevirtual c : (I)Z
    //   431: ifeq -> 441
    //   434: iload #9
    //   436: istore #7
    //   438: goto -> 444
    //   441: iconst_0
    //   442: istore #7
    //   444: aload_0
    //   445: getfield g : Landroid/graphics/drawable/Drawable;
    //   448: astore #12
    //   450: iload #7
    //   452: istore #8
    //   454: aload #12
    //   456: ifnull -> 470
    //   459: iload #7
    //   461: aload #12
    //   463: aload_1
    //   464: invokevirtual setState : ([I)Z
    //   467: ior
    //   468: istore #8
    //   470: iload #8
    //   472: ireturn
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    boolean bool = super.setVisible(paramBoolean1, paramBoolean2);
    g g1 = this.u;
    if (g1 != null && (bool || paramBoolean2)) {
      if (paramBoolean1) {
        g1.c();
        return bool;
      } 
      jumpToCurrentState();
    } 
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */