package c.b.e.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import c.h.b.h;
import java.util.Objects;

public abstract class l extends Drawable implements Drawable.Callback {
  public k e;
  
  public Rect f;
  
  public Drawable g;
  
  public Drawable h;
  
  public int i = 255;
  
  public boolean j;
  
  public int k = -1;
  
  public boolean l;
  
  public Runnable m;
  
  public long n;
  
  public long o;
  
  public j p;
  
  public void a(boolean paramBoolean) {
    boolean bool2 = true;
    this.j = true;
    long l1 = SystemClock.uptimeMillis();
    Drawable drawable = this.g;
    if (drawable != null) {
      long l2 = this.n;
      if (l2 != 0L)
        if (l2 <= l1) {
          drawable.setAlpha(this.i);
          this.n = 0L;
        } else {
          drawable.setAlpha((255 - (int)((l2 - l1) * 255L) / this.e.A) * this.i / 255);
          boolean bool = true;
          drawable = this.h;
        }  
    } else {
      this.n = 0L;
    } 
    boolean bool1 = false;
    drawable = this.h;
  }
  
  public void applyTheme(Resources.Theme paramTheme) {
    k k1 = this.e;
    Objects.requireNonNull(k1);
    if (paramTheme != null) {
      k1.c();
      int m = k1.h;
      Drawable[] arrayOfDrawable = k1.g;
      for (int i = 0; i < m; i++) {
        if (arrayOfDrawable[i] != null && arrayOfDrawable[i].canApplyTheme()) {
          arrayOfDrawable[i].applyTheme(paramTheme);
          k1.e |= arrayOfDrawable[i].getChangingConfigurations();
        } 
      } 
      k1.f(paramTheme.getResources());
    } 
  }
  
  public final void b(Drawable paramDrawable) {
    if (this.p == null)
      this.p = new j(); 
    null = this.p;
    null.e = paramDrawable.getCallback();
    paramDrawable.setCallback(null);
    try {
      if (this.e.A <= 0 && this.j)
        paramDrawable.setAlpha(this.i); 
      k k1 = this.e;
      if (k1.E) {
        paramDrawable.setColorFilter(k1.D);
      } else {
        if (k1.H)
          paramDrawable.setTintList(k1.F); 
        k1 = this.e;
        if (k1.I)
          paramDrawable.setTintMode(k1.G); 
      } 
      paramDrawable.setVisible(isVisible(), true);
      paramDrawable.setDither(this.e.x);
      paramDrawable.setState(getState());
      paramDrawable.setLevel(getLevel());
      paramDrawable.setBounds(getBounds());
      paramDrawable.setLayoutDirection(getLayoutDirection());
      paramDrawable.setAutoMirrored(this.e.C);
      Rect rect = this.f;
      if (rect != null)
        paramDrawable.setHotspotBounds(rect.left, rect.top, rect.right, rect.bottom); 
      return;
    } finally {
      j j1 = this.p;
      Drawable.Callback callback = j1.e;
      j1.e = null;
      paramDrawable.setCallback(callback);
    } 
  }
  
  public boolean c(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: getfield k : I
    //   5: if_icmpne -> 10
    //   8: iconst_0
    //   9: ireturn
    //   10: invokestatic uptimeMillis : ()J
    //   13: lstore_2
    //   14: aload_0
    //   15: getfield e : Lc/b/e/a/k;
    //   18: getfield B : I
    //   21: ifle -> 90
    //   24: aload_0
    //   25: getfield h : Landroid/graphics/drawable/Drawable;
    //   28: astore #4
    //   30: aload #4
    //   32: ifnull -> 43
    //   35: aload #4
    //   37: iconst_0
    //   38: iconst_0
    //   39: invokevirtual setVisible : (ZZ)Z
    //   42: pop
    //   43: aload_0
    //   44: getfield g : Landroid/graphics/drawable/Drawable;
    //   47: astore #4
    //   49: aload #4
    //   51: ifnull -> 77
    //   54: aload_0
    //   55: aload #4
    //   57: putfield h : Landroid/graphics/drawable/Drawable;
    //   60: aload_0
    //   61: aload_0
    //   62: getfield e : Lc/b/e/a/k;
    //   65: getfield B : I
    //   68: i2l
    //   69: lload_2
    //   70: ladd
    //   71: putfield o : J
    //   74: goto -> 109
    //   77: aload_0
    //   78: aconst_null
    //   79: putfield h : Landroid/graphics/drawable/Drawable;
    //   82: aload_0
    //   83: lconst_0
    //   84: putfield o : J
    //   87: goto -> 109
    //   90: aload_0
    //   91: getfield g : Landroid/graphics/drawable/Drawable;
    //   94: astore #4
    //   96: aload #4
    //   98: ifnull -> 109
    //   101: aload #4
    //   103: iconst_0
    //   104: iconst_0
    //   105: invokevirtual setVisible : (ZZ)Z
    //   108: pop
    //   109: iload_1
    //   110: iflt -> 181
    //   113: aload_0
    //   114: getfield e : Lc/b/e/a/k;
    //   117: astore #4
    //   119: iload_1
    //   120: aload #4
    //   122: getfield h : I
    //   125: if_icmpge -> 181
    //   128: aload #4
    //   130: iload_1
    //   131: invokevirtual d : (I)Landroid/graphics/drawable/Drawable;
    //   134: astore #4
    //   136: aload_0
    //   137: aload #4
    //   139: putfield g : Landroid/graphics/drawable/Drawable;
    //   142: aload_0
    //   143: iload_1
    //   144: putfield k : I
    //   147: aload #4
    //   149: ifnull -> 191
    //   152: aload_0
    //   153: getfield e : Lc/b/e/a/k;
    //   156: getfield A : I
    //   159: istore_1
    //   160: iload_1
    //   161: ifle -> 172
    //   164: aload_0
    //   165: lload_2
    //   166: iload_1
    //   167: i2l
    //   168: ladd
    //   169: putfield n : J
    //   172: aload_0
    //   173: aload #4
    //   175: invokevirtual b : (Landroid/graphics/drawable/Drawable;)V
    //   178: goto -> 191
    //   181: aload_0
    //   182: aconst_null
    //   183: putfield g : Landroid/graphics/drawable/Drawable;
    //   186: aload_0
    //   187: iconst_m1
    //   188: putfield k : I
    //   191: aload_0
    //   192: getfield n : J
    //   195: lconst_0
    //   196: lcmp
    //   197: ifne -> 209
    //   200: aload_0
    //   201: getfield o : J
    //   204: lconst_0
    //   205: lcmp
    //   206: ifeq -> 246
    //   209: aload_0
    //   210: getfield m : Ljava/lang/Runnable;
    //   213: astore #4
    //   215: aload #4
    //   217: ifnonnull -> 235
    //   220: aload_0
    //   221: new c/b/e/a/i
    //   224: dup
    //   225: aload_0
    //   226: invokespecial <init> : (Lc/b/e/a/l;)V
    //   229: putfield m : Ljava/lang/Runnable;
    //   232: goto -> 241
    //   235: aload_0
    //   236: aload #4
    //   238: invokevirtual unscheduleSelf : (Ljava/lang/Runnable;)V
    //   241: aload_0
    //   242: iconst_1
    //   243: invokevirtual a : (Z)V
    //   246: aload_0
    //   247: invokevirtual invalidateSelf : ()V
    //   250: iconst_1
    //   251: ireturn
  }
  
  public boolean canApplyTheme() {
    return this.e.canApplyTheme();
  }
  
  public abstract void d(k paramk);
  
  public void draw(Canvas paramCanvas) {
    Drawable drawable = this.g;
    if (drawable != null)
      drawable.draw(paramCanvas); 
    drawable = this.h;
    if (drawable != null)
      drawable.draw(paramCanvas); 
  }
  
  public int getAlpha() {
    return this.i;
  }
  
  public int getChangingConfigurations() {
    return super.getChangingConfigurations() | this.e.getChangingConfigurations();
  }
  
  public final Drawable.ConstantState getConstantState() {
    synchronized (this.e) {
      boolean bool2 = null.v;
      boolean bool1 = true;
      if (bool2) {
        bool1 = null.w;
      } else {
        null.c();
        null.v = true;
        int m = null.h;
        Drawable[] arrayOfDrawable = null.g;
        int i = 0;
        while (true) {
          if (i < m) {
            if (arrayOfDrawable[i].getConstantState() == null) {
              null.w = false;
              bool1 = false;
              break;
            } 
            i++;
            continue;
          } 
          null.w = true;
          break;
        } 
      } 
      if (bool1) {
        this.e.d = getChangingConfigurations();
        return this.e;
      } 
      return null;
    } 
  }
  
  public Drawable getCurrent() {
    return this.g;
  }
  
  public void getHotspotBounds(Rect paramRect) {
    Rect rect = this.f;
    if (rect != null) {
      paramRect.set(rect);
      return;
    } 
    super.getHotspotBounds(paramRect);
  }
  
  public int getIntrinsicHeight() {
    k k1 = this.e;
    if (k1.l) {
      if (!k1.m)
        k1.b(); 
      return k1.o;
    } 
    Drawable drawable = this.g;
    return (drawable != null) ? drawable.getIntrinsicHeight() : -1;
  }
  
  public int getIntrinsicWidth() {
    k k1 = this.e;
    if (k1.l) {
      if (!k1.m)
        k1.b(); 
      return k1.n;
    } 
    Drawable drawable = this.g;
    return (drawable != null) ? drawable.getIntrinsicWidth() : -1;
  }
  
  public int getMinimumHeight() {
    k k1 = this.e;
    if (k1.l) {
      if (!k1.m)
        k1.b(); 
      return k1.q;
    } 
    Drawable drawable = this.g;
    return (drawable != null) ? drawable.getMinimumHeight() : 0;
  }
  
  public int getMinimumWidth() {
    k k1 = this.e;
    if (k1.l) {
      if (!k1.m)
        k1.b(); 
      return k1.p;
    } 
    Drawable drawable = this.g;
    return (drawable != null) ? drawable.getMinimumWidth() : 0;
  }
  
  public int getOpacity() {
    Drawable drawable = this.g;
    int i = -2;
    int m = i;
    if (drawable != null) {
      if (!drawable.isVisible())
        return -2; 
      k k1 = this.e;
      if (k1.r)
        return k1.s; 
      k1.c();
      int n = k1.h;
      Drawable[] arrayOfDrawable = k1.g;
      if (n > 0)
        i = arrayOfDrawable[0].getOpacity(); 
      for (m = 1; m < n; m++)
        i = Drawable.resolveOpacity(i, arrayOfDrawable[m].getOpacity()); 
      k1.s = i;
      k1.r = true;
      m = i;
    } 
    return m;
  }
  
  public void getOutline(Outline paramOutline) {
    Drawable drawable = this.g;
    if (drawable != null)
      drawable.getOutline(paramOutline); 
  }
  
  public boolean getPadding(Rect paramRect) {
    k k1 = this.e;
    boolean bool = k1.i;
    Rect rect2 = null;
    Rect rect1 = null;
    byte b = 0;
    if (bool) {
      rect1 = rect2;
    } else {
      rect2 = k1.k;
      if (rect2 != null || k1.j) {
        rect1 = rect2;
      } else {
        k1.c();
        Rect rect = new Rect();
        int n = k1.h;
        Drawable[] arrayOfDrawable = k1.g;
        int m = 0;
        while (m < n) {
          Rect rect3 = rect1;
          if (arrayOfDrawable[m].getPadding(rect)) {
            rect2 = rect1;
            if (rect1 == null)
              rect2 = new Rect(0, 0, 0, 0); 
            int i1 = rect.left;
            if (i1 > rect2.left)
              rect2.left = i1; 
            i1 = rect.top;
            if (i1 > rect2.top)
              rect2.top = i1; 
            i1 = rect.right;
            if (i1 > rect2.right)
              rect2.right = i1; 
            i1 = rect.bottom;
            rect3 = rect2;
            if (i1 > rect2.bottom) {
              rect2.bottom = i1;
              rect3 = rect2;
            } 
          } 
          m++;
          rect1 = rect3;
        } 
        k1.j = true;
        k1.k = rect1;
      } 
    } 
    if (rect1 != null) {
      paramRect.set(rect1);
      if ((rect1.left | rect1.top | rect1.bottom | rect1.right) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
    } else {
      Drawable drawable = this.g;
      if (drawable != null) {
        bool = drawable.getPadding(paramRect);
      } else {
        bool = super.getPadding(paramRect);
      } 
    } 
    int i = b;
    if (this.e.C) {
      i = b;
      if (getLayoutDirection() == 1)
        i = 1; 
    } 
    if (i) {
      i = paramRect.left;
      paramRect.left = paramRect.right;
      paramRect.right = i;
    } 
    return bool;
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    k k1 = this.e;
    if (k1 != null) {
      k1.r = false;
      k1.t = false;
    } 
    if (paramDrawable == this.g && getCallback() != null)
      getCallback().invalidateDrawable(this); 
  }
  
  public boolean isAutoMirrored() {
    return this.e.C;
  }
  
  public void jumpToCurrentState() {
    boolean bool1;
    Drawable drawable = this.h;
    boolean bool2 = true;
    if (drawable != null) {
      drawable.jumpToCurrentState();
      this.h = null;
      bool1 = true;
    } else {
      bool1 = false;
    } 
    drawable = this.g;
    if (drawable != null) {
      drawable.jumpToCurrentState();
      if (this.j)
        this.g.setAlpha(this.i); 
    } 
    if (this.o != 0L) {
      this.o = 0L;
      bool1 = true;
    } 
    if (this.n != 0L) {
      this.n = 0L;
      bool1 = bool2;
    } 
    if (bool1)
      invalidateSelf(); 
  }
  
  public Drawable mutate() {
    if (!this.l && super.mutate() == this) {
      h h = (h)this;
      c c = new c(h.t, h, null);
      c.e();
      d(c);
      this.l = true;
    } 
    return this;
  }
  
  public void onBoundsChange(Rect paramRect) {
    Drawable drawable = this.h;
    if (drawable != null)
      drawable.setBounds(paramRect); 
    drawable = this.g;
    if (drawable != null)
      drawable.setBounds(paramRect); 
  }
  
  public boolean onLayoutDirectionChanged(int paramInt) {
    k k1 = this.e;
    int m = this.k;
    int n = k1.h;
    Drawable[] arrayOfDrawable = k1.g;
    int i = 0;
    boolean bool;
    for (bool = false; i < n; bool = bool1) {
      boolean bool1 = bool;
      if (arrayOfDrawable[i] != null) {
        boolean bool2 = arrayOfDrawable[i].setLayoutDirection(paramInt);
        bool1 = bool;
        if (i == m)
          bool1 = bool2; 
      } 
      i++;
    } 
    k1.z = paramInt;
    return bool;
  }
  
  public boolean onLevelChange(int paramInt) {
    Drawable drawable = this.h;
    if (drawable != null)
      return drawable.setLevel(paramInt); 
    drawable = this.g;
    return (drawable != null) ? drawable.setLevel(paramInt) : false;
  }
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong) {
    if (paramDrawable == this.g && getCallback() != null)
      getCallback().scheduleDrawable(this, paramRunnable, paramLong); 
  }
  
  public void setAlpha(int paramInt) {
    if (!this.j || this.i != paramInt) {
      this.j = true;
      this.i = paramInt;
      Drawable drawable = this.g;
      if (drawable != null) {
        if (this.n == 0L) {
          drawable.setAlpha(paramInt);
          return;
        } 
        a(false);
      } 
    } 
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    k k1 = this.e;
    if (k1.C != paramBoolean) {
      k1.C = paramBoolean;
      Drawable drawable = this.g;
      if (drawable != null)
        drawable.setAutoMirrored(paramBoolean); 
    } 
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    k k1 = this.e;
    k1.E = true;
    if (k1.D != paramColorFilter) {
      k1.D = paramColorFilter;
      Drawable drawable = this.g;
      if (drawable != null)
        drawable.setColorFilter(paramColorFilter); 
    } 
  }
  
  public void setDither(boolean paramBoolean) {
    k k1 = this.e;
    if (k1.x != paramBoolean) {
      k1.x = paramBoolean;
      Drawable drawable = this.g;
      if (drawable != null)
        drawable.setDither(paramBoolean); 
    } 
  }
  
  public void setHotspot(float paramFloat1, float paramFloat2) {
    Drawable drawable = this.g;
    if (drawable != null)
      drawable.setHotspot(paramFloat1, paramFloat2); 
  }
  
  public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Rect rect = this.f;
    if (rect == null) {
      this.f = new Rect(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      rect.set(paramInt1, paramInt2, paramInt3, paramInt4);
    } 
    Drawable drawable = this.g;
    if (drawable != null)
      drawable.setHotspotBounds(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    k k1 = this.e;
    k1.H = true;
    if (k1.F != paramColorStateList) {
      k1.F = paramColorStateList;
      h.i0(this.g, paramColorStateList);
    } 
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    k k1 = this.e;
    k1.I = true;
    if (k1.G != paramMode) {
      k1.G = paramMode;
      h.j0(this.g, paramMode);
    } 
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    boolean bool = super.setVisible(paramBoolean1, paramBoolean2);
    Drawable drawable = this.h;
    if (drawable != null)
      drawable.setVisible(paramBoolean1, paramBoolean2); 
    drawable = this.g;
    if (drawable != null)
      drawable.setVisible(paramBoolean1, paramBoolean2); 
    return bool;
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable) {
    if (paramDrawable == this.g && getCallback() != null)
      getCallback().unscheduleDrawable(this, paramRunnable); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\e\a\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */