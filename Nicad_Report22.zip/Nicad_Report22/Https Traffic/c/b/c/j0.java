package c.b.c;

import android.view.Menu;
import android.view.Window;
import c.b.g.n.l;
import c.b.g.n.y;

public final class j0 implements y.a {
  public j0(k0 paramk0) {}
  
  public void a(l paraml, boolean paramBoolean) {
    boolean bool;
    l l1 = paraml.k();
    if (l1 != paraml) {
      bool = true;
    } else {
      bool = false;
    } 
    k0 k01 = this.e;
    if (bool)
      paraml = l1; 
    i0 i0 = k01.z((Menu)paraml);
    if (i0 != null) {
      if (bool) {
        this.e.q(i0.a, i0, (Menu)l1);
        this.e.s(i0, true);
        return;
      } 
      this.e.s(i0, paramBoolean);
    } 
  }
  
  public boolean b(l paraml) {
    if (paraml == paraml.k()) {
      k0 k01 = this.e;
      if (k01.C) {
        Window.Callback callback = k01.D();
        if (callback != null && !this.e.O)
          callback.onMenuOpened(108, (Menu)paraml); 
      } 
    } 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */