package c.b.c;

import android.view.Menu;
import android.view.Window;
import c.b.g.n.l;
import c.b.g.n.y;

public final class z implements y.a {
  public z(k0 paramk0) {}
  
  public void a(l paraml, boolean paramBoolean) {
    this.e.r(paraml);
  }
  
  public boolean b(l paraml) {
    Window.Callback callback = this.e.D();
    if (callback != null)
      callback.onMenuOpened(108, (Menu)paraml); 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */