package c.b.c;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import c.b.h.b0;
import c.b.h.n;
import c.b.h.p;
import c.b.h.q;
import c.b.h.u0;
import c.e.i;
import java.lang.reflect.Constructor;

public class n0 {
  public static final Class<?>[] b = new Class[] { Context.class, AttributeSet.class };
  
  public static final int[] c = new int[] { 16843375 };
  
  public static final String[] d = new String[] { "android.widget.", "android.view.", "android.webkit." };
  
  public static final i<String, Constructor<? extends View>> e = new i();
  
  public final Object[] a = new Object[2];
  
  public n a(Context paramContext, AttributeSet paramAttributeSet) {
    return new n(paramContext, paramAttributeSet, 2130903094);
  }
  
  public p b(Context paramContext, AttributeSet paramAttributeSet) {
    return new p(paramContext, paramAttributeSet, 2130903158);
  }
  
  public q c(Context paramContext, AttributeSet paramAttributeSet) {
    return new q(paramContext, paramAttributeSet, 2130903171);
  }
  
  public b0 d(Context paramContext, AttributeSet paramAttributeSet) {
    return new b0(paramContext, paramAttributeSet, 2130903701);
  }
  
  public u0 e(Context paramContext, AttributeSet paramAttributeSet) {
    return new u0(paramContext, paramAttributeSet, 16842884);
  }
  
  public View f() {
    return null;
  }
  
  public final View g(Context paramContext, String paramString1, String paramString2) {
    i<String, Constructor<? extends View>> i1 = e;
    Constructor constructor1 = (Constructor)i1.getOrDefault(paramString1, null);
    Constructor<View> constructor = constructor1;
    if (constructor1 == null) {
      if (paramString2 != null)
        try {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramString2);
          stringBuilder.append(paramString1);
          paramString2 = stringBuilder.toString();
          constructor = Class.forName(paramString2, false, paramContext.getClassLoader()).<View>asSubclass(View.class).getConstructor(b);
          i1.put(paramString1, constructor);
          constructor.setAccessible(true);
          return constructor.newInstance(this.a);
        } catch (Exception exception) {
          return null;
        }  
    } else {
      constructor.setAccessible(true);
      return constructor.newInstance(this.a);
    } 
    paramString2 = paramString1;
    constructor = Class.forName(paramString2, false, paramContext.getClassLoader()).<View>asSubclass(View.class).getConstructor(b);
    i1.put(paramString1, constructor);
    constructor.setAccessible(true);
    return constructor.newInstance(this.a);
  }
  
  public final void h(View paramView, String paramString) {
    if (paramView != null)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getName());
    stringBuilder.append(" asked to inflate view for <");
    stringBuilder.append(paramString);
    stringBuilder.append(">, but returned null");
    throw new IllegalStateException(stringBuilder.toString());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */