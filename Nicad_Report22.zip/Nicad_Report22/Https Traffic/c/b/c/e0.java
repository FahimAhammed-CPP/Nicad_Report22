package c.b.c;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class e0 extends BroadcastReceiver {
  public e0(f0 paramf0) {}
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    this.a.d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */