package c.b.c;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import c.b.g.n.j;
import c.b.g.n.l;
import c.b.g.n.y;

public final class i0 {
  public int a;
  
  public int b;
  
  public int c;
  
  public int d;
  
  public ViewGroup e;
  
  public View f;
  
  public View g;
  
  public l h;
  
  public j i;
  
  public Context j;
  
  public boolean k;
  
  public boolean l;
  
  public boolean m;
  
  public boolean n;
  
  public boolean o;
  
  public boolean p;
  
  public Bundle q;
  
  public i0(int paramInt) {
    this.a = paramInt;
    this.o = false;
  }
  
  public void a(l paraml) {
    l l1 = this.h;
    if (paraml == l1)
      return; 
    if (l1 != null)
      l1.u((y)this.i); 
    this.h = paraml;
    if (paraml != null) {
      j j1 = this.i;
      if (j1 != null)
        paraml.b((y)j1, paraml.a); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */