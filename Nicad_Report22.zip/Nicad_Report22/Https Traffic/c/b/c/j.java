package c.b.c;

import android.view.View;
import android.widget.AdapterView;
import androidx.appcompat.app.AlertController;

public class j implements AdapterView.OnItemClickListener {
  public j(k paramk, AlertController paramAlertController) {}
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.f.h.onClick(this.e.b, paramInt);
    if (!this.f.i)
      this.e.b.dismiss(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */