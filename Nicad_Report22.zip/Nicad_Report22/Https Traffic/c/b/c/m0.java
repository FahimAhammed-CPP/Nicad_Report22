package c.b.c;

import android.content.Context;
import android.view.View;
import java.lang.reflect.Method;

public class m0 implements View.OnClickListener {
  public final View e;
  
  public final String f;
  
  public Method g;
  
  public Context h;
  
  public m0(View paramView, String paramString) {
    this.e = paramView;
    this.f = paramString;
  }
  
  public void onClick(View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Ljava/lang/reflect/Method;
    //   4: ifnonnull -> 198
    //   7: aload_0
    //   8: getfield e : Landroid/view/View;
    //   11: invokevirtual getContext : ()Landroid/content/Context;
    //   14: astore_3
    //   15: aload_3
    //   16: ifnull -> 90
    //   19: aload_3
    //   20: invokevirtual isRestricted : ()Z
    //   23: ifne -> 67
    //   26: aload_3
    //   27: invokevirtual getClass : ()Ljava/lang/Class;
    //   30: aload_0
    //   31: getfield f : Ljava/lang/String;
    //   34: iconst_1
    //   35: anewarray java/lang/Class
    //   38: dup
    //   39: iconst_0
    //   40: ldc android/view/View
    //   42: aastore
    //   43: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   46: astore #4
    //   48: aload #4
    //   50: ifnull -> 67
    //   53: aload_0
    //   54: aload #4
    //   56: putfield g : Ljava/lang/reflect/Method;
    //   59: aload_0
    //   60: aload_3
    //   61: putfield h : Landroid/content/Context;
    //   64: goto -> 198
    //   67: aload_3
    //   68: instanceof android/content/ContextWrapper
    //   71: ifeq -> 85
    //   74: aload_3
    //   75: checkcast android/content/ContextWrapper
    //   78: invokevirtual getBaseContext : ()Landroid/content/Context;
    //   81: astore_3
    //   82: goto -> 15
    //   85: aconst_null
    //   86: astore_3
    //   87: goto -> 15
    //   90: aload_0
    //   91: getfield e : Landroid/view/View;
    //   94: invokevirtual getId : ()I
    //   97: istore_2
    //   98: iload_2
    //   99: iconst_m1
    //   100: if_icmpne -> 109
    //   103: ldc ''
    //   105: astore_1
    //   106: goto -> 146
    //   109: ldc ' with id ''
    //   111: invokestatic p : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   114: astore_1
    //   115: aload_1
    //   116: aload_0
    //   117: getfield e : Landroid/view/View;
    //   120: invokevirtual getContext : ()Landroid/content/Context;
    //   123: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   126: iload_2
    //   127: invokevirtual getResourceEntryName : (I)Ljava/lang/String;
    //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   133: pop
    //   134: aload_1
    //   135: ldc '''
    //   137: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: pop
    //   141: aload_1
    //   142: invokevirtual toString : ()Ljava/lang/String;
    //   145: astore_1
    //   146: ldc 'Could not find method '
    //   148: invokestatic p : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: astore_3
    //   152: aload_3
    //   153: aload_0
    //   154: getfield f : Ljava/lang/String;
    //   157: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: pop
    //   161: aload_3
    //   162: ldc '(View) in a parent or ancestor Context for android:onClick attribute defined on view '
    //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: pop
    //   168: aload_3
    //   169: aload_0
    //   170: getfield e : Landroid/view/View;
    //   173: invokevirtual getClass : ()Ljava/lang/Class;
    //   176: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   179: pop
    //   180: aload_3
    //   181: aload_1
    //   182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: pop
    //   186: new java/lang/IllegalStateException
    //   189: dup
    //   190: aload_3
    //   191: invokevirtual toString : ()Ljava/lang/String;
    //   194: invokespecial <init> : (Ljava/lang/String;)V
    //   197: athrow
    //   198: aload_0
    //   199: getfield g : Ljava/lang/reflect/Method;
    //   202: aload_0
    //   203: getfield h : Landroid/content/Context;
    //   206: iconst_1
    //   207: anewarray java/lang/Object
    //   210: dup
    //   211: iconst_0
    //   212: aload_1
    //   213: aastore
    //   214: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   217: pop
    //   218: return
    //   219: astore_1
    //   220: new java/lang/IllegalStateException
    //   223: dup
    //   224: ldc 'Could not execute method for android:onClick'
    //   226: aload_1
    //   227: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   230: athrow
    //   231: astore_1
    //   232: new java/lang/IllegalStateException
    //   235: dup
    //   236: ldc 'Could not execute non-public method for android:onClick'
    //   238: aload_1
    //   239: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   242: athrow
    //   243: astore #4
    //   245: goto -> 67
    // Exception table:
    //   from	to	target	type
    //   19	48	243	java/lang/NoSuchMethodException
    //   53	64	243	java/lang/NoSuchMethodException
    //   198	218	231	java/lang/IllegalAccessException
    //   198	218	219	java/lang/reflect/InvocationTargetException
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */