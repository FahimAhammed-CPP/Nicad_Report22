package c.b.c;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ListAdapter;

public class k {
  public final Context a;
  
  public final LayoutInflater b;
  
  public Drawable c;
  
  public CharSequence d;
  
  public View e;
  
  public DialogInterface.OnKeyListener f;
  
  public ListAdapter g;
  
  public DialogInterface.OnClickListener h;
  
  public boolean i;
  
  public int j = -1;
  
  public k(Context paramContext) {
    this.a = paramContext;
    this.b = (LayoutInflater)paramContext.getSystemService("layout_inflater");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */