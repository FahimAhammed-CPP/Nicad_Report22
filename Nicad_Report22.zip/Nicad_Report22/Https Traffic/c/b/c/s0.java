package c.b.c;

import android.view.Menu;
import android.view.View;
import android.view.Window;
import c.b.g.m;
import c.b.h.n2;

public class s0 extends m {
  public s0(t0 paramt0, Window.Callback paramCallback) {
    super(paramCallback);
  }
  
  public View onCreatePanelView(int paramInt) {
    return (paramInt == 0) ? new View(((n2)this.f.a).a()) : this.e.onCreatePanelView(paramInt);
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    boolean bool = this.e.onPreparePanel(paramInt, paramView, paramMenu);
    if (bool) {
      t0 t01 = this.f;
      if (!t01.b) {
        ((n2)t01.a).m = true;
        t01.b = true;
      } 
    } 
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */