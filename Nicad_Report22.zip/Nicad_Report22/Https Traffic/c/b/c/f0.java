package c.b.c;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;

public abstract class f0 {
  public BroadcastReceiver a;
  
  public f0(k0 paramk0) {}
  
  public void a() {
    BroadcastReceiver broadcastReceiver = this.a;
    if (broadcastReceiver != null) {
      try {
        this.b.h.unregisterReceiver(broadcastReceiver);
      } catch (IllegalArgumentException illegalArgumentException) {}
      this.a = null;
    } 
  }
  
  public abstract IntentFilter b();
  
  public abstract int c();
  
  public abstract void d();
  
  public void e() {
    a();
    IntentFilter intentFilter = b();
    if (intentFilter != null) {
      if (intentFilter.countActions() == 0)
        return; 
      if (this.a == null)
        this.a = new e0(this); 
      this.b.h.registerReceiver(this.a, intentFilter);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */