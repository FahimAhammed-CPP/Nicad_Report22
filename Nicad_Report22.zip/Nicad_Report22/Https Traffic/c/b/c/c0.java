package c.b.c;

import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import c.b.g.m;
import c.b.g.n.l;
import java.util.List;
import java.util.Objects;

public class c0 extends m {
  public c0(k0 paramk0, Window.Callback paramCallback) {
    super(paramCallback);
  }
  
  public final ActionMode a(ActionMode.Callback paramCallback) {
    // Byte code:
    //   0: new c/b/g/f
    //   3: dup
    //   4: aload_0
    //   5: getfield f : Lc/b/c/k0;
    //   8: getfield h : Landroid/content/Context;
    //   11: aload_1
    //   12: invokespecial <init> : (Landroid/content/Context;Landroid/view/ActionMode$Callback;)V
    //   15: astore #4
    //   17: aload_0
    //   18: getfield f : Lc/b/c/k0;
    //   21: astore #5
    //   23: aload #5
    //   25: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   28: pop
    //   29: aload #5
    //   31: getfield r : Lc/b/g/b;
    //   34: astore_1
    //   35: aload_1
    //   36: ifnull -> 43
    //   39: aload_1
    //   40: invokevirtual c : ()V
    //   43: new c/b/c/b0
    //   46: dup
    //   47: aload #5
    //   49: aload #4
    //   51: invokespecial <init> : (Lc/b/c/k0;Lc/b/g/a;)V
    //   54: astore #6
    //   56: aload #5
    //   58: invokevirtual E : ()V
    //   61: aload #5
    //   63: getfield l : Lc/b/c/a;
    //   66: astore_1
    //   67: aload_1
    //   68: ifnull -> 108
    //   71: aload_1
    //   72: aload #6
    //   74: invokevirtual r : (Lc/b/g/a;)Lc/b/g/b;
    //   77: astore_1
    //   78: aload #5
    //   80: aload_1
    //   81: putfield r : Lc/b/g/b;
    //   84: aload_1
    //   85: ifnull -> 108
    //   88: aload #5
    //   90: getfield k : Lc/b/c/q;
    //   93: astore #7
    //   95: aload #7
    //   97: ifnull -> 108
    //   100: aload #7
    //   102: aload_1
    //   103: invokeinterface f : (Lc/b/g/b;)V
    //   108: aload #5
    //   110: getfield r : Lc/b/g/b;
    //   113: ifnonnull -> 777
    //   116: aload #5
    //   118: invokevirtual w : ()V
    //   121: aload #5
    //   123: getfield r : Lc/b/g/b;
    //   126: astore_1
    //   127: aload_1
    //   128: ifnull -> 135
    //   131: aload_1
    //   132: invokevirtual c : ()V
    //   135: aload #5
    //   137: getfield k : Lc/b/c/q;
    //   140: astore_1
    //   141: aload_1
    //   142: ifnull -> 165
    //   145: aload #5
    //   147: getfield O : Z
    //   150: ifne -> 165
    //   153: aload_1
    //   154: aload #6
    //   156: invokeinterface m : (Lc/b/g/a;)Lc/b/g/b;
    //   161: astore_1
    //   162: goto -> 167
    //   165: aconst_null
    //   166: astore_1
    //   167: aload_1
    //   168: ifnull -> 180
    //   171: aload #5
    //   173: aload_1
    //   174: putfield r : Lc/b/g/b;
    //   177: goto -> 737
    //   180: aload #5
    //   182: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   185: astore_1
    //   186: iconst_1
    //   187: istore_3
    //   188: aload_1
    //   189: ifnonnull -> 467
    //   192: aload #5
    //   194: getfield F : Z
    //   197: ifeq -> 425
    //   200: new android/util/TypedValue
    //   203: dup
    //   204: invokespecial <init> : ()V
    //   207: astore #7
    //   209: aload #5
    //   211: getfield h : Landroid/content/Context;
    //   214: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   217: astore_1
    //   218: aload_1
    //   219: ldc 2130903049
    //   221: aload #7
    //   223: iconst_1
    //   224: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   227: pop
    //   228: aload #7
    //   230: getfield resourceId : I
    //   233: ifeq -> 292
    //   236: aload #5
    //   238: getfield h : Landroid/content/Context;
    //   241: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   244: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   247: astore #8
    //   249: aload #8
    //   251: aload_1
    //   252: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   255: aload #8
    //   257: aload #7
    //   259: getfield resourceId : I
    //   262: iconst_1
    //   263: invokevirtual applyStyle : (IZ)V
    //   266: new c/b/g/d
    //   269: dup
    //   270: aload #5
    //   272: getfield h : Landroid/content/Context;
    //   275: iconst_0
    //   276: invokespecial <init> : (Landroid/content/Context;I)V
    //   279: astore_1
    //   280: aload_1
    //   281: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   284: aload #8
    //   286: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   289: goto -> 298
    //   292: aload #5
    //   294: getfield h : Landroid/content/Context;
    //   297: astore_1
    //   298: aload #5
    //   300: new androidx/appcompat/widget/ActionBarContextView
    //   303: dup
    //   304: aload_1
    //   305: aconst_null
    //   306: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   309: putfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   312: new android/widget/PopupWindow
    //   315: dup
    //   316: aload_1
    //   317: aconst_null
    //   318: ldc 2130903063
    //   320: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   323: astore #8
    //   325: aload #5
    //   327: aload #8
    //   329: putfield t : Landroid/widget/PopupWindow;
    //   332: aload #8
    //   334: iconst_2
    //   335: invokevirtual setWindowLayoutType : (I)V
    //   338: aload #5
    //   340: getfield t : Landroid/widget/PopupWindow;
    //   343: aload #5
    //   345: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   348: invokevirtual setContentView : (Landroid/view/View;)V
    //   351: aload #5
    //   353: getfield t : Landroid/widget/PopupWindow;
    //   356: iconst_m1
    //   357: invokevirtual setWidth : (I)V
    //   360: aload_1
    //   361: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   364: ldc 2130903043
    //   366: aload #7
    //   368: iconst_1
    //   369: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   372: pop
    //   373: aload #7
    //   375: getfield data : I
    //   378: aload_1
    //   379: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   382: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   385: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   388: istore_2
    //   389: aload #5
    //   391: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   394: iload_2
    //   395: invokevirtual setContentHeight : (I)V
    //   398: aload #5
    //   400: getfield t : Landroid/widget/PopupWindow;
    //   403: bipush #-2
    //   405: invokevirtual setHeight : (I)V
    //   408: aload #5
    //   410: new c/b/c/w
    //   413: dup
    //   414: aload #5
    //   416: invokespecial <init> : (Lc/b/c/k0;)V
    //   419: putfield u : Ljava/lang/Runnable;
    //   422: goto -> 467
    //   425: aload #5
    //   427: getfield x : Landroid/view/ViewGroup;
    //   430: ldc 2131230783
    //   432: invokevirtual findViewById : (I)Landroid/view/View;
    //   435: checkcast androidx/appcompat/widget/ViewStubCompat
    //   438: astore_1
    //   439: aload_1
    //   440: ifnull -> 467
    //   443: aload_1
    //   444: aload #5
    //   446: invokevirtual A : ()Landroid/content/Context;
    //   449: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   452: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   455: aload #5
    //   457: aload_1
    //   458: invokevirtual a : ()Landroid/view/View;
    //   461: checkcast androidx/appcompat/widget/ActionBarContextView
    //   464: putfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   467: aload #5
    //   469: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   472: ifnull -> 737
    //   475: aload #5
    //   477: invokevirtual w : ()V
    //   480: aload #5
    //   482: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   485: invokevirtual h : ()V
    //   488: aload #5
    //   490: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   493: invokevirtual getContext : ()Landroid/content/Context;
    //   496: astore_1
    //   497: aload #5
    //   499: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   502: astore #7
    //   504: aload #5
    //   506: getfield t : Landroid/widget/PopupWindow;
    //   509: ifnonnull -> 515
    //   512: goto -> 517
    //   515: iconst_0
    //   516: istore_3
    //   517: new c/b/g/e
    //   520: dup
    //   521: aload_1
    //   522: aload #7
    //   524: aload #6
    //   526: iload_3
    //   527: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Lc/b/g/a;Z)V
    //   530: astore_1
    //   531: aload #6
    //   533: aload_1
    //   534: aload_1
    //   535: getfield l : Lc/b/g/n/l;
    //   538: invokevirtual d : (Lc/b/g/b;Landroid/view/Menu;)Z
    //   541: ifeq -> 731
    //   544: aload_1
    //   545: invokevirtual i : ()V
    //   548: aload #5
    //   550: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   553: aload_1
    //   554: invokevirtual f : (Lc/b/g/b;)V
    //   557: aload #5
    //   559: aload_1
    //   560: putfield r : Lc/b/g/b;
    //   563: aload #5
    //   565: invokevirtual K : ()Z
    //   568: ifeq -> 640
    //   571: aload #5
    //   573: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   576: fconst_0
    //   577: invokevirtual setAlpha : (F)V
    //   580: aload #5
    //   582: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   585: invokestatic b : (Landroid/view/View;)Lc/h/j/y;
    //   588: astore_1
    //   589: aload_1
    //   590: fconst_1
    //   591: invokevirtual a : (F)Lc/h/j/y;
    //   594: pop
    //   595: aload #5
    //   597: aload_1
    //   598: putfield v : Lc/h/j/y;
    //   601: new c/b/c/x
    //   604: dup
    //   605: aload #5
    //   607: invokespecial <init> : (Lc/b/c/k0;)V
    //   610: astore #6
    //   612: aload_1
    //   613: getfield a : Ljava/lang/ref/WeakReference;
    //   616: invokevirtual get : ()Ljava/lang/Object;
    //   619: checkcast android/view/View
    //   622: astore #7
    //   624: aload #7
    //   626: ifnull -> 703
    //   629: aload_1
    //   630: aload #7
    //   632: aload #6
    //   634: invokevirtual e : (Landroid/view/View;Lc/h/j/z;)V
    //   637: goto -> 703
    //   640: aload #5
    //   642: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   645: fconst_1
    //   646: invokevirtual setAlpha : (F)V
    //   649: aload #5
    //   651: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   654: iconst_0
    //   655: invokevirtual setVisibility : (I)V
    //   658: aload #5
    //   660: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   663: bipush #32
    //   665: invokevirtual sendAccessibilityEvent : (I)V
    //   668: aload #5
    //   670: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   673: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   676: instanceof android/view/View
    //   679: ifeq -> 703
    //   682: aload #5
    //   684: getfield s : Landroidx/appcompat/widget/ActionBarContextView;
    //   687: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   690: checkcast android/view/View
    //   693: astore_1
    //   694: getstatic c/h/j/u.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   697: astore #6
    //   699: aload_1
    //   700: invokevirtual requestApplyInsets : ()V
    //   703: aload #5
    //   705: getfield t : Landroid/widget/PopupWindow;
    //   708: ifnull -> 737
    //   711: aload #5
    //   713: getfield i : Landroid/view/Window;
    //   716: invokevirtual getDecorView : ()Landroid/view/View;
    //   719: aload #5
    //   721: getfield u : Ljava/lang/Runnable;
    //   724: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   727: pop
    //   728: goto -> 737
    //   731: aload #5
    //   733: aconst_null
    //   734: putfield r : Lc/b/g/b;
    //   737: aload #5
    //   739: getfield r : Lc/b/g/b;
    //   742: astore_1
    //   743: aload_1
    //   744: ifnull -> 767
    //   747: aload #5
    //   749: getfield k : Lc/b/c/q;
    //   752: astore #6
    //   754: aload #6
    //   756: ifnull -> 767
    //   759: aload #6
    //   761: aload_1
    //   762: invokeinterface f : (Lc/b/g/b;)V
    //   767: aload #5
    //   769: aload #5
    //   771: getfield r : Lc/b/g/b;
    //   774: putfield r : Lc/b/g/b;
    //   777: aload #5
    //   779: getfield r : Lc/b/g/b;
    //   782: astore_1
    //   783: aload_1
    //   784: ifnull -> 794
    //   787: aload #4
    //   789: aload_1
    //   790: invokevirtual e : (Lc/b/g/b;)Landroid/view/ActionMode;
    //   793: areturn
    //   794: aconst_null
    //   795: areturn
    //   796: astore_1
    //   797: goto -> 165
    // Exception table:
    //   from	to	target	type
    //   153	162	796	java/lang/AbstractMethodError
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (this.f.u(paramKeyEvent) || this.e.dispatchKeyEvent(paramKeyEvent));
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroid/view/Window$Callback;
    //   4: aload_1
    //   5: invokeinterface dispatchKeyShortcutEvent : (Landroid/view/KeyEvent;)Z
    //   10: istore #4
    //   12: iconst_0
    //   13: istore_3
    //   14: iload #4
    //   16: ifne -> 168
    //   19: aload_0
    //   20: getfield f : Lc/b/c/k0;
    //   23: astore #5
    //   25: aload_1
    //   26: invokevirtual getKeyCode : ()I
    //   29: istore_2
    //   30: aload #5
    //   32: invokevirtual E : ()V
    //   35: aload #5
    //   37: getfield l : Lc/b/c/a;
    //   40: astore #6
    //   42: aload #6
    //   44: ifnull -> 62
    //   47: aload #6
    //   49: iload_2
    //   50: aload_1
    //   51: invokevirtual i : (ILandroid/view/KeyEvent;)Z
    //   54: ifeq -> 62
    //   57: iconst_1
    //   58: istore_2
    //   59: goto -> 164
    //   62: aload #5
    //   64: getfield J : Lc/b/c/i0;
    //   67: astore #6
    //   69: aload #6
    //   71: ifnull -> 108
    //   74: aload #5
    //   76: aload #6
    //   78: aload_1
    //   79: invokevirtual getKeyCode : ()I
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual I : (Lc/b/c/i0;ILandroid/view/KeyEvent;I)Z
    //   87: ifeq -> 108
    //   90: aload #5
    //   92: getfield J : Lc/b/c/i0;
    //   95: astore_1
    //   96: aload_1
    //   97: ifnull -> 57
    //   100: aload_1
    //   101: iconst_1
    //   102: putfield l : Z
    //   105: goto -> 57
    //   108: aload #5
    //   110: getfield J : Lc/b/c/i0;
    //   113: ifnonnull -> 162
    //   116: aload #5
    //   118: iconst_0
    //   119: invokevirtual C : (I)Lc/b/c/i0;
    //   122: astore #6
    //   124: aload #5
    //   126: aload #6
    //   128: aload_1
    //   129: invokevirtual J : (Lc/b/c/i0;Landroid/view/KeyEvent;)Z
    //   132: pop
    //   133: aload #5
    //   135: aload #6
    //   137: aload_1
    //   138: invokevirtual getKeyCode : ()I
    //   141: aload_1
    //   142: iconst_1
    //   143: invokevirtual I : (Lc/b/c/i0;ILandroid/view/KeyEvent;I)Z
    //   146: istore #4
    //   148: aload #6
    //   150: iconst_0
    //   151: putfield k : Z
    //   154: iload #4
    //   156: ifeq -> 162
    //   159: goto -> 57
    //   162: iconst_0
    //   163: istore_2
    //   164: iload_2
    //   165: ifeq -> 170
    //   168: iconst_1
    //   169: istore_3
    //   170: iload_3
    //   171: ireturn
  }
  
  public void onContentChanged() {}
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return (paramInt == 0 && !(paramMenu instanceof l)) ? false : this.e.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    this.e.onMenuOpened(paramInt, paramMenu);
    k0 k01 = this.f;
    Objects.requireNonNull(k01);
    if (paramInt == 108) {
      k01.E();
      a a = k01.l;
      if (a != null)
        a.c(true); 
    } 
    return true;
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    a a;
    this.e.onPanelClosed(paramInt, paramMenu);
    k0 k01 = this.f;
    Objects.requireNonNull(k01);
    if (paramInt == 108) {
      k01.E();
      a = k01.l;
      if (a != null) {
        a.c(false);
        return;
      } 
    } else if (paramInt == 0) {
      i0 i0 = a.C(paramInt);
      if (i0.m)
        a.s(i0, false); 
    } 
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    Object object;
    if (paramMenu instanceof l) {
      object = paramMenu;
    } else {
      object = null;
    } 
    if (paramInt == 0 && object == null)
      return false; 
    if (object != null)
      ((l)object).x = true; 
    boolean bool = this.e.onPreparePanel(paramInt, paramView, paramMenu);
    if (object != null)
      ((l)object).x = false; 
    return bool;
  }
  
  public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> paramList, Menu paramMenu, int paramInt) {
    l l = (this.f.C(0)).h;
    if (l != null) {
      this.e.onProvideKeyboardShortcuts(paramList, (Menu)l, paramInt);
      return;
    } 
    this.e.onProvideKeyboardShortcuts(paramList, paramMenu, paramInt);
  }
  
  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback) {
    return null;
  }
  
  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback, int paramInt) {
    Objects.requireNonNull(this.f);
    return (paramInt != 0) ? this.e.onWindowStartingActionMode(paramCallback, paramInt) : a(paramCallback);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */