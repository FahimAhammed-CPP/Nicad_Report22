package c.b.c;

import android.view.View;
import androidx.appcompat.app.AlertController;

public class h implements View.OnClickListener {
  public h(AlertController paramAlertController) {}
  
  public void onClick(View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroidx/appcompat/app/AlertController;
    //   4: astore_2
    //   5: aload_1
    //   6: aload_2
    //   7: getfield o : Landroid/widget/Button;
    //   10: if_acmpne -> 30
    //   13: aload_2
    //   14: getfield q : Landroid/os/Message;
    //   17: astore_3
    //   18: aload_3
    //   19: ifnull -> 30
    //   22: aload_3
    //   23: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
    //   26: astore_1
    //   27: goto -> 82
    //   30: aload_1
    //   31: aload_2
    //   32: getfield s : Landroid/widget/Button;
    //   35: if_acmpne -> 55
    //   38: aload_2
    //   39: getfield u : Landroid/os/Message;
    //   42: astore_3
    //   43: aload_3
    //   44: ifnull -> 55
    //   47: aload_3
    //   48: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
    //   51: astore_1
    //   52: goto -> 82
    //   55: aload_1
    //   56: aload_2
    //   57: getfield w : Landroid/widget/Button;
    //   60: if_acmpne -> 80
    //   63: aload_2
    //   64: getfield y : Landroid/os/Message;
    //   67: astore_1
    //   68: aload_1
    //   69: ifnull -> 80
    //   72: aload_1
    //   73: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
    //   76: astore_1
    //   77: goto -> 82
    //   80: aconst_null
    //   81: astore_1
    //   82: aload_1
    //   83: ifnull -> 90
    //   86: aload_1
    //   87: invokevirtual sendToTarget : ()V
    //   90: aload_0
    //   91: getfield e : Landroidx/appcompat/app/AlertController;
    //   94: astore_1
    //   95: aload_1
    //   96: getfield Q : Landroid/os/Handler;
    //   99: iconst_1
    //   100: aload_1
    //   101: getfield b : Lc/b/c/o;
    //   104: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
    //   107: invokevirtual sendToTarget : ()V
    //   110: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */