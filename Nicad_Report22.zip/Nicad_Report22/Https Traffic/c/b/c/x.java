package c.b.c;

import android.view.View;
import c.h.j.a0;
import c.h.j.u;
import java.util.concurrent.atomic.AtomicInteger;

public class x extends a0 {
  public x(k0 paramk0) {}
  
  public void b(View paramView) {
    this.a.s.setAlpha(1.0F);
    this.a.v.d(null);
    this.a.v = null;
  }
  
  public void c(View paramView) {
    this.a.s.setVisibility(0);
    this.a.s.sendAccessibilityEvent(32);
    if (this.a.s.getParent() instanceof View) {
      paramView = (View)this.a.s.getParent();
      AtomicInteger atomicInteger = u.a;
      paramView.requestApplyInsets();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */