package c.b.c;

import android.view.View;
import c.h.j.u;
import c.h.j.y;
import c.h.j.z;

public class w implements Runnable {
  public w(k0 paramk0) {}
  
  public void run() {
    k0 k01 = this.e;
    k01.t.showAtLocation((View)k01.s, 55, 0, 0);
    this.e.w();
    if (this.e.K()) {
      this.e.s.setAlpha(0.0F);
      k01 = this.e;
      y y2 = u.b((View)k01.s);
      y2.a(1.0F);
      k01.v = y2;
      y y1 = this.e.v;
      v v = new v(this);
      View view = y1.a.get();
      if (view != null) {
        y1.e(view, (z)v);
        return;
      } 
    } else {
      this.e.s.setAlpha(1.0F);
      this.e.s.setVisibility(0);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */