package c.b.c;

import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import c.h.j.a0;
import c.h.j.u;
import java.util.concurrent.atomic.AtomicInteger;

public class a0 extends a0 {
  public a0(b0 paramb0) {}
  
  public void b(View paramView) {
    this.a.b.s.setVisibility(8);
    k0 k0 = this.a.b;
    PopupWindow popupWindow = k0.t;
    if (popupWindow != null) {
      popupWindow.dismiss();
    } else if (k0.s.getParent() instanceof View) {
      View view = (View)this.a.b.s.getParent();
      AtomicInteger atomicInteger1 = u.a;
      view.requestApplyInsets();
    } 
    this.a.b.s.removeAllViews();
    this.a.b.v.d(null);
    k0 = this.a.b;
    k0.v = null;
    ViewGroup viewGroup = k0.x;
    AtomicInteger atomicInteger = u.a;
    viewGroup.requestApplyInsets();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */