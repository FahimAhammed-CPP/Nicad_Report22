package c.b.c;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.core.widget.NestedScrollView;
import c.b.g.a;
import c.b.g.b;
import c.e.d;
import c.h.j.d;
import c.h.j.e;
import c.h.j.u;
import java.lang.ref.WeakReference;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class o extends Dialog implements DialogInterface, q {
  public r e;
  
  public final d f = new l0(this);
  
  public final AlertController g;
  
  public o(Context paramContext, int paramInt) {
    super(paramContext, i);
    r r1 = a();
    int i = paramInt;
    if (paramInt == 0) {
      TypedValue typedValue = new TypedValue();
      paramContext.getTheme().resolveAttribute(2130903313, typedValue, true);
      i = typedValue.resourceId;
    } 
    ((k0)r1).Q = i;
    r1.f(null);
    this.g = new AlertController(getContext(), this, getWindow());
  }
  
  public static int b(Context paramContext, int paramInt) {
    if ((paramInt >>> 24 & 0xFF) >= 1)
      return paramInt; 
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(2130903081, typedValue, true);
    return typedValue.resourceId;
  }
  
  public r a() {
    if (this.e == null) {
      d<WeakReference<r>> d1 = r.e;
      this.e = new k0(getContext(), getWindow(), this, this);
    } 
    return this.e;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    a().c(paramView, paramLayoutParams);
  }
  
  public boolean c(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public void dismiss() {
    super.dismiss();
    a().g();
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return e.b(this.f, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public void f(b paramb) {}
  
  public View findViewById(int paramInt) {
    k0 k0 = (k0)a();
    k0.x();
    return k0.i.findViewById(paramInt);
  }
  
  public void g(b paramb) {}
  
  public void invalidateOptionsMenu() {
    a().e();
  }
  
  public void onCreate(Bundle paramBundle) {
    int i;
    int j;
    boolean bool1;
    a().d();
    super.onCreate(paramBundle);
    a().f(paramBundle);
    AlertController alertController = this.g;
    if (alertController.K == 0) {
      i = alertController.J;
    } else {
      i = alertController.J;
    } 
    alertController.b.setContentView(i);
    View view1 = alertController.c.findViewById(2131231030);
    View view4 = view1.findViewById(2131231152);
    View view2 = view1.findViewById(2131230844);
    View view3 = view1.findViewById(2131230818);
    ViewGroup viewGroup3 = (ViewGroup)view1.findViewById(2131230851);
    view1 = alertController.h;
    boolean bool2 = false;
    if (view1 == null)
      if (alertController.i != 0) {
        view1 = LayoutInflater.from(alertController.a).inflate(alertController.i, viewGroup3, false);
      } else {
        view1 = null;
      }  
    if (view1 != null) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 0 || !AlertController.a(view1))
      alertController.c.setFlags(131072, 131072); 
    if (i != 0) {
      FrameLayout frameLayout = (FrameLayout)alertController.c.findViewById(2131230850);
      frameLayout.addView(view1, new ViewGroup.LayoutParams(-1, -1));
      if (alertController.n)
        frameLayout.setPadding(alertController.j, alertController.k, alertController.l, alertController.m); 
      if (alertController.g != null)
        ((LinearLayoutCompat.a)viewGroup3.getLayoutParams()).a = 0.0F; 
    } else {
      viewGroup3.setVisibility(8);
    } 
    view1 = viewGroup3.findViewById(2131231152);
    View view6 = viewGroup3.findViewById(2131230844);
    View view5 = viewGroup3.findViewById(2131230818);
    ViewGroup viewGroup1 = alertController.d(view1, view4);
    ViewGroup viewGroup2 = alertController.d(view6, view2);
    ViewGroup viewGroup4 = alertController.d(view5, view3);
    NestedScrollView nestedScrollView = (NestedScrollView)alertController.c.findViewById(2131231062);
    alertController.A = nestedScrollView;
    nestedScrollView.setFocusable(false);
    alertController.A.setNestedScrollingEnabled(false);
    TextView textView = (TextView)viewGroup2.findViewById(16908299);
    alertController.F = textView;
    if (textView != null) {
      CharSequence charSequence = alertController.f;
      if (charSequence != null) {
        textView.setText(charSequence);
      } else {
        textView.setVisibility(8);
        alertController.A.removeView((View)alertController.F);
        if (alertController.g != null) {
          ViewGroup viewGroup = (ViewGroup)alertController.A.getParent();
          i = viewGroup.indexOfChild((View)alertController.A);
          viewGroup.removeViewAt(i);
          viewGroup.addView((View)alertController.g, i, new ViewGroup.LayoutParams(-1, -1));
        } else {
          viewGroup2.setVisibility(8);
        } 
      } 
    } 
    Button button = (Button)viewGroup4.findViewById(16908313);
    alertController.o = button;
    button.setOnClickListener(alertController.R);
    if (TextUtils.isEmpty(alertController.p) && alertController.r == null) {
      alertController.o.setVisibility(8);
      i = 0;
    } else {
      alertController.o.setText(alertController.p);
      Drawable drawable = alertController.r;
      if (drawable != null) {
        i = alertController.d;
        drawable.setBounds(0, 0, i, i);
        alertController.o.setCompoundDrawables(alertController.r, null, null, null);
      } 
      alertController.o.setVisibility(0);
      i = 1;
    } 
    button = (Button)viewGroup4.findViewById(16908314);
    alertController.s = button;
    button.setOnClickListener(alertController.R);
    if (TextUtils.isEmpty(alertController.t) && alertController.v == null) {
      alertController.s.setVisibility(8);
    } else {
      alertController.s.setText(alertController.t);
      Drawable drawable = alertController.v;
      if (drawable != null) {
        j = alertController.d;
        drawable.setBounds(0, 0, j, j);
        alertController.s.setCompoundDrawables(alertController.v, null, null, null);
      } 
      alertController.s.setVisibility(0);
      i |= 0x2;
    } 
    button = (Button)viewGroup4.findViewById(16908315);
    alertController.w = button;
    button.setOnClickListener(alertController.R);
    if (TextUtils.isEmpty(alertController.x) && alertController.z == null) {
      alertController.w.setVisibility(8);
    } else {
      alertController.w.setText(alertController.x);
      Drawable drawable = alertController.z;
      if (drawable != null) {
        j = alertController.d;
        drawable.setBounds(0, 0, j, j);
        alertController.w.setCompoundDrawables(alertController.z, null, null, null);
      } 
      alertController.w.setVisibility(0);
      i |= 0x4;
    } 
    Context context = alertController.a;
    TypedValue typedValue = new TypedValue();
    context.getTheme().resolveAttribute(2130903079, typedValue, true);
    if (typedValue.data != 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j)
      if (i == 1) {
        alertController.b(alertController.o);
      } else if (i == 2) {
        alertController.b(alertController.s);
      } else if (i == 4) {
        alertController.b(alertController.w);
      }  
    if (i != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i == 0)
      viewGroup4.setVisibility(8); 
    if (alertController.G != null) {
      ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -2);
      viewGroup1.addView(alertController.G, 0, layoutParams);
      alertController.c.findViewById(2131231147).setVisibility(8);
    } else {
      alertController.D = (ImageView)alertController.c.findViewById(16908294);
      if ((TextUtils.isEmpty(alertController.e) ^ true) != 0 && alertController.P) {
        TextView textView1 = (TextView)alertController.c.findViewById(2131230792);
        alertController.E = textView1;
        textView1.setText(alertController.e);
        i = alertController.B;
        if (i != 0) {
          alertController.D.setImageResource(i);
        } else {
          Drawable drawable = alertController.C;
          if (drawable != null) {
            alertController.D.setImageDrawable(drawable);
          } else {
            alertController.E.setPadding(alertController.D.getPaddingLeft(), alertController.D.getPaddingTop(), alertController.D.getPaddingRight(), alertController.D.getPaddingBottom());
            alertController.D.setVisibility(8);
          } 
        } 
      } else {
        alertController.c.findViewById(2131231147).setVisibility(8);
        alertController.D.setVisibility(8);
        viewGroup1.setVisibility(8);
      } 
    } 
    if (viewGroup3.getVisibility() != 8) {
      i = 1;
    } else {
      i = 0;
    } 
    if (viewGroup1 != null && viewGroup1.getVisibility() != 8) {
      j = 1;
    } else {
      j = 0;
    } 
    if (viewGroup4.getVisibility() != 8) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (!bool1) {
      View view = viewGroup2.findViewById(2131231131);
      if (view != null)
        view.setVisibility(0); 
    } 
    if (j) {
      NestedScrollView nestedScrollView1 = alertController.A;
      if (nestedScrollView1 != null)
        nestedScrollView1.setClipToPadding(true); 
      if (alertController.f != null || alertController.g != null) {
        View view = viewGroup1.findViewById(2131231146);
      } else {
        viewGroup1 = null;
      } 
      if (viewGroup1 != null)
        viewGroup1.setVisibility(0); 
    } else {
      View view = viewGroup2.findViewById(2131231132);
      if (view != null)
        view.setVisibility(0); 
    } 
    ListView listView = alertController.g;
    if (listView instanceof AlertController.RecycleListView) {
      AlertController.RecycleListView recycleListView = (AlertController.RecycleListView)listView;
      Objects.requireNonNull(recycleListView);
      if (!bool1 || !j) {
        int k;
        int m;
        int n = recycleListView.getPaddingLeft();
        if (j) {
          k = recycleListView.getPaddingTop();
        } else {
          k = recycleListView.e;
        } 
        int i1 = recycleListView.getPaddingRight();
        if (bool1) {
          m = recycleListView.getPaddingBottom();
        } else {
          m = recycleListView.f;
        } 
        recycleListView.setPadding(n, k, i1, m);
      } 
    } 
    if (i == 0) {
      NestedScrollView nestedScrollView1;
      listView = alertController.g;
      if (listView == null)
        nestedScrollView1 = alertController.A; 
      if (nestedScrollView1 != null) {
        i = bool2;
        if (bool1)
          i = 2; 
        View view7 = alertController.c.findViewById(2131231061);
        View view8 = alertController.c.findViewById(2131231060);
        AtomicInteger atomicInteger = u.a;
        nestedScrollView1.setScrollIndicators(j | i, 3);
        if (view7 != null)
          viewGroup2.removeView(view7); 
        if (view8 != null)
          viewGroup2.removeView(view8); 
      } 
    } 
    listView = alertController.g;
    if (listView != null) {
      ListAdapter listAdapter = alertController.H;
      if (listAdapter != null) {
        listView.setAdapter(listAdapter);
        i = alertController.I;
        if (i > -1) {
          listView.setItemChecked(i, true);
          listView.setSelection(i);
        } 
      } 
    } 
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    NestedScrollView nestedScrollView = this.g.A;
    if (nestedScrollView != null && nestedScrollView.o(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    NestedScrollView nestedScrollView = this.g.A;
    if (nestedScrollView != null && nestedScrollView.o(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool ? true : super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public void onStop() {
    super.onStop();
    k0 k0 = (k0)a();
    k0.N = false;
    k0.E();
    a a = k0.l;
    if (a != null)
      a.o(false); 
  }
  
  public void setContentView(int paramInt) {
    a().j(paramInt);
  }
  
  public void setContentView(View paramView) {
    a().k(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    a().l(paramView, paramLayoutParams);
  }
  
  public void setTitle(int paramInt) {
    super.setTitle(paramInt);
    a().m(getContext().getString(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    a().m(paramCharSequence);
    AlertController alertController = this.g;
    alertController.e = paramCharSequence;
    TextView textView = alertController.E;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */