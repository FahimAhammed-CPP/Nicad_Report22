package c.b.c;

import android.content.IntentFilter;

public class g0 extends f0 {
  public final w0 c;
  
  public g0(k0 paramk0, w0 paramw0) {
    super(paramk0);
    this.c = paramw0;
  }
  
  public IntentFilter b() {
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.intent.action.TIME_SET");
    intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
    intentFilter.addAction("android.intent.action.TIME_TICK");
    return intentFilter;
  }
  
  public int c() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Lc/b/c/w0;
    //   4: astore #16
    //   6: aload #16
    //   8: getfield c : Lc/b/c/v0;
    //   11: astore #15
    //   13: aload #15
    //   15: getfield b : J
    //   18: lstore_3
    //   19: invokestatic currentTimeMillis : ()J
    //   22: lstore #5
    //   24: iconst_1
    //   25: istore_2
    //   26: lload_3
    //   27: lload #5
    //   29: lcmp
    //   30: ifle -> 38
    //   33: iconst_1
    //   34: istore_1
    //   35: goto -> 40
    //   38: iconst_0
    //   39: istore_1
    //   40: iload_1
    //   41: ifeq -> 54
    //   44: aload #15
    //   46: getfield a : Z
    //   49: istore #11
    //   51: goto -> 420
    //   54: aload #16
    //   56: getfield a : Landroid/content/Context;
    //   59: ldc 'android.permission.ACCESS_COARSE_LOCATION'
    //   61: invokestatic i : (Landroid/content/Context;Ljava/lang/String;)I
    //   64: istore_1
    //   65: aconst_null
    //   66: astore #13
    //   68: iload_1
    //   69: ifne -> 84
    //   72: aload #16
    //   74: ldc 'network'
    //   76: invokevirtual a : (Ljava/lang/String;)Landroid/location/Location;
    //   79: astore #12
    //   81: goto -> 87
    //   84: aconst_null
    //   85: astore #12
    //   87: aload #16
    //   89: getfield a : Landroid/content/Context;
    //   92: ldc 'android.permission.ACCESS_FINE_LOCATION'
    //   94: invokestatic i : (Landroid/content/Context;Ljava/lang/String;)I
    //   97: ifne -> 109
    //   100: aload #16
    //   102: ldc 'gps'
    //   104: invokevirtual a : (Ljava/lang/String;)Landroid/location/Location;
    //   107: astore #13
    //   109: aload #13
    //   111: ifnull -> 140
    //   114: aload #12
    //   116: ifnull -> 140
    //   119: aload #12
    //   121: astore #14
    //   123: aload #13
    //   125: invokevirtual getTime : ()J
    //   128: aload #12
    //   130: invokevirtual getTime : ()J
    //   133: lcmp
    //   134: ifle -> 153
    //   137: goto -> 149
    //   140: aload #12
    //   142: astore #14
    //   144: aload #13
    //   146: ifnull -> 153
    //   149: aload #13
    //   151: astore #14
    //   153: aload #14
    //   155: ifnull -> 379
    //   158: aload #16
    //   160: getfield c : Lc/b/c/v0;
    //   163: astore #12
    //   165: invokestatic currentTimeMillis : ()J
    //   168: lstore_3
    //   169: getstatic c/b/c/u0.d : Lc/b/c/u0;
    //   172: ifnonnull -> 185
    //   175: new c/b/c/u0
    //   178: dup
    //   179: invokespecial <init> : ()V
    //   182: putstatic c/b/c/u0.d : Lc/b/c/u0;
    //   185: getstatic c/b/c/u0.d : Lc/b/c/u0;
    //   188: astore #13
    //   190: aload #13
    //   192: lload_3
    //   193: ldc2_w 86400000
    //   196: lsub
    //   197: aload #14
    //   199: invokevirtual getLatitude : ()D
    //   202: aload #14
    //   204: invokevirtual getLongitude : ()D
    //   207: invokevirtual a : (JDD)V
    //   210: aload #13
    //   212: lload_3
    //   213: aload #14
    //   215: invokevirtual getLatitude : ()D
    //   218: aload #14
    //   220: invokevirtual getLongitude : ()D
    //   223: invokevirtual a : (JDD)V
    //   226: aload #13
    //   228: getfield c : I
    //   231: iconst_1
    //   232: if_icmpne -> 241
    //   235: iconst_1
    //   236: istore #11
    //   238: goto -> 244
    //   241: iconst_0
    //   242: istore #11
    //   244: aload #13
    //   246: getfield b : J
    //   249: lstore #5
    //   251: aload #13
    //   253: getfield a : J
    //   256: lstore #7
    //   258: aload #13
    //   260: lload_3
    //   261: ldc2_w 86400000
    //   264: ladd
    //   265: aload #14
    //   267: invokevirtual getLatitude : ()D
    //   270: aload #14
    //   272: invokevirtual getLongitude : ()D
    //   275: invokevirtual a : (JDD)V
    //   278: aload #13
    //   280: getfield b : J
    //   283: lstore #9
    //   285: lload #5
    //   287: ldc2_w -1
    //   290: lcmp
    //   291: ifeq -> 350
    //   294: lload #7
    //   296: ldc2_w -1
    //   299: lcmp
    //   300: ifne -> 306
    //   303: goto -> 350
    //   306: lload_3
    //   307: lload #7
    //   309: lcmp
    //   310: ifle -> 321
    //   313: lload #9
    //   315: lconst_0
    //   316: ladd
    //   317: lstore_3
    //   318: goto -> 341
    //   321: lload_3
    //   322: lload #5
    //   324: lcmp
    //   325: ifle -> 336
    //   328: lload #7
    //   330: lconst_0
    //   331: ladd
    //   332: lstore_3
    //   333: goto -> 341
    //   336: lload #5
    //   338: lconst_0
    //   339: ladd
    //   340: lstore_3
    //   341: lload_3
    //   342: ldc2_w 60000
    //   345: ladd
    //   346: lstore_3
    //   347: goto -> 356
    //   350: lload_3
    //   351: ldc2_w 43200000
    //   354: ladd
    //   355: lstore_3
    //   356: aload #12
    //   358: iload #11
    //   360: putfield a : Z
    //   363: aload #12
    //   365: lload_3
    //   366: putfield b : J
    //   369: aload #15
    //   371: getfield a : Z
    //   374: istore #11
    //   376: goto -> 420
    //   379: ldc 'TwilightManager'
    //   381: ldc 'Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.'
    //   383: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   386: pop
    //   387: invokestatic getInstance : ()Ljava/util/Calendar;
    //   390: bipush #11
    //   392: invokevirtual get : (I)I
    //   395: istore_1
    //   396: iload_1
    //   397: bipush #6
    //   399: if_icmplt -> 417
    //   402: iload_1
    //   403: bipush #22
    //   405: if_icmplt -> 411
    //   408: goto -> 417
    //   411: iconst_0
    //   412: istore #11
    //   414: goto -> 420
    //   417: iconst_1
    //   418: istore #11
    //   420: iload_2
    //   421: istore_1
    //   422: iload #11
    //   424: ifeq -> 429
    //   427: iconst_2
    //   428: istore_1
    //   429: iload_1
    //   430: ireturn
  }
  
  public void d() {
    this.d.n();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */