package c.b.c;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.widget.ActionMenuView;
import c.b.g.n.l;
import c.b.g.n.y;
import c.b.h.m;
import c.b.h.n2;

public final class q0 implements y.a {
  public boolean e;
  
  public q0(t0 paramt0) {}
  
  public void a(l paraml, boolean paramBoolean) {
    if (this.e)
      return; 
    this.e = true;
    ActionMenuView actionMenuView = ((n2)this.f.a).a.e;
    if (actionMenuView != null) {
      m m = actionMenuView.x;
      if (m != null)
        m.b(); 
    } 
    Window.Callback callback = this.f.c;
    if (callback != null)
      callback.onPanelClosed(108, (Menu)paraml); 
    this.e = false;
  }
  
  public boolean b(l paraml) {
    Window.Callback callback = this.f.c;
    if (callback != null) {
      callback.onMenuOpened(108, (Menu)paraml);
      return true;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\q0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */