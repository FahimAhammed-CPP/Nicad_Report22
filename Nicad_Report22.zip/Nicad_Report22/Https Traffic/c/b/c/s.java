package c.b.c;

public class s implements Runnable {
  public s(k0 paramk0) {}
  
  public void run() {
    k0 k01 = this.e;
    if ((k01.W & 0x1) != 0)
      k01.v(0); 
    k01 = this.e;
    if ((k01.W & 0x1000) != 0)
      k01.v(108); 
    k01 = this.e;
    k01.V = false;
    k01.W = 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */