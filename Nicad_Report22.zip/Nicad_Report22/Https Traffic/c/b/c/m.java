package c.b.c;

import android.content.Context;
import android.widget.ArrayAdapter;

public class m extends ArrayAdapter<CharSequence> {
  public m(Context paramContext, int paramInt1, int paramInt2, CharSequence[] paramArrayOfCharSequence) {
    super(paramContext, paramInt1, paramInt2, null);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public boolean hasStableIds() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */