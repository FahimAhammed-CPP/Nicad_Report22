package c.b.c;

import android.view.View;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import c.b.g.a;
import c.h.j.a0;
import c.h.j.u;
import java.util.concurrent.atomic.AtomicInteger;

public class x0 extends a0 {
  public x0(b1 paramb1) {}
  
  public void b(View paramView) {
    b1 b11 = this.a;
    if (b11.p) {
      View view = b11.g;
      if (view != null) {
        view.setTranslationY(0.0F);
        this.a.d.setTranslationY(0.0F);
      } 
    } 
    this.a.d.setVisibility(8);
    this.a.d.setTransitioning(false);
    b11 = this.a;
    b11.t = null;
    a a = b11.k;
    if (a != null) {
      a.b(b11.j);
      b11.j = null;
      b11.k = null;
    } 
    ActionBarOverlayLayout actionBarOverlayLayout = this.a.c;
    if (actionBarOverlayLayout != null) {
      AtomicInteger atomicInteger = u.a;
      actionBarOverlayLayout.requestApplyInsets();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\c\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */