package c.b.g;

import android.view.Menu;
import android.view.MenuItem;

public interface a {
  boolean a(b paramb, Menu paramMenu);
  
  void b(b paramb);
  
  boolean c(b paramb, MenuItem paramMenuItem);
  
  boolean d(b paramb, Menu paramMenu);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */