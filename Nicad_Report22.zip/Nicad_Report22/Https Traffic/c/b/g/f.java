package c.b.g;

import android.content.Context;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import c.b.g.n.a0;
import c.b.g.n.u;
import c.e.i;
import c.h.e.a.a;
import c.h.e.a.b;
import java.util.ArrayList;

public class f implements a {
  public final ActionMode.Callback a;
  
  public final Context b;
  
  public final ArrayList<g> c;
  
  public final i<Menu, Menu> d;
  
  public f(Context paramContext, ActionMode.Callback paramCallback) {
    this.b = paramContext;
    this.a = paramCallback;
    this.c = new ArrayList<g>();
    this.d = new i();
  }
  
  public boolean a(b paramb, Menu paramMenu) {
    return this.a.onPrepareActionMode(e(paramb), f(paramMenu));
  }
  
  public void b(b paramb) {
    this.a.onDestroyActionMode(e(paramb));
  }
  
  public boolean c(b paramb, MenuItem paramMenuItem) {
    return this.a.onActionItemClicked(e(paramb), (MenuItem)new u(this.b, (b)paramMenuItem));
  }
  
  public boolean d(b paramb, Menu paramMenu) {
    return this.a.onCreateActionMode(e(paramb), f(paramMenu));
  }
  
  public ActionMode e(b paramb) {
    int k = this.c.size();
    for (int j = 0; j < k; j++) {
      g g1 = this.c.get(j);
      if (g1 != null && g1.b == paramb)
        return g1; 
    } 
    g g = new g(this.b, paramb);
    this.c.add(g);
    return g;
  }
  
  public final Menu f(Menu paramMenu) {
    a0 a0;
    Menu menu2 = (Menu)this.d.getOrDefault(paramMenu, null);
    Menu menu1 = menu2;
    if (menu2 == null) {
      a0 = new a0(this.b, (a)paramMenu);
      this.d.put(paramMenu, a0);
    } 
    return (Menu)a0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */