package c.b.g;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import c.b.g.n.o;
import c.b.g.n.p;
import c.b.g.n.u;
import c.h.e.a.b;
import java.lang.reflect.Constructor;

public class i {
  public p A;
  
  public CharSequence B;
  
  public CharSequence C;
  
  public ColorStateList D = null;
  
  public PorterDuff.Mode E = null;
  
  public Menu a;
  
  public int b;
  
  public int c;
  
  public int d;
  
  public int e;
  
  public boolean f;
  
  public boolean g;
  
  public boolean h;
  
  public int i;
  
  public int j;
  
  public CharSequence k;
  
  public CharSequence l;
  
  public int m;
  
  public char n;
  
  public int o;
  
  public char p;
  
  public int q;
  
  public int r;
  
  public boolean s;
  
  public boolean t;
  
  public boolean u;
  
  public int v;
  
  public int w;
  
  public String x;
  
  public String y;
  
  public String z;
  
  public i(j paramj, Menu paramMenu) {
    this.a = paramMenu;
    this.b = 0;
    this.c = 0;
    this.d = 0;
    this.e = 0;
    this.f = true;
    this.g = true;
  }
  
  public SubMenu a() {
    this.h = true;
    SubMenu subMenu = this.a.addSubMenu(this.b, this.i, this.j, this.k);
    c(subMenu.getItem());
    return subMenu;
  }
  
  public final <T> T b(String paramString, Class<?>[] paramArrayOfClass, Object[] paramArrayOfObject) {
    try {
      null = Class.forName(paramString, false, this.F.c.getClassLoader()).getConstructor(paramArrayOfClass);
      null.setAccessible(true);
      return (T)null.newInstance(paramArrayOfObject);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot instantiate class: ");
      stringBuilder.append(paramString);
      Log.w("SupportMenuInflater", stringBuilder.toString(), exception);
      return null;
    } 
  }
  
  public final void c(MenuItem paramMenuItem) {
    MenuItem menuItem = paramMenuItem.setChecked(this.s).setVisible(this.t).setEnabled(this.u);
    int m = this.r;
    int k = 0;
    if (m >= 1) {
      bool = true;
    } else {
      bool = false;
    } 
    menuItem.setCheckable(bool).setTitleCondensed(this.l).setIcon(this.m);
    m = this.v;
    if (m >= 0)
      paramMenuItem.setShowAsAction(m); 
    if (this.z != null)
      if (!this.F.c.isRestricted()) {
        j j1 = this.F;
        if (j1.d == null)
          j1.d = j1.a(j1.c); 
        paramMenuItem.setOnMenuItemClickListener(new h(j1.d, this.z));
      } else {
        throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
      }  
    if (this.r >= 2)
      if (paramMenuItem instanceof o) {
        ((o)paramMenuItem).k(true);
      } else if (paramMenuItem instanceof u) {
        u u = (u)paramMenuItem;
        try {
          if (u.d == null)
            u.d = u.c.getClass().getDeclaredMethod("setExclusiveCheckable", new Class[] { boolean.class }); 
          u.d.invoke(u.c, new Object[] { Boolean.TRUE });
        } catch (Exception exception) {
          Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", exception);
        } 
      }  
    String str = this.x;
    if (str != null) {
      paramMenuItem.setActionView(b(str, j.e, this.F.a));
      k = 1;
    } 
    m = this.w;
    if (m > 0)
      if (!k) {
        paramMenuItem.setActionView(m);
      } else {
        Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
      }  
    p p1 = this.A;
    if (p1 != null)
      if (paramMenuItem instanceof b) {
        ((b)paramMenuItem).b(p1);
      } else {
        Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
      }  
    CharSequence charSequence = this.B;
    boolean bool = paramMenuItem instanceof b;
    if (bool) {
      ((b)paramMenuItem).setContentDescription(charSequence);
    } else if (Build.VERSION.SDK_INT >= 26) {
      paramMenuItem.setContentDescription(charSequence);
    } 
    charSequence = this.C;
    if (bool) {
      ((b)paramMenuItem).setTooltipText(charSequence);
    } else if (Build.VERSION.SDK_INT >= 26) {
      paramMenuItem.setTooltipText(charSequence);
    } 
    char c = this.n;
    k = this.o;
    if (bool) {
      ((b)paramMenuItem).setAlphabeticShortcut(c, k);
    } else if (Build.VERSION.SDK_INT >= 26) {
      paramMenuItem.setAlphabeticShortcut(c, k);
    } 
    c = this.p;
    k = this.q;
    if (bool) {
      ((b)paramMenuItem).setNumericShortcut(c, k);
    } else if (Build.VERSION.SDK_INT >= 26) {
      paramMenuItem.setNumericShortcut(c, k);
    } 
    PorterDuff.Mode mode = this.E;
    if (mode != null)
      if (bool) {
        ((b)paramMenuItem).setIconTintMode(mode);
      } else if (Build.VERSION.SDK_INT >= 26) {
        paramMenuItem.setIconTintMode(mode);
      }  
    ColorStateList colorStateList = this.D;
    if (colorStateList != null) {
      if (bool) {
        ((b)paramMenuItem).setIconTintList(colorStateList);
        return;
      } 
      if (Build.VERSION.SDK_INT >= 26)
        paramMenuItem.setIconTintList(colorStateList); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */