package c.b.g.n;

import android.view.CollapsibleActionView;
import android.view.View;
import android.widget.FrameLayout;
import c.b.g.c;

public class r extends FrameLayout implements c {
  public final CollapsibleActionView e;
  
  public r(View paramView) {
    super(paramView.getContext());
    this.e = (CollapsibleActionView)paramView;
    addView(paramView);
  }
  
  public void c() {
    this.e.onActionViewExpanded();
  }
  
  public void d() {
    this.e.onActionViewCollapsed();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */