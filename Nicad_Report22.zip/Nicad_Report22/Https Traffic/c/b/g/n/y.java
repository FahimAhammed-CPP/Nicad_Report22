package c.b.g.n;

import android.content.Context;
import android.os.Parcelable;

public interface y {
  void a(l paraml, boolean paramBoolean);
  
  void c(Context paramContext, l paraml);
  
  void e(Parcelable paramParcelable);
  
  boolean f(f0 paramf0);
  
  int getId();
  
  void h(boolean paramBoolean);
  
  boolean i();
  
  Parcelable j();
  
  boolean k(l paraml, o paramo);
  
  boolean l(l paraml, o paramo);
  
  void m(a parama);
  
  public static interface a {
    void a(l param1l, boolean param1Boolean);
    
    boolean b(l param1l);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */