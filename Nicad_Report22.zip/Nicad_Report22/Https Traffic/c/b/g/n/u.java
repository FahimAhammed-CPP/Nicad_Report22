package c.b.g.n;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import c.h.e.a.b;
import java.lang.reflect.Method;

public class u extends b implements MenuItem {
  public final b c;
  
  public Method d;
  
  public u(Context paramContext, b paramb) {
    super(paramContext);
    if (paramb != null) {
      this.c = paramb;
      return;
    } 
    throw new IllegalArgumentException("Wrapped Object can not be null.");
  }
  
  public boolean collapseActionView() {
    return this.c.collapseActionView();
  }
  
  public boolean expandActionView() {
    return this.c.expandActionView();
  }
  
  public ActionProvider getActionProvider() {
    p p = this.c.a();
    return (p instanceof p) ? p.b : null;
  }
  
  public View getActionView() {
    View view2 = this.c.getActionView();
    View view1 = view2;
    if (view2 instanceof r)
      view1 = (View)((r)view2).e; 
    return view1;
  }
  
  public int getAlphabeticModifiers() {
    return this.c.getAlphabeticModifiers();
  }
  
  public char getAlphabeticShortcut() {
    return this.c.getAlphabeticShortcut();
  }
  
  public CharSequence getContentDescription() {
    return this.c.getContentDescription();
  }
  
  public int getGroupId() {
    return this.c.getGroupId();
  }
  
  public Drawable getIcon() {
    return this.c.getIcon();
  }
  
  public ColorStateList getIconTintList() {
    return this.c.getIconTintList();
  }
  
  public PorterDuff.Mode getIconTintMode() {
    return this.c.getIconTintMode();
  }
  
  public Intent getIntent() {
    return this.c.getIntent();
  }
  
  public int getItemId() {
    return this.c.getItemId();
  }
  
  public ContextMenu.ContextMenuInfo getMenuInfo() {
    return this.c.getMenuInfo();
  }
  
  public int getNumericModifiers() {
    return this.c.getNumericModifiers();
  }
  
  public char getNumericShortcut() {
    return this.c.getNumericShortcut();
  }
  
  public int getOrder() {
    return this.c.getOrder();
  }
  
  public SubMenu getSubMenu() {
    return this.c.getSubMenu();
  }
  
  public CharSequence getTitle() {
    return this.c.getTitle();
  }
  
  public CharSequence getTitleCondensed() {
    return this.c.getTitleCondensed();
  }
  
  public CharSequence getTooltipText() {
    return this.c.getTooltipText();
  }
  
  public boolean hasSubMenu() {
    return this.c.hasSubMenu();
  }
  
  public boolean isActionViewExpanded() {
    return this.c.isActionViewExpanded();
  }
  
  public boolean isCheckable() {
    return this.c.isCheckable();
  }
  
  public boolean isChecked() {
    return this.c.isChecked();
  }
  
  public boolean isEnabled() {
    return this.c.isEnabled();
  }
  
  public boolean isVisible() {
    return this.c.isVisible();
  }
  
  public MenuItem setActionProvider(ActionProvider paramActionProvider) {
    q q = new q(this, this.a, paramActionProvider);
    b b1 = this.c;
    if (paramActionProvider != null) {
      q q1 = q;
    } else {
      paramActionProvider = null;
    } 
    b1.b((p)paramActionProvider);
    return this;
  }
  
  public MenuItem setActionView(int paramInt) {
    this.c.setActionView(paramInt);
    View view = this.c.getActionView();
    if (view instanceof android.view.CollapsibleActionView)
      this.c.setActionView((View)new r(view)); 
    return this;
  }
  
  public MenuItem setActionView(View paramView) {
    r r;
    View view = paramView;
    if (paramView instanceof android.view.CollapsibleActionView)
      r = new r(paramView); 
    this.c.setActionView((View)r);
    return this;
  }
  
  public MenuItem setAlphabeticShortcut(char paramChar) {
    this.c.setAlphabeticShortcut(paramChar);
    return this;
  }
  
  public MenuItem setAlphabeticShortcut(char paramChar, int paramInt) {
    this.c.setAlphabeticShortcut(paramChar, paramInt);
    return this;
  }
  
  public MenuItem setCheckable(boolean paramBoolean) {
    this.c.setCheckable(paramBoolean);
    return this;
  }
  
  public MenuItem setChecked(boolean paramBoolean) {
    this.c.setChecked(paramBoolean);
    return this;
  }
  
  public MenuItem setContentDescription(CharSequence paramCharSequence) {
    this.c.setContentDescription(paramCharSequence);
    return this;
  }
  
  public MenuItem setEnabled(boolean paramBoolean) {
    this.c.setEnabled(paramBoolean);
    return this;
  }
  
  public MenuItem setIcon(int paramInt) {
    this.c.setIcon(paramInt);
    return this;
  }
  
  public MenuItem setIcon(Drawable paramDrawable) {
    this.c.setIcon(paramDrawable);
    return this;
  }
  
  public MenuItem setIconTintList(ColorStateList paramColorStateList) {
    this.c.setIconTintList(paramColorStateList);
    return this;
  }
  
  public MenuItem setIconTintMode(PorterDuff.Mode paramMode) {
    this.c.setIconTintMode(paramMode);
    return this;
  }
  
  public MenuItem setIntent(Intent paramIntent) {
    this.c.setIntent(paramIntent);
    return this;
  }
  
  public MenuItem setNumericShortcut(char paramChar) {
    this.c.setNumericShortcut(paramChar);
    return this;
  }
  
  public MenuItem setNumericShortcut(char paramChar, int paramInt) {
    this.c.setNumericShortcut(paramChar, paramInt);
    return this;
  }
  
  public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener paramOnActionExpandListener) {
    b b1 = this.c;
    if (paramOnActionExpandListener != null) {
      paramOnActionExpandListener = new s(this, paramOnActionExpandListener);
    } else {
      paramOnActionExpandListener = null;
    } 
    b1.setOnActionExpandListener(paramOnActionExpandListener);
    return this;
  }
  
  public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener paramOnMenuItemClickListener) {
    b b1 = this.c;
    if (paramOnMenuItemClickListener != null) {
      paramOnMenuItemClickListener = new t(this, paramOnMenuItemClickListener);
    } else {
      paramOnMenuItemClickListener = null;
    } 
    b1.setOnMenuItemClickListener(paramOnMenuItemClickListener);
    return this;
  }
  
  public MenuItem setShortcut(char paramChar1, char paramChar2) {
    this.c.setShortcut(paramChar1, paramChar2);
    return this;
  }
  
  public MenuItem setShortcut(char paramChar1, char paramChar2, int paramInt1, int paramInt2) {
    this.c.setShortcut(paramChar1, paramChar2, paramInt1, paramInt2);
    return this;
  }
  
  public void setShowAsAction(int paramInt) {
    this.c.setShowAsAction(paramInt);
  }
  
  public MenuItem setShowAsActionFlags(int paramInt) {
    this.c.setShowAsActionFlags(paramInt);
    return this;
  }
  
  public MenuItem setTitle(int paramInt) {
    this.c.setTitle(paramInt);
    return this;
  }
  
  public MenuItem setTitle(CharSequence paramCharSequence) {
    this.c.setTitle(paramCharSequence);
    return this;
  }
  
  public MenuItem setTitleCondensed(CharSequence paramCharSequence) {
    this.c.setTitleCondensed(paramCharSequence);
    return this;
  }
  
  public MenuItem setTooltipText(CharSequence paramCharSequence) {
    this.c.setTooltipText(paramCharSequence);
    return this;
  }
  
  public MenuItem setVisible(boolean paramBoolean) {
    return this.c.setVisible(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */