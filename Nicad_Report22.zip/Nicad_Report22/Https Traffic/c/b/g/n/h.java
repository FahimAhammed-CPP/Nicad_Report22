package c.b.g.n;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.os.Parcelable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import c.b.h.q1;
import c.b.h.r1;
import c.h.j.u;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public final class h extends v implements y, View.OnKeyListener, PopupWindow.OnDismissListener {
  public boolean A;
  
  public y.a B;
  
  public ViewTreeObserver C;
  
  public PopupWindow.OnDismissListener D;
  
  public boolean E;
  
  public final Context f;
  
  public final int g;
  
  public final int h;
  
  public final int i;
  
  public final boolean j;
  
  public final Handler k;
  
  public final List<l> l = new ArrayList<l>();
  
  public final List<g> m = new ArrayList<g>();
  
  public final ViewTreeObserver.OnGlobalLayoutListener n = new c(this);
  
  public final View.OnAttachStateChangeListener o = new d(this);
  
  public final r1 p = new f(this);
  
  public int q;
  
  public int r;
  
  public View s;
  
  public View t;
  
  public int u;
  
  public boolean v;
  
  public boolean w;
  
  public int x;
  
  public int y;
  
  public boolean z;
  
  public h(Context paramContext, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    boolean bool = false;
    this.q = 0;
    this.r = 0;
    this.f = paramContext;
    this.s = paramView;
    this.h = paramInt1;
    this.i = paramInt2;
    this.j = paramBoolean;
    this.z = false;
    AtomicInteger atomicInteger = u.a;
    if (paramView.getLayoutDirection() == 1) {
      paramInt1 = bool;
    } else {
      paramInt1 = 1;
    } 
    this.u = paramInt1;
    Resources resources = paramContext.getResources();
    this.g = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(2131100431));
    this.k = new Handler();
  }
  
  public void a(l paraml, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Ljava/util/List;
    //   4: invokeinterface size : ()I
    //   9: istore #4
    //   11: iconst_0
    //   12: istore_3
    //   13: iload_3
    //   14: iload #4
    //   16: if_icmpge -> 49
    //   19: aload_1
    //   20: aload_0
    //   21: getfield m : Ljava/util/List;
    //   24: iload_3
    //   25: invokeinterface get : (I)Ljava/lang/Object;
    //   30: checkcast c/b/g/n/g
    //   33: getfield b : Lc/b/g/n/l;
    //   36: if_acmpne -> 42
    //   39: goto -> 51
    //   42: iload_3
    //   43: iconst_1
    //   44: iadd
    //   45: istore_3
    //   46: goto -> 13
    //   49: iconst_m1
    //   50: istore_3
    //   51: iload_3
    //   52: ifge -> 56
    //   55: return
    //   56: iload_3
    //   57: iconst_1
    //   58: iadd
    //   59: istore #4
    //   61: iload #4
    //   63: aload_0
    //   64: getfield m : Ljava/util/List;
    //   67: invokeinterface size : ()I
    //   72: if_icmpge -> 96
    //   75: aload_0
    //   76: getfield m : Ljava/util/List;
    //   79: iload #4
    //   81: invokeinterface get : (I)Ljava/lang/Object;
    //   86: checkcast c/b/g/n/g
    //   89: getfield b : Lc/b/g/n/l;
    //   92: iconst_0
    //   93: invokevirtual c : (Z)V
    //   96: aload_0
    //   97: getfield m : Ljava/util/List;
    //   100: iload_3
    //   101: invokeinterface remove : (I)Ljava/lang/Object;
    //   106: checkcast c/b/g/n/g
    //   109: astore #5
    //   111: aload #5
    //   113: getfield b : Lc/b/g/n/l;
    //   116: aload_0
    //   117: invokevirtual u : (Lc/b/g/n/y;)V
    //   120: aload_0
    //   121: getfield E : Z
    //   124: ifeq -> 151
    //   127: aload #5
    //   129: getfield a : Lc/b/h/t1;
    //   132: getfield D : Landroid/widget/PopupWindow;
    //   135: aconst_null
    //   136: invokevirtual setExitTransition : (Landroid/transition/Transition;)V
    //   139: aload #5
    //   141: getfield a : Lc/b/h/t1;
    //   144: getfield D : Landroid/widget/PopupWindow;
    //   147: iconst_0
    //   148: invokevirtual setAnimationStyle : (I)V
    //   151: aload #5
    //   153: getfield a : Lc/b/h/t1;
    //   156: invokevirtual dismiss : ()V
    //   159: aload_0
    //   160: getfield m : Ljava/util/List;
    //   163: invokeinterface size : ()I
    //   168: istore #4
    //   170: iload #4
    //   172: ifle -> 201
    //   175: aload_0
    //   176: aload_0
    //   177: getfield m : Ljava/util/List;
    //   180: iload #4
    //   182: iconst_1
    //   183: isub
    //   184: invokeinterface get : (I)Ljava/lang/Object;
    //   189: checkcast c/b/g/n/g
    //   192: getfield c : I
    //   195: putfield u : I
    //   198: goto -> 233
    //   201: aload_0
    //   202: getfield s : Landroid/view/View;
    //   205: astore #5
    //   207: getstatic c/h/j/u.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   210: astore #6
    //   212: aload #5
    //   214: invokevirtual getLayoutDirection : ()I
    //   217: iconst_1
    //   218: if_icmpne -> 226
    //   221: iconst_0
    //   222: istore_3
    //   223: goto -> 228
    //   226: iconst_1
    //   227: istore_3
    //   228: aload_0
    //   229: iload_3
    //   230: putfield u : I
    //   233: iload #4
    //   235: ifne -> 315
    //   238: aload_0
    //   239: invokevirtual dismiss : ()V
    //   242: aload_0
    //   243: getfield B : Lc/b/g/n/y$a;
    //   246: astore #5
    //   248: aload #5
    //   250: ifnull -> 262
    //   253: aload #5
    //   255: aload_1
    //   256: iconst_1
    //   257: invokeinterface a : (Lc/b/g/n/l;Z)V
    //   262: aload_0
    //   263: getfield C : Landroid/view/ViewTreeObserver;
    //   266: astore_1
    //   267: aload_1
    //   268: ifnull -> 294
    //   271: aload_1
    //   272: invokevirtual isAlive : ()Z
    //   275: ifeq -> 289
    //   278: aload_0
    //   279: getfield C : Landroid/view/ViewTreeObserver;
    //   282: aload_0
    //   283: getfield n : Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;
    //   286: invokevirtual removeGlobalOnLayoutListener : (Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    //   289: aload_0
    //   290: aconst_null
    //   291: putfield C : Landroid/view/ViewTreeObserver;
    //   294: aload_0
    //   295: getfield t : Landroid/view/View;
    //   298: aload_0
    //   299: getfield o : Landroid/view/View$OnAttachStateChangeListener;
    //   302: invokevirtual removeOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
    //   305: aload_0
    //   306: getfield D : Landroid/widget/PopupWindow$OnDismissListener;
    //   309: invokeinterface onDismiss : ()V
    //   314: return
    //   315: iload_2
    //   316: ifeq -> 339
    //   319: aload_0
    //   320: getfield m : Ljava/util/List;
    //   323: iconst_0
    //   324: invokeinterface get : (I)Ljava/lang/Object;
    //   329: checkcast c/b/g/n/g
    //   332: getfield b : Lc/b/g/n/l;
    //   335: iconst_0
    //   336: invokevirtual c : (Z)V
    //   339: return
  }
  
  public boolean b() {
    int i = this.m.size();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      bool1 = bool2;
      if (((g)this.m.get(0)).a.b())
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void d() {
    if (b())
      return; 
    Iterator<l> iterator = this.l.iterator();
    while (iterator.hasNext())
      y(iterator.next()); 
    this.l.clear();
    View view = this.s;
    this.t = view;
    if (view != null) {
      boolean bool;
      if (this.C == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.C = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.n); 
      this.t.addOnAttachStateChangeListener(this.o);
    } 
  }
  
  public void dismiss() {
    int i = this.m.size();
    if (i > 0) {
      g[] arrayOfG = this.m.<g>toArray(new g[i]);
      while (--i >= 0) {
        g g = arrayOfG[i];
        if (g.a.b())
          g.a.dismiss(); 
        i--;
      } 
    } 
  }
  
  public void e(Parcelable paramParcelable) {}
  
  public boolean f(f0 paramf0) {
    for (g g : this.m) {
      if (paramf0 == g.b) {
        ((q1)g.a).g.requestFocus();
        return true;
      } 
    } 
    if (paramf0.hasVisibleItems()) {
      paramf0.b(this, this.f);
      if (b()) {
        y(paramf0);
      } else {
        this.l.add(paramf0);
      } 
      y.a a1 = this.B;
      if (a1 != null)
        a1.b(paramf0); 
      return true;
    } 
    return false;
  }
  
  public ListView g() {
    if (this.m.isEmpty())
      return null; 
    List<g> list = this.m;
    return (ListView)((q1)((g)list.get(list.size() - 1)).a).g;
  }
  
  public void h(boolean paramBoolean) {
    Iterator<g> iterator = this.m.iterator();
    while (iterator.hasNext()) {
      k k;
      ListAdapter listAdapter = ((q1)((g)iterator.next()).a).g.getAdapter();
      if (listAdapter instanceof HeaderViewListAdapter) {
        k = (k)((HeaderViewListAdapter)listAdapter).getWrappedAdapter();
      } else {
        k = k;
      } 
      k.notifyDataSetChanged();
    } 
  }
  
  public boolean i() {
    return false;
  }
  
  public Parcelable j() {
    return null;
  }
  
  public void m(y.a parama) {
    this.B = parama;
  }
  
  public void n(l paraml) {
    paraml.b(this, this.f);
    if (b()) {
      y(paraml);
      return;
    } 
    this.l.add(paraml);
  }
  
  public boolean o() {
    return false;
  }
  
  public void onDismiss() {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Ljava/util/List;
    //   4: invokeinterface size : ()I
    //   9: istore_2
    //   10: iconst_0
    //   11: istore_1
    //   12: iload_1
    //   13: iload_2
    //   14: if_icmpge -> 51
    //   17: aload_0
    //   18: getfield m : Ljava/util/List;
    //   21: iload_1
    //   22: invokeinterface get : (I)Ljava/lang/Object;
    //   27: checkcast c/b/g/n/g
    //   30: astore_3
    //   31: aload_3
    //   32: getfield a : Lc/b/h/t1;
    //   35: invokevirtual b : ()Z
    //   38: ifne -> 44
    //   41: goto -> 53
    //   44: iload_1
    //   45: iconst_1
    //   46: iadd
    //   47: istore_1
    //   48: goto -> 12
    //   51: aconst_null
    //   52: astore_3
    //   53: aload_3
    //   54: ifnull -> 65
    //   57: aload_3
    //   58: getfield b : Lc/b/g/n/l;
    //   61: iconst_0
    //   62: invokevirtual c : (Z)V
    //   65: return
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void q(View paramView) {
    if (this.s != paramView) {
      this.s = paramView;
      int i = this.q;
      AtomicInteger atomicInteger = u.a;
      this.r = Gravity.getAbsoluteGravity(i, paramView.getLayoutDirection());
    } 
  }
  
  public void r(boolean paramBoolean) {
    this.z = paramBoolean;
  }
  
  public void s(int paramInt) {
    if (this.q != paramInt) {
      this.q = paramInt;
      View view = this.s;
      AtomicInteger atomicInteger = u.a;
      this.r = Gravity.getAbsoluteGravity(paramInt, view.getLayoutDirection());
    } 
  }
  
  public void t(int paramInt) {
    this.v = true;
    this.x = paramInt;
  }
  
  public void u(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.D = paramOnDismissListener;
  }
  
  public void v(boolean paramBoolean) {
    this.A = paramBoolean;
  }
  
  public void w(int paramInt) {
    this.w = true;
    this.y = paramInt;
  }
  
  public final void y(l paraml) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Landroid/content/Context;
    //   4: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   7: astore #10
    //   9: new c/b/g/n/k
    //   12: dup
    //   13: aload_1
    //   14: aload #10
    //   16: aload_0
    //   17: getfield j : Z
    //   20: ldc_w 2131427339
    //   23: invokespecial <init> : (Lc/b/g/n/l;Landroid/view/LayoutInflater;ZI)V
    //   26: astore #6
    //   28: aload_0
    //   29: invokevirtual b : ()Z
    //   32: ifne -> 51
    //   35: aload_0
    //   36: getfield z : Z
    //   39: ifeq -> 51
    //   42: aload #6
    //   44: iconst_1
    //   45: putfield g : Z
    //   48: goto -> 67
    //   51: aload_0
    //   52: invokevirtual b : ()Z
    //   55: ifeq -> 67
    //   58: aload #6
    //   60: aload_1
    //   61: invokestatic x : (Lc/b/g/n/l;)Z
    //   64: putfield g : Z
    //   67: aload_0
    //   68: getfield f : Landroid/content/Context;
    //   71: astore #7
    //   73: aload_0
    //   74: getfield g : I
    //   77: istore_2
    //   78: aconst_null
    //   79: astore #8
    //   81: aload #6
    //   83: aconst_null
    //   84: aload #7
    //   86: iload_2
    //   87: invokestatic p : (Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I
    //   90: istore_3
    //   91: new c/b/h/t1
    //   94: dup
    //   95: aload_0
    //   96: getfield f : Landroid/content/Context;
    //   99: aconst_null
    //   100: aload_0
    //   101: getfield h : I
    //   104: aload_0
    //   105: getfield i : I
    //   108: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;II)V
    //   111: astore #9
    //   113: aload #9
    //   115: aload_0
    //   116: getfield p : Lc/b/h/r1;
    //   119: putfield H : Lc/b/h/r1;
    //   122: aload #9
    //   124: aload_0
    //   125: putfield u : Landroid/widget/AdapterView$OnItemClickListener;
    //   128: aload #9
    //   130: getfield D : Landroid/widget/PopupWindow;
    //   133: aload_0
    //   134: invokevirtual setOnDismissListener : (Landroid/widget/PopupWindow$OnDismissListener;)V
    //   137: aload #9
    //   139: aload_0
    //   140: getfield s : Landroid/view/View;
    //   143: putfield t : Landroid/view/View;
    //   146: aload #9
    //   148: aload_0
    //   149: getfield r : I
    //   152: putfield p : I
    //   155: aload #9
    //   157: iconst_1
    //   158: invokevirtual s : (Z)V
    //   161: aload #9
    //   163: getfield D : Landroid/widget/PopupWindow;
    //   166: iconst_2
    //   167: invokevirtual setInputMethodMode : (I)V
    //   170: aload #9
    //   172: aload #6
    //   174: invokevirtual p : (Landroid/widget/ListAdapter;)V
    //   177: aload #9
    //   179: iload_3
    //   180: invokevirtual r : (I)V
    //   183: aload #9
    //   185: aload_0
    //   186: getfield r : I
    //   189: putfield p : I
    //   192: aload_0
    //   193: getfield m : Ljava/util/List;
    //   196: invokeinterface size : ()I
    //   201: ifle -> 477
    //   204: aload_0
    //   205: getfield m : Ljava/util/List;
    //   208: astore #6
    //   210: aload #6
    //   212: aload #6
    //   214: invokeinterface size : ()I
    //   219: iconst_1
    //   220: isub
    //   221: invokeinterface get : (I)Ljava/lang/Object;
    //   226: checkcast c/b/g/n/g
    //   229: astore #6
    //   231: aload #6
    //   233: getfield b : Lc/b/g/n/l;
    //   236: astore #11
    //   238: aload #11
    //   240: invokevirtual size : ()I
    //   243: istore #4
    //   245: iconst_0
    //   246: istore_2
    //   247: iload_2
    //   248: iload #4
    //   250: if_icmpge -> 292
    //   253: aload #11
    //   255: iload_2
    //   256: invokevirtual getItem : (I)Landroid/view/MenuItem;
    //   259: astore #7
    //   261: aload #7
    //   263: invokeinterface hasSubMenu : ()Z
    //   268: ifeq -> 285
    //   271: aload_1
    //   272: aload #7
    //   274: invokeinterface getSubMenu : ()Landroid/view/SubMenu;
    //   279: if_acmpne -> 285
    //   282: goto -> 295
    //   285: iload_2
    //   286: iconst_1
    //   287: iadd
    //   288: istore_2
    //   289: goto -> 247
    //   292: aconst_null
    //   293: astore #7
    //   295: aload #7
    //   297: ifnonnull -> 311
    //   300: aload #6
    //   302: astore #7
    //   304: aload #8
    //   306: astore #6
    //   308: goto -> 483
    //   311: aload #6
    //   313: getfield a : Lc/b/h/t1;
    //   316: getfield g : Lc/b/h/f1;
    //   319: astore #11
    //   321: aload #11
    //   323: invokevirtual getAdapter : ()Landroid/widget/ListAdapter;
    //   326: astore #8
    //   328: aload #8
    //   330: instanceof android/widget/HeaderViewListAdapter
    //   333: ifeq -> 363
    //   336: aload #8
    //   338: checkcast android/widget/HeaderViewListAdapter
    //   341: astore #8
    //   343: aload #8
    //   345: invokevirtual getHeadersCount : ()I
    //   348: istore #4
    //   350: aload #8
    //   352: invokevirtual getWrappedAdapter : ()Landroid/widget/ListAdapter;
    //   355: checkcast c/b/g/n/k
    //   358: astore #8
    //   360: goto -> 373
    //   363: aload #8
    //   365: checkcast c/b/g/n/k
    //   368: astore #8
    //   370: iconst_0
    //   371: istore #4
    //   373: aload #8
    //   375: invokevirtual getCount : ()I
    //   378: istore #5
    //   380: iconst_0
    //   381: istore_2
    //   382: iload_2
    //   383: iload #5
    //   385: if_icmpge -> 409
    //   388: aload #7
    //   390: aload #8
    //   392: iload_2
    //   393: invokevirtual b : (I)Lc/b/g/n/o;
    //   396: if_acmpne -> 402
    //   399: goto -> 411
    //   402: iload_2
    //   403: iconst_1
    //   404: iadd
    //   405: istore_2
    //   406: goto -> 382
    //   409: iconst_m1
    //   410: istore_2
    //   411: iload_2
    //   412: iconst_m1
    //   413: if_icmpne -> 423
    //   416: aload #6
    //   418: astore #7
    //   420: goto -> 480
    //   423: iload_2
    //   424: iload #4
    //   426: iadd
    //   427: aload #11
    //   429: invokevirtual getFirstVisiblePosition : ()I
    //   432: isub
    //   433: istore_2
    //   434: aload #6
    //   436: astore #7
    //   438: iload_2
    //   439: iflt -> 480
    //   442: iload_2
    //   443: aload #11
    //   445: invokevirtual getChildCount : ()I
    //   448: if_icmplt -> 458
    //   451: aload #6
    //   453: astore #7
    //   455: goto -> 480
    //   458: aload #11
    //   460: iload_2
    //   461: invokevirtual getChildAt : (I)Landroid/view/View;
    //   464: astore #8
    //   466: aload #6
    //   468: astore #7
    //   470: aload #8
    //   472: astore #6
    //   474: goto -> 483
    //   477: aconst_null
    //   478: astore #7
    //   480: aconst_null
    //   481: astore #6
    //   483: aload #6
    //   485: ifnull -> 893
    //   488: getstatic android/os/Build$VERSION.SDK_INT : I
    //   491: bipush #28
    //   493: if_icmpgt -> 543
    //   496: getstatic c/b/h/t1.I : Ljava/lang/reflect/Method;
    //   499: astore #8
    //   501: aload #8
    //   503: ifnull -> 552
    //   506: aload #8
    //   508: aload #9
    //   510: getfield D : Landroid/widget/PopupWindow;
    //   513: iconst_1
    //   514: anewarray java/lang/Object
    //   517: dup
    //   518: iconst_0
    //   519: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   522: aastore
    //   523: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   526: pop
    //   527: goto -> 552
    //   530: ldc_w 'MenuPopupWindow'
    //   533: ldc_w 'Could not invoke setTouchModal() on PopupWindow. Oh well.'
    //   536: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   539: pop
    //   540: goto -> 552
    //   543: aload #9
    //   545: getfield D : Landroid/widget/PopupWindow;
    //   548: iconst_0
    //   549: invokevirtual setTouchModal : (Z)V
    //   552: aload #9
    //   554: getfield D : Landroid/widget/PopupWindow;
    //   557: aconst_null
    //   558: invokevirtual setEnterTransition : (Landroid/transition/Transition;)V
    //   561: aload_0
    //   562: getfield m : Ljava/util/List;
    //   565: astore #8
    //   567: aload #8
    //   569: aload #8
    //   571: invokeinterface size : ()I
    //   576: iconst_1
    //   577: isub
    //   578: invokeinterface get : (I)Ljava/lang/Object;
    //   583: checkcast c/b/g/n/g
    //   586: getfield a : Lc/b/h/t1;
    //   589: getfield g : Lc/b/h/f1;
    //   592: astore #8
    //   594: iconst_2
    //   595: newarray int
    //   597: astore #11
    //   599: aload #8
    //   601: aload #11
    //   603: invokevirtual getLocationOnScreen : ([I)V
    //   606: new android/graphics/Rect
    //   609: dup
    //   610: invokespecial <init> : ()V
    //   613: astore #12
    //   615: aload_0
    //   616: getfield t : Landroid/view/View;
    //   619: aload #12
    //   621: invokevirtual getWindowVisibleDisplayFrame : (Landroid/graphics/Rect;)V
    //   624: aload_0
    //   625: getfield u : I
    //   628: iconst_1
    //   629: if_icmpne -> 657
    //   632: aload #11
    //   634: iconst_0
    //   635: iaload
    //   636: istore_2
    //   637: aload #8
    //   639: invokevirtual getWidth : ()I
    //   642: iload_2
    //   643: iadd
    //   644: iload_3
    //   645: iadd
    //   646: aload #12
    //   648: getfield right : I
    //   651: if_icmple -> 666
    //   654: goto -> 672
    //   657: aload #11
    //   659: iconst_0
    //   660: iaload
    //   661: iload_3
    //   662: isub
    //   663: ifge -> 672
    //   666: iconst_1
    //   667: istore #4
    //   669: goto -> 675
    //   672: iconst_0
    //   673: istore #4
    //   675: iload #4
    //   677: iconst_1
    //   678: if_icmpne -> 686
    //   681: iconst_1
    //   682: istore_2
    //   683: goto -> 688
    //   686: iconst_0
    //   687: istore_2
    //   688: aload_0
    //   689: iload #4
    //   691: putfield u : I
    //   694: getstatic android/os/Build$VERSION.SDK_INT : I
    //   697: bipush #26
    //   699: if_icmplt -> 719
    //   702: aload #9
    //   704: aload #6
    //   706: putfield t : Landroid/view/View;
    //   709: iconst_0
    //   710: istore #4
    //   712: iload #4
    //   714: istore #5
    //   716: goto -> 816
    //   719: iconst_2
    //   720: newarray int
    //   722: astore #8
    //   724: aload_0
    //   725: getfield s : Landroid/view/View;
    //   728: aload #8
    //   730: invokevirtual getLocationOnScreen : ([I)V
    //   733: iconst_2
    //   734: newarray int
    //   736: astore #11
    //   738: aload #6
    //   740: aload #11
    //   742: invokevirtual getLocationOnScreen : ([I)V
    //   745: aload_0
    //   746: getfield r : I
    //   749: bipush #7
    //   751: iand
    //   752: iconst_5
    //   753: if_icmpne -> 794
    //   756: aload #8
    //   758: iconst_0
    //   759: iaload
    //   760: istore #4
    //   762: aload #8
    //   764: iconst_0
    //   765: aload_0
    //   766: getfield s : Landroid/view/View;
    //   769: invokevirtual getWidth : ()I
    //   772: iload #4
    //   774: iadd
    //   775: iastore
    //   776: aload #11
    //   778: iconst_0
    //   779: iaload
    //   780: istore #4
    //   782: aload #11
    //   784: iconst_0
    //   785: aload #6
    //   787: invokevirtual getWidth : ()I
    //   790: iload #4
    //   792: iadd
    //   793: iastore
    //   794: aload #11
    //   796: iconst_0
    //   797: iaload
    //   798: aload #8
    //   800: iconst_0
    //   801: iaload
    //   802: isub
    //   803: istore #5
    //   805: aload #11
    //   807: iconst_1
    //   808: iaload
    //   809: aload #8
    //   811: iconst_1
    //   812: iaload
    //   813: isub
    //   814: istore #4
    //   816: aload_0
    //   817: getfield r : I
    //   820: iconst_5
    //   821: iand
    //   822: iconst_5
    //   823: if_icmpne -> 842
    //   826: iload_2
    //   827: ifeq -> 833
    //   830: goto -> 852
    //   833: aload #6
    //   835: invokevirtual getWidth : ()I
    //   838: istore_3
    //   839: goto -> 860
    //   842: iload_2
    //   843: ifeq -> 860
    //   846: aload #6
    //   848: invokevirtual getWidth : ()I
    //   851: istore_3
    //   852: iload #5
    //   854: iload_3
    //   855: iadd
    //   856: istore_2
    //   857: goto -> 865
    //   860: iload #5
    //   862: iload_3
    //   863: isub
    //   864: istore_2
    //   865: aload #9
    //   867: iload_2
    //   868: putfield j : I
    //   871: aload #9
    //   873: iconst_1
    //   874: putfield o : Z
    //   877: aload #9
    //   879: iconst_1
    //   880: putfield n : Z
    //   883: aload #9
    //   885: iload #4
    //   887: invokevirtual j : (I)V
    //   890: goto -> 960
    //   893: aload_0
    //   894: getfield v : Z
    //   897: ifeq -> 909
    //   900: aload #9
    //   902: aload_0
    //   903: getfield x : I
    //   906: putfield j : I
    //   909: aload_0
    //   910: getfield w : Z
    //   913: ifeq -> 925
    //   916: aload #9
    //   918: aload_0
    //   919: getfield y : I
    //   922: invokevirtual j : (I)V
    //   925: aload_0
    //   926: getfield e : Landroid/graphics/Rect;
    //   929: astore #6
    //   931: aload #6
    //   933: ifnull -> 950
    //   936: new android/graphics/Rect
    //   939: dup
    //   940: aload #6
    //   942: invokespecial <init> : (Landroid/graphics/Rect;)V
    //   945: astore #6
    //   947: goto -> 953
    //   950: aconst_null
    //   951: astore #6
    //   953: aload #9
    //   955: aload #6
    //   957: putfield B : Landroid/graphics/Rect;
    //   960: new c/b/g/n/g
    //   963: dup
    //   964: aload #9
    //   966: aload_1
    //   967: aload_0
    //   968: getfield u : I
    //   971: invokespecial <init> : (Lc/b/h/t1;Lc/b/g/n/l;I)V
    //   974: astore #6
    //   976: aload_0
    //   977: getfield m : Ljava/util/List;
    //   980: aload #6
    //   982: invokeinterface add : (Ljava/lang/Object;)Z
    //   987: pop
    //   988: aload #9
    //   990: invokevirtual d : ()V
    //   993: aload #9
    //   995: getfield g : Lc/b/h/f1;
    //   998: astore #6
    //   1000: aload #6
    //   1002: aload_0
    //   1003: invokevirtual setOnKeyListener : (Landroid/view/View$OnKeyListener;)V
    //   1006: aload #7
    //   1008: ifnonnull -> 1083
    //   1011: aload_0
    //   1012: getfield A : Z
    //   1015: ifeq -> 1083
    //   1018: aload_1
    //   1019: getfield m : Ljava/lang/CharSequence;
    //   1022: ifnull -> 1083
    //   1025: aload #10
    //   1027: ldc_w 2131427346
    //   1030: aload #6
    //   1032: iconst_0
    //   1033: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
    //   1036: checkcast android/widget/FrameLayout
    //   1039: astore #7
    //   1041: aload #7
    //   1043: ldc_w 16908310
    //   1046: invokevirtual findViewById : (I)Landroid/view/View;
    //   1049: checkcast android/widget/TextView
    //   1052: astore #8
    //   1054: aload #7
    //   1056: iconst_0
    //   1057: invokevirtual setEnabled : (Z)V
    //   1060: aload #8
    //   1062: aload_1
    //   1063: getfield m : Ljava/lang/CharSequence;
    //   1066: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   1069: aload #6
    //   1071: aload #7
    //   1073: aconst_null
    //   1074: iconst_0
    //   1075: invokevirtual addHeaderView : (Landroid/view/View;Ljava/lang/Object;Z)V
    //   1078: aload #9
    //   1080: invokevirtual d : ()V
    //   1083: return
    //   1084: astore #8
    //   1086: goto -> 530
    // Exception table:
    //   from	to	target	type
    //   506	527	1084	java/lang/Exception
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */