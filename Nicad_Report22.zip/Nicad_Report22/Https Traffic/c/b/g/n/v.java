package c.b.g.n;

import android.content.Context;
import android.graphics.Rect;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;

public abstract class v implements b0, y, AdapterView.OnItemClickListener {
  public Rect e;
  
  public static int p(ListAdapter paramListAdapter, ViewGroup paramViewGroup, Context paramContext, int paramInt) {
    int i = 0;
    int m = View.MeasureSpec.makeMeasureSpec(0, 0);
    int n = View.MeasureSpec.makeMeasureSpec(0, 0);
    k k1 = (k)paramListAdapter;
    int i1 = k1.getCount();
    int j = 0;
    int k = j;
    paramViewGroup = null;
    ViewGroup viewGroup = paramViewGroup;
    while (i < i1) {
      FrameLayout frameLayout2;
      int i3 = k1.getItemViewType(i);
      int i2 = k;
      if (i3 != k) {
        viewGroup = null;
        i2 = i3;
      } 
      ViewGroup viewGroup1 = paramViewGroup;
      if (paramViewGroup == null)
        frameLayout2 = new FrameLayout(paramContext); 
      View view = k1.getView(i, (View)viewGroup, (ViewGroup)frameLayout2);
      view.measure(m, n);
      i3 = view.getMeasuredWidth();
      if (i3 >= paramInt)
        return paramInt; 
      k = j;
      if (i3 > j)
        k = i3; 
      i++;
      j = k;
      k = i2;
      FrameLayout frameLayout1 = frameLayout2;
    } 
    return j;
  }
  
  public static boolean x(l paraml) {
    int j = paraml.size();
    for (int i = 0; i < j; i++) {
      MenuItem menuItem = paraml.getItem(i);
      if (menuItem.isVisible() && menuItem.getIcon() != null)
        return true; 
    } 
    return false;
  }
  
  public void c(Context paramContext, l paraml) {}
  
  public int getId() {
    return 0;
  }
  
  public boolean k(l paraml, o paramo) {
    return false;
  }
  
  public boolean l(l paraml, o paramo) {
    return false;
  }
  
  public abstract void n(l paraml);
  
  public boolean o() {
    return true;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    k k;
    ListAdapter listAdapter = (ListAdapter)paramAdapterView.getAdapter();
    if (listAdapter instanceof HeaderViewListAdapter) {
      k = (k)((HeaderViewListAdapter)listAdapter).getWrappedAdapter();
    } else {
      k = (k)listAdapter;
    } 
    l l = k.e;
    MenuItem menuItem = (MenuItem)listAdapter.getItem(paramInt);
    if (o()) {
      paramInt = 0;
    } else {
      paramInt = 4;
    } 
    l.s(menuItem, this, paramInt);
  }
  
  public abstract void q(View paramView);
  
  public abstract void r(boolean paramBoolean);
  
  public abstract void s(int paramInt);
  
  public abstract void t(int paramInt);
  
  public abstract void u(PopupWindow.OnDismissListener paramOnDismissListener);
  
  public abstract void v(boolean paramBoolean);
  
  public abstract void w(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */