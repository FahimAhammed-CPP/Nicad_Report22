package c.b.g.n;

import android.content.Context;
import android.view.ActionProvider;
import android.view.MenuItem;
import android.view.View;

public class q extends p implements ActionProvider.VisibilityListener {
  public n d;
  
  public q(u paramu, Context paramContext, ActionProvider paramActionProvider) {
    super(paramu, paramContext, paramActionProvider);
  }
  
  public boolean a() {
    return this.b.isVisible();
  }
  
  public View b(MenuItem paramMenuItem) {
    return this.b.onCreateActionView(paramMenuItem);
  }
  
  public boolean c() {
    return this.b.overridesItemVisibility();
  }
  
  public void d(n paramn) {
    this.d = paramn;
    this.b.setVisibilityListener(this);
  }
  
  public void onActionProviderVisibilityChanged(boolean paramBoolean) {
    n n1 = this.d;
    if (n1 != null) {
      l l = n1.a.n;
      l.h = true;
      l.q(true);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */