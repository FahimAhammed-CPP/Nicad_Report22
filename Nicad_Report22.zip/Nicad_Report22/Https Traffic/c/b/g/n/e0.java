package c.b.g.n;

import android.content.Context;
import android.content.res.Resources;
import android.os.Parcelable;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.PopupWindow;
import c.b.h.q1;
import c.b.h.t1;

public final class e0 extends v implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, y, View.OnKeyListener {
  public final Context f;
  
  public final l g;
  
  public final k h;
  
  public final boolean i;
  
  public final int j;
  
  public final int k;
  
  public final int l;
  
  public final t1 m;
  
  public final ViewTreeObserver.OnGlobalLayoutListener n = new c0(this);
  
  public final View.OnAttachStateChangeListener o = new d0(this);
  
  public PopupWindow.OnDismissListener p;
  
  public View q;
  
  public View r;
  
  public y.a s;
  
  public ViewTreeObserver t;
  
  public boolean u;
  
  public boolean v;
  
  public int w;
  
  public int x = 0;
  
  public boolean y;
  
  public e0(Context paramContext, l paraml, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.f = paramContext;
    this.g = paraml;
    this.i = paramBoolean;
    this.h = new k(paraml, LayoutInflater.from(paramContext), paramBoolean, 2131427347);
    this.k = paramInt1;
    this.l = paramInt2;
    Resources resources = paramContext.getResources();
    this.j = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(2131100431));
    this.q = paramView;
    this.m = new t1(paramContext, null, paramInt1, paramInt2);
    paraml.b(this, paramContext);
  }
  
  public void a(l paraml, boolean paramBoolean) {
    if (paraml != this.g)
      return; 
    dismiss();
    y.a a1 = this.s;
    if (a1 != null)
      a1.a(paraml, paramBoolean); 
  }
  
  public boolean b() {
    return (!this.u && this.m.b());
  }
  
  public void d() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual b : ()Z
    //   4: istore_3
    //   5: iconst_1
    //   6: istore_2
    //   7: iload_3
    //   8: ifeq -> 16
    //   11: iload_2
    //   12: istore_1
    //   13: goto -> 378
    //   16: aload_0
    //   17: getfield u : Z
    //   20: ifne -> 376
    //   23: aload_0
    //   24: getfield q : Landroid/view/View;
    //   27: astore #4
    //   29: aload #4
    //   31: ifnonnull -> 37
    //   34: goto -> 376
    //   37: aload_0
    //   38: aload #4
    //   40: putfield r : Landroid/view/View;
    //   43: aload_0
    //   44: getfield m : Lc/b/h/t1;
    //   47: getfield D : Landroid/widget/PopupWindow;
    //   50: aload_0
    //   51: invokevirtual setOnDismissListener : (Landroid/widget/PopupWindow$OnDismissListener;)V
    //   54: aload_0
    //   55: getfield m : Lc/b/h/t1;
    //   58: astore #4
    //   60: aload #4
    //   62: aload_0
    //   63: putfield u : Landroid/widget/AdapterView$OnItemClickListener;
    //   66: aload #4
    //   68: iconst_1
    //   69: invokevirtual s : (Z)V
    //   72: aload_0
    //   73: getfield r : Landroid/view/View;
    //   76: astore #4
    //   78: aload_0
    //   79: getfield t : Landroid/view/ViewTreeObserver;
    //   82: ifnonnull -> 90
    //   85: iconst_1
    //   86: istore_1
    //   87: goto -> 92
    //   90: iconst_0
    //   91: istore_1
    //   92: aload #4
    //   94: invokevirtual getViewTreeObserver : ()Landroid/view/ViewTreeObserver;
    //   97: astore #5
    //   99: aload_0
    //   100: aload #5
    //   102: putfield t : Landroid/view/ViewTreeObserver;
    //   105: iload_1
    //   106: ifeq -> 118
    //   109: aload #5
    //   111: aload_0
    //   112: getfield n : Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;
    //   115: invokevirtual addOnGlobalLayoutListener : (Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V
    //   118: aload #4
    //   120: aload_0
    //   121: getfield o : Landroid/view/View$OnAttachStateChangeListener;
    //   124: invokevirtual addOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
    //   127: aload_0
    //   128: getfield m : Lc/b/h/t1;
    //   131: astore #5
    //   133: aload #5
    //   135: aload #4
    //   137: putfield t : Landroid/view/View;
    //   140: aload #5
    //   142: aload_0
    //   143: getfield x : I
    //   146: putfield p : I
    //   149: aload_0
    //   150: getfield v : Z
    //   153: ifne -> 181
    //   156: aload_0
    //   157: aload_0
    //   158: getfield h : Lc/b/g/n/k;
    //   161: aconst_null
    //   162: aload_0
    //   163: getfield f : Landroid/content/Context;
    //   166: aload_0
    //   167: getfield j : I
    //   170: invokestatic p : (Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I
    //   173: putfield w : I
    //   176: aload_0
    //   177: iconst_1
    //   178: putfield v : Z
    //   181: aload_0
    //   182: getfield m : Lc/b/h/t1;
    //   185: aload_0
    //   186: getfield w : I
    //   189: invokevirtual r : (I)V
    //   192: aload_0
    //   193: getfield m : Lc/b/h/t1;
    //   196: getfield D : Landroid/widget/PopupWindow;
    //   199: iconst_2
    //   200: invokevirtual setInputMethodMode : (I)V
    //   203: aload_0
    //   204: getfield m : Lc/b/h/t1;
    //   207: astore #5
    //   209: aload_0
    //   210: getfield e : Landroid/graphics/Rect;
    //   213: astore #4
    //   215: aload #5
    //   217: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   220: pop
    //   221: aload #4
    //   223: ifnull -> 240
    //   226: new android/graphics/Rect
    //   229: dup
    //   230: aload #4
    //   232: invokespecial <init> : (Landroid/graphics/Rect;)V
    //   235: astore #4
    //   237: goto -> 243
    //   240: aconst_null
    //   241: astore #4
    //   243: aload #5
    //   245: aload #4
    //   247: putfield B : Landroid/graphics/Rect;
    //   250: aload_0
    //   251: getfield m : Lc/b/h/t1;
    //   254: invokevirtual d : ()V
    //   257: aload_0
    //   258: getfield m : Lc/b/h/t1;
    //   261: getfield g : Lc/b/h/f1;
    //   264: astore #4
    //   266: aload #4
    //   268: aload_0
    //   269: invokevirtual setOnKeyListener : (Landroid/view/View$OnKeyListener;)V
    //   272: aload_0
    //   273: getfield y : Z
    //   276: ifeq -> 353
    //   279: aload_0
    //   280: getfield g : Lc/b/g/n/l;
    //   283: getfield m : Ljava/lang/CharSequence;
    //   286: ifnull -> 353
    //   289: aload_0
    //   290: getfield f : Landroid/content/Context;
    //   293: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   296: ldc 2131427346
    //   298: aload #4
    //   300: iconst_0
    //   301: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
    //   304: checkcast android/widget/FrameLayout
    //   307: astore #5
    //   309: aload #5
    //   311: ldc 16908310
    //   313: invokevirtual findViewById : (I)Landroid/view/View;
    //   316: checkcast android/widget/TextView
    //   319: astore #6
    //   321: aload #6
    //   323: ifnull -> 338
    //   326: aload #6
    //   328: aload_0
    //   329: getfield g : Lc/b/g/n/l;
    //   332: getfield m : Ljava/lang/CharSequence;
    //   335: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   338: aload #5
    //   340: iconst_0
    //   341: invokevirtual setEnabled : (Z)V
    //   344: aload #4
    //   346: aload #5
    //   348: aconst_null
    //   349: iconst_0
    //   350: invokevirtual addHeaderView : (Landroid/view/View;Ljava/lang/Object;Z)V
    //   353: aload_0
    //   354: getfield m : Lc/b/h/t1;
    //   357: aload_0
    //   358: getfield h : Lc/b/g/n/k;
    //   361: invokevirtual p : (Landroid/widget/ListAdapter;)V
    //   364: aload_0
    //   365: getfield m : Lc/b/h/t1;
    //   368: invokevirtual d : ()V
    //   371: iload_2
    //   372: istore_1
    //   373: goto -> 378
    //   376: iconst_0
    //   377: istore_1
    //   378: iload_1
    //   379: ifeq -> 383
    //   382: return
    //   383: new java/lang/IllegalStateException
    //   386: dup
    //   387: ldc_w 'StandardMenuPopup cannot be used without an anchor'
    //   390: invokespecial <init> : (Ljava/lang/String;)V
    //   393: athrow
  }
  
  public void dismiss() {
    if (b())
      this.m.dismiss(); 
  }
  
  public void e(Parcelable paramParcelable) {}
  
  public boolean f(f0 paramf0) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual hasVisibleItems : ()Z
    //   4: ifeq -> 241
    //   7: new c/b/g/n/x
    //   10: dup
    //   11: aload_0
    //   12: getfield f : Landroid/content/Context;
    //   15: aload_1
    //   16: aload_0
    //   17: getfield r : Landroid/view/View;
    //   20: aload_0
    //   21: getfield i : Z
    //   24: aload_0
    //   25: getfield k : I
    //   28: aload_0
    //   29: getfield l : I
    //   32: invokespecial <init> : (Landroid/content/Context;Lc/b/g/n/l;Landroid/view/View;ZII)V
    //   35: astore #7
    //   37: aload #7
    //   39: aload_0
    //   40: getfield s : Lc/b/g/n/y$a;
    //   43: invokevirtual d : (Lc/b/g/n/y$a;)V
    //   46: aload_1
    //   47: invokestatic x : (Lc/b/g/n/l;)Z
    //   50: istore #6
    //   52: aload #7
    //   54: iload #6
    //   56: putfield h : Z
    //   59: aload #7
    //   61: getfield j : Lc/b/g/n/v;
    //   64: astore #8
    //   66: aload #8
    //   68: ifnull -> 78
    //   71: aload #8
    //   73: iload #6
    //   75: invokevirtual r : (Z)V
    //   78: aload #7
    //   80: aload_0
    //   81: getfield p : Landroid/widget/PopupWindow$OnDismissListener;
    //   84: putfield k : Landroid/widget/PopupWindow$OnDismissListener;
    //   87: aload_0
    //   88: aconst_null
    //   89: putfield p : Landroid/widget/PopupWindow$OnDismissListener;
    //   92: aload_0
    //   93: getfield g : Lc/b/g/n/l;
    //   96: iconst_0
    //   97: invokevirtual c : (Z)V
    //   100: aload_0
    //   101: getfield m : Lc/b/h/t1;
    //   104: astore #8
    //   106: aload #8
    //   108: getfield j : I
    //   111: istore #4
    //   113: aload #8
    //   115: getfield m : Z
    //   118: ifne -> 126
    //   121: iconst_0
    //   122: istore_2
    //   123: goto -> 132
    //   126: aload #8
    //   128: getfield k : I
    //   131: istore_2
    //   132: aload_0
    //   133: getfield x : I
    //   136: istore #5
    //   138: aload_0
    //   139: getfield q : Landroid/view/View;
    //   142: astore #8
    //   144: getstatic c/h/j/u.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   147: astore #9
    //   149: iload #4
    //   151: istore_3
    //   152: iload #5
    //   154: aload #8
    //   156: invokevirtual getLayoutDirection : ()I
    //   159: invokestatic getAbsoluteGravity : (II)I
    //   162: bipush #7
    //   164: iand
    //   165: iconst_5
    //   166: if_icmpne -> 180
    //   169: iload #4
    //   171: aload_0
    //   172: getfield q : Landroid/view/View;
    //   175: invokevirtual getWidth : ()I
    //   178: iadd
    //   179: istore_3
    //   180: aload #7
    //   182: invokevirtual b : ()Z
    //   185: ifeq -> 191
    //   188: goto -> 213
    //   191: aload #7
    //   193: getfield f : Landroid/view/View;
    //   196: ifnonnull -> 204
    //   199: iconst_0
    //   200: istore_2
    //   201: goto -> 215
    //   204: aload #7
    //   206: iload_3
    //   207: iload_2
    //   208: iconst_1
    //   209: iconst_1
    //   210: invokevirtual e : (IIZZ)V
    //   213: iconst_1
    //   214: istore_2
    //   215: iload_2
    //   216: ifeq -> 241
    //   219: aload_0
    //   220: getfield s : Lc/b/g/n/y$a;
    //   223: astore #7
    //   225: aload #7
    //   227: ifnull -> 239
    //   230: aload #7
    //   232: aload_1
    //   233: invokeinterface b : (Lc/b/g/n/l;)Z
    //   238: pop
    //   239: iconst_1
    //   240: ireturn
    //   241: iconst_0
    //   242: ireturn
  }
  
  public ListView g() {
    return (ListView)((q1)this.m).g;
  }
  
  public void h(boolean paramBoolean) {
    this.v = false;
    k k1 = this.h;
    if (k1 != null)
      k1.notifyDataSetChanged(); 
  }
  
  public boolean i() {
    return false;
  }
  
  public Parcelable j() {
    return null;
  }
  
  public void m(y.a parama) {
    this.s = parama;
  }
  
  public void n(l paraml) {}
  
  public void onDismiss() {
    this.u = true;
    this.g.c(true);
    ViewTreeObserver viewTreeObserver = this.t;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.t = this.r.getViewTreeObserver(); 
      this.t.removeGlobalOnLayoutListener(this.n);
      this.t = null;
    } 
    this.r.removeOnAttachStateChangeListener(this.o);
    PopupWindow.OnDismissListener onDismissListener = this.p;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void q(View paramView) {
    this.q = paramView;
  }
  
  public void r(boolean paramBoolean) {
    this.h.g = paramBoolean;
  }
  
  public void s(int paramInt) {
    this.x = paramInt;
  }
  
  public void t(int paramInt) {
    ((q1)this.m).j = paramInt;
  }
  
  public void u(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.p = paramOnDismissListener;
  }
  
  public void v(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  public void w(int paramInt) {
    t1 t11 = this.m;
    ((q1)t11).k = paramInt;
    ((q1)t11).m = true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */