package c.b.g.n;

import android.content.Context;
import android.view.ActionProvider;
import android.view.MenuItem;
import android.view.View;

public abstract class p {
  public n a;
  
  public final ActionProvider b;
  
  public p(u paramu, Context paramContext, ActionProvider paramActionProvider) {
    this.b = paramActionProvider;
  }
  
  public abstract View b(MenuItem paramMenuItem);
  
  public abstract void d(n paramn);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */