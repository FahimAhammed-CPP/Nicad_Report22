package c.b.g.n;

import android.view.MenuItem;

public class s implements MenuItem.OnActionExpandListener {
  public final MenuItem.OnActionExpandListener a;
  
  public s(u paramu, MenuItem.OnActionExpandListener paramOnActionExpandListener) {
    this.a = paramOnActionExpandListener;
  }
  
  public boolean onMenuItemActionCollapse(MenuItem paramMenuItem) {
    return this.a.onMenuItemActionCollapse(this.b.c(paramMenuItem));
  }
  
  public boolean onMenuItemActionExpand(MenuItem paramMenuItem) {
    return this.a.onMenuItemActionExpand(this.b.c(paramMenuItem));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */