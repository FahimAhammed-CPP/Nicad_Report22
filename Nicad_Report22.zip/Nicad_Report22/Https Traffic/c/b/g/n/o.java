package c.b.g.n;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewDebug.CapturedViewProperty;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import c.b.d.a.a;
import c.h.e.a.b;
import java.util.Objects;

public final class o implements b {
  public p A;
  
  public MenuItem.OnActionExpandListener B;
  
  public boolean C = false;
  
  public ContextMenu.ContextMenuInfo D;
  
  public final int a;
  
  public final int b;
  
  public final int c;
  
  public final int d;
  
  public CharSequence e;
  
  public CharSequence f;
  
  public Intent g;
  
  public char h;
  
  public int i = 4096;
  
  public char j;
  
  public int k = 4096;
  
  public Drawable l;
  
  public int m = 0;
  
  public l n;
  
  public f0 o;
  
  public MenuItem.OnMenuItemClickListener p;
  
  public CharSequence q;
  
  public CharSequence r;
  
  public ColorStateList s = null;
  
  public PorterDuff.Mode t = null;
  
  public boolean u = false;
  
  public boolean v = false;
  
  public boolean w = false;
  
  public int x = 16;
  
  public int y = 0;
  
  public View z;
  
  public o(l paraml, int paramInt1, int paramInt2, int paramInt3, int paramInt4, CharSequence paramCharSequence, int paramInt5) {
    this.n = paraml;
    this.a = paramInt2;
    this.b = paramInt1;
    this.c = paramInt3;
    this.d = paramInt4;
    this.e = paramCharSequence;
    this.y = paramInt5;
  }
  
  public static void c(StringBuilder paramStringBuilder, int paramInt1, int paramInt2, String paramString) {
    if ((paramInt1 & paramInt2) == paramInt2)
      paramStringBuilder.append(paramString); 
  }
  
  public p a() {
    return this.A;
  }
  
  public b b(p paramp) {
    p p1 = this.A;
    if (p1 != null)
      p1.a = null; 
    this.z = null;
    this.A = paramp;
    this.n.q(true);
    paramp = this.A;
    if (paramp != null)
      paramp.d(new n(this)); 
    return this;
  }
  
  public boolean collapseActionView() {
    if ((this.y & 0x8) == 0)
      return false; 
    if (this.z == null)
      return true; 
    MenuItem.OnActionExpandListener onActionExpandListener = this.B;
    return (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse((MenuItem)this)) ? this.n.d(this) : false;
  }
  
  public final Drawable d(Drawable paramDrawable) {
    // Byte code:
    //   0: aload_1
    //   1: astore_2
    //   2: aload_1
    //   3: ifnull -> 71
    //   6: aload_1
    //   7: astore_2
    //   8: aload_0
    //   9: getfield w : Z
    //   12: ifeq -> 71
    //   15: aload_0
    //   16: getfield u : Z
    //   19: ifne -> 31
    //   22: aload_1
    //   23: astore_2
    //   24: aload_0
    //   25: getfield v : Z
    //   28: ifeq -> 71
    //   31: aload_1
    //   32: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
    //   35: astore_2
    //   36: aload_0
    //   37: getfield u : Z
    //   40: ifeq -> 51
    //   43: aload_2
    //   44: aload_0
    //   45: getfield s : Landroid/content/res/ColorStateList;
    //   48: invokevirtual setTintList : (Landroid/content/res/ColorStateList;)V
    //   51: aload_0
    //   52: getfield v : Z
    //   55: ifeq -> 66
    //   58: aload_2
    //   59: aload_0
    //   60: getfield t : Landroid/graphics/PorterDuff$Mode;
    //   63: invokevirtual setTintMode : (Landroid/graphics/PorterDuff$Mode;)V
    //   66: aload_0
    //   67: iconst_0
    //   68: putfield w : Z
    //   71: aload_2
    //   72: areturn
  }
  
  public char e() {
    return this.n.n() ? this.j : this.h;
  }
  
  public boolean expandActionView() {
    if (!f())
      return false; 
    MenuItem.OnActionExpandListener onActionExpandListener = this.B;
    return (onActionExpandListener == null || onActionExpandListener.onMenuItemActionExpand((MenuItem)this)) ? this.n.f(this) : false;
  }
  
  public boolean f() {
    int i = this.y;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if ((i & 0x8) != 0) {
      if (this.z == null) {
        p p1 = this.A;
        if (p1 != null)
          this.z = p1.b((MenuItem)this); 
      } 
      bool1 = bool2;
      if (this.z != null)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public boolean g() {
    return ((this.x & 0x20) == 32);
  }
  
  public ActionProvider getActionProvider() {
    throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
  }
  
  public View getActionView() {
    View view = this.z;
    if (view != null)
      return view; 
    p p1 = this.A;
    if (p1 != null) {
      View view1 = p1.b((MenuItem)this);
      this.z = view1;
      return view1;
    } 
    return null;
  }
  
  public int getAlphabeticModifiers() {
    return this.k;
  }
  
  public char getAlphabeticShortcut() {
    return this.j;
  }
  
  public CharSequence getContentDescription() {
    return this.q;
  }
  
  public int getGroupId() {
    return this.b;
  }
  
  public Drawable getIcon() {
    Drawable drawable = this.l;
    if (drawable != null)
      return d(drawable); 
    int i = this.m;
    if (i != 0) {
      drawable = a.a(this.n.a, i);
      this.m = 0;
      this.l = drawable;
      return d(drawable);
    } 
    return null;
  }
  
  public ColorStateList getIconTintList() {
    return this.s;
  }
  
  public PorterDuff.Mode getIconTintMode() {
    return this.t;
  }
  
  public Intent getIntent() {
    return this.g;
  }
  
  @CapturedViewProperty
  public int getItemId() {
    return this.a;
  }
  
  public ContextMenu.ContextMenuInfo getMenuInfo() {
    return this.D;
  }
  
  public int getNumericModifiers() {
    return this.i;
  }
  
  public char getNumericShortcut() {
    return this.h;
  }
  
  public int getOrder() {
    return this.c;
  }
  
  public SubMenu getSubMenu() {
    return this.o;
  }
  
  @CapturedViewProperty
  public CharSequence getTitle() {
    return this.e;
  }
  
  public CharSequence getTitleCondensed() {
    CharSequence charSequence = this.f;
    return (charSequence != null) ? charSequence : this.e;
  }
  
  public CharSequence getTooltipText() {
    return this.r;
  }
  
  public boolean h() {
    return ((this.x & 0x4) != 0);
  }
  
  public boolean hasSubMenu() {
    return (this.o != null);
  }
  
  public b i(View paramView) {
    this.z = paramView;
    this.A = null;
    if (paramView != null && paramView.getId() == -1) {
      int i = this.a;
      if (i > 0)
        paramView.setId(i); 
    } 
    this.n.p();
    return this;
  }
  
  public boolean isActionViewExpanded() {
    return this.C;
  }
  
  public boolean isCheckable() {
    return ((this.x & 0x1) == 1);
  }
  
  public boolean isChecked() {
    return ((this.x & 0x2) == 2);
  }
  
  public boolean isEnabled() {
    return ((this.x & 0x10) != 0);
  }
  
  public boolean isVisible() {
    p p1 = this.A;
    return (p1 != null && p1.c()) ? (((this.x & 0x8) == 0 && this.A.a())) : (((this.x & 0x8) == 0));
  }
  
  public void j(boolean paramBoolean) {
    int i;
    int j = this.x;
    if (paramBoolean) {
      i = 2;
    } else {
      i = 0;
    } 
    i |= j & 0xFFFFFFFD;
    this.x = i;
    if (j != i)
      this.n.q(false); 
  }
  
  public void k(boolean paramBoolean) {
    boolean bool;
    int i = this.x;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    this.x = bool | i & 0xFFFFFFFB;
  }
  
  public void l(boolean paramBoolean) {
    if (paramBoolean) {
      this.x |= 0x20;
      return;
    } 
    this.x &= 0xFFFFFFDF;
  }
  
  public boolean m(boolean paramBoolean) {
    int i;
    int j = this.x;
    boolean bool = false;
    if (paramBoolean) {
      i = 0;
    } else {
      i = 8;
    } 
    i |= j & 0xFFFFFFF7;
    this.x = i;
    paramBoolean = bool;
    if (j != i)
      paramBoolean = true; 
    return paramBoolean;
  }
  
  public boolean n() {
    return (this.n.o() && e() != '\000');
  }
  
  public MenuItem setActionProvider(ActionProvider paramActionProvider) {
    throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
  }
  
  public MenuItem setActionView(int paramInt) {
    Context context = this.n.a;
    i(LayoutInflater.from(context).inflate(paramInt, (ViewGroup)new LinearLayout(context), false));
    return (MenuItem)this;
  }
  
  public MenuItem setAlphabeticShortcut(char paramChar) {
    if (this.j == paramChar)
      return (MenuItem)this; 
    this.j = Character.toLowerCase(paramChar);
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setAlphabeticShortcut(char paramChar, int paramInt) {
    if (this.j == paramChar && this.k == paramInt)
      return (MenuItem)this; 
    this.j = Character.toLowerCase(paramChar);
    this.k = KeyEvent.normalizeMetaState(paramInt);
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setCheckable(boolean paramBoolean) {
    int i = this.x;
    int j = paramBoolean | i & 0xFFFFFFFE;
    this.x = j;
    if (i != j)
      this.n.q(false); 
    return (MenuItem)this;
  }
  
  public MenuItem setChecked(boolean paramBoolean) {
    if ((this.x & 0x4) != 0) {
      l l1 = this.n;
      Objects.requireNonNull(l1);
      int j = getGroupId();
      int k = l1.f.size();
      l1.z();
      for (int i = 0; i < k; i++) {
        o o1 = l1.f.get(i);
        if (o1.b == j && o1.h() && o1.isCheckable()) {
          if (o1 == this) {
            paramBoolean = true;
          } else {
            paramBoolean = false;
          } 
          o1.j(paramBoolean);
        } 
      } 
      l1.y();
      return (MenuItem)this;
    } 
    j(paramBoolean);
    return (MenuItem)this;
  }
  
  public MenuItem setContentDescription(CharSequence paramCharSequence) {
    this.q = paramCharSequence;
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public b setContentDescription(CharSequence paramCharSequence) {
    this.q = paramCharSequence;
    this.n.q(false);
    return this;
  }
  
  public MenuItem setEnabled(boolean paramBoolean) {
    if (paramBoolean) {
      this.x |= 0x10;
    } else {
      this.x &= 0xFFFFFFEF;
    } 
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setIcon(int paramInt) {
    this.l = null;
    this.m = paramInt;
    this.w = true;
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setIcon(Drawable paramDrawable) {
    this.m = 0;
    this.l = paramDrawable;
    this.w = true;
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setIconTintList(ColorStateList paramColorStateList) {
    this.s = paramColorStateList;
    this.u = true;
    this.w = true;
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setIconTintMode(PorterDuff.Mode paramMode) {
    this.t = paramMode;
    this.v = true;
    this.w = true;
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setIntent(Intent paramIntent) {
    this.g = paramIntent;
    return (MenuItem)this;
  }
  
  public MenuItem setNumericShortcut(char paramChar) {
    if (this.h == paramChar)
      return (MenuItem)this; 
    this.h = paramChar;
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setNumericShortcut(char paramChar, int paramInt) {
    if (this.h == paramChar && this.i == paramInt)
      return (MenuItem)this; 
    this.h = paramChar;
    this.i = KeyEvent.normalizeMetaState(paramInt);
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener paramOnActionExpandListener) {
    this.B = paramOnActionExpandListener;
    return (MenuItem)this;
  }
  
  public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener paramOnMenuItemClickListener) {
    this.p = paramOnMenuItemClickListener;
    return (MenuItem)this;
  }
  
  public MenuItem setShortcut(char paramChar1, char paramChar2) {
    this.h = paramChar1;
    this.j = Character.toLowerCase(paramChar2);
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setShortcut(char paramChar1, char paramChar2, int paramInt1, int paramInt2) {
    this.h = paramChar1;
    this.i = KeyEvent.normalizeMetaState(paramInt1);
    this.j = Character.toLowerCase(paramChar2);
    this.k = KeyEvent.normalizeMetaState(paramInt2);
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public void setShowAsAction(int paramInt) {
    int i = paramInt & 0x3;
    if (i == 0 || i == 1 || i == 2) {
      this.y = paramInt;
      this.n.p();
      return;
    } 
    throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
  }
  
  public MenuItem setShowAsActionFlags(int paramInt) {
    setShowAsAction(paramInt);
    return (MenuItem)this;
  }
  
  public MenuItem setTitle(int paramInt) {
    setTitle(this.n.a.getString(paramInt));
    return (MenuItem)this;
  }
  
  public MenuItem setTitle(CharSequence paramCharSequence) {
    this.e = paramCharSequence;
    this.n.q(false);
    f0 f01 = this.o;
    if (f01 != null)
      f01.setHeaderTitle(paramCharSequence); 
    return (MenuItem)this;
  }
  
  public MenuItem setTitleCondensed(CharSequence paramCharSequence) {
    this.f = paramCharSequence;
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public MenuItem setTooltipText(CharSequence paramCharSequence) {
    this.r = paramCharSequence;
    this.n.q(false);
    return (MenuItem)this;
  }
  
  public b setTooltipText(CharSequence paramCharSequence) {
    this.r = paramCharSequence;
    this.n.q(false);
    return this;
  }
  
  public MenuItem setVisible(boolean paramBoolean) {
    if (m(paramBoolean)) {
      l l1 = this.n;
      l1.h = true;
      l1.q(true);
    } 
    return (MenuItem)this;
  }
  
  public String toString() {
    CharSequence charSequence = this.e;
    return (charSequence != null) ? charSequence.toString() : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */