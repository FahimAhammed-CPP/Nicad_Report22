package c.b.g.n;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import c.h.b.b;
import c.h.c.b;
import c.h.e.a.b;

public class a implements b {
  public CharSequence a;
  
  public CharSequence b;
  
  public Intent c;
  
  public char d;
  
  public int e = 4096;
  
  public char f;
  
  public int g = 4096;
  
  public Drawable h;
  
  public Context i;
  
  public CharSequence j;
  
  public CharSequence k;
  
  public ColorStateList l = null;
  
  public PorterDuff.Mode m = null;
  
  public boolean n = false;
  
  public boolean o = false;
  
  public int p = 16;
  
  public a(Context paramContext, int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    this.i = paramContext;
    this.a = paramCharSequence;
  }
  
  public p a() {
    return null;
  }
  
  public b b(p paramp) {
    throw new UnsupportedOperationException();
  }
  
  public final void c() {
    Drawable drawable = this.h;
    if (drawable != null && (this.n || this.o)) {
      this.h = drawable;
      drawable = drawable.mutate();
      this.h = drawable;
      if (this.n)
        drawable.setTintList(this.l); 
      if (this.o)
        this.h.setTintMode(this.m); 
    } 
  }
  
  public boolean collapseActionView() {
    return false;
  }
  
  public boolean expandActionView() {
    return false;
  }
  
  public ActionProvider getActionProvider() {
    throw new UnsupportedOperationException();
  }
  
  public View getActionView() {
    return null;
  }
  
  public int getAlphabeticModifiers() {
    return this.g;
  }
  
  public char getAlphabeticShortcut() {
    return this.f;
  }
  
  public CharSequence getContentDescription() {
    return this.j;
  }
  
  public int getGroupId() {
    return 0;
  }
  
  public Drawable getIcon() {
    return this.h;
  }
  
  public ColorStateList getIconTintList() {
    return this.l;
  }
  
  public PorterDuff.Mode getIconTintMode() {
    return this.m;
  }
  
  public Intent getIntent() {
    return this.c;
  }
  
  public int getItemId() {
    return 16908332;
  }
  
  public ContextMenu.ContextMenuInfo getMenuInfo() {
    return null;
  }
  
  public int getNumericModifiers() {
    return this.e;
  }
  
  public char getNumericShortcut() {
    return this.d;
  }
  
  public int getOrder() {
    return 0;
  }
  
  public SubMenu getSubMenu() {
    return null;
  }
  
  public CharSequence getTitle() {
    return this.a;
  }
  
  public CharSequence getTitleCondensed() {
    CharSequence charSequence = this.b;
    return (charSequence != null) ? charSequence : this.a;
  }
  
  public CharSequence getTooltipText() {
    return this.k;
  }
  
  public boolean hasSubMenu() {
    return false;
  }
  
  public boolean isActionViewExpanded() {
    return false;
  }
  
  public boolean isCheckable() {
    return ((this.p & 0x1) != 0);
  }
  
  public boolean isChecked() {
    return ((this.p & 0x2) != 0);
  }
  
  public boolean isEnabled() {
    return ((this.p & 0x10) != 0);
  }
  
  public boolean isVisible() {
    return ((this.p & 0x8) == 0);
  }
  
  public MenuItem setActionProvider(ActionProvider paramActionProvider) {
    throw new UnsupportedOperationException();
  }
  
  public MenuItem setActionView(int paramInt) {
    throw new UnsupportedOperationException();
  }
  
  public MenuItem setActionView(View paramView) {
    throw new UnsupportedOperationException();
  }
  
  public MenuItem setAlphabeticShortcut(char paramChar) {
    this.f = Character.toLowerCase(paramChar);
    return (MenuItem)this;
  }
  
  public MenuItem setAlphabeticShortcut(char paramChar, int paramInt) {
    this.f = Character.toLowerCase(paramChar);
    this.g = KeyEvent.normalizeMetaState(paramInt);
    return (MenuItem)this;
  }
  
  public MenuItem setCheckable(boolean paramBoolean) {
    this.p = paramBoolean | this.p & 0xFFFFFFFE;
    return (MenuItem)this;
  }
  
  public MenuItem setChecked(boolean paramBoolean) {
    boolean bool;
    int i = this.p;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    this.p = bool | i & 0xFFFFFFFD;
    return (MenuItem)this;
  }
  
  public MenuItem setContentDescription(CharSequence paramCharSequence) {
    this.j = paramCharSequence;
    return (MenuItem)this;
  }
  
  public b setContentDescription(CharSequence paramCharSequence) {
    this.j = paramCharSequence;
    return this;
  }
  
  public MenuItem setEnabled(boolean paramBoolean) {
    boolean bool;
    int i = this.p;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    this.p = bool | i & 0xFFFFFFEF;
    return (MenuItem)this;
  }
  
  public MenuItem setIcon(int paramInt) {
    Context context = this.i;
    Object object = b.a;
    this.h = b.b(context, paramInt);
    c();
    return (MenuItem)this;
  }
  
  public MenuItem setIcon(Drawable paramDrawable) {
    this.h = paramDrawable;
    c();
    return (MenuItem)this;
  }
  
  public MenuItem setIconTintList(ColorStateList paramColorStateList) {
    this.l = paramColorStateList;
    this.n = true;
    c();
    return (MenuItem)this;
  }
  
  public MenuItem setIconTintMode(PorterDuff.Mode paramMode) {
    this.m = paramMode;
    this.o = true;
    c();
    return (MenuItem)this;
  }
  
  public MenuItem setIntent(Intent paramIntent) {
    this.c = paramIntent;
    return (MenuItem)this;
  }
  
  public MenuItem setNumericShortcut(char paramChar) {
    this.d = paramChar;
    return (MenuItem)this;
  }
  
  public MenuItem setNumericShortcut(char paramChar, int paramInt) {
    this.d = paramChar;
    this.e = KeyEvent.normalizeMetaState(paramInt);
    return (MenuItem)this;
  }
  
  public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener paramOnActionExpandListener) {
    throw new UnsupportedOperationException();
  }
  
  public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener paramOnMenuItemClickListener) {
    return (MenuItem)this;
  }
  
  public MenuItem setShortcut(char paramChar1, char paramChar2) {
    this.d = paramChar1;
    this.f = Character.toLowerCase(paramChar2);
    return (MenuItem)this;
  }
  
  public MenuItem setShortcut(char paramChar1, char paramChar2, int paramInt1, int paramInt2) {
    this.d = paramChar1;
    this.e = KeyEvent.normalizeMetaState(paramInt1);
    this.f = Character.toLowerCase(paramChar2);
    this.g = KeyEvent.normalizeMetaState(paramInt2);
    return (MenuItem)this;
  }
  
  public void setShowAsAction(int paramInt) {}
  
  public MenuItem setShowAsActionFlags(int paramInt) {
    return (MenuItem)this;
  }
  
  public MenuItem setTitle(int paramInt) {
    this.a = this.i.getResources().getString(paramInt);
    return (MenuItem)this;
  }
  
  public MenuItem setTitle(CharSequence paramCharSequence) {
    this.a = paramCharSequence;
    return (MenuItem)this;
  }
  
  public MenuItem setTitleCondensed(CharSequence paramCharSequence) {
    this.b = paramCharSequence;
    return (MenuItem)this;
  }
  
  public MenuItem setTooltipText(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    return (MenuItem)this;
  }
  
  public b setTooltipText(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    return this;
  }
  
  public MenuItem setVisible(boolean paramBoolean) {
    int i = this.p;
    byte b1 = 8;
    if (paramBoolean)
      b1 = 0; 
    this.p = i & 0x8 | b1;
    return (MenuItem)this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */