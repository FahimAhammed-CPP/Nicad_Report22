package c.b.g.n;

import android.view.View;
import android.view.ViewTreeObserver;
import c.b.h.q1;

public class c0 implements ViewTreeObserver.OnGlobalLayoutListener {
  public c0(e0 parame0) {}
  
  public void onGlobalLayout() {
    if (this.e.b()) {
      e0 e01 = this.e;
      if (!((q1)e01.m).C) {
        View view = e01.r;
        if (view == null || !view.isShown()) {
          this.e.dismiss();
          return;
        } 
        this.e.m.d();
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */