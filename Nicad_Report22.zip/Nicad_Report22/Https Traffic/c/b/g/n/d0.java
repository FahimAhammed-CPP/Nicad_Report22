package c.b.g.n;

import android.view.View;
import android.view.ViewTreeObserver;

public class d0 implements View.OnAttachStateChangeListener {
  public d0(e0 parame0) {}
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    ViewTreeObserver viewTreeObserver = this.e.t;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.e.t = paramView.getViewTreeObserver(); 
      e0 e01 = this.e;
      e01.t.removeGlobalOnLayoutListener(e01.n);
    } 
    paramView.removeOnAttachStateChangeListener(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\n\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */