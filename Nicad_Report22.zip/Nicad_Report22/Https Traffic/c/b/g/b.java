package c.b.g;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;

public abstract class b {
  public Object e;
  
  public boolean f;
  
  public abstract void c();
  
  public abstract View d();
  
  public abstract Menu e();
  
  public abstract MenuInflater f();
  
  public abstract CharSequence g();
  
  public abstract CharSequence h();
  
  public abstract void i();
  
  public abstract boolean j();
  
  public abstract void k(View paramView);
  
  public abstract void l(int paramInt);
  
  public abstract void m(CharSequence paramCharSequence);
  
  public abstract void n(int paramInt);
  
  public abstract void o(CharSequence paramCharSequence);
  
  public abstract void p(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */