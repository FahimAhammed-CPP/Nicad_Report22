package c.b.g;

import android.view.View;
import c.h.j.a0;
import c.h.j.z;

public class k extends a0 {
  public boolean a = false;
  
  public int b = 0;
  
  public k(l paraml) {}
  
  public void b(View paramView) {
    int i = this.b + 1;
    this.b = i;
    if (i == this.c.a.size()) {
      z z = this.c.d;
      if (z != null)
        z.b(null); 
      this.b = 0;
      this.a = false;
      this.c.e = false;
    } 
  }
  
  public void c(View paramView) {
    if (this.a)
      return; 
    this.a = true;
    z z = this.c.d;
    if (z != null)
      z.c(null); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\g\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */