package c.b.h;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

public class d1 extends Drawable implements Drawable.Callback {
  public Drawable e;
  
  public boolean f;
  
  public d1(Drawable paramDrawable) {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.setCallback(null); 
    this.e = paramDrawable;
    paramDrawable.setCallback(this);
    this.f = true;
  }
  
  public void draw(Canvas paramCanvas) {
    if (this.f)
      this.e.draw(paramCanvas); 
  }
  
  public int getChangingConfigurations() {
    return this.e.getChangingConfigurations();
  }
  
  public Drawable getCurrent() {
    return this.e.getCurrent();
  }
  
  public int getIntrinsicHeight() {
    return this.e.getIntrinsicHeight();
  }
  
  public int getIntrinsicWidth() {
    return this.e.getIntrinsicWidth();
  }
  
  public int getMinimumHeight() {
    return this.e.getMinimumHeight();
  }
  
  public int getMinimumWidth() {
    return this.e.getMinimumWidth();
  }
  
  public int getOpacity() {
    return this.e.getOpacity();
  }
  
  public boolean getPadding(Rect paramRect) {
    return this.e.getPadding(paramRect);
  }
  
  public int[] getState() {
    return this.e.getState();
  }
  
  public Region getTransparentRegion() {
    return this.e.getTransparentRegion();
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    invalidateSelf();
  }
  
  public boolean isAutoMirrored() {
    return this.e.isAutoMirrored();
  }
  
  public boolean isStateful() {
    return this.e.isStateful();
  }
  
  public void jumpToCurrentState() {
    this.e.jumpToCurrentState();
  }
  
  public void onBoundsChange(Rect paramRect) {
    this.e.setBounds(paramRect);
  }
  
  public boolean onLevelChange(int paramInt) {
    return this.e.setLevel(paramInt);
  }
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong) {
    scheduleSelf(paramRunnable, paramLong);
  }
  
  public void setAlpha(int paramInt) {
    this.e.setAlpha(paramInt);
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    this.e.setAutoMirrored(paramBoolean);
  }
  
  public void setChangingConfigurations(int paramInt) {
    this.e.setChangingConfigurations(paramInt);
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.e.setColorFilter(paramColorFilter);
  }
  
  public void setDither(boolean paramBoolean) {
    this.e.setDither(paramBoolean);
  }
  
  public void setFilterBitmap(boolean paramBoolean) {
    this.e.setFilterBitmap(paramBoolean);
  }
  
  public void setHotspot(float paramFloat1, float paramFloat2) {
    if (this.f)
      this.e.setHotspot(paramFloat1, paramFloat2); 
  }
  
  public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.f)
      this.e.setHotspotBounds(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public boolean setState(int[] paramArrayOfint) {
    return this.f ? this.e.setState(paramArrayOfint) : false;
  }
  
  public void setTint(int paramInt) {
    this.e.setTint(paramInt);
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    this.e.setTintList(paramColorStateList);
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    this.e.setTintMode(paramMode);
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    boolean bool1 = this.f;
    boolean bool = false;
    null = bool;
    if (bool1) {
      if (!super.setVisible(paramBoolean1, paramBoolean2)) {
        null = bool;
        return this.e.setVisible(paramBoolean1, paramBoolean2) ? true : null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable) {
    unscheduleSelf(paramRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\d1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */