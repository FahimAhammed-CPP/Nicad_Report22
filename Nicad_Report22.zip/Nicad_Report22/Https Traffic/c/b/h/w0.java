package c.b.h;

import android.text.StaticLayout;
import android.widget.TextView;

public class w0 extends v0 {
  public void a(StaticLayout.Builder paramBuilder, TextView paramTextView) {
    paramBuilder.setTextDirection(paramTextView.getTextDirectionHeuristic());
  }
  
  public boolean b(TextView paramTextView) {
    return paramTextView.isHorizontallyScrollable();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\w0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */