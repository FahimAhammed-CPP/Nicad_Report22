package c.b.h;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;

public class o0 extends View.BaseSavedState {
  public static final Parcelable.Creator<o0> CREATOR = new n0();
  
  public boolean e;
  
  public o0(Parcel paramParcel) {
    super(paramParcel);
    boolean bool;
    if (paramParcel.readByte() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.e = bool;
  }
  
  public o0(Parcelable paramParcelable) {
    super(paramParcelable);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeByte((byte)this.e);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */