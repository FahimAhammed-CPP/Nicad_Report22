package c.b.h;

public class l1 implements Runnable {
  public l1(q1 paramq1) {}
  
  public void run() {
    f1 f1 = this.e.g;
    if (f1 != null) {
      f1.setListSelectionHidden(true);
      f1.requestLayout();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\l1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */