package c.b.h;

import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import c.b.g.n.a;

public class l2 implements View.OnClickListener {
  public final a e;
  
  public l2(n2 paramn2) {
    this.e = new a(paramn2.a.getContext(), 0, 16908332, 0, paramn2.i);
  }
  
  public void onClick(View paramView) {
    n2 n21 = this.f;
    Window.Callback callback = n21.l;
    if (callback != null && n21.m)
      callback.onMenuItemSelected(0, (MenuItem)this.e); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\l2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */