package c.b.h;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import c.b.g.n.f0;
import c.b.g.n.l;
import c.b.g.n.o;
import c.b.g.n.p;
import c.b.g.n.v;
import c.b.g.n.y;
import c.b.g.n.z;
import java.util.ArrayList;

public class m implements y {
  public f A;
  
  public e B;
  
  public final j C;
  
  public int D;
  
  public Context e;
  
  public Context f;
  
  public l g;
  
  public LayoutInflater h;
  
  public y.a i;
  
  public int j;
  
  public int k;
  
  public z l;
  
  public int m;
  
  public h n;
  
  public Drawable o;
  
  public boolean p;
  
  public boolean q;
  
  public boolean r;
  
  public int s;
  
  public int t;
  
  public int u;
  
  public boolean v;
  
  public int w;
  
  public final SparseBooleanArray x;
  
  public i y;
  
  public d z;
  
  public m(Context paramContext) {
    this.e = paramContext;
    this.h = LayoutInflater.from(paramContext);
    this.j = 2131427331;
    this.k = 2131427330;
    this.x = new SparseBooleanArray();
    this.C = new j(this);
  }
  
  public void a(l paraml, boolean paramBoolean) {
    b();
    y.a a1 = this.i;
    if (a1 != null)
      a1.a(paraml, paramBoolean); 
  }
  
  public boolean b() {
    return g() | n();
  }
  
  public void c(Context paramContext, l paraml) {
    this.f = paramContext;
    LayoutInflater.from(paramContext);
    this.g = paraml;
    Resources resources = paramContext.getResources();
    if (!this.r)
      this.q = true; 
    int n = (paramContext.getResources().getDisplayMetrics()).widthPixels;
    int k = 2;
    this.s = n / 2;
    Configuration configuration = paramContext.getResources().getConfiguration();
    n = configuration.screenWidthDp;
    int i1 = configuration.screenHeightDp;
    if (configuration.smallestScreenWidthDp > 600 || n > 600 || (n > 960 && i1 > 720) || (n > 720 && i1 > 960)) {
      k = 5;
    } else if (n >= 500 || (n > 640 && i1 > 480) || (n > 480 && i1 > 640)) {
      k = 4;
    } else if (n >= 360) {
      k = 3;
    } 
    this.u = k;
    k = this.s;
    if (this.q) {
      if (this.n == null) {
        h h1 = new h(this, this.e);
        this.n = h1;
        if (this.p) {
          h1.setImageDrawable(this.o);
          this.o = null;
          this.p = false;
        } 
        n = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.n.measure(n, n);
      } 
      k -= this.n.getMeasuredWidth();
    } else {
      this.n = null;
    } 
    this.t = k;
    this.w = (int)((resources.getDisplayMetrics()).density * 56.0F);
  }
  
  public View d(o paramo, View paramView, ViewGroup paramViewGroup) {
    View view = paramo.getActionView();
    byte b = 0;
    if (view == null || paramo.f()) {
      z.a a1;
      if (paramView instanceof z.a) {
        a1 = (z.a)paramView;
      } else {
        a1 = (z.a)this.h.inflate(this.k, paramViewGroup, false);
      } 
      a1.f(paramo, 0);
      ActionMenuView actionMenuView1 = (ActionMenuView)this.l;
      ActionMenuItemView actionMenuItemView = (ActionMenuItemView)a1;
      actionMenuItemView.setItemInvoker((l.b)actionMenuView1);
      if (this.B == null)
        this.B = new e(this); 
      actionMenuItemView.setPopupCallback(this.B);
      view = (View)a1;
    } 
    if (paramo.C)
      b = 8; 
    view.setVisibility(b);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.r(layoutParams)); 
    return view;
  }
  
  public void e(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof l))
      return; 
    int k = ((l)paramParcelable).e;
    if (k > 0) {
      MenuItem menuItem = this.g.findItem(k);
      if (menuItem != null)
        f((f0)menuItem.getSubMenu()); 
    } 
  }
  
  public boolean f(f0 paramf0) {
    boolean bool = paramf0.hasVisibleItems();
    boolean bool1 = false;
    if (!bool)
      return false; 
    f0 f01 = paramf0;
    while (true) {
      View view;
      l l1 = f01.z;
      if (l1 != this.g) {
        f01 = (f0)l1;
        continue;
      } 
      o o = f01.A;
      ViewGroup viewGroup = (ViewGroup)this.l;
      l1 = null;
      if (viewGroup == null) {
        l l2 = l1;
      } else {
        int i2 = viewGroup.getChildCount();
        int i1 = 0;
        while (true) {
          l l2 = l1;
          if (i1 < i2) {
            view = viewGroup.getChildAt(i1);
            if (view instanceof z.a && ((z.a)view).getItemData() == o)
              break; 
            i1++;
            continue;
          } 
          break;
        } 
      } 
      if (view == null)
        return false; 
      this.D = paramf0.A.a;
      int n = paramf0.size();
      int k = 0;
      while (true) {
        bool = bool1;
        if (k < n) {
          MenuItem menuItem = paramf0.getItem(k);
          if (menuItem.isVisible() && menuItem.getIcon() != null) {
            bool = true;
            break;
          } 
          k++;
          continue;
        } 
        break;
      } 
      d d1 = new d(this, this.f, paramf0, view);
      this.z = d1;
      d1.h = bool;
      v v = d1.j;
      if (v != null)
        v.r(bool); 
      if (this.z.f()) {
        y.a a1 = this.i;
        if (a1 != null)
          a1.b((l)paramf0); 
        return true;
      } 
      throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
    } 
  }
  
  public boolean g() {
    f f1 = this.A;
    if (f1 != null) {
      z z1 = this.l;
      if (z1 != null) {
        ((View)z1).removeCallbacks(f1);
        this.A = null;
        return true;
      } 
    } 
    i i1 = this.y;
    if (i1 != null) {
      if (i1.b())
        i1.j.dismiss(); 
      return true;
    } 
    return false;
  }
  
  public int getId() {
    return this.m;
  }
  
  public void h(boolean paramBoolean) {
    ArrayList arrayList;
    ViewGroup viewGroup = (ViewGroup)this.l;
    l l2 = null;
    byte b = 0;
    if (viewGroup != null) {
      int n;
      l l4 = this.g;
      if (l4 != null) {
        l4.i();
        ArrayList<o> arrayList1 = this.g.l();
        int i3 = arrayList1.size();
        int i2 = 0;
        int i1 = i2;
        while (true) {
          n = i1;
          if (i2 < i3) {
            o o = arrayList1.get(i2);
            n = i1;
            if (o.g()) {
              View view1 = viewGroup.getChildAt(i1);
              if (view1 instanceof z.a) {
                o o1 = ((z.a)view1).getItemData();
              } else {
                l4 = null;
              } 
              View view2 = d(o, view1, viewGroup);
              if (o != l4) {
                view2.setPressed(false);
                view2.jumpDrawablesToCurrentState();
              } 
              if (view2 != view1) {
                ViewGroup viewGroup1 = (ViewGroup)view2.getParent();
                if (viewGroup1 != null)
                  viewGroup1.removeView(view2); 
                ((ViewGroup)this.l).addView(view2, i1);
              } 
              n = i1 + 1;
            } 
            i2++;
            i1 = n;
            continue;
          } 
          break;
        } 
      } else {
        n = 0;
      } 
      while (n < viewGroup.getChildCount()) {
        boolean bool;
        if (viewGroup.getChildAt(n) == this.n) {
          bool = false;
        } else {
          viewGroup.removeViewAt(n);
          bool = true;
        } 
        if (!bool)
          n++; 
      } 
    } 
    ((View)this.l).requestLayout();
    l l1 = this.g;
    if (l1 != null) {
      l1.i();
      arrayList = l1.i;
      int i1 = arrayList.size();
      for (int n = 0; n < i1; n++)
        p p = ((o)arrayList.get(n)).A; 
    } 
    l l3 = this.g;
    l1 = l2;
    if (l3 != null) {
      l3.i();
      arrayList = l3.j;
    } 
    int k = b;
    if (this.q) {
      k = b;
      if (arrayList != null) {
        int n = arrayList.size();
        if (n == 1) {
          k = ((o)arrayList.get(0)).C ^ true;
        } else {
          k = b;
          if (n > 0)
            k = 1; 
        } 
      } 
    } 
    if (k != 0) {
      if (this.n == null)
        this.n = new h(this, this.e); 
      ViewGroup viewGroup1 = (ViewGroup)this.n.getParent();
      if (viewGroup1 != this.l) {
        if (viewGroup1 != null)
          viewGroup1.removeView((View)this.n); 
        ActionMenuView actionMenuView = (ActionMenuView)this.l;
        h h1 = this.n;
        ActionMenuView.c c = actionMenuView.q();
        c.c = true;
        actionMenuView.addView((View)h1, (ViewGroup.LayoutParams)c);
      } 
    } else {
      h h1 = this.n;
      if (h1 != null) {
        ViewParent viewParent = h1.getParent();
        z z1 = this.l;
        if (viewParent == z1)
          ((ViewGroup)z1).removeView((View)this.n); 
      } 
    } 
    ((ActionMenuView)this.l).setOverflowReserved(this.q);
  }
  
  public boolean i() {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Lc/b/g/n/l;
    //   4: astore #14
    //   6: aload #14
    //   8: ifnull -> 28
    //   11: aload #14
    //   13: invokevirtual l : ()Ljava/util/ArrayList;
    //   16: astore #14
    //   18: aload #14
    //   20: invokevirtual size : ()I
    //   23: istore #6
    //   25: goto -> 34
    //   28: iconst_0
    //   29: istore #6
    //   31: aconst_null
    //   32: astore #14
    //   34: aload_0
    //   35: getfield u : I
    //   38: istore #9
    //   40: aload_0
    //   41: getfield t : I
    //   44: istore #8
    //   46: iconst_0
    //   47: iconst_0
    //   48: invokestatic makeMeasureSpec : (II)I
    //   51: istore #10
    //   53: aload_0
    //   54: getfield l : Lc/b/g/n/z;
    //   57: checkcast android/view/ViewGroup
    //   60: astore #15
    //   62: iconst_0
    //   63: istore #7
    //   65: iload #7
    //   67: istore_1
    //   68: iload_1
    //   69: istore_2
    //   70: iload_2
    //   71: istore_3
    //   72: iload_2
    //   73: istore #4
    //   75: iload_1
    //   76: istore #5
    //   78: iload #7
    //   80: istore_2
    //   81: iload #9
    //   83: istore_1
    //   84: iload_2
    //   85: iload #6
    //   87: if_icmpge -> 205
    //   90: aload #14
    //   92: iload_2
    //   93: invokevirtual get : (I)Ljava/lang/Object;
    //   96: checkcast c/b/g/n/o
    //   99: astore #16
    //   101: aload #16
    //   103: getfield y : I
    //   106: istore #9
    //   108: iload #9
    //   110: iconst_2
    //   111: iand
    //   112: iconst_2
    //   113: if_icmpne -> 122
    //   116: iconst_1
    //   117: istore #7
    //   119: goto -> 125
    //   122: iconst_0
    //   123: istore #7
    //   125: iload #7
    //   127: ifeq -> 137
    //   130: iload_3
    //   131: iconst_1
    //   132: iadd
    //   133: istore_3
    //   134: goto -> 171
    //   137: iload #9
    //   139: iconst_1
    //   140: iand
    //   141: iconst_1
    //   142: if_icmpne -> 151
    //   145: iconst_1
    //   146: istore #7
    //   148: goto -> 154
    //   151: iconst_0
    //   152: istore #7
    //   154: iload #7
    //   156: ifeq -> 168
    //   159: iload #4
    //   161: iconst_1
    //   162: iadd
    //   163: istore #4
    //   165: goto -> 171
    //   168: iconst_1
    //   169: istore #5
    //   171: iload_1
    //   172: istore #7
    //   174: aload_0
    //   175: getfield v : Z
    //   178: ifeq -> 195
    //   181: iload_1
    //   182: istore #7
    //   184: aload #16
    //   186: getfield C : Z
    //   189: ifeq -> 195
    //   192: iconst_0
    //   193: istore #7
    //   195: iload_2
    //   196: iconst_1
    //   197: iadd
    //   198: istore_2
    //   199: iload #7
    //   201: istore_1
    //   202: goto -> 84
    //   205: iload_1
    //   206: istore_2
    //   207: aload_0
    //   208: getfield q : Z
    //   211: ifeq -> 233
    //   214: iload #5
    //   216: ifne -> 229
    //   219: iload_1
    //   220: istore_2
    //   221: iload #4
    //   223: iload_3
    //   224: iadd
    //   225: iload_1
    //   226: if_icmple -> 233
    //   229: iload_1
    //   230: iconst_1
    //   231: isub
    //   232: istore_2
    //   233: iload_2
    //   234: iload_3
    //   235: isub
    //   236: istore_1
    //   237: aload_0
    //   238: getfield x : Landroid/util/SparseBooleanArray;
    //   241: astore #16
    //   243: aload #16
    //   245: invokevirtual clear : ()V
    //   248: iconst_0
    //   249: istore #7
    //   251: iconst_0
    //   252: istore_2
    //   253: iload #8
    //   255: istore_3
    //   256: iload #7
    //   258: iload #6
    //   260: if_icmpge -> 659
    //   263: aload #14
    //   265: iload #7
    //   267: invokevirtual get : (I)Ljava/lang/Object;
    //   270: checkcast c/b/g/n/o
    //   273: astore #17
    //   275: aload #17
    //   277: getfield y : I
    //   280: istore #5
    //   282: iload #5
    //   284: iconst_2
    //   285: iand
    //   286: iconst_2
    //   287: if_icmpne -> 296
    //   290: iconst_1
    //   291: istore #4
    //   293: goto -> 299
    //   296: iconst_0
    //   297: istore #4
    //   299: iload #4
    //   301: ifeq -> 372
    //   304: aload_0
    //   305: aload #17
    //   307: aconst_null
    //   308: aload #15
    //   310: invokevirtual d : (Lc/b/g/n/o;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   313: astore #18
    //   315: aload #18
    //   317: iload #10
    //   319: iload #10
    //   321: invokevirtual measure : (II)V
    //   324: aload #18
    //   326: invokevirtual getMeasuredWidth : ()I
    //   329: istore #5
    //   331: iload_3
    //   332: iload #5
    //   334: isub
    //   335: istore #4
    //   337: iload_2
    //   338: istore_3
    //   339: iload_2
    //   340: ifne -> 346
    //   343: iload #5
    //   345: istore_3
    //   346: aload #17
    //   348: getfield b : I
    //   351: istore_2
    //   352: iload_2
    //   353: ifeq -> 363
    //   356: aload #16
    //   358: iload_2
    //   359: iconst_1
    //   360: invokevirtual put : (IZ)V
    //   363: aload #17
    //   365: iconst_1
    //   366: invokevirtual l : (Z)V
    //   369: goto -> 633
    //   372: iload #5
    //   374: iconst_1
    //   375: iand
    //   376: iconst_1
    //   377: if_icmpne -> 386
    //   380: iconst_1
    //   381: istore #4
    //   383: goto -> 389
    //   386: iconst_0
    //   387: istore #4
    //   389: iload #4
    //   391: ifeq -> 638
    //   394: aload #17
    //   396: getfield b : I
    //   399: istore #9
    //   401: aload #16
    //   403: iload #9
    //   405: invokevirtual get : (I)Z
    //   408: istore #13
    //   410: iload_1
    //   411: ifgt -> 419
    //   414: iload #13
    //   416: ifeq -> 429
    //   419: iload_3
    //   420: ifle -> 429
    //   423: iconst_1
    //   424: istore #11
    //   426: goto -> 432
    //   429: iconst_0
    //   430: istore #11
    //   432: iload_3
    //   433: istore #4
    //   435: iload_2
    //   436: istore #5
    //   438: iload #11
    //   440: istore #12
    //   442: iload #11
    //   444: ifeq -> 512
    //   447: aload_0
    //   448: aload #17
    //   450: aconst_null
    //   451: aload #15
    //   453: invokevirtual d : (Lc/b/g/n/o;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   456: astore #18
    //   458: aload #18
    //   460: iload #10
    //   462: iload #10
    //   464: invokevirtual measure : (II)V
    //   467: aload #18
    //   469: invokevirtual getMeasuredWidth : ()I
    //   472: istore #8
    //   474: iload_3
    //   475: iload #8
    //   477: isub
    //   478: istore #4
    //   480: iload_2
    //   481: istore #5
    //   483: iload_2
    //   484: ifne -> 491
    //   487: iload #8
    //   489: istore #5
    //   491: iload #4
    //   493: iload #5
    //   495: iadd
    //   496: ifle -> 504
    //   499: iconst_1
    //   500: istore_2
    //   501: goto -> 506
    //   504: iconst_0
    //   505: istore_2
    //   506: iload #11
    //   508: iload_2
    //   509: iand
    //   510: istore #12
    //   512: iload #12
    //   514: ifeq -> 535
    //   517: iload #9
    //   519: ifeq -> 535
    //   522: aload #16
    //   524: iload #9
    //   526: iconst_1
    //   527: invokevirtual put : (IZ)V
    //   530: iload_1
    //   531: istore_2
    //   532: goto -> 612
    //   535: iload_1
    //   536: istore_2
    //   537: iload #13
    //   539: ifeq -> 612
    //   542: aload #16
    //   544: iload #9
    //   546: iconst_0
    //   547: invokevirtual put : (IZ)V
    //   550: iconst_0
    //   551: istore_3
    //   552: iload_1
    //   553: istore_2
    //   554: iload_3
    //   555: iload #7
    //   557: if_icmpge -> 612
    //   560: aload #14
    //   562: iload_3
    //   563: invokevirtual get : (I)Ljava/lang/Object;
    //   566: checkcast c/b/g/n/o
    //   569: astore #18
    //   571: iload_1
    //   572: istore_2
    //   573: aload #18
    //   575: getfield b : I
    //   578: iload #9
    //   580: if_icmpne -> 603
    //   583: iload_1
    //   584: istore_2
    //   585: aload #18
    //   587: invokevirtual g : ()Z
    //   590: ifeq -> 597
    //   593: iload_1
    //   594: iconst_1
    //   595: iadd
    //   596: istore_2
    //   597: aload #18
    //   599: iconst_0
    //   600: invokevirtual l : (Z)V
    //   603: iload_3
    //   604: iconst_1
    //   605: iadd
    //   606: istore_3
    //   607: iload_2
    //   608: istore_1
    //   609: goto -> 552
    //   612: iload_2
    //   613: istore_1
    //   614: iload #12
    //   616: ifeq -> 623
    //   619: iload_2
    //   620: iconst_1
    //   621: isub
    //   622: istore_1
    //   623: aload #17
    //   625: iload #12
    //   627: invokevirtual l : (Z)V
    //   630: iload #5
    //   632: istore_3
    //   633: iload_3
    //   634: istore_2
    //   635: goto -> 647
    //   638: aload #17
    //   640: iconst_0
    //   641: invokevirtual l : (Z)V
    //   644: iload_3
    //   645: istore #4
    //   647: iload #7
    //   649: iconst_1
    //   650: iadd
    //   651: istore #7
    //   653: iload #4
    //   655: istore_3
    //   656: goto -> 256
    //   659: iconst_1
    //   660: ireturn
  }
  
  public Parcelable j() {
    l l1 = new l();
    l1.e = this.D;
    return l1;
  }
  
  public void m(y.a parama) {
    this.i = parama;
  }
  
  public boolean n() {
    d d1 = this.z;
    if (d1 != null) {
      if (d1.b())
        d1.j.dismiss(); 
      return true;
    } 
    return false;
  }
  
  public boolean o() {
    i i1 = this.y;
    return (i1 != null && i1.b());
  }
  
  public boolean p() {
    if (this.q && !o()) {
      l l1 = this.g;
      if (l1 != null && this.l != null && this.A == null) {
        l1.i();
        if (!l1.j.isEmpty()) {
          f f1 = new f(this, new i(this, this.f, this.g, (View)this.n, true));
          this.A = f1;
          ((View)this.l).post(f1);
          return true;
        } 
      } 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */