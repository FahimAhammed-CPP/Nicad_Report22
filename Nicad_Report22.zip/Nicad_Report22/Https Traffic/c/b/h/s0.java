package c.b.h;

import android.graphics.Typeface;
import android.os.Build;
import android.widget.TextView;
import c.h.c.f.j;
import java.lang.ref.WeakReference;

public class s0 extends j {
  public s0(t0 paramt0, int paramInt1, int paramInt2, WeakReference paramWeakReference) {}
  
  public void d(int paramInt) {}
  
  public void e(Typeface paramTypeface) {
    Typeface typeface = paramTypeface;
    if (Build.VERSION.SDK_INT >= 28) {
      int i = this.a;
      typeface = paramTypeface;
      if (i != -1) {
        boolean bool;
        if ((this.b & 0x2) != 0) {
          bool = true;
        } else {
          bool = false;
        } 
        typeface = Typeface.create(paramTypeface, i, bool);
      } 
    } 
    t0 t01 = this.d;
    WeakReference<TextView> weakReference = this.c;
    if (t01.m) {
      t01.l = typeface;
      TextView textView = weakReference.get();
      if (textView != null)
        textView.setTypeface(typeface, t01.j); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */