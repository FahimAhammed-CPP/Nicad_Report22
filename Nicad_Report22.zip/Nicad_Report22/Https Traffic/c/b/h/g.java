package c.b.h;

import android.view.View;
import c.b.g.n.b0;

public class g extends j1 {
  public g(h paramh, View paramView, m paramm) {
    super(paramView);
  }
  
  public b0 b() {
    i i = this.n.g.y;
    return (b0)((i == null) ? null : i.a());
  }
  
  public boolean c() {
    this.n.g.p();
    return true;
  }
  
  public boolean f() {
    m m = this.n.g;
    if (m.A != null)
      return false; 
    m.g();
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */