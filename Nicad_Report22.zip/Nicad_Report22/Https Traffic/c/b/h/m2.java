package c.b.h;

import android.view.View;
import c.h.j.a0;

public class m2 extends a0 {
  public boolean a = false;
  
  public m2(n2 paramn2, int paramInt) {}
  
  public void a(View paramView) {
    this.a = true;
  }
  
  public void b(View paramView) {
    if (!this.a)
      this.c.a.setVisibility(this.b); 
  }
  
  public void c(View paramView) {
    this.c.a.setVisibility(0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\m2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */