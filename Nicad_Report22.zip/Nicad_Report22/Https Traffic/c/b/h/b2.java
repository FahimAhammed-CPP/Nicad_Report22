package c.b.h;

import android.widget.AdapterView;
import android.widget.HorizontalScrollView;

public abstract class b2 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\b2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */