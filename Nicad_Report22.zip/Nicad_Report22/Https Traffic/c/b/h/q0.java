package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import c.b.d.a.a;

public class q0 extends Spinner {
  public static final int[] m = new int[] { 16843505 };
  
  public final o e;
  
  public final Context f;
  
  public j1 g;
  
  public SpinnerAdapter h;
  
  public final boolean i;
  
  public p0 j;
  
  public int k;
  
  public final Rect l;
  
  public q0(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: ldc 2130903754
    //   5: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   8: aload_0
    //   9: new android/graphics/Rect
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: putfield l : Landroid/graphics/Rect;
    //   19: aload_0
    //   20: aload_0
    //   21: invokevirtual getContext : ()Landroid/content/Context;
    //   24: invokestatic a : (Landroid/view/View;Landroid/content/Context;)V
    //   27: aload_1
    //   28: aload_2
    //   29: getstatic c/b/b.w : [I
    //   32: ldc 2130903754
    //   34: iconst_0
    //   35: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   38: astore #8
    //   40: aload_0
    //   41: new c/b/h/o
    //   44: dup
    //   45: aload_0
    //   46: invokespecial <init> : (Landroid/view/View;)V
    //   49: putfield e : Lc/b/h/o;
    //   52: aload #8
    //   54: iconst_4
    //   55: iconst_0
    //   56: invokevirtual getResourceId : (II)I
    //   59: istore_3
    //   60: iload_3
    //   61: ifeq -> 80
    //   64: aload_0
    //   65: new c/b/g/d
    //   68: dup
    //   69: aload_1
    //   70: iload_3
    //   71: invokespecial <init> : (Landroid/content/Context;I)V
    //   74: putfield f : Landroid/content/Context;
    //   77: goto -> 85
    //   80: aload_0
    //   81: aload_1
    //   82: putfield f : Landroid/content/Context;
    //   85: aconst_null
    //   86: astore #6
    //   88: iconst_m1
    //   89: istore #4
    //   91: aload_1
    //   92: aload_2
    //   93: getstatic c/b/h/q0.m : [I
    //   96: ldc 2130903754
    //   98: iconst_0
    //   99: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   102: astore #5
    //   104: aload #5
    //   106: astore #6
    //   108: iload #4
    //   110: istore_3
    //   111: aload #5
    //   113: astore #7
    //   115: aload #5
    //   117: iconst_0
    //   118: invokevirtual hasValue : (I)Z
    //   121: ifeq -> 196
    //   124: aload #5
    //   126: astore #6
    //   128: aload #5
    //   130: iconst_0
    //   131: iconst_0
    //   132: invokevirtual getInt : (II)I
    //   135: istore_3
    //   136: aload #5
    //   138: astore #7
    //   140: goto -> 196
    //   143: astore_2
    //   144: aload #6
    //   146: astore_1
    //   147: goto -> 423
    //   150: astore #7
    //   152: goto -> 167
    //   155: astore_2
    //   156: aload #6
    //   158: astore_1
    //   159: goto -> 423
    //   162: astore #7
    //   164: aconst_null
    //   165: astore #5
    //   167: aload #5
    //   169: astore #6
    //   171: ldc 'AppCompatSpinner'
    //   173: ldc 'Could not read android:spinnerMode'
    //   175: aload #7
    //   177: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   180: pop
    //   181: iload #4
    //   183: istore_3
    //   184: aload #5
    //   186: ifnull -> 201
    //   189: aload #5
    //   191: astore #7
    //   193: iload #4
    //   195: istore_3
    //   196: aload #7
    //   198: invokevirtual recycle : ()V
    //   201: iload_3
    //   202: ifeq -> 319
    //   205: iload_3
    //   206: iconst_1
    //   207: if_icmpeq -> 213
    //   210: goto -> 346
    //   213: new c/b/h/m0
    //   216: dup
    //   217: aload_0
    //   218: aload_0
    //   219: getfield f : Landroid/content/Context;
    //   222: aload_2
    //   223: ldc 2130903754
    //   225: invokespecial <init> : (Lc/b/h/q0;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   228: astore #5
    //   230: aload_0
    //   231: getfield f : Landroid/content/Context;
    //   234: aload_2
    //   235: getstatic c/b/b.w : [I
    //   238: ldc 2130903754
    //   240: iconst_0
    //   241: invokestatic q : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Lc/b/h/j2;
    //   244: astore #6
    //   246: aload_0
    //   247: aload #6
    //   249: iconst_3
    //   250: bipush #-2
    //   252: invokevirtual k : (II)I
    //   255: putfield k : I
    //   258: aload #6
    //   260: iconst_1
    //   261: invokevirtual g : (I)Landroid/graphics/drawable/Drawable;
    //   264: astore #7
    //   266: aload #5
    //   268: getfield D : Landroid/widget/PopupWindow;
    //   271: aload #7
    //   273: invokevirtual setBackgroundDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   276: aload #5
    //   278: aload #8
    //   280: iconst_2
    //   281: invokevirtual getString : (I)Ljava/lang/String;
    //   284: putfield H : Ljava/lang/CharSequence;
    //   287: aload #6
    //   289: getfield b : Landroid/content/res/TypedArray;
    //   292: invokevirtual recycle : ()V
    //   295: aload_0
    //   296: aload #5
    //   298: putfield j : Lc/b/h/p0;
    //   301: aload_0
    //   302: new c/b/h/f0
    //   305: dup
    //   306: aload_0
    //   307: aload_0
    //   308: aload #5
    //   310: invokespecial <init> : (Lc/b/h/q0;Landroid/view/View;Lc/b/h/m0;)V
    //   313: putfield g : Lc/b/h/j1;
    //   316: goto -> 346
    //   319: new c/b/h/h0
    //   322: dup
    //   323: aload_0
    //   324: invokespecial <init> : (Lc/b/h/q0;)V
    //   327: astore #5
    //   329: aload_0
    //   330: aload #5
    //   332: putfield j : Lc/b/h/p0;
    //   335: aload #5
    //   337: aload #8
    //   339: iconst_2
    //   340: invokevirtual getString : (I)Ljava/lang/String;
    //   343: invokevirtual h : (Ljava/lang/CharSequence;)V
    //   346: aload #8
    //   348: iconst_0
    //   349: invokevirtual getTextArray : (I)[Ljava/lang/CharSequence;
    //   352: astore #5
    //   354: aload #5
    //   356: ifnull -> 383
    //   359: new android/widget/ArrayAdapter
    //   362: dup
    //   363: aload_1
    //   364: ldc 17367048
    //   366: aload #5
    //   368: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   371: astore_1
    //   372: aload_1
    //   373: ldc 2131427445
    //   375: invokevirtual setDropDownViewResource : (I)V
    //   378: aload_0
    //   379: aload_1
    //   380: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   383: aload #8
    //   385: invokevirtual recycle : ()V
    //   388: aload_0
    //   389: iconst_1
    //   390: putfield i : Z
    //   393: aload_0
    //   394: getfield h : Landroid/widget/SpinnerAdapter;
    //   397: astore_1
    //   398: aload_1
    //   399: ifnull -> 412
    //   402: aload_0
    //   403: aload_1
    //   404: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   407: aload_0
    //   408: aconst_null
    //   409: putfield h : Landroid/widget/SpinnerAdapter;
    //   412: aload_0
    //   413: getfield e : Lc/b/h/o;
    //   416: aload_2
    //   417: ldc 2130903754
    //   419: invokevirtual d : (Landroid/util/AttributeSet;I)V
    //   422: return
    //   423: aload_1
    //   424: ifnull -> 431
    //   427: aload_1
    //   428: invokevirtual recycle : ()V
    //   431: aload_2
    //   432: athrow
    // Exception table:
    //   from	to	target	type
    //   91	104	162	java/lang/Exception
    //   91	104	155	finally
    //   115	124	150	java/lang/Exception
    //   115	124	143	finally
    //   128	136	150	java/lang/Exception
    //   128	136	143	finally
    //   171	181	143	finally
  }
  
  public int a(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int k = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int m = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i1 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int j = Math.max(0, i - 15 - i1 - i);
    View view = null;
    i = 0;
    while (j < i1) {
      int i3 = paramSpinnerAdapter.getItemViewType(j);
      int i2 = k;
      if (i3 != k) {
        view = null;
        i2 = i3;
      } 
      view = paramSpinnerAdapter.getView(j, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(m, n);
      i = Math.max(i, view.getMeasuredWidth());
      j++;
      k = i2;
    } 
    j = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.l);
      Rect rect = this.l;
      j = i + rect.left + rect.right;
    } 
    return j;
  }
  
  public void b() {
    this.j.m(getTextDirection(), getTextAlignment());
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    o o1 = this.e;
    if (o1 != null)
      o1.a(); 
  }
  
  public int getDropDownHorizontalOffset() {
    p0 p01 = this.j;
    return (p01 != null) ? p01.a() : super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset() {
    p0 p01 = this.j;
    return (p01 != null) ? p01.n() : super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth() {
    return (this.j != null) ? this.k : super.getDropDownWidth();
  }
  
  public final p0 getInternalPopup() {
    return this.j;
  }
  
  public Drawable getPopupBackground() {
    p0 p01 = this.j;
    return (p01 != null) ? p01.f() : super.getPopupBackground();
  }
  
  public Context getPopupContext() {
    return this.f;
  }
  
  public CharSequence getPrompt() {
    p0 p01 = this.j;
    return (p01 != null) ? p01.o() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    o o1 = this.e;
    return (o1 != null) ? o1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    o o1 = this.e;
    return (o1 != null) ? o1.c() : null;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    p0 p01 = this.j;
    if (p01 != null && p01.b())
      this.j.dismiss(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.j != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    o0 o0 = (o0)paramParcelable;
    super.onRestoreInstanceState(o0.getSuperState());
    if (o0.e) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new g0(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    o0 o0 = new o0(super.onSaveInstanceState());
    p0 p01 = this.j;
    if (p01 != null && p01.b()) {
      bool = true;
    } else {
      bool = false;
    } 
    o0.e = bool;
    return (Parcelable)o0;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    j1 j11 = this.g;
    return (j11 != null && j11.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    p0 p01 = this.j;
    if (p01 != null) {
      if (!p01.b())
        b(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.i) {
      this.h = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.j != null) {
      Context context2 = this.f;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.j.p(new i0(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    o o1 = this.e;
    if (o1 != null)
      o1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    o o1 = this.e;
    if (o1 != null)
      o1.f(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    p0 p01 = this.j;
    if (p01 != null) {
      p01.k(paramInt);
      this.j.l(paramInt);
      return;
    } 
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    p0 p01 = this.j;
    if (p01 != null) {
      p01.j(paramInt);
      return;
    } 
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.j != null) {
      this.k = paramInt;
      return;
    } 
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    p0 p01 = this.j;
    if (p01 != null) {
      p01.i(paramDrawable);
      return;
    } 
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(a.a(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    p0 p01 = this.j;
    if (p01 != null) {
      p01.h(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    o o1 = this.e;
    if (o1 != null)
      o1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    o o1 = this.e;
    if (o1 != null)
      o1.i(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\q0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */