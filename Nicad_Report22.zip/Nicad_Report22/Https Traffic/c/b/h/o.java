package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import c.b.b;
import c.h.j.u;
import java.util.concurrent.atomic.AtomicInteger;

public class o {
  public final View a;
  
  public final u b;
  
  public int c = -1;
  
  public h2 d;
  
  public h2 e;
  
  public h2 f;
  
  public o(View paramView) {
    this.a = paramView;
    this.b = u.a();
  }
  
  public void a() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      boolean bool1;
      h2 h21 = this.d;
      boolean bool2 = true;
      if (h21 != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1) {
        if (this.f == null)
          this.f = new h2(); 
        h21 = this.f;
        h21.a = null;
        h21.d = false;
        h21.b = null;
        h21.c = false;
        View view = this.a;
        AtomicInteger atomicInteger = u.a;
        ColorStateList colorStateList = view.getBackgroundTintList();
        if (colorStateList != null) {
          h21.d = true;
          h21.a = colorStateList;
        } 
        PorterDuff.Mode mode = this.a.getBackgroundTintMode();
        if (mode != null) {
          h21.c = true;
          h21.b = mode;
        } 
        if (h21.d || h21.c) {
          u.f(drawable, h21, this.a.getDrawableState());
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
        if (bool1)
          return; 
      } 
      h21 = this.e;
      if (h21 != null) {
        u.f(drawable, h21, this.a.getDrawableState());
        return;
      } 
      h21 = this.d;
      if (h21 != null)
        u.f(drawable, h21, this.a.getDrawableState()); 
    } 
  }
  
  public ColorStateList b() {
    h2 h21 = this.e;
    return (h21 != null) ? h21.a : null;
  }
  
  public PorterDuff.Mode c() {
    h2 h21 = this.e;
    return (h21 != null) ? h21.b : null;
  }
  
  public void d(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = b.A;
    j2 j2 = j2.q(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    View view = this.a;
    u.m(view, view.getContext(), arrayOfInt, paramAttributeSet, j2.b, paramInt, 0);
    try {
      if (j2.o(0)) {
        this.c = j2.l(0, -1);
        ColorStateList colorStateList = this.b.d(this.a.getContext(), this.c);
        if (colorStateList != null)
          g(colorStateList); 
      } 
      if (j2.o(1))
        this.a.setBackgroundTintList(j2.c(1)); 
      if (j2.o(2))
        this.a.setBackgroundTintMode(c1.b(j2.j(2, -1), null)); 
      return;
    } finally {
      j2.b.recycle();
    } 
  }
  
  public void e() {
    this.c = -1;
    g(null);
    a();
  }
  
  public void f(int paramInt) {
    this.c = paramInt;
    u u1 = this.b;
    if (u1 != null) {
      ColorStateList colorStateList = u1.d(this.a.getContext(), paramInt);
    } else {
      u1 = null;
    } 
    g((ColorStateList)u1);
    a();
  }
  
  public void g(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new h2(); 
      h2 h21 = this.d;
      h21.a = paramColorStateList;
      h21.d = true;
    } else {
      this.d = null;
    } 
    a();
  }
  
  public void h(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new h2(); 
    h2 h21 = this.e;
    h21.a = paramColorStateList;
    h21.d = true;
    a();
  }
  
  public void i(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new h2(); 
    h2 h21 = this.e;
    h21.b = paramMode;
    h21.c = true;
    a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */