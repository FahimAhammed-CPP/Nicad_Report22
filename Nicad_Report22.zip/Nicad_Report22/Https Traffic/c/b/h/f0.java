package c.b.h;

import android.view.View;
import c.b.g.n.b0;

public class f0 extends j1 {
  public f0(q0 paramq0, View paramView, m0 paramm0) {
    super(paramView);
  }
  
  public b0 b() {
    return this.n;
  }
  
  public boolean c() {
    if (!this.o.getInternalPopup().b())
      this.o.b(); 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */