package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import c.b.a;
import c.b.d.a.a;

public class y extends MultiAutoCompleteTextView {
  public static final int[] g = new int[] { 16843126 };
  
  public final o e;
  
  public final t0 f;
  
  public y(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903094);
    f2.a((View)this, getContext());
    j2 j2 = j2.q(getContext(), paramAttributeSet, g, 2130903094, 0);
    if (j2.o(0))
      setDropDownBackgroundDrawable(j2.g(0)); 
    j2.b.recycle();
    o o1 = new o((View)this);
    this.e = o1;
    o1.d(paramAttributeSet, 2130903094);
    t0 t01 = new t0((TextView)this);
    this.f = t01;
    t01.e(paramAttributeSet, 2130903094);
    t01.b();
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    o o1 = this.e;
    if (o1 != null)
      o1.a(); 
    t0 t01 = this.f;
    if (t01 != null)
      t01.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    o o1 = this.e;
    return (o1 != null) ? o1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    o o1 = this.e;
    return (o1 != null) ? o1.c() : null;
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    a.e(inputConnection, paramEditorInfo, (View)this);
    return inputConnection;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    o o1 = this.e;
    if (o1 != null)
      o1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    o o1 = this.e;
    if (o1 != null)
      o1.f(paramInt); 
  }
  
  public void setDropDownBackgroundResource(int paramInt) {
    setDropDownBackgroundDrawable(a.a(getContext(), paramInt));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    o o1 = this.e;
    if (o1 != null)
      o1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    o o1 = this.e;
    if (o1 != null)
      o1.i(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    t0 t01 = this.f;
    if (t01 != null)
      t01.f(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */