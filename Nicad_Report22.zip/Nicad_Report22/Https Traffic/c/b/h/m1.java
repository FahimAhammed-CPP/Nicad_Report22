package c.b.h;

import android.database.DataSetObserver;

public class m1 extends DataSetObserver {
  public m1(q1 paramq1) {}
  
  public void onChanged() {
    if (this.a.b())
      this.a.d(); 
  }
  
  public void onInvalidated() {
    this.a.dismiss();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\m1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */