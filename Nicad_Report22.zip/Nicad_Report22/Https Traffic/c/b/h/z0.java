package c.b.h;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import android.widget.ToggleButton;

public class z0 extends ToggleButton {
  public final t0 e;
  
  public z0(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 16842827);
    f2.a((View)this, getContext());
    t0 t01 = new t0((TextView)this);
    this.e = t01;
    t01.e(paramAttributeSet, 16842827);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\z0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */