package c.b.h;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import c.b.c.k;
import c.b.c.n;
import c.b.c.o;

public class h0 implements p0, DialogInterface.OnClickListener {
  public o e;
  
  public ListAdapter f;
  
  public CharSequence g;
  
  public h0(q0 paramq0) {}
  
  public int a() {
    return 0;
  }
  
  public boolean b() {
    o o1 = this.e;
    return (o1 != null) ? o1.isShowing() : false;
  }
  
  public void dismiss() {
    o o1 = this.e;
    if (o1 != null) {
      o1.dismiss();
      this.e = null;
    } 
  }
  
  public Drawable f() {
    return null;
  }
  
  public void h(CharSequence paramCharSequence) {
    this.g = paramCharSequence;
  }
  
  public void i(Drawable paramDrawable) {
    Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
  }
  
  public void j(int paramInt) {
    Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
  }
  
  public void k(int paramInt) {
    Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
  }
  
  public void l(int paramInt) {
    Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
  }
  
  public void m(int paramInt1, int paramInt2) {
    if (this.f == null)
      return; 
    n n = new n(this.h.getPopupContext());
    CharSequence charSequence = this.g;
    if (charSequence != null)
      n.a.d = charSequence; 
    ListAdapter listAdapter = this.f;
    int i = this.h.getSelectedItemPosition();
    k k = n.a;
    k.g = listAdapter;
    k.h = this;
    k.j = i;
    k.i = true;
    o o1 = n.a();
    this.e = o1;
    ListView listView = o1.g.g;
    listView.setTextDirection(paramInt1);
    listView.setTextAlignment(paramInt2);
    this.e.show();
  }
  
  public int n() {
    return 0;
  }
  
  public CharSequence o() {
    return this.g;
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    this.h.setSelection(paramInt);
    if (this.h.getOnItemClickListener() != null)
      this.h.performItemClick(null, paramInt, this.f.getItemId(paramInt)); 
    o o1 = this.e;
    if (o1 != null) {
      o1.dismiss();
      this.e = null;
    } 
  }
  
  public void p(ListAdapter paramListAdapter) {
    this.f = paramListAdapter;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */