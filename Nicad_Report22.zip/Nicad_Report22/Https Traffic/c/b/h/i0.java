package c.b.h;

import android.content.res.Resources;
import android.database.DataSetObserver;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;

public class i0 implements ListAdapter, SpinnerAdapter {
  public SpinnerAdapter e;
  
  public ListAdapter f;
  
  public i0(SpinnerAdapter paramSpinnerAdapter, Resources.Theme paramTheme) {
    this.e = paramSpinnerAdapter;
    if (paramSpinnerAdapter instanceof ListAdapter)
      this.f = (ListAdapter)paramSpinnerAdapter; 
    if (paramTheme != null && paramSpinnerAdapter instanceof ThemedSpinnerAdapter) {
      ThemedSpinnerAdapter themedSpinnerAdapter = (ThemedSpinnerAdapter)paramSpinnerAdapter;
      if (themedSpinnerAdapter.getDropDownViewTheme() != paramTheme)
        themedSpinnerAdapter.setDropDownViewTheme(paramTheme); 
    } 
  }
  
  public boolean areAllItemsEnabled() {
    ListAdapter listAdapter = this.f;
    return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
  }
  
  public int getCount() {
    SpinnerAdapter spinnerAdapter = this.e;
    return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
  }
  
  public View getDropDownView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    SpinnerAdapter spinnerAdapter = this.e;
    return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(paramInt, paramView, paramViewGroup);
  }
  
  public Object getItem(int paramInt) {
    SpinnerAdapter spinnerAdapter = this.e;
    return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(paramInt);
  }
  
  public long getItemId(int paramInt) {
    SpinnerAdapter spinnerAdapter = this.e;
    return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(paramInt);
  }
  
  public int getItemViewType(int paramInt) {
    return 0;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    SpinnerAdapter spinnerAdapter = this.e;
    return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(paramInt, paramView, paramViewGroup);
  }
  
  public int getViewTypeCount() {
    return 1;
  }
  
  public boolean hasStableIds() {
    SpinnerAdapter spinnerAdapter = this.e;
    return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
  }
  
  public boolean isEmpty() {
    return (getCount() == 0);
  }
  
  public boolean isEnabled(int paramInt) {
    ListAdapter listAdapter = this.f;
    return (listAdapter != null) ? listAdapter.isEnabled(paramInt) : true;
  }
  
  public void registerDataSetObserver(DataSetObserver paramDataSetObserver) {
    SpinnerAdapter spinnerAdapter = this.e;
    if (spinnerAdapter != null)
      spinnerAdapter.registerDataSetObserver(paramDataSetObserver); 
  }
  
  public void unregisterDataSetObserver(DataSetObserver paramDataSetObserver) {
    SpinnerAdapter spinnerAdapter = this.e;
    if (spinnerAdapter != null)
      spinnerAdapter.unregisterDataSetObserver(paramDataSetObserver); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */