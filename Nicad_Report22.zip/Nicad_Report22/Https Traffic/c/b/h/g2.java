package c.b.h;

import android.content.Context;
import android.content.ContextWrapper;

public abstract class g2 extends ContextWrapper {
  public static final Object a = new Object();
  
  public static Context a(Context paramContext) {
    if (!(paramContext instanceof g2) && !(paramContext.getResources() instanceof i2)) {
      paramContext.getResources();
      int i = s2.a;
    } 
    return paramContext;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\g2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */