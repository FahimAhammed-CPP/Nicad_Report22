package c.b.h;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;

public class z extends PopupWindow {
  public z(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: iload #4
    //   6: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;II)V
    //   9: aload_1
    //   10: aload_2
    //   11: getstatic c/b/b.t : [I
    //   14: iload_3
    //   15: iload #4
    //   17: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   20: astore_2
    //   21: aload_2
    //   22: iconst_2
    //   23: invokevirtual hasValue : (I)Z
    //   26: ifeq -> 39
    //   29: aload_0
    //   30: aload_2
    //   31: iconst_2
    //   32: iconst_0
    //   33: invokevirtual getBoolean : (IZ)Z
    //   36: invokevirtual setOverlapAnchor : (Z)V
    //   39: aload_2
    //   40: iconst_0
    //   41: invokevirtual hasValue : (I)Z
    //   44: ifeq -> 67
    //   47: aload_2
    //   48: iconst_0
    //   49: iconst_0
    //   50: invokevirtual getResourceId : (II)I
    //   53: istore_3
    //   54: iload_3
    //   55: ifeq -> 67
    //   58: aload_1
    //   59: iload_3
    //   60: invokestatic a : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   63: astore_1
    //   64: goto -> 73
    //   67: aload_2
    //   68: iconst_0
    //   69: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   72: astore_1
    //   73: aload_0
    //   74: aload_1
    //   75: invokevirtual setBackgroundDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   78: aload_2
    //   79: invokevirtual recycle : ()V
    //   82: return
  }
  
  public void showAsDropDown(View paramView, int paramInt1, int paramInt2) {
    super.showAsDropDown(paramView, paramInt1, paramInt2);
  }
  
  public void showAsDropDown(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    super.showAsDropDown(paramView, paramInt1, paramInt2, paramInt3);
  }
  
  public void update(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.update(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */