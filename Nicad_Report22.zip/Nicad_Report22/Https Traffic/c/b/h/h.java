package c.b.h;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatImageView;
import c.b.a;

public class h extends AppCompatImageView implements ActionMenuView.a {
  public h(m paramm, Context paramContext) {
    super(paramContext, null, 2130903069);
    setClickable(true);
    setFocusable(true);
    setVisibility(0);
    setEnabled(true);
    a.f((View)this, getContentDescription());
    setOnTouchListener(new g(this, (View)this, paramm));
  }
  
  public boolean a() {
    return false;
  }
  
  public boolean b() {
    return false;
  }
  
  public boolean performClick() {
    if (super.performClick())
      return true; 
    playSoundEffect(0);
    this.g.p();
    return true;
  }
  
  public boolean setFrame(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    boolean bool = super.setFrame(paramInt1, paramInt2, paramInt3, paramInt4);
    Drawable drawable1 = getDrawable();
    Drawable drawable2 = getBackground();
    if (drawable1 != null && drawable2 != null) {
      int i = getWidth();
      paramInt2 = getHeight();
      paramInt1 = Math.max(i, paramInt2) / 2;
      int j = getPaddingLeft();
      int k = getPaddingRight();
      paramInt3 = getPaddingTop();
      paramInt4 = getPaddingBottom();
      i = (i + j - k) / 2;
      paramInt2 = (paramInt2 + paramInt3 - paramInt4) / 2;
      drawable2.setHotspotBounds(i - paramInt1, paramInt2 - paramInt1, i + paramInt1, paramInt2 + paramInt1);
    } 
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */