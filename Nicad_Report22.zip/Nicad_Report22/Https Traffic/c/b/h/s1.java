package c.b.h;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import c.b.g.n.k;
import c.b.g.n.l;
import c.b.g.n.o;

public class s1 extends f1 {
  public final int r;
  
  public final int s;
  
  public r1 t;
  
  public MenuItem u;
  
  public s1(Context paramContext, boolean paramBoolean) {
    super(paramContext, paramBoolean);
    if (1 == paramContext.getResources().getConfiguration().getLayoutDirection()) {
      this.r = 21;
      this.s = 22;
      return;
    } 
    this.r = 22;
    this.s = 21;
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    if (this.t != null) {
      int i;
      k k;
      ListAdapter listAdapter = getAdapter();
      if (listAdapter instanceof HeaderViewListAdapter) {
        HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter)listAdapter;
        i = headerViewListAdapter.getHeadersCount();
        k = (k)headerViewListAdapter.getWrappedAdapter();
      } else {
        i = 0;
        k = k;
      } 
      o o2 = null;
      o o1 = o2;
      if (paramMotionEvent.getAction() != 10) {
        int j = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
        o1 = o2;
        if (j != -1) {
          i = j - i;
          o1 = o2;
          if (i >= 0) {
            o1 = o2;
            if (i < k.getCount())
              o1 = k.b(i); 
          } 
        } 
      } 
      MenuItem menuItem = this.u;
      if (menuItem != o1) {
        l l = k.e;
        if (menuItem != null)
          this.t.e(l, menuItem); 
        this.u = (MenuItem)o1;
        if (o1 != null)
          this.t.c(l, (MenuItem)o1); 
      } 
    } 
    return super.onHoverEvent(paramMotionEvent);
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
    if (listMenuItemView != null && paramInt == this.r) {
      if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
        performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
      return true;
    } 
    if (listMenuItemView != null && paramInt == this.s) {
      setSelection(-1);
      ((k)getAdapter()).e.c(false);
      return true;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public void setHoverListener(r1 paramr1) {
    this.t = paramr1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\s1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */