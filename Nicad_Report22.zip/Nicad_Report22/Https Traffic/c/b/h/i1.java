package c.b.h;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

public class i1 implements Runnable {
  public i1(j1 paramj1) {}
  
  public void run() {
    j1 j11 = this.e;
    j11.a();
    View view = j11.h;
    if (view.isEnabled()) {
      if (view.isLongClickable())
        return; 
      if (!j11.c())
        return; 
      view.getParent().requestDisallowInterceptTouchEvent(true);
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      view.onTouchEvent(motionEvent);
      motionEvent.recycle();
      j11.k = true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\i1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */