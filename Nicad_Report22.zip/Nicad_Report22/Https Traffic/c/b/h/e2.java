package c.b.h;

import android.app.SearchableInfo;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.appcompat.widget.SearchView;
import c.i.a.c;
import d.a.a.a.a;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.WeakHashMap;

public class e2 extends c implements View.OnClickListener {
  public int A;
  
  public int B;
  
  public int m;
  
  public int n;
  
  public LayoutInflater o;
  
  public final SearchView p;
  
  public final SearchableInfo q;
  
  public final Context r;
  
  public final WeakHashMap<String, Drawable.ConstantState> s;
  
  public final int t;
  
  public int u;
  
  public ColorStateList v;
  
  public int w;
  
  public int x;
  
  public int y;
  
  public int z;
  
  public e2(Context paramContext, SearchView paramSearchView, SearchableInfo paramSearchableInfo, WeakHashMap<String, Drawable.ConstantState> paramWeakHashMap) {
    super(paramContext, null, true);
    this.n = i;
    this.m = i;
    this.o = (LayoutInflater)paramContext.getSystemService("layout_inflater");
    this.u = 1;
    this.w = -1;
    this.x = -1;
    this.y = -1;
    this.z = -1;
    this.A = -1;
    this.B = -1;
    this.p = paramSearchView;
    this.q = paramSearchableInfo;
    this.t = paramSearchView.getSuggestionCommitIconResId();
    this.r = paramContext;
    this.s = paramWeakHashMap;
  }
  
  public static String r(Cursor paramCursor, int paramInt) {
    if (paramInt == -1)
      return null; 
    try {
      return paramCursor.getString(paramInt);
    } catch (Exception exception) {
      Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", exception);
      return null;
    } 
  }
  
  public void a(View paramView, Context paramContext, Cursor paramCursor) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getTag : ()Ljava/lang/Object;
    //   4: checkcast c/b/h/d2
    //   7: astore #6
    //   9: aload_0
    //   10: getfield B : I
    //   13: istore #4
    //   15: iload #4
    //   17: iconst_m1
    //   18: if_icmpeq -> 34
    //   21: aload_3
    //   22: iload #4
    //   24: invokeinterface getInt : (I)I
    //   29: istore #4
    //   31: goto -> 37
    //   34: iconst_0
    //   35: istore #4
    //   37: aload #6
    //   39: getfield a : Landroid/widget/TextView;
    //   42: ifnull -> 86
    //   45: aload_3
    //   46: aload_0
    //   47: getfield w : I
    //   50: invokestatic r : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   53: astore_1
    //   54: aload #6
    //   56: getfield a : Landroid/widget/TextView;
    //   59: astore_2
    //   60: aload_2
    //   61: aload_1
    //   62: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   65: aload_1
    //   66: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   69: ifeq -> 81
    //   72: aload_2
    //   73: bipush #8
    //   75: invokevirtual setVisibility : (I)V
    //   78: goto -> 86
    //   81: aload_2
    //   82: iconst_0
    //   83: invokevirtual setVisibility : (I)V
    //   86: aload #6
    //   88: getfield b : Landroid/widget/TextView;
    //   91: ifnull -> 292
    //   94: aload_3
    //   95: aload_0
    //   96: getfield y : I
    //   99: invokestatic r : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   102: astore_2
    //   103: aload_2
    //   104: ifnull -> 193
    //   107: aload_0
    //   108: getfield v : Landroid/content/res/ColorStateList;
    //   111: ifnonnull -> 155
    //   114: new android/util/TypedValue
    //   117: dup
    //   118: invokespecial <init> : ()V
    //   121: astore_1
    //   122: aload_0
    //   123: getfield h : Landroid/content/Context;
    //   126: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   129: ldc 2130903844
    //   131: aload_1
    //   132: iconst_1
    //   133: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   136: pop
    //   137: aload_0
    //   138: aload_0
    //   139: getfield h : Landroid/content/Context;
    //   142: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   145: aload_1
    //   146: getfield resourceId : I
    //   149: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   152: putfield v : Landroid/content/res/ColorStateList;
    //   155: new android/text/SpannableString
    //   158: dup
    //   159: aload_2
    //   160: invokespecial <init> : (Ljava/lang/CharSequence;)V
    //   163: astore_1
    //   164: aload_1
    //   165: new android/text/style/TextAppearanceSpan
    //   168: dup
    //   169: aconst_null
    //   170: iconst_0
    //   171: iconst_0
    //   172: aload_0
    //   173: getfield v : Landroid/content/res/ColorStateList;
    //   176: aconst_null
    //   177: invokespecial <init> : (Ljava/lang/String;IILandroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;)V
    //   180: iconst_0
    //   181: aload_2
    //   182: invokevirtual length : ()I
    //   185: bipush #33
    //   187: invokevirtual setSpan : (Ljava/lang/Object;III)V
    //   190: goto -> 202
    //   193: aload_3
    //   194: aload_0
    //   195: getfield x : I
    //   198: invokestatic r : (Landroid/database/Cursor;I)Ljava/lang/String;
    //   201: astore_1
    //   202: aload_1
    //   203: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   206: ifeq -> 236
    //   209: aload #6
    //   211: getfield a : Landroid/widget/TextView;
    //   214: astore_2
    //   215: aload_2
    //   216: ifnull -> 260
    //   219: aload_2
    //   220: iconst_0
    //   221: invokevirtual setSingleLine : (Z)V
    //   224: aload #6
    //   226: getfield a : Landroid/widget/TextView;
    //   229: iconst_2
    //   230: invokevirtual setMaxLines : (I)V
    //   233: goto -> 260
    //   236: aload #6
    //   238: getfield a : Landroid/widget/TextView;
    //   241: astore_2
    //   242: aload_2
    //   243: ifnull -> 260
    //   246: aload_2
    //   247: iconst_1
    //   248: invokevirtual setSingleLine : (Z)V
    //   251: aload #6
    //   253: getfield a : Landroid/widget/TextView;
    //   256: iconst_1
    //   257: invokevirtual setMaxLines : (I)V
    //   260: aload #6
    //   262: getfield b : Landroid/widget/TextView;
    //   265: astore_2
    //   266: aload_2
    //   267: aload_1
    //   268: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   271: aload_1
    //   272: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   275: ifeq -> 287
    //   278: aload_2
    //   279: bipush #8
    //   281: invokevirtual setVisibility : (I)V
    //   284: goto -> 292
    //   287: aload_2
    //   288: iconst_0
    //   289: invokevirtual setVisibility : (I)V
    //   292: aload #6
    //   294: getfield c : Landroid/widget/ImageView;
    //   297: astore #7
    //   299: aload #7
    //   301: ifnull -> 609
    //   304: aload_0
    //   305: getfield z : I
    //   308: istore #5
    //   310: iload #5
    //   312: iconst_m1
    //   313: if_icmpne -> 321
    //   316: aconst_null
    //   317: astore_1
    //   318: goto -> 570
    //   321: aload_0
    //   322: aload_3
    //   323: iload #5
    //   325: invokeinterface getString : (I)Ljava/lang/String;
    //   330: invokevirtual p : (Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    //   333: astore_1
    //   334: aload_1
    //   335: ifnull -> 341
    //   338: goto -> 570
    //   341: aload_0
    //   342: getfield q : Landroid/app/SearchableInfo;
    //   345: invokevirtual getSearchActivity : ()Landroid/content/ComponentName;
    //   348: astore #9
    //   350: aload #9
    //   352: invokevirtual flattenToShortString : ()Ljava/lang/String;
    //   355: astore #8
    //   357: aload_0
    //   358: getfield s : Ljava/util/WeakHashMap;
    //   361: aload #8
    //   363: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   366: ifeq -> 406
    //   369: aload_0
    //   370: getfield s : Ljava/util/WeakHashMap;
    //   373: aload #8
    //   375: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   378: checkcast android/graphics/drawable/Drawable$ConstantState
    //   381: astore_1
    //   382: aload_1
    //   383: ifnonnull -> 391
    //   386: aconst_null
    //   387: astore_1
    //   388: goto -> 552
    //   391: aload_1
    //   392: aload_0
    //   393: getfield r : Landroid/content/Context;
    //   396: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   399: invokevirtual newDrawable : (Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    //   402: astore_1
    //   403: goto -> 552
    //   406: aload_0
    //   407: getfield h : Landroid/content/Context;
    //   410: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   413: astore_1
    //   414: aload_1
    //   415: aload #9
    //   417: sipush #128
    //   420: invokevirtual getActivityInfo : (Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;
    //   423: astore_2
    //   424: aload_2
    //   425: invokevirtual getIconResource : ()I
    //   428: istore #5
    //   430: iload #5
    //   432: ifne -> 438
    //   435: goto -> 525
    //   438: aload_1
    //   439: aload #9
    //   441: invokevirtual getPackageName : ()Ljava/lang/String;
    //   444: iload #5
    //   446: aload_2
    //   447: getfield applicationInfo : Landroid/content/pm/ApplicationInfo;
    //   450: invokevirtual getDrawable : (Ljava/lang/String;ILandroid/content/pm/ApplicationInfo;)Landroid/graphics/drawable/Drawable;
    //   453: astore_2
    //   454: aload_2
    //   455: astore_1
    //   456: aload_2
    //   457: ifnonnull -> 527
    //   460: new java/lang/StringBuilder
    //   463: dup
    //   464: invokespecial <init> : ()V
    //   467: astore_1
    //   468: aload_1
    //   469: ldc_w 'Invalid icon resource '
    //   472: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   475: pop
    //   476: aload_1
    //   477: iload #5
    //   479: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   482: pop
    //   483: aload_1
    //   484: ldc_w ' for '
    //   487: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   490: pop
    //   491: aload_1
    //   492: aload #9
    //   494: invokevirtual flattenToShortString : ()Ljava/lang/String;
    //   497: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   500: pop
    //   501: ldc 'SuggestionsAdapter'
    //   503: aload_1
    //   504: invokevirtual toString : ()Ljava/lang/String;
    //   507: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   510: pop
    //   511: goto -> 525
    //   514: astore_1
    //   515: ldc 'SuggestionsAdapter'
    //   517: aload_1
    //   518: invokevirtual toString : ()Ljava/lang/String;
    //   521: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   524: pop
    //   525: aconst_null
    //   526: astore_1
    //   527: aload_1
    //   528: ifnonnull -> 536
    //   531: aconst_null
    //   532: astore_2
    //   533: goto -> 541
    //   536: aload_1
    //   537: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   540: astore_2
    //   541: aload_0
    //   542: getfield s : Ljava/util/WeakHashMap;
    //   545: aload #8
    //   547: aload_2
    //   548: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   551: pop
    //   552: aload_1
    //   553: ifnull -> 559
    //   556: goto -> 570
    //   559: aload_0
    //   560: getfield h : Landroid/content/Context;
    //   563: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   566: invokevirtual getDefaultActivityIcon : ()Landroid/graphics/drawable/Drawable;
    //   569: astore_1
    //   570: aload #7
    //   572: aload_1
    //   573: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   576: aload_1
    //   577: ifnonnull -> 589
    //   580: aload #7
    //   582: iconst_4
    //   583: invokevirtual setVisibility : (I)V
    //   586: goto -> 609
    //   589: aload #7
    //   591: iconst_0
    //   592: invokevirtual setVisibility : (I)V
    //   595: aload_1
    //   596: iconst_0
    //   597: iconst_0
    //   598: invokevirtual setVisible : (ZZ)Z
    //   601: pop
    //   602: aload_1
    //   603: iconst_1
    //   604: iconst_0
    //   605: invokevirtual setVisible : (ZZ)Z
    //   608: pop
    //   609: aload #6
    //   611: getfield d : Landroid/widget/ImageView;
    //   614: astore_2
    //   615: aload_2
    //   616: ifnull -> 686
    //   619: aload_0
    //   620: getfield A : I
    //   623: istore #5
    //   625: iload #5
    //   627: iconst_m1
    //   628: if_icmpne -> 636
    //   631: aconst_null
    //   632: astore_1
    //   633: goto -> 649
    //   636: aload_0
    //   637: aload_3
    //   638: iload #5
    //   640: invokeinterface getString : (I)Ljava/lang/String;
    //   645: invokevirtual p : (Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    //   648: astore_1
    //   649: aload_2
    //   650: aload_1
    //   651: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   654: aload_1
    //   655: ifnonnull -> 667
    //   658: aload_2
    //   659: bipush #8
    //   661: invokevirtual setVisibility : (I)V
    //   664: goto -> 686
    //   667: aload_2
    //   668: iconst_0
    //   669: invokevirtual setVisibility : (I)V
    //   672: aload_1
    //   673: iconst_0
    //   674: iconst_0
    //   675: invokevirtual setVisible : (ZZ)Z
    //   678: pop
    //   679: aload_1
    //   680: iconst_1
    //   681: iconst_0
    //   682: invokevirtual setVisible : (ZZ)Z
    //   685: pop
    //   686: aload_0
    //   687: getfield u : I
    //   690: istore #5
    //   692: iload #5
    //   694: iconst_2
    //   695: if_icmpeq -> 725
    //   698: iload #5
    //   700: iconst_1
    //   701: if_icmpne -> 714
    //   704: iload #4
    //   706: iconst_1
    //   707: iand
    //   708: ifeq -> 714
    //   711: goto -> 725
    //   714: aload #6
    //   716: getfield e : Landroid/widget/ImageView;
    //   719: bipush #8
    //   721: invokevirtual setVisibility : (I)V
    //   724: return
    //   725: aload #6
    //   727: getfield e : Landroid/widget/ImageView;
    //   730: iconst_0
    //   731: invokevirtual setVisibility : (I)V
    //   734: aload #6
    //   736: getfield e : Landroid/widget/ImageView;
    //   739: aload #6
    //   741: getfield a : Landroid/widget/TextView;
    //   744: invokevirtual getText : ()Ljava/lang/CharSequence;
    //   747: invokevirtual setTag : (Ljava/lang/Object;)V
    //   750: aload #6
    //   752: getfield e : Landroid/widget/ImageView;
    //   755: aload_0
    //   756: invokevirtual setOnClickListener : (Landroid/view/View$OnClickListener;)V
    //   759: return
    // Exception table:
    //   from	to	target	type
    //   414	424	514	android/content/pm/PackageManager$NameNotFoundException
  }
  
  public void b(Cursor paramCursor) {
    try {
      super.b(paramCursor);
      if (paramCursor != null) {
        this.w = paramCursor.getColumnIndex("suggest_text_1");
        this.x = paramCursor.getColumnIndex("suggest_text_2");
        this.y = paramCursor.getColumnIndex("suggest_text_2_url");
        this.z = paramCursor.getColumnIndex("suggest_icon_1");
        this.A = paramCursor.getColumnIndex("suggest_icon_2");
        this.B = paramCursor.getColumnIndex("suggest_flags");
        return;
      } 
    } catch (Exception exception) {
      Log.e("SuggestionsAdapter", "error changing cursor and caching columns", exception);
    } 
  }
  
  public CharSequence c(Cursor paramCursor) {
    if (paramCursor == null)
      return null; 
    String str = r(paramCursor, paramCursor.getColumnIndex("suggest_intent_query"));
    if (str != null)
      return str; 
    if (this.q.shouldRewriteQueryFromData()) {
      str = r(paramCursor, paramCursor.getColumnIndex("suggest_intent_data"));
      if (str != null)
        return str; 
    } 
    if (this.q.shouldRewriteQueryFromText()) {
      String str1 = r(paramCursor, paramCursor.getColumnIndex("suggest_text_1"));
      if (str1 != null)
        return str1; 
    } 
    return null;
  }
  
  public View f(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup) {
    View view = this.o.inflate(this.m, paramViewGroup, false);
    view.setTag(new d2(view));
    ((ImageView)view.findViewById(2131230884)).setImageResource(this.t);
    return view;
  }
  
  public Drawable g(Uri paramUri) {
    String str = paramUri.getAuthority();
    if (!TextUtils.isEmpty(str))
      try {
        int i;
        Resources resources = this.h.getPackageManager().getResourcesForApplication(str);
        List<String> list = paramUri.getPathSegments();
        if (list != null) {
          i = list.size();
          if (i == 1)
            try {
              i = Integer.parseInt(list.get(0));
              if (i != 0)
                return resources.getDrawable(i); 
              throw new FileNotFoundException(a.d("No resource found for: ", paramUri));
            } catch (NumberFormatException numberFormatException) {
              throw new FileNotFoundException(a.d("Single path segment is not a resource ID: ", paramUri));
            }  
          if (i == 2) {
            i = resources.getIdentifier(list.get(1), list.get(0), (String)numberFormatException);
          } else {
            throw new FileNotFoundException(a.d("More than two path segments: ", paramUri));
          } 
        } else {
          throw new FileNotFoundException(a.d("No path: ", paramUri));
        } 
        if (i != 0)
          return resources.getDrawable(i); 
        throw new FileNotFoundException(a.d("No resource found for: ", paramUri));
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        throw new FileNotFoundException(a.d("No package found for authority: ", paramUri));
      }  
    throw new FileNotFoundException(a.d("No authority: ", paramUri));
  }
  
  public View getDropDownView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    try {
      return super.getDropDownView(paramInt, paramView, paramViewGroup);
    } catch (RuntimeException runtimeException) {
      Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", runtimeException);
      View view = this.o.inflate(this.n, paramViewGroup, false);
      if (view != null)
        ((d2)view.getTag()).a.setText(runtimeException.toString()); 
      return view;
    } 
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    try {
      return super.getView(paramInt, paramView, paramViewGroup);
    } catch (RuntimeException runtimeException) {
      Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", runtimeException);
      View view = f(this.h, this.g, paramViewGroup);
      ((d2)view.getTag()).a.setText(runtimeException.toString());
      return view;
    } 
  }
  
  public boolean hasStableIds() {
    return false;
  }
  
  public void notifyDataSetChanged() {
    super.notifyDataSetChanged();
    s(this.g);
  }
  
  public void notifyDataSetInvalidated() {
    super.notifyDataSetInvalidated();
    s(this.g);
  }
  
  public void onClick(View paramView) {
    Object object = paramView.getTag();
    if (object instanceof CharSequence)
      this.p.x((CharSequence)object); 
  }
  
  public final Drawable p(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aconst_null
    //   4: astore #6
    //   6: aload #4
    //   8: astore #5
    //   10: aload_1
    //   11: ifnull -> 584
    //   14: aload #4
    //   16: astore #5
    //   18: aload_1
    //   19: invokevirtual isEmpty : ()Z
    //   22: ifne -> 584
    //   25: ldc_w '0'
    //   28: aload_1
    //   29: invokevirtual equals : (Ljava/lang/Object;)Z
    //   32: ifeq -> 37
    //   35: aconst_null
    //   36: areturn
    //   37: aload_1
    //   38: invokestatic parseInt : (Ljava/lang/String;)I
    //   41: istore_2
    //   42: new java/lang/StringBuilder
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: astore #4
    //   51: aload #4
    //   53: ldc_w 'android.resource://'
    //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   59: pop
    //   60: aload #4
    //   62: aload_0
    //   63: getfield r : Landroid/content/Context;
    //   66: invokevirtual getPackageName : ()Ljava/lang/String;
    //   69: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: pop
    //   73: aload #4
    //   75: ldc_w '/'
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload #4
    //   84: iload_2
    //   85: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   88: pop
    //   89: aload #4
    //   91: invokevirtual toString : ()Ljava/lang/String;
    //   94: astore #5
    //   96: aload_0
    //   97: getfield s : Ljava/util/WeakHashMap;
    //   100: aload #5
    //   102: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   105: checkcast android/graphics/drawable/Drawable$ConstantState
    //   108: astore #4
    //   110: aload #4
    //   112: ifnonnull -> 121
    //   115: aconst_null
    //   116: astore #4
    //   118: goto -> 602
    //   121: aload #4
    //   123: invokevirtual newDrawable : ()Landroid/graphics/drawable/Drawable;
    //   126: astore #4
    //   128: goto -> 602
    //   131: aload_0
    //   132: getfield r : Landroid/content/Context;
    //   135: astore #4
    //   137: getstatic c/h/b/b.a : Ljava/lang/Object;
    //   140: astore #7
    //   142: aload #4
    //   144: iload_2
    //   145: invokestatic b : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   148: astore #4
    //   150: aload #4
    //   152: ifnull -> 170
    //   155: aload_0
    //   156: getfield s : Ljava/util/WeakHashMap;
    //   159: aload #5
    //   161: aload #4
    //   163: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   166: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   169: pop
    //   170: aload #4
    //   172: areturn
    //   173: new java/lang/StringBuilder
    //   176: dup
    //   177: invokespecial <init> : ()V
    //   180: astore #4
    //   182: aload #4
    //   184: ldc_w 'Icon resource not found: '
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: pop
    //   191: aload #4
    //   193: aload_1
    //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: pop
    //   198: ldc 'SuggestionsAdapter'
    //   200: aload #4
    //   202: invokevirtual toString : ()Ljava/lang/String;
    //   205: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   208: pop
    //   209: aconst_null
    //   210: areturn
    //   211: aload_0
    //   212: getfield s : Ljava/util/WeakHashMap;
    //   215: aload_1
    //   216: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   219: checkcast android/graphics/drawable/Drawable$ConstantState
    //   222: astore #4
    //   224: aload #4
    //   226: ifnonnull -> 235
    //   229: aconst_null
    //   230: astore #4
    //   232: goto -> 242
    //   235: aload #4
    //   237: invokevirtual newDrawable : ()Landroid/graphics/drawable/Drawable;
    //   240: astore #4
    //   242: aload #4
    //   244: ifnull -> 250
    //   247: aload #4
    //   249: areturn
    //   250: aload_1
    //   251: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   254: astore #5
    //   256: ldc_w 'android.resource'
    //   259: aload #5
    //   261: invokevirtual getScheme : ()Ljava/lang/String;
    //   264: invokevirtual equals : (Ljava/lang/Object;)Z
    //   267: istore_3
    //   268: iload_3
    //   269: ifeq -> 322
    //   272: aload_0
    //   273: aload #5
    //   275: invokevirtual g : (Landroid/net/Uri;)Landroid/graphics/drawable/Drawable;
    //   278: astore #4
    //   280: goto -> 557
    //   283: new java/lang/StringBuilder
    //   286: dup
    //   287: invokespecial <init> : ()V
    //   290: astore #4
    //   292: aload #4
    //   294: ldc_w 'Resource does not exist: '
    //   297: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   300: pop
    //   301: aload #4
    //   303: aload #5
    //   305: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   308: pop
    //   309: new java/io/FileNotFoundException
    //   312: dup
    //   313: aload #4
    //   315: invokevirtual toString : ()Ljava/lang/String;
    //   318: invokespecial <init> : (Ljava/lang/String;)V
    //   321: athrow
    //   322: aload_0
    //   323: getfield r : Landroid/content/Context;
    //   326: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   329: aload #5
    //   331: invokevirtual openInputStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   334: astore #7
    //   336: aload #7
    //   338: ifnull -> 455
    //   341: aload #7
    //   343: aconst_null
    //   344: invokestatic createFromStream : (Ljava/io/InputStream;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    //   347: astore #4
    //   349: aload #7
    //   351: invokevirtual close : ()V
    //   354: goto -> 398
    //   357: astore #7
    //   359: new java/lang/StringBuilder
    //   362: dup
    //   363: invokespecial <init> : ()V
    //   366: astore #8
    //   368: aload #8
    //   370: ldc_w 'Error closing icon stream for '
    //   373: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: pop
    //   377: aload #8
    //   379: aload #5
    //   381: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   384: pop
    //   385: ldc 'SuggestionsAdapter'
    //   387: aload #8
    //   389: invokevirtual toString : ()Ljava/lang/String;
    //   392: aload #7
    //   394: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   397: pop
    //   398: goto -> 557
    //   401: astore #4
    //   403: aload #7
    //   405: invokevirtual close : ()V
    //   408: goto -> 452
    //   411: astore #7
    //   413: new java/lang/StringBuilder
    //   416: dup
    //   417: invokespecial <init> : ()V
    //   420: astore #8
    //   422: aload #8
    //   424: ldc_w 'Error closing icon stream for '
    //   427: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   430: pop
    //   431: aload #8
    //   433: aload #5
    //   435: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   438: pop
    //   439: ldc 'SuggestionsAdapter'
    //   441: aload #8
    //   443: invokevirtual toString : ()Ljava/lang/String;
    //   446: aload #7
    //   448: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   451: pop
    //   452: aload #4
    //   454: athrow
    //   455: new java/lang/StringBuilder
    //   458: dup
    //   459: invokespecial <init> : ()V
    //   462: astore #4
    //   464: aload #4
    //   466: ldc_w 'Failed to open '
    //   469: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   472: pop
    //   473: aload #4
    //   475: aload #5
    //   477: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   480: pop
    //   481: new java/io/FileNotFoundException
    //   484: dup
    //   485: aload #4
    //   487: invokevirtual toString : ()Ljava/lang/String;
    //   490: invokespecial <init> : (Ljava/lang/String;)V
    //   493: athrow
    //   494: astore #4
    //   496: new java/lang/StringBuilder
    //   499: dup
    //   500: invokespecial <init> : ()V
    //   503: astore #7
    //   505: aload #7
    //   507: ldc_w 'Icon not found: '
    //   510: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   513: pop
    //   514: aload #7
    //   516: aload #5
    //   518: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   521: pop
    //   522: aload #7
    //   524: ldc_w ', '
    //   527: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   530: pop
    //   531: aload #7
    //   533: aload #4
    //   535: invokevirtual getMessage : ()Ljava/lang/String;
    //   538: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   541: pop
    //   542: ldc 'SuggestionsAdapter'
    //   544: aload #7
    //   546: invokevirtual toString : ()Ljava/lang/String;
    //   549: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   552: pop
    //   553: aload #6
    //   555: astore #4
    //   557: aload #4
    //   559: astore #5
    //   561: aload #4
    //   563: ifnull -> 584
    //   566: aload_0
    //   567: getfield s : Ljava/util/WeakHashMap;
    //   570: aload_1
    //   571: aload #4
    //   573: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
    //   576: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   579: pop
    //   580: aload #4
    //   582: astore #5
    //   584: aload #5
    //   586: areturn
    //   587: astore #4
    //   589: goto -> 211
    //   592: astore #4
    //   594: goto -> 173
    //   597: astore #4
    //   599: goto -> 283
    //   602: aload #4
    //   604: ifnull -> 131
    //   607: aload #4
    //   609: areturn
    // Exception table:
    //   from	to	target	type
    //   37	110	587	java/lang/NumberFormatException
    //   37	110	592	android/content/res/Resources$NotFoundException
    //   121	128	587	java/lang/NumberFormatException
    //   121	128	592	android/content/res/Resources$NotFoundException
    //   131	150	587	java/lang/NumberFormatException
    //   131	150	592	android/content/res/Resources$NotFoundException
    //   155	170	587	java/lang/NumberFormatException
    //   155	170	592	android/content/res/Resources$NotFoundException
    //   256	268	494	java/io/FileNotFoundException
    //   272	280	597	android/content/res/Resources$NotFoundException
    //   272	280	494	java/io/FileNotFoundException
    //   283	322	494	java/io/FileNotFoundException
    //   322	336	494	java/io/FileNotFoundException
    //   341	349	401	finally
    //   349	354	357	java/io/IOException
    //   359	398	494	java/io/FileNotFoundException
    //   403	408	411	java/io/IOException
    //   413	452	494	java/io/FileNotFoundException
    //   452	455	494	java/io/FileNotFoundException
    //   455	494	494	java/io/FileNotFoundException
  }
  
  public Cursor q(SearchableInfo paramSearchableInfo, String paramString, int paramInt) {
    SearchableInfo searchableInfo = null;
    if (paramSearchableInfo == null)
      return null; 
    String str1 = paramSearchableInfo.getSuggestAuthority();
    if (str1 == null)
      return null; 
    Uri.Builder builder = (new Uri.Builder()).scheme("content").authority(str1).query("").fragment("");
    String str2 = paramSearchableInfo.getSuggestPath();
    if (str2 != null)
      builder.appendEncodedPath(str2); 
    builder.appendPath("search_suggest_query");
    str2 = paramSearchableInfo.getSuggestSelection();
    if (str2 != null) {
      String[] arrayOfString = new String[1];
      arrayOfString[0] = paramString;
    } else {
      builder.appendPath(paramString);
      paramSearchableInfo = searchableInfo;
    } 
    if (paramInt > 0)
      builder.appendQueryParameter("limit", String.valueOf(paramInt)); 
    Uri uri = builder.build();
    return this.h.getContentResolver().query(uri, null, str2, (String[])paramSearchableInfo, null);
  }
  
  public final void s(Cursor paramCursor) {
    if (paramCursor != null) {
      Bundle bundle = paramCursor.getExtras();
    } else {
      paramCursor = null;
    } 
    if (paramCursor == null || paramCursor.getBoolean("in_progress"));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\e2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */