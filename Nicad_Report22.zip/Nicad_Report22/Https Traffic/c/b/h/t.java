package c.b.h;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import c.b.d.a.a;
import c.h.d.a;

public class t {
  public final int[] a = new int[] { 2131165274, 2131165272, 2131165191 };
  
  public final int[] b = new int[] { 2131165215, 2131165256, 2131165222, 2131165217, 2131165218, 2131165221, 2131165220 };
  
  public final int[] c = new int[] { 2131165271, 2131165273, 2131165208, 2131165264, 2131165265, 2131165267, 2131165269, 2131165266, 2131165268, 2131165270 };
  
  public final int[] d = new int[] { 2131165246, 2131165206, 2131165245 };
  
  public final int[] e = new int[] { 2131165262, 2131165275 };
  
  public final int[] f = new int[] { 2131165194, 2131165200, 2131165195, 2131165201 };
  
  public final boolean a(int[] paramArrayOfint, int paramInt) {
    int j = paramArrayOfint.length;
    for (int i = 0; i < j; i++) {
      if (paramArrayOfint[i] == paramInt)
        return true; 
    } 
    return false;
  }
  
  public final ColorStateList b(Context paramContext, int paramInt) {
    int k = f2.c(paramContext, 2130903228);
    int i = f2.b(paramContext, 2130903226);
    int[] arrayOfInt1 = f2.b;
    int[] arrayOfInt2 = f2.d;
    int j = a.a(k, paramInt);
    int[] arrayOfInt3 = f2.c;
    k = a.a(k, paramInt);
    return new ColorStateList(new int[][] { arrayOfInt1, arrayOfInt2, arrayOfInt3, f2.f }, new int[] { i, j, k, paramInt });
  }
  
  public ColorStateList c(Context paramContext, int paramInt) {
    if (paramInt == 2131165211) {
      ThreadLocal threadLocal = a.a;
      return paramContext.getColorStateList(2131034133);
    } 
    if (paramInt == 2131165261) {
      ThreadLocal threadLocal = a.a;
      return paramContext.getColorStateList(2131034136);
    } 
    if (paramInt == 2131165260) {
      int[][] arrayOfInt = new int[3][];
      int[] arrayOfInt1 = new int[3];
      ColorStateList colorStateList = f2.d(paramContext, 2130903245);
      if (colorStateList != null && colorStateList.isStateful()) {
        arrayOfInt[0] = f2.b;
        arrayOfInt1[0] = colorStateList.getColorForState(arrayOfInt[0], 0);
        arrayOfInt[1] = f2.e;
        arrayOfInt1[1] = f2.c(paramContext, 2130903227);
        arrayOfInt[2] = f2.f;
        arrayOfInt1[2] = colorStateList.getDefaultColor();
      } else {
        arrayOfInt[0] = f2.b;
        arrayOfInt1[0] = f2.b(paramContext, 2130903245);
        arrayOfInt[1] = f2.e;
        arrayOfInt1[1] = f2.c(paramContext, 2130903227);
        arrayOfInt[2] = f2.f;
        arrayOfInt1[2] = f2.c(paramContext, 2130903245);
      } 
      return new ColorStateList(arrayOfInt, arrayOfInt1);
    } 
    if (paramInt == 2131165199)
      return b(paramContext, f2.c(paramContext, 2130903226)); 
    if (paramInt == 2131165193)
      return b(paramContext, 0); 
    if (paramInt == 2131165198)
      return b(paramContext, f2.c(paramContext, 2130903224)); 
    if (paramInt == 2131165258 || paramInt == 2131165259) {
      ThreadLocal threadLocal = a.a;
      return paramContext.getColorStateList(2131034135);
    } 
    if (a(this.b, paramInt))
      return f2.d(paramContext, 2130903229); 
    if (a(this.e, paramInt)) {
      ThreadLocal threadLocal = a.a;
      return paramContext.getColorStateList(2131034132);
    } 
    if (a(this.f, paramInt)) {
      ThreadLocal threadLocal = a.a;
      return paramContext.getColorStateList(2131034131);
    } 
    if (paramInt == 2131165255) {
      ThreadLocal threadLocal = a.a;
      return paramContext.getColorStateList(2131034134);
    } 
    return null;
  }
  
  public final void d(Drawable paramDrawable, int paramInt, PorterDuff.Mode paramMode) {
    Drawable drawable = paramDrawable;
    if (c1.a(paramDrawable))
      drawable = paramDrawable.mutate(); 
    PorterDuff.Mode mode = paramMode;
    if (paramMode == null)
      mode = u.b; 
    drawable.setColorFilter((ColorFilter)u.c(paramInt, mode));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */