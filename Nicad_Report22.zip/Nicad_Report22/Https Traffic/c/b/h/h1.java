package c.b.h;

import android.view.ViewParent;

public class h1 implements Runnable {
  public h1(j1 paramj1) {}
  
  public void run() {
    ViewParent viewParent = this.e.h.getParent();
    if (viewParent != null)
      viewParent.requestDisallowInterceptTouchEvent(true); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\h1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */