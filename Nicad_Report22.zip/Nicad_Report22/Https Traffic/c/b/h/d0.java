package c.b.h;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.SeekBar;

public class d0 extends SeekBar {
  public final e0 e;
  
  public d0(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903723);
    f2.a((View)this, getContext());
    e0 e01 = new e0(this);
    this.e = e01;
    e01.a(paramAttributeSet, 2130903723);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    e0 e01 = this.e;
    Drawable drawable = e01.e;
    if (drawable != null && drawable.isStateful() && drawable.setState(e01.d.getDrawableState()))
      e01.d.invalidateDrawable(drawable); 
  }
  
  public void jumpDrawablesToCurrentState() {
    super.jumpDrawablesToCurrentState();
    Drawable drawable = this.e.e;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
  }
  
  public void onDraw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokespecial onDraw : (Landroid/graphics/Canvas;)V
    //   7: aload_0
    //   8: getfield e : Lc/b/h/e0;
    //   11: aload_1
    //   12: invokevirtual d : (Landroid/graphics/Canvas;)V
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */