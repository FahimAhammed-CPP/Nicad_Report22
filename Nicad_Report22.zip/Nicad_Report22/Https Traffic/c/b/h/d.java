package c.b.h;

import android.content.Context;
import android.view.View;
import c.b.g.n.f0;
import c.b.g.n.l;
import c.b.g.n.x;

public class d extends x {
  public d(m paramm, Context paramContext, f0 paramf0, View paramView) {
    super(paramContext, (l)paramf0, paramView, false, 2130903070, 0);
    if (!paramf0.A.g()) {
      View view;
      h h2 = paramm.n;
      h h1 = h2;
      if (h2 == null)
        view = (View)paramm.l; 
      this.f = view;
    } 
    d(paramm.C);
  }
  
  public void c() {
    m m1 = this.m;
    m1.z = null;
    m1.D = 0;
    super.c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */