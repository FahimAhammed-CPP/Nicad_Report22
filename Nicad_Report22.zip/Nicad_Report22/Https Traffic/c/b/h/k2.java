package c.b.h;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.appcompat.widget.Toolbar;

public class k2 implements Parcelable.ClassLoaderCreator<Toolbar.g> {
  public Object createFromParcel(Parcel paramParcel) {
    return new Toolbar.g(paramParcel, null);
  }
  
  public Object createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader) {
    return new Toolbar.g(paramParcel, paramClassLoader);
  }
  
  public Object[] newArray(int paramInt) {
    return (Object[])new Toolbar.g[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\k2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */