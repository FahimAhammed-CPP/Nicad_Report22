package c.b.h;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;
import android.widget.SpinnerAdapter;

public class m0 extends q1 implements p0 {
  public CharSequence H;
  
  public ListAdapter I;
  
  public final Rect J = new Rect();
  
  public int K;
  
  public m0(q0 paramq0, Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt, 0);
    this.t = (View)paramq0;
    s(true);
    this.r = 0;
    this.u = new j0(this, paramq0);
  }
  
  public void h(CharSequence paramCharSequence) {
    this.H = paramCharSequence;
  }
  
  public void k(int paramInt) {
    this.K = paramInt;
  }
  
  public void m(int paramInt1, int paramInt2) {
    boolean bool = b();
    t();
    this.D.setInputMethodMode(2);
    d();
    f1 f1 = this.g;
    f1.setChoiceMode(1);
    f1.setTextDirection(paramInt1);
    f1.setTextAlignment(paramInt2);
    paramInt1 = this.L.getSelectedItemPosition();
    f1 = this.g;
    if (b() && f1 != null) {
      f1.setListSelectionHidden(false);
      f1.setSelection(paramInt1);
      if (f1.getChoiceMode() != 0)
        f1.setItemChecked(paramInt1, true); 
    } 
    if (bool)
      return; 
    ViewTreeObserver viewTreeObserver = this.L.getViewTreeObserver();
    if (viewTreeObserver != null) {
      k0 k0 = new k0(this);
      viewTreeObserver.addOnGlobalLayoutListener(k0);
      l0 l0 = new l0(this, k0);
      this.D.setOnDismissListener(l0);
    } 
  }
  
  public CharSequence o() {
    return this.H;
  }
  
  public void p(ListAdapter paramListAdapter) {
    super.p(paramListAdapter);
    this.I = paramListAdapter;
  }
  
  public void t() {
    Drawable drawable = f();
    int i = 0;
    if (drawable != null) {
      drawable.getPadding(this.L.l);
      if (t2.b((View)this.L)) {
        i = this.L.l.right;
      } else {
        i = -this.L.l.left;
      } 
    } else {
      Rect rect = this.L.l;
      rect.right = 0;
      rect.left = 0;
    } 
    int k = this.L.getPaddingLeft();
    int m = this.L.getPaddingRight();
    int n = this.L.getWidth();
    q0 q01 = this.L;
    int j = q01.k;
    if (j == -2) {
      int i1 = q01.a((SpinnerAdapter)this.I, f());
      j = (this.L.getContext().getResources().getDisplayMetrics()).widthPixels;
      Rect rect = this.L.l;
      int i2 = j - rect.left - rect.right;
      j = i1;
      if (i1 > i2)
        j = i2; 
      r(Math.max(j, n - k - m));
    } else if (j == -1) {
      r(n - k - m);
    } else {
      r(j);
    } 
    if (t2.b((View)this.L)) {
      i = n - m - this.i - this.K + i;
    } else {
      i = k + this.K + i;
    } 
    this.j = i;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */