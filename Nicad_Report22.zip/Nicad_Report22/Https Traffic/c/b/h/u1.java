package c.b.h;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import c.b.e.a.h;
import org.xmlpull.v1.XmlPullParser;

public class u1 implements x1 {
  public Drawable a(Context paramContext, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    try {
      return (Drawable)h.e(paramContext, paramContext.getResources(), paramXmlPullParser, paramAttributeSet, paramTheme);
    } catch (Exception exception) {
      Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", exception);
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\\\u1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */