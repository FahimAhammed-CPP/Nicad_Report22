package c.b.h;

import android.os.Parcel;
import android.os.Parcelable;

public class l implements Parcelable {
  public static final Parcelable.Creator<l> CREATOR = new k();
  
  public int e;
  
  public l() {}
  
  public l(Parcel paramParcel) {
    this.e = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.e);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */