package c.b.h;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Shader;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import c.h.d.n.b;

public class a0 {
  public static final int[] c = new int[] { 16843067, 16843068 };
  
  public final ProgressBar a;
  
  public Bitmap b;
  
  public a0(ProgressBar paramProgressBar) {
    this.a = paramProgressBar;
  }
  
  public void a(AttributeSet paramAttributeSet, int paramInt) {
    j2 j2 = j2.q(this.a.getContext(), paramAttributeSet, c, paramInt, 0);
    Drawable drawable2 = j2.h(0);
    if (drawable2 != null) {
      AnimationDrawable animationDrawable;
      ProgressBar progressBar = this.a;
      Drawable drawable = drawable2;
      if (drawable2 instanceof AnimationDrawable) {
        AnimationDrawable animationDrawable1 = (AnimationDrawable)drawable2;
        int i = animationDrawable1.getNumberOfFrames();
        animationDrawable = new AnimationDrawable();
        animationDrawable.setOneShot(animationDrawable1.isOneShot());
        for (paramInt = 0; paramInt < i; paramInt++) {
          Drawable drawable3 = b(animationDrawable1.getFrame(paramInt), true);
          drawable3.setLevel(10000);
          animationDrawable.addFrame(drawable3, animationDrawable1.getDuration(paramInt));
        } 
        animationDrawable.setLevel(10000);
      } 
      progressBar.setIndeterminateDrawable((Drawable)animationDrawable);
    } 
    Drawable drawable1 = j2.h(1);
    if (drawable1 != null)
      this.a.setProgressDrawable(b(drawable1, false)); 
    j2.b.recycle();
  }
  
  public final Drawable b(Drawable paramDrawable, boolean paramBoolean) {
    ClipDrawable clipDrawable;
    if (paramDrawable instanceof c.h.d.n.a) {
      b b = (b)paramDrawable;
      Drawable drawable = b.e;
      if (drawable != null) {
        b.a(b(drawable, paramBoolean));
        return paramDrawable;
      } 
    } else {
      LayerDrawable layerDrawable;
      if (paramDrawable instanceof LayerDrawable) {
        layerDrawable = (LayerDrawable)paramDrawable;
        int j = layerDrawable.getNumberOfLayers();
        Drawable[] arrayOfDrawable = new Drawable[j];
        boolean bool = false;
        int i;
        for (i = 0; i < j; i++) {
          int k = layerDrawable.getId(i);
          Drawable drawable = layerDrawable.getDrawable(i);
          if (k == 16908301 || k == 16908303) {
            paramBoolean = true;
          } else {
            paramBoolean = false;
          } 
          arrayOfDrawable[i] = b(drawable, paramBoolean);
        } 
        LayerDrawable layerDrawable1 = new LayerDrawable(arrayOfDrawable);
        for (i = bool; i < j; i++)
          layerDrawable1.setId(i, layerDrawable.getId(i)); 
        return (Drawable)layerDrawable1;
      } 
      if (layerDrawable instanceof BitmapDrawable) {
        BitmapDrawable bitmapDrawable = (BitmapDrawable)layerDrawable;
        Bitmap bitmap = bitmapDrawable.getBitmap();
        if (this.b == null)
          this.b = bitmap; 
        ShapeDrawable shapeDrawable2 = new ShapeDrawable((Shape)new RoundRectShape(new float[] { 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }, null, null));
        BitmapShader bitmapShader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP);
        shapeDrawable2.getPaint().setShader((Shader)bitmapShader);
        shapeDrawable2.getPaint().setColorFilter(bitmapDrawable.getPaint().getColorFilter());
        ShapeDrawable shapeDrawable1 = shapeDrawable2;
        if (paramBoolean)
          clipDrawable = new ClipDrawable((Drawable)shapeDrawable2, 3, 1); 
        return (Drawable)clipDrawable;
      } 
    } 
    return (Drawable)clipDrawable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */