package c.b.h;

import c.b.g.n.f0;
import c.b.g.n.l;
import c.b.g.n.y;

public class j implements y.a {
  public j(m paramm) {}
  
  public void a(l paraml, boolean paramBoolean) {
    if (paraml instanceof f0)
      paraml.k().c(false); 
    y.a a1 = this.e.i;
    if (a1 != null)
      a1.a(paraml, paramBoolean); 
  }
  
  public boolean b(l paraml) {
    m m1 = this.e;
    l l1 = m1.g;
    boolean bool = false;
    if (paraml == l1)
      return false; 
    m1.D = ((f0)paraml).A.a;
    y.a a1 = m1.i;
    if (a1 != null)
      bool = a1.b(paraml); 
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */