package c.b.h;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import c.b.b;
import c.h.j.u;
import c.h.j.y;
import c.h.j.z;

public class n2 implements b1 {
  public Toolbar a;
  
  public int b;
  
  public View c;
  
  public View d;
  
  public Drawable e;
  
  public Drawable f;
  
  public Drawable g;
  
  public boolean h;
  
  public CharSequence i;
  
  public CharSequence j;
  
  public CharSequence k;
  
  public Window.Callback l;
  
  public boolean m;
  
  public m n;
  
  public int o;
  
  public Drawable p;
  
  public n2(Toolbar paramToolbar, boolean paramBoolean) {
    boolean bool;
    this.o = 0;
    this.a = paramToolbar;
    this.i = paramToolbar.getTitle();
    this.j = paramToolbar.getSubtitle();
    if (this.i != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.h = bool;
    this.g = paramToolbar.getNavigationIcon();
    j2 j2 = j2.q(paramToolbar.getContext(), null, b.a, 2130903045, 0);
    int i = 15;
    this.p = j2.g(15);
    if (paramBoolean) {
      CharSequence charSequence = j2.n(27);
      if (!TextUtils.isEmpty(charSequence))
        e(charSequence); 
      charSequence = j2.n(25);
      if (!TextUtils.isEmpty(charSequence)) {
        this.j = charSequence;
        if ((this.b & 0x8) != 0)
          this.a.setSubtitle(charSequence); 
      } 
      Drawable drawable = j2.g(20);
      if (drawable != null) {
        this.f = drawable;
        j();
      } 
      drawable = j2.g(17);
      if (drawable != null) {
        this.e = drawable;
        j();
      } 
      if (this.g == null) {
        drawable = this.p;
        if (drawable != null) {
          this.g = drawable;
          i();
        } 
      } 
      c(j2.j(10, 0));
      i = j2.l(9, 0);
      if (i != 0) {
        View view1 = LayoutInflater.from(this.a.getContext()).inflate(i, (ViewGroup)this.a, false);
        View view2 = this.d;
        if (view2 != null && (this.b & 0x10) != 0)
          this.a.removeView(view2); 
        this.d = view1;
        if (view1 != null && (this.b & 0x10) != 0)
          this.a.addView(view1); 
        c(this.b | 0x10);
      } 
      i = j2.k(13, 0);
      if (i > 0) {
        ViewGroup.LayoutParams layoutParams = this.a.getLayoutParams();
        layoutParams.height = i;
        this.a.setLayoutParams(layoutParams);
      } 
      int j = j2.e(7, -1);
      i = j2.e(3, -1);
      if (j >= 0 || i >= 0) {
        Toolbar toolbar = this.a;
        j = Math.max(j, 0);
        i = Math.max(i, 0);
        toolbar.d();
        toolbar.x.a(j, i);
      } 
      i = j2.l(28, 0);
      if (i != 0) {
        Toolbar toolbar = this.a;
        Context context = toolbar.getContext();
        toolbar.p = i;
        TextView textView = toolbar.f;
        if (textView != null)
          textView.setTextAppearance(context, i); 
      } 
      i = j2.l(26, 0);
      if (i != 0) {
        Toolbar toolbar = this.a;
        Context context = toolbar.getContext();
        toolbar.q = i;
        TextView textView = toolbar.g;
        if (textView != null)
          textView.setTextAppearance(context, i); 
      } 
      i = j2.l(22, 0);
      if (i != 0)
        this.a.setPopupTheme(i); 
    } else {
      if (this.a.getNavigationIcon() != null) {
        this.p = this.a.getNavigationIcon();
      } else {
        i = 11;
      } 
      this.b = i;
    } 
    j2.b.recycle();
    if (2131755009 != this.o) {
      this.o = 2131755009;
      if (TextUtils.isEmpty(this.a.getNavigationContentDescription()))
        d(this.o); 
    } 
    this.k = this.a.getNavigationContentDescription();
    this.a.setNavigationOnClickListener(new l2(this));
  }
  
  public Context a() {
    return this.a.getContext();
  }
  
  public boolean b() {
    ActionMenuView actionMenuView = this.a.e;
    if (actionMenuView != null) {
      boolean bool;
      m m1 = actionMenuView.x;
      if (m1 != null && m1.g()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public void c(int paramInt) {
    int i = this.b ^ paramInt;
    this.b = paramInt;
    if (i != 0) {
      if ((i & 0x4) != 0) {
        if ((paramInt & 0x4) != 0)
          h(); 
        i();
      } 
      if ((i & 0x3) != 0)
        j(); 
      if ((i & 0x8) != 0)
        if ((paramInt & 0x8) != 0) {
          this.a.setTitle(this.i);
          this.a.setSubtitle(this.j);
        } else {
          this.a.setTitle(null);
          this.a.setSubtitle(null);
        }  
      if ((i & 0x10) != 0) {
        View view = this.d;
        if (view != null) {
          if ((paramInt & 0x10) != 0) {
            this.a.addView(view);
            return;
          } 
          this.a.removeView(view);
        } 
      } 
    } 
  }
  
  public void d(int paramInt) {
    String str;
    if (paramInt == 0) {
      str = null;
    } else {
      str = a().getString(paramInt);
    } 
    this.k = str;
    h();
  }
  
  public void e(CharSequence paramCharSequence) {
    this.h = true;
    this.i = paramCharSequence;
    if ((this.b & 0x8) != 0)
      this.a.setTitle(paramCharSequence); 
  }
  
  public void f(CharSequence paramCharSequence) {
    if (!this.h) {
      this.i = paramCharSequence;
      if ((this.b & 0x8) != 0)
        this.a.setTitle(paramCharSequence); 
    } 
  }
  
  public y g(int paramInt, long paramLong) {
    float f;
    y y = u.b((View)this.a);
    if (paramInt == 0) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    y.a(f);
    y.c(paramLong);
    m2 m2 = new m2(this, paramInt);
    View view = y.a.get();
    if (view != null)
      y.e(view, (z)m2); 
    return y;
  }
  
  public final void h() {
    if ((this.b & 0x4) != 0) {
      if (TextUtils.isEmpty(this.k)) {
        this.a.setNavigationContentDescription(this.o);
        return;
      } 
      this.a.setNavigationContentDescription(this.k);
    } 
  }
  
  public final void i() {
    if ((this.b & 0x4) != 0) {
      Toolbar toolbar = this.a;
      Drawable drawable = this.g;
      if (drawable == null)
        drawable = this.p; 
      toolbar.setNavigationIcon(drawable);
      return;
    } 
    this.a.setNavigationIcon(null);
  }
  
  public final void j() {
    Drawable drawable;
    int i = this.b;
    if ((i & 0x2) != 0) {
      if ((i & 0x1) != 0) {
        drawable = this.f;
        if (drawable == null)
          drawable = this.e; 
      } else {
        drawable = this.e;
      } 
    } else {
      drawable = null;
    } 
    this.a.setLogo(drawable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\n2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */