package c.b.h;

import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.ScaleDrawable;
import c.h.d.n.b;

public abstract class c1 {
  public static final int[] a = new int[] { 16842912 };
  
  public static final int[] b = new int[0];
  
  static {
    new Rect();
    try {
      Class.forName("android.graphics.Insets");
      return;
    } catch (ClassNotFoundException classNotFoundException) {
      return;
    } 
  }
  
  public static boolean a(Drawable paramDrawable) {
    Drawable[] arrayOfDrawable;
    if (paramDrawable instanceof DrawableContainer) {
      Drawable.ConstantState constantState = paramDrawable.getConstantState();
      if (constantState instanceof DrawableContainer.DrawableContainerState) {
        arrayOfDrawable = ((DrawableContainer.DrawableContainerState)constantState).getChildren();
        int j = arrayOfDrawable.length;
        for (int i = 0; i < j; i++) {
          if (!a(arrayOfDrawable[i]))
            return false; 
        } 
      } 
    } else {
      if (arrayOfDrawable instanceof c.h.d.n.a)
        return a(((b)arrayOfDrawable).e); 
      if (arrayOfDrawable instanceof d1)
        return a(((d1)arrayOfDrawable).e); 
      if (arrayOfDrawable instanceof ScaleDrawable)
        return a(((ScaleDrawable)arrayOfDrawable).getDrawable()); 
    } 
    return true;
  }
  
  public static PorterDuff.Mode b(int paramInt, PorterDuff.Mode paramMode) {
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 9) {
          switch (paramInt) {
            default:
              return paramMode;
            case 16:
              return PorterDuff.Mode.ADD;
            case 15:
              return PorterDuff.Mode.SCREEN;
            case 14:
              break;
          } 
          return PorterDuff.Mode.MULTIPLY;
        } 
        return PorterDuff.Mode.SRC_ATOP;
      } 
      return PorterDuff.Mode.SRC_IN;
    } 
    return PorterDuff.Mode.SRC_OVER;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */