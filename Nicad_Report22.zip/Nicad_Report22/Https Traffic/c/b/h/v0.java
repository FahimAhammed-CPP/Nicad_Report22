package c.b.h;

import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.widget.TextView;

public class v0 extends x0 {
  public void a(StaticLayout.Builder paramBuilder, TextView paramTextView) {
    paramBuilder.setTextDirection(y0.<TextDirectionHeuristic>e(paramTextView, "getTextDirectionHeuristic", TextDirectionHeuristics.FIRSTSTRONG_LTR));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\v0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */