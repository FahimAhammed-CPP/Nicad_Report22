package c.b.h;

import android.text.StaticLayout;
import android.widget.TextView;

public abstract class x0 {
  public abstract void a(StaticLayout.Builder paramBuilder, TextView paramTextView);
  
  public boolean b(TextView paramTextView) {
    return ((Boolean)y0.<Boolean>e(paramTextView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */