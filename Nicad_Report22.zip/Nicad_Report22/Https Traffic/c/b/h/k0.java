package c.b.h;

import android.view.ViewTreeObserver;
import c.h.j.u;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class k0 implements ViewTreeObserver.OnGlobalLayoutListener {
  public k0(m0 paramm0) {}
  
  public void onGlobalLayout() {
    boolean bool;
    m0 m01 = this.e;
    q0 q0 = m01.L;
    Objects.requireNonNull(m01);
    AtomicInteger atomicInteger = u.a;
    if (q0.isAttachedToWindow() && q0.getGlobalVisibleRect(m01.J)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool) {
      this.e.dismiss();
      return;
    } 
    this.e.t();
    this.e.d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */