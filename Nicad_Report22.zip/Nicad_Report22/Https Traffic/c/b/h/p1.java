package c.b.h;

import c.h.j.u;
import java.util.concurrent.atomic.AtomicInteger;

public class p1 implements Runnable {
  public p1(q1 paramq1) {}
  
  public void run() {
    f1 f1 = this.e.g;
    if (f1 != null) {
      AtomicInteger atomicInteger = u.a;
      if (f1.isAttachedToWindow() && this.e.g.getCount() > this.e.g.getChildCount()) {
        int i = this.e.g.getChildCount();
        q1 q11 = this.e;
        if (i <= q11.q) {
          q11.D.setInputMethodMode(2);
          this.e.d();
        } 
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b\h\p1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */