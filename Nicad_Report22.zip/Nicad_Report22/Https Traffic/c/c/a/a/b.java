package c.c.a.a;

import java.util.concurrent.Executor;

public class b extends e {
  public static volatile b c;
  
  public static final Executor d = new a();
  
  public e a;
  
  public e b;
  
  public b() {
    d d = new d();
    this.b = d;
    this.a = d;
  }
  
  public static b d() {
    // Byte code:
    //   0: getstatic c/c/a/a/b.c : Lc/c/a/a/b;
    //   3: ifnull -> 10
    //   6: getstatic c/c/a/a/b.c : Lc/c/a/a/b;
    //   9: areturn
    //   10: ldc c/c/a/a/b
    //   12: monitorenter
    //   13: getstatic c/c/a/a/b.c : Lc/c/a/a/b;
    //   16: ifnonnull -> 29
    //   19: new c/c/a/a/b
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: putstatic c/c/a/a/b.c : Lc/c/a/a/b;
    //   29: ldc c/c/a/a/b
    //   31: monitorexit
    //   32: getstatic c/c/a/a/b.c : Lc/c/a/a/b;
    //   35: areturn
    //   36: astore_0
    //   37: ldc c/c/a/a/b
    //   39: monitorexit
    //   40: aload_0
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   13	29	36	finally
    //   29	32	36	finally
    //   37	40	36	finally
  }
  
  public void a(Runnable paramRunnable) {
    this.a.a(paramRunnable);
  }
  
  public boolean b() {
    return this.a.b();
  }
  
  public void c(Runnable paramRunnable) {
    this.a.c(paramRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\c\a\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */