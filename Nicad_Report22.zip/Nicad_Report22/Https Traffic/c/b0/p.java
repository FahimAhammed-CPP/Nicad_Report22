package c.b0;

public enum p {
  e, f, g, h, i, j;
  
  static {
    p p1 = new p("NOT_REQUIRED", 0);
    e = p1;
    p p2 = new p("CONNECTED", 1);
    f = p2;
    p p3 = new p("UNMETERED", 2);
    g = p3;
    p p4 = new p("NOT_ROAMING", 3);
    h = p4;
    p p5 = new p("METERED", 4);
    i = p5;
    p p6 = new p("TEMPORARILY_UNMETERED", 5);
    j = p6;
    k = new p[] { p1, p2, p3, p4, p5, p6 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */