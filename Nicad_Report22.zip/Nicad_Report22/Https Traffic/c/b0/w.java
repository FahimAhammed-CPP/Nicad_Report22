package c.b0;

public interface w {
  public static final u a = new u(null);
  
  public static final t b = new t(null);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */