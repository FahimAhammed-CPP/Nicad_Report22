package c.b0;

import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class g {
  public static final String b = o.e("Data");
  
  public static final g c;
  
  public Map<String, Object> a;
  
  static {
    g g1 = new g(new HashMap<String, Object>());
    c(g1);
    c = g1;
  }
  
  public g(g paramg) {
    this.a = new HashMap<String, Object>(paramg.a);
  }
  
  public g(Map<String, ?> paramMap) {
    this.a = new HashMap<String, Object>(paramMap);
  }
  
  public static g a(byte[] paramArrayOfbyte) {
    ByteArrayInputStream byteArrayInputStream;
    if (paramArrayOfbyte.length <= 10240) {
      byte[] arrayOfByte;
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
      IOException iOException = null;
      try {
        arrayOfByte = (byte[])new ObjectInputStream(byteArrayInputStream);
        ObjectInputStream objectInputStream = (ObjectInputStream)arrayOfByte;
        try {
          for (int i = arrayOfByte.readInt(); i > 0; i--) {
            objectInputStream = (ObjectInputStream)arrayOfByte;
            hashMap.put(arrayOfByte.readUTF(), arrayOfByte.readObject());
          } 
          try {
            arrayOfByte.close();
          } catch (IOException iOException1) {
            Log.e(b, "Error in Data#fromByteArray: ", iOException1);
          } 
          try {
            byteArrayInputStream.close();
          } catch (IOException iOException1) {}
        } catch (IOException iOException1) {
        
        } catch (ClassNotFoundException classNotFoundException) {
        
        } finally {}
      } catch (IOException iOException1) {
        arrayOfByte = null;
        iOException = iOException1;
      } catch (ClassNotFoundException classNotFoundException) {
      
      } finally {}
      paramArrayOfbyte = arrayOfByte;
      Log.e(b, "Error in Data#fromByteArray: ", iOException);
      if (arrayOfByte != null) {
        try {
          arrayOfByte.close();
          try {
            byteArrayInputStream.close();
          } catch (IOException null) {}
        } catch (IOException null) {
          Log.e(b, "Error in Data#fromByteArray: ", iOException1);
          try {
            byteArrayInputStream.close();
          } catch (IOException iOException1) {}
        } 
        Log.e(b, "Error in Data#fromByteArray: ", iOException1);
      } 
    } else {
      throw new IllegalStateException("Data cannot occupy more than 10240 bytes when serialized");
    } 
    try {
      byteArrayInputStream.close();
    } catch (IOException iOException) {}
  }
  
  public static byte[] c(g paramg) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    g g2 = null;
    entry = null;
    try {
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
      try {
        objectOutputStream.writeInt(paramg.a.size());
        for (Map.Entry<String, Object> entry : paramg.a.entrySet()) {
          objectOutputStream.writeUTF((String)entry.getKey());
          objectOutputStream.writeObject(entry.getValue());
        } 
        try {
          objectOutputStream.close();
        } catch (IOException iOException1) {
          Log.e(b, "Error in Data#toByteArray: ", iOException1);
        } 
        try {
          byteArrayOutputStream.close();
        } catch (IOException iOException1) {
          Log.e(b, "Error in Data#toByteArray: ", iOException1);
        } 
        if (byteArrayOutputStream.size() <= 10240)
          return byteArrayOutputStream.toByteArray(); 
        throw new IllegalStateException("Data cannot occupy more than 10240 bytes when serialized");
      } catch (IOException iOException1) {
        ObjectOutputStream objectOutputStream1 = objectOutputStream;
        iOException = iOException1;
      } finally {}
    } catch (IOException iOException) {
      paramg = g2;
    } finally {}
    g g1 = paramg;
    Log.e(b, "Error in Data#toByteArray: ", iOException);
    g1 = paramg;
    byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
    if (paramg != null)
      try {
        paramg.close();
      } catch (IOException iOException1) {
        Log.e(b, "Error in Data#toByteArray: ", iOException1);
      }  
    try {
      byteArrayOutputStream.close();
      return arrayOfByte;
    } catch (IOException iOException1) {
      Log.e(b, "Error in Data#toByteArray: ", iOException1);
      return arrayOfByte;
    } 
  }
  
  public String b(String paramString) {
    paramString = (String)this.a.get(paramString);
    return (paramString instanceof String) ? paramString : null;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (g.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      Set<String> set = this.a.keySet();
      if (!set.equals(((g)paramObject).a.keySet()))
        return false; 
      for (String str : set) {
        boolean bool;
        Object object = this.a.get(str);
        str = (String)((g)paramObject).a.get(str);
        if (object == null || str == null) {
          if (object == str) {
            bool = true;
          } else {
            bool = false;
          } 
        } else if (object instanceof Object[] && str instanceof Object[]) {
          bool = Arrays.deepEquals((Object[])object, (Object[])str);
        } else {
          bool = object.equals(str);
        } 
        if (!bool)
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  public int hashCode() {
    return this.a.hashCode() * 31;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("Data {");
    if (!this.a.isEmpty())
      for (String str : this.a.keySet()) {
        stringBuilder.append(str);
        stringBuilder.append(" : ");
        str = (String)this.a.get(str);
        if (str instanceof Object[]) {
          stringBuilder.append(Arrays.toString((Object[])str));
        } else {
          stringBuilder.append(str);
        } 
        stringBuilder.append(", ");
      }  
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public static final class a {
    public Map<String, Object> a = new HashMap<String, Object>();
    
    public g a() {
      g g = new g(this.a);
      g.c(g);
      return g;
    }
    
    public a b(Map<String, Object> param1Map) {
      for (Map.Entry<String, Object> entry : param1Map.entrySet()) {
        boolean[] arrayOfBoolean;
        byte[] arrayOfByte;
        int[] arrayOfInt;
        long[] arrayOfLong;
        float[] arrayOfFloat;
        Map<String, Object> map;
        String str = (String)entry.getKey();
        entry = (Map.Entry<String, Object>)entry.getValue();
        if (entry == null) {
          this.a.put(str, null);
          continue;
        } 
        Class<?> clazz = entry.getClass();
        if (clazz == Boolean.class || clazz == Byte.class || clazz == Integer.class || clazz == Long.class || clazz == Float.class || clazz == Double.class || clazz == String.class || clazz == Boolean[].class || clazz == Byte[].class || clazz == Integer[].class || clazz == Long[].class || clazz == Float[].class || clazz == Double[].class || clazz == String[].class) {
          this.a.put(str, entry);
          continue;
        } 
        boolean bool1 = false;
        boolean bool2 = false;
        boolean bool3 = false;
        boolean bool4 = false;
        boolean bool5 = false;
        int i = 0;
        if (clazz == boolean[].class) {
          map = this.a;
          arrayOfBoolean = (boolean[])entry;
          String str1 = g.b;
          Boolean[] arrayOfBoolean1 = new Boolean[arrayOfBoolean.length];
          while (i < arrayOfBoolean.length) {
            arrayOfBoolean1[i] = Boolean.valueOf(arrayOfBoolean[i]);
            i++;
          } 
          map.put(str, arrayOfBoolean1);
          continue;
        } 
        if (map == byte[].class) {
          map = this.a;
          arrayOfByte = (byte[])arrayOfBoolean;
          String str1 = g.b;
          Byte[] arrayOfByte1 = new Byte[arrayOfByte.length];
          for (i = bool1; i < arrayOfByte.length; i++)
            arrayOfByte1[i] = Byte.valueOf(arrayOfByte[i]); 
          map.put(str, arrayOfByte1);
          continue;
        } 
        if (map == int[].class) {
          map = this.a;
          arrayOfInt = (int[])arrayOfByte;
          String str1 = g.b;
          Integer[] arrayOfInteger = new Integer[arrayOfInt.length];
          for (i = bool2; i < arrayOfInt.length; i++)
            arrayOfInteger[i] = Integer.valueOf(arrayOfInt[i]); 
          map.put(str, arrayOfInteger);
          continue;
        } 
        if (map == long[].class) {
          map = this.a;
          arrayOfLong = (long[])arrayOfInt;
          String str1 = g.b;
          Long[] arrayOfLong1 = new Long[arrayOfLong.length];
          for (i = bool3; i < arrayOfLong.length; i++)
            arrayOfLong1[i] = Long.valueOf(arrayOfLong[i]); 
          map.put(str, arrayOfLong1);
          continue;
        } 
        if (map == float[].class) {
          map = this.a;
          arrayOfFloat = (float[])arrayOfLong;
          String str1 = g.b;
          Float[] arrayOfFloat1 = new Float[arrayOfFloat.length];
          for (i = bool4; i < arrayOfFloat.length; i++)
            arrayOfFloat1[i] = Float.valueOf(arrayOfFloat[i]); 
          map.put(str, arrayOfFloat1);
          continue;
        } 
        if (map == double[].class) {
          map = this.a;
          double[] arrayOfDouble = (double[])arrayOfFloat;
          String str1 = g.b;
          Double[] arrayOfDouble1 = new Double[arrayOfDouble.length];
          for (i = bool5; i < arrayOfDouble.length; i++)
            arrayOfDouble1[i] = Double.valueOf(arrayOfDouble[i]); 
          map.put(str, arrayOfDouble1);
          continue;
        } 
        throw new IllegalArgumentException(String.format("Key %s has invalid type %s", new Object[] { str, map }));
      } 
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */