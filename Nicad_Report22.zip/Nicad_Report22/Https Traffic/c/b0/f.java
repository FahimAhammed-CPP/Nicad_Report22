package c.b0;

import java.util.HashSet;
import java.util.Set;

public final class f {
  public final Set<e> a = new HashSet<e>();
  
  public int a() {
    return this.a.size();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null || f.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return this.a.equals(((f)paramObject).a);
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */