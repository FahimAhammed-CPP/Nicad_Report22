package c.b0.f0;

import c.u.t.a;
import c.w.a.b;
import c.w.a.f.c;

public class k extends a {
  public k(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public void a(b paramb) {
    ((c)paramb).e.execSQL("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
    c c = (c)paramb;
    c.e.execSQL("INSERT INTO SystemIdInfo(work_spec_id, system_id) SELECT work_spec_id, alarm_id AS system_id FROM alarmInfo");
    c.e.execSQL("DROP TABLE IF EXISTS alarmInfo");
    c.e.execSQL("INSERT OR IGNORE INTO worktag(tag, work_spec_id) SELECT worker_class_name AS tag, id AS work_spec_id FROM workspec");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */