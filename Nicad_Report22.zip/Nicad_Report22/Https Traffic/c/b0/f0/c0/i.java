package c.b0.f0.c0;

import android.content.Context;
import c.b0.c;
import c.b0.o;

public abstract class i {
  public static final String a = o.e("ProcessUtils");
  
  public static boolean a(Context paramContext, c paramc) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: bipush #28
    //   5: if_icmplt -> 15
    //   8: invokestatic getProcessName : ()Ljava/lang/String;
    //   11: astore_3
    //   12: goto -> 169
    //   15: ldc 'android.app.ActivityThread'
    //   17: iconst_0
    //   18: ldc c/b0/f0/c0/i
    //   20: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   23: invokestatic forName : (Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    //   26: ldc 'currentProcessName'
    //   28: iconst_0
    //   29: anewarray java/lang/Class
    //   32: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   35: astore_3
    //   36: aload_3
    //   37: iconst_1
    //   38: invokevirtual setAccessible : (Z)V
    //   41: aload_3
    //   42: aconst_null
    //   43: iconst_0
    //   44: anewarray java/lang/Object
    //   47: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   50: astore_3
    //   51: aload_3
    //   52: instanceof java/lang/String
    //   55: ifeq -> 86
    //   58: aload_3
    //   59: checkcast java/lang/String
    //   62: astore_3
    //   63: goto -> 169
    //   66: astore_3
    //   67: invokestatic c : ()Lc/b0/o;
    //   70: getstatic c/b0/f0/c0/i.a : Ljava/lang/String;
    //   73: ldc 'Unable to check ActivityThread for processName'
    //   75: iconst_1
    //   76: anewarray java/lang/Throwable
    //   79: dup
    //   80: iconst_0
    //   81: aload_3
    //   82: aastore
    //   83: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   86: invokestatic myPid : ()I
    //   89: istore_2
    //   90: aload_0
    //   91: ldc 'activity'
    //   93: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   96: checkcast android/app/ActivityManager
    //   99: astore_3
    //   100: aload_3
    //   101: ifnull -> 167
    //   104: aload_3
    //   105: invokevirtual getRunningAppProcesses : ()Ljava/util/List;
    //   108: astore_3
    //   109: aload_3
    //   110: ifnull -> 167
    //   113: aload_3
    //   114: invokeinterface isEmpty : ()Z
    //   119: ifne -> 167
    //   122: aload_3
    //   123: invokeinterface iterator : ()Ljava/util/Iterator;
    //   128: astore_3
    //   129: aload_3
    //   130: invokeinterface hasNext : ()Z
    //   135: ifeq -> 167
    //   138: aload_3
    //   139: invokeinterface next : ()Ljava/lang/Object;
    //   144: checkcast android/app/ActivityManager$RunningAppProcessInfo
    //   147: astore #4
    //   149: aload #4
    //   151: getfield pid : I
    //   154: iload_2
    //   155: if_icmpne -> 129
    //   158: aload #4
    //   160: getfield processName : Ljava/lang/String;
    //   163: astore_3
    //   164: goto -> 169
    //   167: aconst_null
    //   168: astore_3
    //   169: aload_1
    //   170: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   173: pop
    //   174: aconst_null
    //   175: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   178: ifne -> 187
    //   181: aload_3
    //   182: aconst_null
    //   183: invokestatic equals : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    //   186: ireturn
    //   187: aload_3
    //   188: aload_0
    //   189: invokevirtual getApplicationInfo : ()Landroid/content/pm/ApplicationInfo;
    //   192: getfield processName : Ljava/lang/String;
    //   195: invokestatic equals : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    //   198: ireturn
    // Exception table:
    //   from	to	target	type
    //   15	63	66	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */