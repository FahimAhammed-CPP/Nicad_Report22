package c.b0.f0.c0;

import c.b0.o;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public class y {
  public static final String f = o.e("WorkTimer");
  
  public final ThreadFactory a;
  
  public final ScheduledExecutorService b;
  
  public final Map<String, x> c;
  
  public final Map<String, w> d;
  
  public final Object e;
  
  public y() {
    v v = new v(this);
    this.a = v;
    this.c = new HashMap<String, x>();
    this.d = new HashMap<String, w>();
    this.e = new Object();
    this.b = Executors.newSingleThreadScheduledExecutor(v);
  }
  
  public void a(String paramString, long paramLong, w paramw) {
    synchronized (this.e) {
      o.c().a(f, String.format("Starting timer for %s", new Object[] { paramString }), new Throwable[0]);
      b(paramString);
      x x = new x(this, paramString);
      this.c.put(paramString, x);
      this.d.put(paramString, paramw);
      this.b.schedule(x, paramLong, TimeUnit.MILLISECONDS);
      return;
    } 
  }
  
  public void b(String paramString) {
    synchronized (this.e) {
      if ((x)this.c.remove(paramString) != null) {
        o.c().a(f, String.format("Stopping timer for %s", new Object[] { paramString }), new Throwable[0]);
        this.d.remove(paramString);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */