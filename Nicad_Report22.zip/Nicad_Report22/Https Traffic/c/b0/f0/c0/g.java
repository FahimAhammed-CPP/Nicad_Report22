package c.b0.f0.c0;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import c.b0.o;

public abstract class g {
  public static final String a = o.e("PackageManagerHelper");
  
  public static void a(Context paramContext, Class<?> paramClass, boolean paramBoolean) {
    String str = "enabled";
    try {
      String str1;
      byte b;
      PackageManager packageManager = paramContext.getPackageManager();
      ComponentName componentName = new ComponentName(paramContext, paramClass.getName());
      if (paramBoolean) {
        b = 1;
      } else {
        b = 2;
      } 
      packageManager.setComponentEnabledSetting(componentName, b, 1);
      o o = o.c();
      String str2 = a;
      String str3 = paramClass.getName();
      if (paramBoolean) {
        str1 = "enabled";
      } else {
        str1 = "disabled";
      } 
      o.a(str2, String.format("%s %s", new Object[] { str3, str1 }), new Throwable[0]);
      return;
    } catch (Exception exception) {
      String str1;
      o o = o.c();
      String str3 = a;
      String str2 = paramClass.getName();
      if (paramBoolean) {
        str1 = str;
      } else {
        str1 = "disabled";
      } 
      o.a(str3, String.format("%s could not be %s", new Object[] { str2, str1 }), new Throwable[] { exception });
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */