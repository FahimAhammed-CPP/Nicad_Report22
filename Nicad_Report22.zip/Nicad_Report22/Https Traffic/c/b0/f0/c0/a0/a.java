package c.b0.f0.c0.a0;

public interface a {}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */