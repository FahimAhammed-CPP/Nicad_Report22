package c.b0.f0.c0.a0;

import java.util.concurrent.Executor;

public class b implements Executor {
  public b(c paramc) {}
  
  public void execute(Runnable paramRunnable) {
    this.e.b.post(paramRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */