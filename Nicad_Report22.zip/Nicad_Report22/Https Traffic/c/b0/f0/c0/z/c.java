package c.b0.f0.c0.z;

public final class c {
  public static final c c;
  
  public static final c d = new c(false, null);
  
  public final boolean a;
  
  public final Throwable b;
  
  static {
    c = new c(true, null);
  }
  
  public c(boolean paramBoolean, Throwable paramThrowable) {
    this.a = paramBoolean;
    this.b = paramThrowable;
  }
  
  static {
    if (k.h) {
      d = null;
      c = null;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */