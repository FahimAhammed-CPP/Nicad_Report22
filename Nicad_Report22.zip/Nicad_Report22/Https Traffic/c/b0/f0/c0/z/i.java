package c.b0.f0.c0.z;

public final class i extends b {
  public i() {
    super(null);
  }
  
  public boolean a(k<?> paramk, f paramf1, f paramf2) {
    // Byte code:
    //   0: aload_1
    //   1: monitorenter
    //   2: aload_1
    //   3: getfield f : Lc/b0/f0/c0/z/f;
    //   6: aload_2
    //   7: if_acmpne -> 19
    //   10: aload_1
    //   11: aload_3
    //   12: putfield f : Lc/b0/f0/c0/z/f;
    //   15: aload_1
    //   16: monitorexit
    //   17: iconst_1
    //   18: ireturn
    //   19: aload_1
    //   20: monitorexit
    //   21: iconst_0
    //   22: ireturn
    //   23: astore_2
    //   24: aload_1
    //   25: monitorexit
    //   26: aload_2
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	23	finally
    //   19	21	23	finally
    //   24	26	23	finally
  }
  
  public boolean b(k<?> paramk, Object paramObject1, Object paramObject2) {
    // Byte code:
    //   0: aload_1
    //   1: monitorenter
    //   2: aload_1
    //   3: getfield e : Ljava/lang/Object;
    //   6: aload_2
    //   7: if_acmpne -> 19
    //   10: aload_1
    //   11: aload_3
    //   12: putfield e : Ljava/lang/Object;
    //   15: aload_1
    //   16: monitorexit
    //   17: iconst_1
    //   18: ireturn
    //   19: aload_1
    //   20: monitorexit
    //   21: iconst_0
    //   22: ireturn
    //   23: astore_2
    //   24: aload_1
    //   25: monitorexit
    //   26: aload_2
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	23	finally
    //   19	21	23	finally
    //   24	26	23	finally
  }
  
  public boolean c(k<?> paramk, j paramj1, j paramj2) {
    // Byte code:
    //   0: aload_1
    //   1: monitorenter
    //   2: aload_1
    //   3: getfield g : Lc/b0/f0/c0/z/j;
    //   6: aload_2
    //   7: if_acmpne -> 19
    //   10: aload_1
    //   11: aload_3
    //   12: putfield g : Lc/b0/f0/c0/z/j;
    //   15: aload_1
    //   16: monitorexit
    //   17: iconst_1
    //   18: ireturn
    //   19: aload_1
    //   20: monitorexit
    //   21: iconst_0
    //   22: ireturn
    //   23: astore_2
    //   24: aload_1
    //   25: monitorexit
    //   26: aload_2
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	23	finally
    //   19	21	23	finally
    //   24	26	23	finally
  }
  
  public void d(j paramj1, j paramj2) {
    paramj1.b = paramj2;
  }
  
  public void e(j paramj, Thread paramThread) {
    paramj.a = paramThread;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */