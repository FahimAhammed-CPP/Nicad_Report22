package c.b0.f0.c0.z;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public final class g extends b {
  public final AtomicReferenceFieldUpdater<j, Thread> a;
  
  public final AtomicReferenceFieldUpdater<j, j> b;
  
  public final AtomicReferenceFieldUpdater<k, j> c;
  
  public final AtomicReferenceFieldUpdater<k, f> d;
  
  public final AtomicReferenceFieldUpdater<k, Object> e;
  
  public g(AtomicReferenceFieldUpdater<j, Thread> paramAtomicReferenceFieldUpdater, AtomicReferenceFieldUpdater<j, j> paramAtomicReferenceFieldUpdater1, AtomicReferenceFieldUpdater<k, j> paramAtomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater<k, f> paramAtomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater<k, Object> paramAtomicReferenceFieldUpdater4) {
    super(null);
    this.a = paramAtomicReferenceFieldUpdater;
    this.b = paramAtomicReferenceFieldUpdater1;
    this.c = paramAtomicReferenceFieldUpdater2;
    this.d = paramAtomicReferenceFieldUpdater3;
    this.e = paramAtomicReferenceFieldUpdater4;
  }
  
  public boolean a(k<?> paramk, f paramf1, f paramf2) {
    return this.d.compareAndSet(paramk, paramf1, paramf2);
  }
  
  public boolean b(k<?> paramk, Object paramObject1, Object paramObject2) {
    return this.e.compareAndSet(paramk, paramObject1, paramObject2);
  }
  
  public boolean c(k<?> paramk, j paramj1, j paramj2) {
    return this.c.compareAndSet(paramk, paramj1, paramj2);
  }
  
  public void d(j paramj1, j paramj2) {
    this.b.lazySet(paramj1, paramj2);
  }
  
  public void e(j paramj, Thread paramThread) {
    this.a.lazySet(paramj, paramThread);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */