package c.b0.f0.c0.z;

import java.util.concurrent.Executor;

public enum l implements Executor {
  e;
  
  static {
    l l1 = new l("INSTANCE", 0);
    e = l1;
    f = new l[] { l1 };
  }
  
  public void execute(Runnable paramRunnable) {
    paramRunnable.run();
  }
  
  public String toString() {
    return "DirectExecutor";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */