package c.b0.f0.c0.z;

public class d extends Throwable {
  public d(String paramString) {
    super(paramString);
  }
  
  public Throwable fillInStackTrace() {
    /* monitor enter ThisExpression{ObjectType{c/b0/f0/c0/z/d}} */
    /* monitor exit ThisExpression{ObjectType{c/b0/f0/c0/z/d}} */
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */