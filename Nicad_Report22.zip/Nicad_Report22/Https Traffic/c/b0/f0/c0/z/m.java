package c.b0.f0.c0.z;

import d.c.c.d.a.a;
import java.util.Objects;
import java.util.concurrent.Executor;

public final class m<V> extends k<V> {
  public boolean k(V paramV) {
    V v = paramV;
    if (paramV == null)
      v = (V)k.k; 
    if (k.j.b(this, null, v)) {
      k.d(this);
      return true;
    } 
    return false;
  }
  
  public boolean l(Throwable paramThrowable) {
    Objects.requireNonNull(paramThrowable);
    e e = new e(paramThrowable);
    if (k.j.b(this, null, e)) {
      k.d(this);
      return true;
    } 
    return false;
  }
  
  public boolean m(a<? extends V> parama) {
    Object object1;
    Objects.requireNonNull(parama);
    Object object3 = this.e;
    Object object2 = object3;
    if (object3 == null) {
      if (((k)parama).isDone()) {
        object1 = k.g(parama);
        if (k.j.b(this, null, object1)) {
          k.d(this);
          return true;
        } 
      } else {
        object2 = new h(this, (a<?>)object1);
        if (k.j.b(this, null, object2)) {
          try {
            object3 = l.e;
            ((k)object1).c((Runnable)object2, (Executor)object3);
          } finally {}
          return true;
        } 
        object2 = this.e;
        if (object2 instanceof c) {
          boolean bool = ((c)object2).a;
          ((k)object1).cancel(bool);
        } 
      } 
      return false;
    } 
    if (object2 instanceof c) {
      boolean bool = ((c)object2).a;
      ((k)object1).cancel(bool);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */