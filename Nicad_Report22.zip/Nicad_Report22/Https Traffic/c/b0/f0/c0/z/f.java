package c.b0.f0.c0.z;

import java.util.concurrent.Executor;

public final class f {
  public static final f d = new f(null, null);
  
  public final Runnable a;
  
  public final Executor b;
  
  public f c;
  
  public f(Runnable paramRunnable, Executor paramExecutor) {
    this.a = paramRunnable;
    this.b = paramExecutor;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */