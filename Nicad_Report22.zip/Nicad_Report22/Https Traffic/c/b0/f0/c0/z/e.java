package c.b0.f0.c0.z;

import java.util.Objects;

public final class e {
  public static final e b = new e(new d("Failure occurred while trying to finish a future."));
  
  public final Throwable a;
  
  public e(Throwable paramThrowable) {
    boolean bool = k.h;
    Objects.requireNonNull(paramThrowable);
    this.a = paramThrowable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\z\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */