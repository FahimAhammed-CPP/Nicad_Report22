package c.b0.f0.c0;

import androidx.work.impl.WorkDatabase;
import c.b0.f0.t;
import java.util.UUID;

public class a extends d {
  public a(t paramt, UUID paramUUID) {}
  
  public void c() {
    WorkDatabase workDatabase = this.f.c;
    workDatabase.c();
    try {
      a(this.f, this.g.toString());
      workDatabase.k();
      workDatabase.g();
      return;
    } finally {
      workDatabase.g();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */