package c.b0.f0.c0;

public class j implements Runnable {
  public final k e;
  
  public final Runnable f;
  
  public j(k paramk, Runnable paramRunnable) {
    this.e = paramk;
    this.f = paramRunnable;
  }
  
  public void run() {
    try {
      this.f.run();
      return;
    } finally {
      this.e.a();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */