package c.b0.f0.c0;

import android.content.Context;
import androidx.work.impl.WorkDatabase;
import c.b0.f0.a0.a;
import c.b0.f0.b0.c0;
import c.b0.f0.c0.a0.a;
import c.b0.f0.c0.a0.c;
import c.b0.f0.c0.z.m;
import c.b0.h;
import c.b0.i;
import c.b0.o;
import d.c.c.d.a.a;
import java.util.UUID;

public class s implements i {
  public final a a;
  
  public final a b;
  
  public final c0 c;
  
  static {
    o.e("WMFgUpdater");
  }
  
  public s(WorkDatabase paramWorkDatabase, a parama, a parama1) {
    this.b = parama;
    this.a = parama1;
    this.c = paramWorkDatabase.q();
  }
  
  public a<Void> a(Context paramContext, UUID paramUUID, h paramh) {
    m m = new m();
    a a1 = this.a;
    r r = new r(this, m, paramUUID, paramh, paramContext);
    ((c)a1).a.execute(r);
    return (a<Void>)m;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */