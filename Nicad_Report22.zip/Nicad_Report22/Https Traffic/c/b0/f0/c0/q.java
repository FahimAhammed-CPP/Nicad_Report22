package c.b0.f0.c0;

import android.content.Context;
import androidx.work.ListenableWorker;
import c.b0.f0.b0.t;
import c.b0.f0.c0.a0.a;
import c.b0.f0.c0.a0.c;
import c.b0.f0.c0.z.m;
import c.b0.i;
import c.b0.o;
import c.h.b.h;

public class q implements Runnable {
  public static final String k = o.e("WorkForegroundRunnable");
  
  public final m<Void> e = new m();
  
  public final Context f;
  
  public final t g;
  
  public final ListenableWorker h;
  
  public final i i;
  
  public final a j;
  
  public q(Context paramContext, t paramt, ListenableWorker paramListenableWorker, i parami, a parama) {
    this.f = paramContext;
    this.g = paramt;
    this.h = paramListenableWorker;
    this.i = parami;
    this.j = parama;
  }
  
  public void run() {
    if (!this.g.q || h.Q()) {
      this.e.k(null);
      return;
    } 
    m m1 = new m();
    ((c)this.j).c.execute(new o(this, m1));
    m1.c(new p(this, m1), ((c)this.j).c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c0\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */