package c.b0.f0;

import android.content.Context;
import c.b0.o;
import java.io.File;
import java.util.HashMap;

public abstract class s {
  public static final String a = o.e("WrkDbPathHelper");
  
  public static final String[] b = new String[] { "-journal", "-shm", "-wal" };
  
  public static void a(Context paramContext) {
    if (paramContext.getDatabasePath("androidx.work.workdb").exists()) {
      o.c().a(a, "Migrating WorkDatabase to the no-backup directory", new Throwable[0]);
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      File file2 = paramContext.getDatabasePath("androidx.work.workdb");
      file1 = new File(paramContext.getNoBackupFilesDir(), "androidx.work.workdb");
      hashMap.put(file2, file1);
      for (String str : b) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(file2.getPath());
        stringBuilder1.append(str);
        File file = new File(stringBuilder1.toString());
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(file1.getPath());
        stringBuilder2.append(str);
        hashMap.put(file, new File(stringBuilder2.toString()));
      } 
      for (File file1 : hashMap.keySet()) {
        File file = (File)hashMap.get(file1);
        if (file1.exists() && file != null) {
          String str;
          if (file.exists()) {
            String str1 = String.format("Over-writing contents of %s", new Object[] { file });
            o.c().f(a, str1, new Throwable[0]);
          } 
          if (file1.renameTo(file)) {
            str = String.format("Migrated %s to %s", new Object[] { file1, file });
          } else {
            str = String.format("Renaming %s to %s failed", new Object[] { str, file });
          } 
          o.c().a(a, str, new Throwable[0]);
        } 
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */