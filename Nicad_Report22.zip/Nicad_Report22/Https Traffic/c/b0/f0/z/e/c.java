package c.b0.f0.z.e;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class c extends BroadcastReceiver {
  public c(d paramd) {}
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent != null)
      this.a.g(paramContext, paramIntent); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\e\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */