package c.b0.f0.z.e;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import c.b0.o;

public class a extends d<Boolean> {
  public static final String i = o.e("BatteryChrgTracker");
  
  public a(Context paramContext, c.b0.f0.c0.a0.a parama) {
    super(paramContext, parama);
  }
  
  public Object a() {
    IntentFilter intentFilter = new IntentFilter("android.intent.action.BATTERY_CHANGED");
    Intent intent = this.b.registerReceiver(null, intentFilter);
    boolean bool = false;
    if (intent == null) {
      o.c().b(i, "getInitialState - null intent received", new Throwable[0]);
      return null;
    } 
    int i = intent.getIntExtra("status", -1);
    if (i == 2 || i == 5)
      bool = true; 
    return Boolean.valueOf(bool);
  }
  
  public IntentFilter f() {
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.os.action.CHARGING");
    intentFilter.addAction("android.os.action.DISCHARGING");
    return intentFilter;
  }
  
  public void g(Context paramContext, Intent paramIntent) {
    // Byte code:
    //   0: aload_2
    //   1: invokevirtual getAction : ()Ljava/lang/String;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnonnull -> 10
    //   9: return
    //   10: invokestatic c : ()Lc/b0/o;
    //   13: astore_2
    //   14: getstatic c/b0/f0/z/e/a.i : Ljava/lang/String;
    //   17: astore #4
    //   19: iconst_1
    //   20: istore_3
    //   21: aload_2
    //   22: aload #4
    //   24: ldc 'Received %s'
    //   26: iconst_1
    //   27: anewarray java/lang/Object
    //   30: dup
    //   31: iconst_0
    //   32: aload_1
    //   33: aastore
    //   34: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   37: iconst_0
    //   38: anewarray java/lang/Throwable
    //   41: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   44: aload_1
    //   45: invokevirtual hashCode : ()I
    //   48: lookupswitch default -> 92, -1886648615 -> 143, -54942926 -> 131, 948344062 -> 114, 1019184907 -> 97
    //   92: iconst_m1
    //   93: istore_3
    //   94: goto -> 157
    //   97: aload_1
    //   98: ldc 'android.intent.action.ACTION_POWER_CONNECTED'
    //   100: invokevirtual equals : (Ljava/lang/Object;)Z
    //   103: ifne -> 109
    //   106: goto -> 92
    //   109: iconst_3
    //   110: istore_3
    //   111: goto -> 157
    //   114: aload_1
    //   115: ldc 'android.os.action.CHARGING'
    //   117: invokevirtual equals : (Ljava/lang/Object;)Z
    //   120: ifne -> 126
    //   123: goto -> 92
    //   126: iconst_2
    //   127: istore_3
    //   128: goto -> 157
    //   131: aload_1
    //   132: ldc 'android.os.action.DISCHARGING'
    //   134: invokevirtual equals : (Ljava/lang/Object;)Z
    //   137: ifne -> 157
    //   140: goto -> 92
    //   143: aload_1
    //   144: ldc 'android.intent.action.ACTION_POWER_DISCONNECTED'
    //   146: invokevirtual equals : (Ljava/lang/Object;)Z
    //   149: ifne -> 155
    //   152: goto -> 92
    //   155: iconst_0
    //   156: istore_3
    //   157: iload_3
    //   158: tableswitch default -> 188, 0 -> 213, 1 -> 205, 2 -> 197, 3 -> 189
    //   188: return
    //   189: aload_0
    //   190: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   193: invokevirtual c : (Ljava/lang/Object;)V
    //   196: return
    //   197: aload_0
    //   198: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   201: invokevirtual c : (Ljava/lang/Object;)V
    //   204: return
    //   205: aload_0
    //   206: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   209: invokevirtual c : (Ljava/lang/Object;)V
    //   212: return
    //   213: aload_0
    //   214: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   217: invokevirtual c : (Ljava/lang/Object;)V
    //   220: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\e\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */