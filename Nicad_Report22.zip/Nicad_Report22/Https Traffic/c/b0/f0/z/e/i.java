package c.b0.f0.z.e;

import android.content.Context;
import c.b0.f0.c0.a0.a;

public class i {
  public static i e;
  
  public a a;
  
  public b b;
  
  public g c;
  
  public h d;
  
  public i(Context paramContext, a parama) {
    paramContext = paramContext.getApplicationContext();
    this.a = new a(paramContext, parama);
    this.b = new b(paramContext, parama);
    this.c = new g(paramContext, parama);
    this.d = new h(paramContext, parama);
  }
  
  public static i a(Context paramContext, a parama) {
    // Byte code:
    //   0: ldc c/b0/f0/z/e/i
    //   2: monitorenter
    //   3: getstatic c/b0/f0/z/e/i.e : Lc/b0/f0/z/e/i;
    //   6: ifnonnull -> 21
    //   9: new c/b0/f0/z/e/i
    //   12: dup
    //   13: aload_0
    //   14: aload_1
    //   15: invokespecial <init> : (Landroid/content/Context;Lc/b0/f0/c0/a0/a;)V
    //   18: putstatic c/b0/f0/z/e/i.e : Lc/b0/f0/z/e/i;
    //   21: getstatic c/b0/f0/z/e/i.e : Lc/b0/f0/z/e/i;
    //   24: astore_0
    //   25: ldc c/b0/f0/z/e/i
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc c/b0/f0/z/e/i
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	30	finally
    //   21	25	30	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\e\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */