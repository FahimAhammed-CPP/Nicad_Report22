package c.b0.f0.z;

import android.content.Context;
import c.b0.f0.b0.t;
import c.b0.f0.c0.a0.a;
import c.b0.f0.z.d.a;
import c.b0.f0.z.d.b;
import c.b0.f0.z.d.c;
import c.b0.f0.z.d.d;
import c.b0.f0.z.d.e;
import c.b0.f0.z.d.f;
import c.b0.f0.z.d.g;
import c.b0.f0.z.d.h;
import c.b0.f0.z.d.i;
import c.b0.o;

public class c implements c {
  public static final String d = o.e("WorkConstraintsTracker");
  
  public final b a;
  
  public final d<?>[] b;
  
  public final Object c;
  
  public c(Context paramContext, a parama, b paramb) {
    paramContext = paramContext.getApplicationContext();
    this.a = paramb;
    this.b = (d<?>[])new d[] { (d)new a(paramContext, parama), (d)new b(paramContext, parama), (d)new i(paramContext, parama), (d)new e(paramContext, parama), (d)new h(paramContext, parama), (d)new g(paramContext, parama), (d)new f(paramContext, parama) };
    this.c = new Object();
  }
  
  public boolean a(String paramString) {
    synchronized (this.c) {
      d<?>[] arrayOfD = this.b;
      int j = arrayOfD.length;
      for (int i = 0;; i++) {
        if (i < j) {
          boolean bool;
          d<?> d1 = arrayOfD[i];
          Object object = d1.b;
          if (object != null && d1.b(object) && d1.a.contains(paramString)) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool) {
            o.c().a(d, String.format("Work %s constrained by %s", new Object[] { paramString, d1.getClass().getSimpleName() }), new Throwable[0]);
            return false;
          } 
        } else {
          return true;
        } 
      } 
    } 
  }
  
  public void b(Iterable<t> paramIterable) {
    int i;
    synchronized (this.c) {
      d<?>[] arrayOfD = this.b;
      int j = arrayOfD.length;
      boolean bool = false;
      for (i = 0;; i++) {
        if (i < j) {
          d<?> d1 = arrayOfD[i];
          if (d1.d != null) {
            d1.d = null;
            d1.d(null, d1.b);
          } 
        } else {
          arrayOfD = this.b;
          j = arrayOfD.length;
          for (i = 0; i < j; i++)
            arrayOfD[i].c(paramIterable); 
          d<?>[] arrayOfD1 = this.b;
          j = arrayOfD1.length;
          for (i = bool;; i++) {
            if (i < j) {
              d<?> d1 = arrayOfD1[i];
              if (d1.d != this) {
                d1.d = this;
                d1.d(this, d1.b);
              } 
            } else {
              return;
            } 
          } 
        } 
      } 
    } 
    i++;
    continue;
  }
  
  public void c() {
    synchronized (this.c) {
      d<?>[] arrayOfD = this.b;
      int j = arrayOfD.length;
      for (int i = 0;; i++) {
        if (i < j) {
          d<?> d1 = arrayOfD[i];
          if (!d1.a.isEmpty()) {
            d1.a.clear();
            d1.c.b(d1);
          } 
        } else {
          return;
        } 
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */