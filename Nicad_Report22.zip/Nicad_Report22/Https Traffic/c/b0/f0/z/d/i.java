package c.b0.f0.z.d;

import android.content.Context;
import c.b0.f0.b0.t;
import c.b0.f0.c0.a0.a;
import c.b0.f0.z.e.f;

public class i extends d<Boolean> {
  public i(Context paramContext, a parama) {
    super((f<Boolean>)(c.b0.f0.z.e.i.a(paramContext, parama)).d);
  }
  
  public boolean a(t paramt) {
    return paramt.j.e;
  }
  
  public boolean b(Object paramObject) {
    return ((Boolean)paramObject).booleanValue() ^ true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\d\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */