package c.b0.f0.z.d;

import android.content.Context;
import c.b0.f0.b0.t;
import c.b0.f0.z.e.f;
import c.b0.f0.z.e.i;

public class a extends d<Boolean> {
  public a(Context paramContext, c.b0.f0.c0.a0.a parama) {
    super((f<Boolean>)(i.a(paramContext, parama)).a);
  }
  
  public boolean a(t paramt) {
    return paramt.j.b;
  }
  
  public boolean b(Object paramObject) {
    return ((Boolean)paramObject).booleanValue() ^ true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\d\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */