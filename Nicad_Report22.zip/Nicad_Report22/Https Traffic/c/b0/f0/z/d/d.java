package c.b0.f0.z.d;

import c.b0.f0.b0.t;
import c.b0.f0.z.b;
import c.b0.f0.z.c;
import c.b0.f0.z.e.f;
import c.b0.o;
import java.util.ArrayList;
import java.util.List;

public abstract class d<T> implements d<T> {
  public final List<String> a = new ArrayList<String>();
  
  public T b;
  
  public f<T> c;
  
  public c d;
  
  public d(f<T> paramf) {
    this.c = paramf;
  }
  
  public abstract boolean a(t paramt);
  
  public abstract boolean b(T paramT);
  
  public void c(Iterable<t> paramIterable) {
    this.a.clear();
    for (t t : paramIterable) {
      if (a(t))
        this.a.add(t.a); 
    } 
    if (this.a.isEmpty()) {
      this.c.b(this);
    } else {
      null = this.c;
      synchronized (null.c) {
        if (null.d.add(this)) {
          if (null.d.size() == 1) {
            null.e = null.a();
            o.c().a(f.f, String.format("%s: initial state = %s", new Object[] { null.getClass().getSimpleName(), null.e }), new Throwable[0]);
            null.d();
          } 
          Object object = null.e;
          this.b = (T)object;
          d(this.d, (T)object);
        } 
        d(this.d, this.b);
        return;
      } 
    } 
    d(this.d, this.b);
  }
  
  public final void d(c paramc, T paramT) {
    if (!this.a.isEmpty()) {
      if (paramc == null)
        return; 
      if (paramT == null || b(paramT)) {
        null = this.a;
        c c2 = (c)paramc;
        synchronized (c2.c) {
          b b = c2.a;
          if (b != null)
            b.d(null); 
          return;
        } 
      } 
      List<String> list = this.a;
      c c1 = (c)paramc;
      synchronized (c1.c) {
        ArrayList<String> arrayList = new ArrayList();
        for (String str : list) {
          if (c1.a(str)) {
            o.c().a(c.d, String.format("Constraints met for %s", new Object[] { str }), new Throwable[0]);
            arrayList.add(str);
          } 
        } 
        b b = c1.a;
        if (b != null)
          b.e(arrayList); 
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\d\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */