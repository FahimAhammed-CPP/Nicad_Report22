package c.b0.f0.z;

import java.util.List;

public interface b {
  void d(List<String> paramList);
  
  void e(List<String> paramList);
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\z\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */