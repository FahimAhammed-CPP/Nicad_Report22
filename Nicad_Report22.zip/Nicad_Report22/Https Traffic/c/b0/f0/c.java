package c.b0.f0;

import androidx.lifecycle.LiveData;
import c.b0.f0.c0.z.m;
import c.b0.s;
import c.b0.u;
import c.b0.v;
import c.b0.w;
import c.c.a.a.b;
import c.p.o;

public class c implements w {
  public final o<v> c = new o();
  
  public final m<u> d = new m();
  
  public c() {
    a((v)w.b);
  }
  
  public void a(v paramv) {
    o<v> o1 = this.c;
    synchronized (((LiveData)o1).a) {
      boolean bool;
      if (((LiveData)o1).e == LiveData.j) {
        bool = true;
      } else {
        bool = false;
      } 
      ((LiveData)o1).e = paramv;
      if (bool) {
        null = b.d();
        Runnable runnable = ((LiveData)o1).i;
        ((b)null).a.c(runnable);
      } 
      if (paramv instanceof u) {
        this.d.k(paramv);
        return;
      } 
      if (paramv instanceof s) {
        s s = (s)paramv;
        this.d.l(s.a);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */