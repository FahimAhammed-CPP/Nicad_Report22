package c.b0.f0.d0;

import androidx.work.impl.workers.ConstraintTrackingWorker;

public class a implements Runnable {
  public a(ConstraintTrackingWorker paramConstraintTrackingWorker, d.c.c.d.a.a parama) {}
  
  public void run() {
    synchronized (this.f.k) {
      if (this.f.l) {
        this.f.b();
      } else {
        this.f.m.m(this.e);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\d0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */