package c.b0.f0.b0;

import android.database.Cursor;
import c.b0.a0;
import c.b0.d;
import c.b0.g;
import c.h.b.h;
import c.u.b;
import c.u.l;
import c.u.q;
import c.u.s;
import c.u.u.a;
import c.w.a.e;
import c.w.a.f.h;
import c.w.a.f.i;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public final class c0 {
  public final l a;
  
  public final b<t> b;
  
  public final s c;
  
  public final s d;
  
  public final s e;
  
  public final s f;
  
  public final s g;
  
  public final s h;
  
  public final s i;
  
  public c0(l paraml) {
    this.a = paraml;
    this.b = new u(this, paraml);
    this.c = new v(this, paraml);
    this.d = new w(this, paraml);
    this.e = new x(this, paraml);
    this.f = new y(this, paraml);
    this.g = new z(this, paraml);
    this.h = new a0(this, paraml);
    this.i = new b0(this, paraml);
    new AtomicBoolean(false);
  }
  
  public void a(String paramString) {
    this.a.b();
    i i = this.c.a();
    if (paramString == null) {
      ((h)i).e.bindNull(1);
    } else {
      ((h)i).e.bindString(1, paramString);
    } 
    this.a.c();
    try {
      i.a();
      this.a.k();
      this.a.g();
      return;
    } finally {
      this.a.g();
      this.c.c(i);
    } 
  }
  
  public List<t> b(int paramInt) {
    Exception exception;
    q q = q.d("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 ORDER BY period_start_time LIMIT ?", 1);
    q.e(1, paramInt);
    this.a.b();
    Cursor cursor = a.a(this.a, (e)q, false, null);
    try {
      int n = h.x(cursor, "required_network_type");
      int i2 = h.x(cursor, "requires_charging");
      int j = h.x(cursor, "requires_device_idle");
      int i = h.x(cursor, "requires_battery_not_low");
      int i4 = h.x(cursor, "requires_storage_not_low");
      int i5 = h.x(cursor, "trigger_content_update_delay");
      int i6 = h.x(cursor, "trigger_max_content_delay");
      int i7 = h.x(cursor, "content_uri_triggers");
      int m = h.x(cursor, "id");
      int i8 = h.x(cursor, "state");
      int k = h.x(cursor, "worker_class_name");
      int i1 = h.x(cursor, "input_merger_class_name");
      int i9 = h.x(cursor, "input");
      int i3 = h.x(cursor, "output");
      try {
        int i16 = h.x(cursor, "initial_delay");
        int i15 = h.x(cursor, "interval_duration");
        int i19 = h.x(cursor, "flex_duration");
        int i14 = h.x(cursor, "run_attempt_count");
        paramInt = h.x(cursor, "backoff_policy");
        int i11 = h.x(cursor, "backoff_delay_duration");
        int i18 = h.x(cursor, "period_start_time");
        int i12 = h.x(cursor, "minimum_retention_duration");
        int i13 = h.x(cursor, "schedule_requested_at");
        int i10 = h.x(cursor, "run_in_foreground");
        int i17 = h.x(cursor, "out_of_quota_policy");
        ArrayList<t> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            d d = new d();
            d.a = h.N(cursor.getInt(n));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.b = bool;
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.c = bool;
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.d = bool;
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.e = bool;
            d.f = cursor.getLong(i5);
            d.g = cursor.getLong(i6);
            d.h = h.d(cursor.getBlob(i7));
            t t = new t(str1, str2);
            t.b = h.P(cursor.getInt(i8));
            t.d = cursor.getString(i1);
            t.e = g.a(cursor.getBlob(i9));
            t.f = g.a(cursor.getBlob(i3));
            t.g = cursor.getLong(i16);
            t.h = cursor.getLong(i15);
            t.i = cursor.getLong(i19);
            t.k = cursor.getInt(i14);
            t.l = h.M(cursor.getInt(paramInt));
            t.m = cursor.getLong(i11);
            t.n = cursor.getLong(i18);
            t.o = cursor.getLong(i12);
            t.p = cursor.getLong(i13);
            if (cursor.getInt(i10) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            t.q = bool;
            t.r = h.O(cursor.getInt(i17));
            t.j = d;
            arrayList.add(t);
            continue;
          } 
          cursor.close();
          q.h();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    q.h();
    throw exception;
  }
  
  public List<t> c(int paramInt) {
    Exception exception;
    q q = q.d("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at=-1 ORDER BY period_start_time LIMIT (SELECT MAX(?-COUNT(*), 0) FROM workspec WHERE schedule_requested_at<>-1 AND state NOT IN (2, 3, 5))", 1);
    q.e(1, paramInt);
    this.a.b();
    Cursor cursor = a.a(this.a, (e)q, false, null);
    try {
      int n = h.x(cursor, "required_network_type");
      int i2 = h.x(cursor, "requires_charging");
      int j = h.x(cursor, "requires_device_idle");
      int i = h.x(cursor, "requires_battery_not_low");
      int i4 = h.x(cursor, "requires_storage_not_low");
      int i5 = h.x(cursor, "trigger_content_update_delay");
      int i6 = h.x(cursor, "trigger_max_content_delay");
      int i7 = h.x(cursor, "content_uri_triggers");
      int m = h.x(cursor, "id");
      int i8 = h.x(cursor, "state");
      int k = h.x(cursor, "worker_class_name");
      int i1 = h.x(cursor, "input_merger_class_name");
      int i9 = h.x(cursor, "input");
      int i3 = h.x(cursor, "output");
      try {
        int i16 = h.x(cursor, "initial_delay");
        int i15 = h.x(cursor, "interval_duration");
        int i19 = h.x(cursor, "flex_duration");
        int i14 = h.x(cursor, "run_attempt_count");
        paramInt = h.x(cursor, "backoff_policy");
        int i11 = h.x(cursor, "backoff_delay_duration");
        int i18 = h.x(cursor, "period_start_time");
        int i12 = h.x(cursor, "minimum_retention_duration");
        int i13 = h.x(cursor, "schedule_requested_at");
        int i10 = h.x(cursor, "run_in_foreground");
        int i17 = h.x(cursor, "out_of_quota_policy");
        ArrayList<t> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            d d = new d();
            d.a = h.N(cursor.getInt(n));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.b = bool;
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.c = bool;
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.d = bool;
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.e = bool;
            d.f = cursor.getLong(i5);
            d.g = cursor.getLong(i6);
            d.h = h.d(cursor.getBlob(i7));
            t t = new t(str1, str2);
            t.b = h.P(cursor.getInt(i8));
            t.d = cursor.getString(i1);
            t.e = g.a(cursor.getBlob(i9));
            t.f = g.a(cursor.getBlob(i3));
            t.g = cursor.getLong(i16);
            t.h = cursor.getLong(i15);
            t.i = cursor.getLong(i19);
            t.k = cursor.getInt(i14);
            t.l = h.M(cursor.getInt(paramInt));
            t.m = cursor.getLong(i11);
            t.n = cursor.getLong(i18);
            t.o = cursor.getLong(i12);
            t.p = cursor.getLong(i13);
            if (cursor.getInt(i10) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            t.q = bool;
            t.r = h.O(cursor.getInt(i17));
            t.j = d;
            arrayList.add(t);
            continue;
          } 
          cursor.close();
          q.h();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    q.h();
    throw exception;
  }
  
  public List<t> d() {
    Exception exception;
    q q = q.d("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=1", 0);
    this.a.b();
    Cursor cursor = a.a(this.a, (e)q, false, null);
    try {
      int n = h.x(cursor, "required_network_type");
      int i2 = h.x(cursor, "requires_charging");
      int j = h.x(cursor, "requires_device_idle");
      int i = h.x(cursor, "requires_battery_not_low");
      int i4 = h.x(cursor, "requires_storage_not_low");
      int i5 = h.x(cursor, "trigger_content_update_delay");
      int i6 = h.x(cursor, "trigger_max_content_delay");
      int i7 = h.x(cursor, "content_uri_triggers");
      int m = h.x(cursor, "id");
      int i8 = h.x(cursor, "state");
      int k = h.x(cursor, "worker_class_name");
      int i9 = h.x(cursor, "input_merger_class_name");
      int i1 = h.x(cursor, "input");
      int i3 = h.x(cursor, "output");
      try {
        int i17 = h.x(cursor, "initial_delay");
        int i16 = h.x(cursor, "interval_duration");
        int i20 = h.x(cursor, "flex_duration");
        int i15 = h.x(cursor, "run_attempt_count");
        int i10 = h.x(cursor, "backoff_policy");
        int i12 = h.x(cursor, "backoff_delay_duration");
        int i19 = h.x(cursor, "period_start_time");
        int i13 = h.x(cursor, "minimum_retention_duration");
        int i14 = h.x(cursor, "schedule_requested_at");
        int i11 = h.x(cursor, "run_in_foreground");
        int i18 = h.x(cursor, "out_of_quota_policy");
        ArrayList<t> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            d d = new d();
            d.a = h.N(cursor.getInt(n));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.b = bool;
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.c = bool;
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.d = bool;
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.e = bool;
            d.f = cursor.getLong(i5);
            d.g = cursor.getLong(i6);
            d.h = h.d(cursor.getBlob(i7));
            t t = new t(str1, str2);
            t.b = h.P(cursor.getInt(i8));
            t.d = cursor.getString(i9);
            t.e = g.a(cursor.getBlob(i1));
            t.f = g.a(cursor.getBlob(i3));
            t.g = cursor.getLong(i17);
            t.h = cursor.getLong(i16);
            t.i = cursor.getLong(i20);
            t.k = cursor.getInt(i15);
            t.l = h.M(cursor.getInt(i10));
            t.m = cursor.getLong(i12);
            t.n = cursor.getLong(i19);
            t.o = cursor.getLong(i13);
            t.p = cursor.getLong(i14);
            if (cursor.getInt(i11) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            t.q = bool;
            t.r = h.O(cursor.getInt(i18));
            t.j = d;
            arrayList.add(t);
            continue;
          } 
          cursor.close();
          q.h();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    q.h();
    throw exception;
  }
  
  public List<t> e() {
    Exception exception;
    q q = q.d("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE state=0 AND schedule_requested_at<>-1", 0);
    this.a.b();
    Cursor cursor = a.a(this.a, (e)q, false, null);
    try {
      int n = h.x(cursor, "required_network_type");
      int i2 = h.x(cursor, "requires_charging");
      int j = h.x(cursor, "requires_device_idle");
      int i = h.x(cursor, "requires_battery_not_low");
      int i4 = h.x(cursor, "requires_storage_not_low");
      int i5 = h.x(cursor, "trigger_content_update_delay");
      int i6 = h.x(cursor, "trigger_max_content_delay");
      int i7 = h.x(cursor, "content_uri_triggers");
      int m = h.x(cursor, "id");
      int i8 = h.x(cursor, "state");
      int k = h.x(cursor, "worker_class_name");
      int i9 = h.x(cursor, "input_merger_class_name");
      int i1 = h.x(cursor, "input");
      int i3 = h.x(cursor, "output");
      try {
        int i17 = h.x(cursor, "initial_delay");
        int i16 = h.x(cursor, "interval_duration");
        int i20 = h.x(cursor, "flex_duration");
        int i15 = h.x(cursor, "run_attempt_count");
        int i10 = h.x(cursor, "backoff_policy");
        int i12 = h.x(cursor, "backoff_delay_duration");
        int i19 = h.x(cursor, "period_start_time");
        int i13 = h.x(cursor, "minimum_retention_duration");
        int i14 = h.x(cursor, "schedule_requested_at");
        int i11 = h.x(cursor, "run_in_foreground");
        int i18 = h.x(cursor, "out_of_quota_policy");
        ArrayList<t> arrayList = new ArrayList(cursor.getCount());
        while (true) {
          if (cursor.moveToNext()) {
            boolean bool;
            String str1 = cursor.getString(m);
            String str2 = cursor.getString(k);
            d d = new d();
            d.a = h.N(cursor.getInt(n));
            if (cursor.getInt(i2) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.b = bool;
            if (cursor.getInt(j) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.c = bool;
            if (cursor.getInt(i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.d = bool;
            if (cursor.getInt(i4) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            d.e = bool;
            d.f = cursor.getLong(i5);
            d.g = cursor.getLong(i6);
            d.h = h.d(cursor.getBlob(i7));
            t t = new t(str1, str2);
            t.b = h.P(cursor.getInt(i8));
            t.d = cursor.getString(i9);
            t.e = g.a(cursor.getBlob(i1));
            t.f = g.a(cursor.getBlob(i3));
            t.g = cursor.getLong(i17);
            t.h = cursor.getLong(i16);
            t.i = cursor.getLong(i20);
            t.k = cursor.getInt(i15);
            t.l = h.M(cursor.getInt(i10));
            t.m = cursor.getLong(i12);
            t.n = cursor.getLong(i19);
            t.o = cursor.getLong(i13);
            t.p = cursor.getLong(i14);
            if (cursor.getInt(i11) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            t.q = bool;
            t.r = h.O(cursor.getInt(i18));
            t.j = d;
            arrayList.add(t);
            continue;
          } 
          cursor.close();
          q.h();
          return arrayList;
        } 
      } finally {}
    } finally {}
    cursor.close();
    q.h();
    throw exception;
  }
  
  public a0 f(String paramString) {
    q q = q.d("SELECT state FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      q.f(1);
    } else {
      q.g(1, paramString);
    } 
    this.a.b();
    l l1 = this.a;
    paramString = null;
    Cursor cursor = a.a(l1, (e)q, false, null);
    try {
      a0 a0;
      if (cursor.moveToFirst())
        a0 = h.P(cursor.getInt(0)); 
      return a0;
    } finally {
      cursor.close();
      q.h();
    } 
  }
  
  public List<String> g(String paramString) {
    q q = q.d("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      q.f(1);
    } else {
      q.g(1, paramString);
    } 
    this.a.b();
    Cursor cursor = a.a(this.a, (e)q, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      q.h();
    } 
  }
  
  public List<String> h(String paramString) {
    q q = q.d("SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM worktag WHERE tag=?)", 1);
    if (paramString == null) {
      q.f(1);
    } else {
      q.g(1, paramString);
    } 
    this.a.b();
    Cursor cursor = a.a(this.a, (e)q, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      q.h();
    } 
  }
  
  public t i(String paramString) {
    q q = q.d("SELECT `required_network_type`, `requires_charging`, `requires_device_idle`, `requires_battery_not_low`, `requires_storage_not_low`, `trigger_content_update_delay`, `trigger_max_content_delay`, `content_uri_triggers`, `WorkSpec`.`id` AS `id`, `WorkSpec`.`state` AS `state`, `WorkSpec`.`worker_class_name` AS `worker_class_name`, `WorkSpec`.`input_merger_class_name` AS `input_merger_class_name`, `WorkSpec`.`input` AS `input`, `WorkSpec`.`output` AS `output`, `WorkSpec`.`initial_delay` AS `initial_delay`, `WorkSpec`.`interval_duration` AS `interval_duration`, `WorkSpec`.`flex_duration` AS `flex_duration`, `WorkSpec`.`run_attempt_count` AS `run_attempt_count`, `WorkSpec`.`backoff_policy` AS `backoff_policy`, `WorkSpec`.`backoff_delay_duration` AS `backoff_delay_duration`, `WorkSpec`.`period_start_time` AS `period_start_time`, `WorkSpec`.`minimum_retention_duration` AS `minimum_retention_duration`, `WorkSpec`.`schedule_requested_at` AS `schedule_requested_at`, `WorkSpec`.`run_in_foreground` AS `run_in_foreground`, `WorkSpec`.`out_of_quota_policy` AS `out_of_quota_policy` FROM workspec WHERE id=?", 1);
    if (paramString == null) {
      q.f(1);
    } else {
      q.g(1, paramString);
    } 
    this.a.b();
    Cursor cursor = a.a(this.a, (e)q, false, null);
    try {
      int i = h.x(cursor, "required_network_type");
      int j = h.x(cursor, "requires_charging");
      int k = h.x(cursor, "requires_device_idle");
      int m = h.x(cursor, "requires_battery_not_low");
      int n = h.x(cursor, "requires_storage_not_low");
      int i1 = h.x(cursor, "trigger_content_update_delay");
      int i2 = h.x(cursor, "trigger_max_content_delay");
      int i3 = h.x(cursor, "content_uri_triggers");
      int i4 = h.x(cursor, "id");
      int i5 = h.x(cursor, "state");
      int i6 = h.x(cursor, "worker_class_name");
      int i7 = h.x(cursor, "input_merger_class_name");
      int i8 = h.x(cursor, "input");
      int i9 = h.x(cursor, "output");
      try {
        int i10 = h.x(cursor, "initial_delay");
        int i11 = h.x(cursor, "interval_duration");
        int i12 = h.x(cursor, "flex_duration");
        int i13 = h.x(cursor, "run_attempt_count");
        int i14 = h.x(cursor, "backoff_policy");
        int i15 = h.x(cursor, "backoff_delay_duration");
        int i16 = h.x(cursor, "period_start_time");
        int i17 = h.x(cursor, "minimum_retention_duration");
        int i18 = h.x(cursor, "schedule_requested_at");
        int i19 = h.x(cursor, "run_in_foreground");
        int i20 = h.x(cursor, "out_of_quota_policy");
        if (cursor.moveToFirst()) {
          boolean bool;
          paramString = cursor.getString(i4);
          String str = cursor.getString(i6);
          d d = new d();
          d.a = h.N(cursor.getInt(i));
          if (cursor.getInt(j) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          d.b = bool;
          if (cursor.getInt(k) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          d.c = bool;
          if (cursor.getInt(m) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          d.d = bool;
          if (cursor.getInt(n) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          d.e = bool;
          d.f = cursor.getLong(i1);
          d.g = cursor.getLong(i2);
          d.h = h.d(cursor.getBlob(i3));
          t t = new t(paramString, str);
          t.b = h.P(cursor.getInt(i5));
          t.d = cursor.getString(i7);
          t.e = g.a(cursor.getBlob(i8));
          t.f = g.a(cursor.getBlob(i9));
          t.g = cursor.getLong(i10);
          t.h = cursor.getLong(i11);
          t.i = cursor.getLong(i12);
          t.k = cursor.getInt(i13);
          t.l = h.M(cursor.getInt(i14));
          t.m = cursor.getLong(i15);
          t.n = cursor.getLong(i16);
          t.o = cursor.getLong(i17);
          t.p = cursor.getLong(i18);
          if (cursor.getInt(i19) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          t.q = bool;
          t.r = h.O(cursor.getInt(i20));
          t.j = d;
        } else {
          paramString = null;
        } 
        cursor.close();
        q.h();
        return (t)paramString;
      } finally {}
    } finally {}
    cursor.close();
    q.h();
    throw paramString;
  }
  
  public List<s> j(String paramString) {
    q q = q.d("SELECT id, state FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)", 1);
    if (paramString == null) {
      q.f(1);
    } else {
      q.g(1, paramString);
    } 
    this.a.b();
    Cursor cursor = a.a(this.a, (e)q, false, null);
    try {
      int i = h.x(cursor, "id");
      int j = h.x(cursor, "state");
      ArrayList<s> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext()) {
        s s1 = new s();
        s1.a = cursor.getString(i);
        s1.b = h.P(cursor.getInt(j));
        arrayList.add(s1);
      } 
      return arrayList;
    } finally {
      cursor.close();
      q.h();
    } 
  }
  
  public int k(String paramString) {
    this.a.b();
    i i = this.f.a();
    if (paramString == null) {
      ((h)i).e.bindNull(1);
    } else {
      ((h)i).e.bindString(1, paramString);
    } 
    this.a.c();
    try {
      int j = i.a();
      this.a.k();
      this.a.g();
      return j;
    } finally {
      this.a.g();
      this.f.c(i);
    } 
  }
  
  public int l(String paramString, long paramLong) {
    this.a.b();
    i i = this.h.a();
    ((h)i).e.bindLong(1, paramLong);
    if (paramString == null) {
      ((h)i).e.bindNull(2);
    } else {
      ((h)i).e.bindString(2, paramString);
    } 
    this.a.c();
    try {
      int j = i.a();
      this.a.k();
      return j;
    } finally {
      this.a.g();
      s s1 = this.h;
      if (i == s1.c)
        s1.a.set(false); 
    } 
  }
  
  public int m(String paramString) {
    this.a.b();
    i i = this.g.a();
    if (paramString == null) {
      ((h)i).e.bindNull(1);
    } else {
      ((h)i).e.bindString(1, paramString);
    } 
    this.a.c();
    try {
      int j = i.a();
      this.a.k();
      this.a.g();
      return j;
    } finally {
      this.a.g();
      this.g.c(i);
    } 
  }
  
  public void n(String paramString, g paramg) {
    this.a.b();
    i i = this.d.a();
    byte[] arrayOfByte = g.c(paramg);
    if (arrayOfByte == null) {
      ((h)i).e.bindNull(1);
    } else {
      ((h)i).e.bindBlob(1, arrayOfByte);
    } 
    if (paramString == null) {
      ((h)i).e.bindNull(2);
    } else {
      ((h)i).e.bindString(2, paramString);
    } 
    this.a.c();
    try {
      i.a();
      this.a.k();
      this.a.g();
      return;
    } finally {
      this.a.g();
      this.d.c(i);
    } 
  }
  
  public void o(String paramString, long paramLong) {
    this.a.b();
    i i = this.e.a();
    ((h)i).e.bindLong(1, paramLong);
    if (paramString == null) {
      ((h)i).e.bindNull(2);
    } else {
      ((h)i).e.bindString(2, paramString);
    } 
    this.a.c();
    try {
      i.a();
      this.a.k();
      return;
    } finally {
      this.a.g();
      s s1 = this.e;
      if (i == s1.c)
        s1.a.set(false); 
    } 
  }
  
  public int p(a0 parama0, String... paramVarArgs) {
    this.a.b();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("UPDATE workspec SET state=");
    stringBuilder.append("?");
    stringBuilder.append(" WHERE id IN (");
    int j = paramVarArgs.length;
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      stringBuilder.append("?");
      if (i < j - 1)
        stringBuilder.append(","); 
    } 
    stringBuilder.append(")");
    String str = stringBuilder.toString();
    i i1 = this.a.d(str);
    long l1 = h.l0(parama0);
    ((h)i1).e.bindLong(1, l1);
    j = 2;
    int k = paramVarArgs.length;
    for (i = bool; i < k; i++) {
      String str1 = paramVarArgs[i];
      if (str1 == null) {
        ((h)i1).e.bindNull(j);
      } else {
        ((h)i1).e.bindString(j, str1);
      } 
      j++;
    } 
    this.a.c();
    try {
      i = i1.a();
      this.a.k();
      return i;
    } finally {
      this.a.g();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */