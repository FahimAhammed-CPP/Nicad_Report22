package c.b0.f0.b0;

import c.u.l;
import c.u.s;

public class a0 extends s {
  public a0(c0 paramc0, l paraml) {
    super(paraml);
  }
  
  public String b() {
    return "UPDATE workspec SET schedule_requested_at=? WHERE id=?";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */