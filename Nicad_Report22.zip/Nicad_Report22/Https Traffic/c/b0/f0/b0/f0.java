package c.b0.f0.b0;

import android.database.Cursor;
import c.u.b;
import c.u.l;
import c.u.q;
import c.u.u.a;
import c.w.a.e;
import java.util.ArrayList;
import java.util.List;

public final class f0 {
  public final l a;
  
  public final b<d0> b;
  
  public f0(l paraml) {
    this.a = paraml;
    this.b = new e0(this, paraml);
  }
  
  public List<String> a(String paramString) {
    q q = q.d("SELECT DISTINCT tag FROM worktag WHERE work_spec_id=?", 1);
    if (paramString == null) {
      q.f(1);
    } else {
      q.g(1, paramString);
    } 
    this.a.b();
    Cursor cursor = a.a(this.a, (e)q, false, null);
    try {
      ArrayList<String> arrayList = new ArrayList(cursor.getCount());
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      return arrayList;
    } finally {
      cursor.close();
      q.h();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */