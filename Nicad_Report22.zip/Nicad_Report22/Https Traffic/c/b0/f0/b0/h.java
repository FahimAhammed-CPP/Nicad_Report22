package c.b0.f0.b0;

import c.u.b;
import c.u.l;
import c.w.a.f.i;

public class h extends b<g> {
  public h(j paramj, l paraml) {
    super(paraml);
  }
  
  public String b() {
    return "INSERT OR REPLACE INTO `SystemIdInfo` (`work_spec_id`,`system_id`) VALUES (?,?)";
  }
  
  public void d(i parami, Object paramObject) {
    paramObject = paramObject;
    String str = ((g)paramObject).a;
    if (str == null) {
      ((c.w.a.f.h)parami).e.bindNull(1);
    } else {
      ((c.w.a.f.h)parami).e.bindString(1, str);
    } 
    long l = ((g)paramObject).b;
    ((c.w.a.f.h)parami).e.bindLong(2, l);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */