package c.b0.f0.b0;

import c.u.b;
import c.w.a.f.h;
import c.w.a.f.i;

public class l extends b<k> {
  public l(m paramm, c.u.l paraml) {
    super(paraml);
  }
  
  public String b() {
    return "INSERT OR IGNORE INTO `WorkName` (`name`,`work_spec_id`) VALUES (?,?)";
  }
  
  public void d(i parami, Object paramObject) {
    paramObject = paramObject;
    String str = ((k)paramObject).a;
    if (str == null) {
      ((h)parami).e.bindNull(1);
    } else {
      ((h)parami).e.bindString(1, str);
    } 
    paramObject = ((k)paramObject).b;
    if (paramObject == null) {
      ((h)parami).e.bindNull(2);
      return;
    } 
    ((h)parami).e.bindString(2, (String)paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */