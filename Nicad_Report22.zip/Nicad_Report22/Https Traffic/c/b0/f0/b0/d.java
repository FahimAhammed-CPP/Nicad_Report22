package c.b0.f0.b0;

public class d {
  public String a;
  
  public Long b;
  
  public d(String paramString, long paramLong) {
    this.a = paramString;
    this.b = Long.valueOf(paramLong);
  }
  
  public d(String paramString, boolean paramBoolean) {
    long l;
    this.a = paramString;
    this.b = Long.valueOf(l);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof d))
      return false; 
    d d1 = (d)paramObject;
    if (!this.a.equals(d1.a))
      return false; 
    paramObject = this.b;
    Long long_ = d1.b;
    return (paramObject != null) ? paramObject.equals(long_) : ((long_ == null));
  }
  
  public int hashCode() {
    byte b;
    int i = this.a.hashCode();
    Long long_ = this.b;
    if (long_ != null) {
      b = long_.hashCode();
    } else {
      b = 0;
    } 
    return i * 31 + b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */