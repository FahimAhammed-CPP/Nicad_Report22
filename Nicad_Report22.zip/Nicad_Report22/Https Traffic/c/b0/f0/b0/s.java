package c.b0.f0.b0;

import c.b0.a0;

public class s {
  public String a;
  
  public a0 b;
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof s))
      return false; 
    paramObject = paramObject;
    return (this.b != ((s)paramObject).b) ? false : this.a.equals(((s)paramObject).a);
  }
  
  public int hashCode() {
    int i = this.a.hashCode();
    return this.b.hashCode() + i * 31;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */