package c.b0.f0.b0;

import c.u.b;
import c.u.l;
import c.w.a.f.h;
import c.w.a.f.i;

public class b extends b<a> {
  public b(c paramc, l paraml) {
    super(paraml);
  }
  
  public String b() {
    return "INSERT OR IGNORE INTO `Dependency` (`work_spec_id`,`prerequisite_id`) VALUES (?,?)";
  }
  
  public void d(i parami, Object paramObject) {
    paramObject = paramObject;
    String str = ((a)paramObject).a;
    if (str == null) {
      ((h)parami).e.bindNull(1);
    } else {
      ((h)parami).e.bindString(1, str);
    } 
    paramObject = ((a)paramObject).b;
    if (paramObject == null) {
      ((h)parami).e.bindNull(2);
      return;
    } 
    ((h)parami).e.bindString(2, (String)paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */