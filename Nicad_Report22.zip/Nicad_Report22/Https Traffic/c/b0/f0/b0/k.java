package c.b0.f0.b0;

public class k {
  public final String a;
  
  public final String b;
  
  public k(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */