package c.b0.f0.b0;

import c.u.l;
import c.u.s;

public class x extends s {
  public x(c0 paramc0, l paraml) {
    super(paraml);
  }
  
  public String b() {
    return "UPDATE workspec SET period_start_time=? WHERE id=?";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\b0\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */