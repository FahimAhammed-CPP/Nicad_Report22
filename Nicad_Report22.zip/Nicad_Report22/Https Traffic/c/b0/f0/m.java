package c.b0.f0;

import c.u.t.a;
import c.w.a.b;
import c.w.a.f.c;

public class m extends a {
  public m(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public void a(b paramb) {
    ((c)paramb).e.execSQL("ALTER TABLE workspec ADD COLUMN `trigger_content_update_delay` INTEGER NOT NULL DEFAULT -1");
    ((c)paramb).e.execSQL("ALTER TABLE workspec ADD COLUMN `trigger_max_content_delay` INTEGER NOT NULL DEFAULT -1");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */