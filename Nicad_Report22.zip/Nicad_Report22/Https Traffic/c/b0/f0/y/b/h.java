package c.b0.f0.y.b;

public class h implements Runnable {
  public final g e;
  
  public h(g paramg) {
    this.e = paramg;
  }
  
  public void run() {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Lc/b0/f0/y/b/g;
    //   4: astore #4
    //   6: aload #4
    //   8: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: invokestatic c : ()Lc/b0/o;
    //   15: astore_3
    //   16: getstatic c/b0/f0/y/b/g.o : Ljava/lang/String;
    //   19: astore #5
    //   21: aload_3
    //   22: aload #5
    //   24: ldc 'Checking if commands are complete.'
    //   26: iconst_0
    //   27: anewarray java/lang/Throwable
    //   30: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   33: aload #4
    //   35: invokevirtual c : ()V
    //   38: aload #4
    //   40: getfield l : Ljava/util/List;
    //   43: astore_3
    //   44: aload_3
    //   45: monitorenter
    //   46: aload #4
    //   48: getfield m : Landroid/content/Intent;
    //   51: astore #6
    //   53: iconst_1
    //   54: istore_2
    //   55: aload #6
    //   57: ifnull -> 133
    //   60: invokestatic c : ()Lc/b0/o;
    //   63: aload #5
    //   65: ldc 'Removing command %s'
    //   67: iconst_1
    //   68: anewarray java/lang/Object
    //   71: dup
    //   72: iconst_0
    //   73: aload #4
    //   75: getfield m : Landroid/content/Intent;
    //   78: aastore
    //   79: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   82: iconst_0
    //   83: anewarray java/lang/Throwable
    //   86: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   89: aload #4
    //   91: getfield l : Ljava/util/List;
    //   94: iconst_0
    //   95: invokeinterface remove : (I)Ljava/lang/Object;
    //   100: checkcast android/content/Intent
    //   103: aload #4
    //   105: getfield m : Landroid/content/Intent;
    //   108: invokevirtual equals : (Ljava/lang/Object;)Z
    //   111: ifeq -> 123
    //   114: aload #4
    //   116: aconst_null
    //   117: putfield m : Landroid/content/Intent;
    //   120: goto -> 133
    //   123: new java/lang/IllegalStateException
    //   126: dup
    //   127: ldc 'Dequeue-d command is not the first.'
    //   129: invokespecial <init> : (Ljava/lang/String;)V
    //   132: athrow
    //   133: aload #4
    //   135: getfield f : Lc/b0/f0/c0/a0/a;
    //   138: checkcast c/b0/f0/c0/a0/c
    //   141: getfield a : Lc/b0/f0/c0/k;
    //   144: astore #6
    //   146: aload #4
    //   148: getfield j : Lc/b0/f0/y/b/b;
    //   151: astore #8
    //   153: aload #8
    //   155: getfield g : Ljava/lang/Object;
    //   158: astore #7
    //   160: aload #7
    //   162: monitorenter
    //   163: aload #8
    //   165: getfield f : Ljava/util/Map;
    //   168: invokeinterface isEmpty : ()Z
    //   173: ifne -> 315
    //   176: iconst_1
    //   177: istore_1
    //   178: goto -> 181
    //   181: aload #7
    //   183: monitorexit
    //   184: iload_1
    //   185: ifne -> 279
    //   188: aload #4
    //   190: getfield l : Ljava/util/List;
    //   193: invokeinterface isEmpty : ()Z
    //   198: ifeq -> 279
    //   201: aload #6
    //   203: getfield g : Ljava/lang/Object;
    //   206: astore #7
    //   208: aload #7
    //   210: monitorenter
    //   211: aload #6
    //   213: getfield e : Ljava/util/ArrayDeque;
    //   216: invokevirtual isEmpty : ()Z
    //   219: ifne -> 320
    //   222: iload_2
    //   223: istore_1
    //   224: goto -> 227
    //   227: aload #7
    //   229: monitorexit
    //   230: iload_1
    //   231: ifne -> 279
    //   234: invokestatic c : ()Lc/b0/o;
    //   237: aload #5
    //   239: ldc 'No more commands & intents.'
    //   241: iconst_0
    //   242: anewarray java/lang/Throwable
    //   245: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   248: aload #4
    //   250: getfield n : Lc/b0/f0/y/b/g$a;
    //   253: astore #4
    //   255: aload #4
    //   257: ifnull -> 297
    //   260: aload #4
    //   262: checkcast androidx/work/impl/background/systemalarm/SystemAlarmService
    //   265: invokevirtual d : ()V
    //   268: goto -> 297
    //   271: astore #4
    //   273: aload #7
    //   275: monitorexit
    //   276: aload #4
    //   278: athrow
    //   279: aload #4
    //   281: getfield l : Ljava/util/List;
    //   284: invokeinterface isEmpty : ()Z
    //   289: ifne -> 297
    //   292: aload #4
    //   294: invokevirtual e : ()V
    //   297: aload_3
    //   298: monitorexit
    //   299: return
    //   300: astore #4
    //   302: aload #7
    //   304: monitorexit
    //   305: aload #4
    //   307: athrow
    //   308: astore #4
    //   310: aload_3
    //   311: monitorexit
    //   312: aload #4
    //   314: athrow
    //   315: iconst_0
    //   316: istore_1
    //   317: goto -> 181
    //   320: iconst_0
    //   321: istore_1
    //   322: goto -> 227
    // Exception table:
    //   from	to	target	type
    //   46	53	308	finally
    //   60	120	308	finally
    //   123	133	308	finally
    //   133	163	308	finally
    //   163	176	300	finally
    //   181	184	300	finally
    //   188	211	308	finally
    //   211	222	271	finally
    //   227	230	271	finally
    //   234	255	308	finally
    //   260	268	308	finally
    //   273	276	271	finally
    //   276	279	308	finally
    //   279	297	308	finally
    //   297	299	308	finally
    //   302	305	300	finally
    //   305	308	308	finally
    //   310	312	308	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\b\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */