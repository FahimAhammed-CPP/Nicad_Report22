package c.b0.f0.y.b;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import c.b0.f0.t;
import c.b0.o;

public abstract class a {
  public static final String a = o.e("Alarms");
  
  public static void a(Context paramContext, String paramString, int paramInt) {
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    PendingIntent pendingIntent = PendingIntent.getService(paramContext, paramInt, b.c(paramContext, paramString), 603979776);
    if (pendingIntent != null && alarmManager != null) {
      o.c().a(a, String.format("Cancelling existing alarm with (workSpecId, systemId) (%s, %s)", new Object[] { paramString, Integer.valueOf(paramInt) }), new Throwable[0]);
      alarmManager.cancel(pendingIntent);
    } 
  }
  
  public static void b(Context paramContext, t paramt, String paramString, long paramLong) {
    // Byte code:
    //   0: aload_1
    //   1: getfield c : Landroidx/work/impl/WorkDatabase;
    //   4: astore_1
    //   5: aload_1
    //   6: invokevirtual n : ()Lc/b0/f0/b0/j;
    //   9: astore #7
    //   11: aload #7
    //   13: aload_2
    //   14: invokevirtual a : (Ljava/lang/String;)Lc/b0/f0/b0/g;
    //   17: astore #8
    //   19: aload #8
    //   21: ifnull -> 46
    //   24: aload_0
    //   25: aload_2
    //   26: aload #8
    //   28: getfield b : I
    //   31: invokestatic a : (Landroid/content/Context;Ljava/lang/String;I)V
    //   34: aload_0
    //   35: aload_2
    //   36: aload #8
    //   38: getfield b : I
    //   41: lload_3
    //   42: invokestatic c : (Landroid/content/Context;Ljava/lang/String;IJ)V
    //   45: return
    //   46: ldc c/b0/f0/c0/f
    //   48: monitorenter
    //   49: aload_1
    //   50: invokevirtual c : ()V
    //   53: aload_1
    //   54: invokevirtual m : ()Lc/b0/f0/b0/f;
    //   57: ldc 'next_alarm_manager_id'
    //   59: invokevirtual a : (Ljava/lang/String;)Ljava/lang/Long;
    //   62: astore #8
    //   64: iconst_0
    //   65: istore #6
    //   67: aload #8
    //   69: ifnull -> 149
    //   72: aload #8
    //   74: invokevirtual intValue : ()I
    //   77: istore #5
    //   79: goto -> 152
    //   82: aload_1
    //   83: invokevirtual m : ()Lc/b0/f0/b0/f;
    //   86: new c/b0/f0/b0/d
    //   89: dup
    //   90: ldc 'next_alarm_manager_id'
    //   92: iload #6
    //   94: i2l
    //   95: invokespecial <init> : (Ljava/lang/String;J)V
    //   98: invokevirtual b : (Lc/b0/f0/b0/d;)V
    //   101: aload_1
    //   102: invokevirtual k : ()V
    //   105: aload_1
    //   106: invokevirtual g : ()V
    //   109: ldc c/b0/f0/c0/f
    //   111: monitorexit
    //   112: aload #7
    //   114: new c/b0/f0/b0/g
    //   117: dup
    //   118: aload_2
    //   119: iload #5
    //   121: invokespecial <init> : (Ljava/lang/String;I)V
    //   124: invokevirtual b : (Lc/b0/f0/b0/g;)V
    //   127: aload_0
    //   128: aload_2
    //   129: iload #5
    //   131: lload_3
    //   132: invokestatic c : (Landroid/content/Context;Ljava/lang/String;IJ)V
    //   135: return
    //   136: astore_0
    //   137: aload_1
    //   138: invokevirtual g : ()V
    //   141: aload_0
    //   142: athrow
    //   143: astore_0
    //   144: ldc c/b0/f0/c0/f
    //   146: monitorexit
    //   147: aload_0
    //   148: athrow
    //   149: iconst_0
    //   150: istore #5
    //   152: iload #5
    //   154: ldc 2147483647
    //   156: if_icmpne -> 162
    //   159: goto -> 82
    //   162: iload #5
    //   164: iconst_1
    //   165: iadd
    //   166: istore #6
    //   168: goto -> 82
    // Exception table:
    //   from	to	target	type
    //   49	53	143	finally
    //   53	64	136	finally
    //   72	79	136	finally
    //   82	105	136	finally
    //   105	112	143	finally
    //   137	143	143	finally
    //   144	147	143	finally
  }
  
  public static void c(Context paramContext, String paramString, int paramInt, long paramLong) {
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    PendingIntent pendingIntent = PendingIntent.getService(paramContext, paramInt, b.c(paramContext, paramString), 201326592);
    if (alarmManager != null)
      alarmManager.setExact(0, paramLong, pendingIntent); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */