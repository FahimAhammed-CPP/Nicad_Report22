package c.b0.f0.y.b;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import androidx.work.impl.background.systemalarm.SystemAlarmService;
import c.b0.f0.b;
import c.b0.f0.b0.t;
import c.b0.f0.c0.n;
import c.b0.f0.c0.w;
import c.b0.f0.z.b;
import c.b0.f0.z.c;
import c.b0.o;
import java.util.Collections;
import java.util.List;

public class d implements b, b, w {
  public static final String n = o.e("DelayMetCommandHandler");
  
  public final Context e;
  
  public final int f;
  
  public final String g;
  
  public final g h;
  
  public final c i;
  
  public final Object j;
  
  public int k;
  
  public PowerManager.WakeLock l;
  
  public boolean m;
  
  public d(Context paramContext, int paramInt, String paramString, g paramg) {
    this.e = paramContext;
    this.f = paramInt;
    this.h = paramg;
    this.g = paramString;
    this.i = new c(paramContext, paramg.f, this);
    this.m = false;
    this.k = 0;
    this.j = new Object();
  }
  
  public void a(String paramString, boolean paramBoolean) {
    o.c().a(n, String.format("onExecuted %s, %s", new Object[] { paramString, Boolean.valueOf(paramBoolean) }), new Throwable[0]);
    b();
    if (paramBoolean) {
      Intent intent = b.d(this.e, this.g);
      g g1 = this.h;
      f f = new f(g1, intent, this.f);
      g1.k.post(f);
    } 
    if (this.m) {
      Intent intent = b.b(this.e);
      g g1 = this.h;
      f f = new f(g1, intent, this.f);
      g1.k.post(f);
    } 
  }
  
  public final void b() {
    synchronized (this.j) {
      this.i.c();
      this.h.g.b(this.g);
      PowerManager.WakeLock wakeLock = this.l;
      if (wakeLock != null && wakeLock.isHeld()) {
        o.c().a(n, String.format("Releasing wakelock %s for WorkSpec %s", new Object[] { this.l, this.g }), new Throwable[0]);
        this.l.release();
      } 
      return;
    } 
  }
  
  public void c() {
    this.l = n.a(this.e, String.format("%s (%s)", new Object[] { this.g, Integer.valueOf(this.f) }));
    o o = o.c();
    String str = n;
    o.a(str, String.format("Acquiring wakelock %s for WorkSpec %s", new Object[] { this.l, this.g }), new Throwable[0]);
    this.l.acquire();
    t t = this.h.i.c.q().i(this.g);
    if (t == null) {
      f();
      return;
    } 
    boolean bool = t.b();
    this.m = bool;
    if (!bool) {
      o.c().a(str, String.format("No constraints for %s", new Object[] { this.g }), new Throwable[0]);
      e(Collections.singletonList(this.g));
      return;
    } 
    this.i.b(Collections.singletonList(t));
  }
  
  public void d(List<String> paramList) {
    f();
  }
  
  public void e(List<String> paramList) {
    if (!paramList.contains(this.g))
      return; 
    synchronized (this.j) {
      if (this.k == 0) {
        this.k = 1;
        o.c().a(n, String.format("onAllConstraintsMet for %s", new Object[] { this.g }), new Throwable[0]);
        if (this.h.h.g(this.g, null)) {
          this.h.g.a(this.g, 600000L, this);
        } else {
          b();
        } 
      } else {
        o.c().a(n, String.format("Already started work for %s", new Object[] { this.g }), new Throwable[0]);
      } 
      return;
    } 
  }
  
  public final void f() {
    synchronized (this.j) {
      if (this.k < 2) {
        g g1;
        this.k = 2;
        o o = o.c();
        String str1 = n;
        o.a(str1, String.format("Stopping work for WorkSpec %s", new Object[] { this.g }), new Throwable[0]);
        Context context = this.e;
        String str2 = this.g;
        Intent intent = new Intent(context, SystemAlarmService.class);
        intent.setAction("ACTION_STOP_WORK");
        intent.putExtra("KEY_WORKSPEC_ID", str2);
        g g2 = this.h;
        f f = new f(g2, intent, this.f);
        g2.k.post(f);
        if (this.h.h.d(this.g)) {
          o.c().a(str1, String.format("WorkSpec %s needs to be rescheduled", new Object[] { this.g }), new Throwable[0]);
          Intent intent1 = b.d(this.e, this.g);
          g1 = this.h;
          f f1 = new f(g1, intent1, this.f);
          g1.k.post(f1);
        } else {
          o.c().a((String)g1, String.format("Processor does not have WorkSpec %s. No need to reschedule ", new Object[] { this.g }), new Throwable[0]);
        } 
      } else {
        o.c().a(n, String.format("Already stopped work for %s", new Object[] { this.g }), new Throwable[0]);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\b\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */