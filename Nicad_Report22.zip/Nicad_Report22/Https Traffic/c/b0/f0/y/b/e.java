package c.b0.f0.y.b;

import android.content.Intent;
import android.os.PowerManager;
import c.b0.f0.c0.n;
import c.b0.o;
import java.util.List;

public class e implements Runnable {
  public e(g paramg) {}
  
  public void run() {
    List<Intent> list;
    g g1;
    synchronized (this.e.l) {
      g g2 = this.e;
      g2.m = g2.l.get(0);
      Intent intent = this.e.m;
      if (intent != null) {
        h h;
        String str1 = intent.getAction();
        int i = this.e.m.getIntExtra("KEY_START_ID", 0);
        o o = o.c();
        String str2 = g.o;
        o.a(str2, String.format("Processing command %s, %s", new Object[] { this.e.m, Integer.valueOf(i) }), new Throwable[0]);
        PowerManager.WakeLock wakeLock = n.a(this.e.e, String.format("%s (%s)", new Object[] { str1, Integer.valueOf(i) }));
        try {
          o.c().a(str2, String.format("Acquiring operation wake lock (%s) %s", new Object[] { str1, wakeLock }), new Throwable[0]);
          wakeLock.acquire();
          g g3 = this.e;
          g3.j.e(g3.m, i, g3);
          o.c().a(str2, String.format("Releasing operation wake lock (%s) %s", new Object[] { str1, wakeLock }), new Throwable[0]);
          wakeLock.release();
          g1 = this.e;
          h = new h(g1);
          return;
        } finally {
          str2 = null;
        } 
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\b\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */