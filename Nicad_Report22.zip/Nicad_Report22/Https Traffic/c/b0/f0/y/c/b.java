package c.b0.f0.y.c;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.PersistableBundle;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemjob.SystemJobService;
import c.b0.a0;
import c.b0.f0.b0.g;
import c.b0.f0.b0.t;
import c.b0.f0.c0.f;
import c.b0.f0.f;
import c.b0.f0.t;
import c.b0.o;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class b implements f {
  public static final String i = o.e("SystemJobScheduler");
  
  public final Context e;
  
  public final JobScheduler f;
  
  public final t g;
  
  public final a h;
  
  public b(Context paramContext, t paramt) {
    this.e = paramContext;
    this.g = paramt;
    this.f = jobScheduler;
    this.h = a1;
  }
  
  public static void a(JobScheduler paramJobScheduler, int paramInt) {
    try {
      return;
    } finally {
      paramJobScheduler = null;
      o.c().b(i, String.format(Locale.getDefault(), "Exception while trying to cancel job (%d)", new Object[] { Integer.valueOf(paramInt) }), new Throwable[] { (Throwable)paramJobScheduler });
    } 
  }
  
  public static List<Integer> d(Context paramContext, JobScheduler paramJobScheduler, String paramString) {
    List<JobInfo> list = e(paramContext, paramJobScheduler);
    if (list == null)
      return null; 
    ArrayList<Integer> arrayList = new ArrayList(2);
    for (JobInfo jobInfo : list) {
      if (paramString.equals(g(jobInfo)))
        arrayList.add(Integer.valueOf(jobInfo.getId())); 
    } 
    return arrayList;
  }
  
  public static List<JobInfo> e(Context paramContext, JobScheduler paramJobScheduler) {
    ArrayList<JobInfo> arrayList;
    try {
      List list = paramJobScheduler.getAllPendingJobs();
    } finally {
      paramJobScheduler = null;
      o.c().b(i, "getAllPendingJobs() is not reliable on this device.", new Throwable[] { (Throwable)paramJobScheduler });
    } 
    ComponentName componentName = new ComponentName(paramContext, SystemJobService.class);
    for (JobInfo jobInfo : paramJobScheduler) {
      if (componentName.equals(jobInfo.getService()))
        arrayList.add(jobInfo); 
    } 
    return arrayList;
  }
  
  public static String g(JobInfo paramJobInfo) {
    PersistableBundle persistableBundle = paramJobInfo.getExtras();
    if (persistableBundle != null)
      try {
        if (persistableBundle.containsKey("EXTRA_WORK_SPEC_ID"))
          return persistableBundle.getString("EXTRA_WORK_SPEC_ID"); 
      } catch (NullPointerException nullPointerException) {} 
    return null;
  }
  
  public void b(String paramString) {
    List<Integer> list = d(this.e, this.f, paramString);
    if (list != null && !list.isEmpty()) {
      Iterator<Integer> iterator = list.iterator();
      while (iterator.hasNext()) {
        int i = ((Integer)iterator.next()).intValue();
        a(this.f, i);
      } 
      this.g.c.n().c(paramString);
    } 
  }
  
  public void c(t... paramVarArgs) {
    WorkDatabase workDatabase = this.g.c;
    f f1 = new f(workDatabase);
    int j = paramVarArgs.length;
    int i = 0;
    while (i < j) {
      t t1 = paramVarArgs[i];
      workDatabase.c();
      try {
        o o;
        t t2 = workDatabase.q().i(t1.a);
        if (t2 == null) {
          o = o.c();
          String str = i;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Skipping scheduling ");
          stringBuilder.append(t1.a);
          stringBuilder.append(" because it's no longer in the DB");
          o.f(str, stringBuilder.toString(), new Throwable[0]);
          workDatabase.k();
        } else if (((t)o).b != a0.e) {
          o = o.c();
          String str = i;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Skipping scheduling ");
          stringBuilder.append(t1.a);
          stringBuilder.append(" because it is no longer enqueued");
          o.f(str, stringBuilder.toString(), new Throwable[0]);
          workDatabase.k();
        } else {
          int k;
          g g = workDatabase.n().a(t1.a);
          if (g != null) {
            k = g.b;
          } else {
            Objects.requireNonNull(this.g.b);
            k = f1.b(0, this.g.b.g);
          } 
          if (g == null) {
            g = new g(t1.a, k);
            this.g.c.n().b(g);
          } 
          h(t1, k);
          if (Build.VERSION.SDK_INT == 23) {
            List<Integer> list = d(this.e, this.f, t1.a);
            if (list != null) {
              k = list.indexOf(Integer.valueOf(k));
              if (k >= 0)
                list.remove(k); 
              if (!list.isEmpty()) {
                k = ((Integer)list.get(0)).intValue();
              } else {
                Objects.requireNonNull(this.g.b);
                k = f1.b(0, this.g.b.g);
              } 
              h(t1, k);
            } 
          } 
          workDatabase.k();
        } 
        workDatabase.g();
      } finally {
        workDatabase.g();
      } 
    } 
  }
  
  public boolean f() {
    return true;
  }
  
  public void h(t paramt, int paramInt) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\c\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */