package c.b0.f0.y.a;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import c.b0.a0;
import c.b0.d;
import c.b0.f0.b;
import c.b0.f0.b0.t;
import c.b0.f0.c0.a0.a;
import c.b0.f0.c0.i;
import c.b0.f0.c0.l;
import c.b0.f0.f;
import c.b0.f0.t;
import c.b0.f0.z.b;
import c.b0.o;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class c implements f, b, b {
  public static final String m = o.e("GreedyScheduler");
  
  public final Context e;
  
  public final t f;
  
  public final c.b0.f0.z.c g;
  
  public final Set<t> h = new HashSet<t>();
  
  public b i;
  
  public boolean j;
  
  public final Object k;
  
  public Boolean l;
  
  public c(Context paramContext, c.b0.c paramc, a parama, t paramt) {
    this.e = paramContext;
    this.f = paramt;
    this.g = new c.b0.f0.z.c(paramContext, parama, this);
    this.i = new b(this, paramc.e);
    this.k = new Object();
  }
  
  public void a(String paramString, boolean paramBoolean) {
    synchronized (this.k) {
      for (t t1 : this.h) {
        if (t1.a.equals(paramString)) {
          o.c().a(m, String.format("Stopping tracking for %s", new Object[] { paramString }), new Throwable[0]);
          this.h.remove(t1);
          this.g.b(this.h);
          break;
        } 
      } 
      return;
    } 
  }
  
  public void b(String paramString) {
    if (this.l == null) {
      c.b0.c c1 = this.f.b;
      this.l = Boolean.valueOf(i.a(this.e, c1));
    } 
    if (!this.l.booleanValue()) {
      o.c().d(m, "Ignoring schedule request in non-main process", new Throwable[0]);
      return;
    } 
    if (!this.j) {
      this.f.f.b(this);
      this.j = true;
    } 
    o.c().a(m, String.format("Cancelling work ID %s", new Object[] { paramString }), new Throwable[0]);
    b b1 = this.i;
    if (b1 != null) {
      Runnable runnable = b1.c.remove(paramString);
      if (runnable != null)
        b1.b.a.removeCallbacks(runnable); 
    } 
    this.f.f(paramString);
  }
  
  public void c(t... paramVarArgs) {
    if (this.l == null) {
      c.b0.c c1 = this.f.b;
      this.l = Boolean.valueOf(i.a(this.e, c1));
    } 
    if (!this.l.booleanValue()) {
      o.c().d(m, "Ignoring schedule request in a secondary process", new Throwable[0]);
      return;
    } 
    if (!this.j) {
      this.f.f.b(this);
      this.j = true;
    } 
    null = new HashSet();
    HashSet<String> hashSet = new HashSet();
    int j = paramVarArgs.length;
    for (int i = 0; i < j; i++) {
      t t1 = paramVarArgs[i];
      long l1 = t1.a();
      long l2 = System.currentTimeMillis();
      if (t1.b == a0.e)
        if (l2 < l1) {
          b b1 = this.i;
          if (b1 != null) {
            Runnable runnable = b1.c.remove(t1.a);
            if (runnable != null)
              b1.b.a.removeCallbacks(runnable); 
            runnable = new a(b1, t1);
            b1.c.put(t1.a, runnable);
            l1 = System.currentTimeMillis();
            l2 = t1.a();
            b1.b.a.postDelayed(runnable, l2 - l1);
          } 
        } else if (t1.b()) {
          int k = Build.VERSION.SDK_INT;
          d d = t1.j;
          if (d.c) {
            o.c().a(m, String.format("Ignoring WorkSpec %s, Requires device idle.", new Object[] { t1 }), new Throwable[0]);
          } else if (k >= 24 && d.a()) {
            o.c().a(m, String.format("Ignoring WorkSpec %s, Requires ContentUri triggers.", new Object[] { t1 }), new Throwable[0]);
          } else {
            null.add(t1);
            hashSet.add(t1.a);
          } 
        } else {
          o.c().a(m, String.format("Starting work for %s", new Object[] { t1.a }), new Throwable[0]);
          t t2 = this.f;
          String str = t1.a;
          a a = t2.d;
          l l = new l(t2, str, null);
          ((c.b0.f0.c0.a0.c)a).a.execute((Runnable)l);
        }  
    } 
    synchronized (this.k) {
      if (!null.isEmpty()) {
        o.c().a(m, String.format("Starting tracking for [%s]", new Object[] { TextUtils.join(",", hashSet) }), new Throwable[0]);
        this.h.addAll(null);
        this.g.b(this.h);
      } 
      return;
    } 
  }
  
  public void d(List<String> paramList) {
    for (String str : paramList) {
      o.c().a(m, String.format("Constraints not met: Cancelling work ID %s", new Object[] { str }), new Throwable[0]);
      this.f.f(str);
    } 
  }
  
  public void e(List<String> paramList) {
    for (String str : paramList) {
      o.c().a(m, String.format("Constraints met: Scheduling work ID %s", new Object[] { str }), new Throwable[0]);
      t t1 = this.f;
      a a = t1.d;
      l l = new l(t1, str, null);
      ((c.b0.f0.c0.a0.c)a).a.execute((Runnable)l);
    } 
  }
  
  public boolean f() {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\y\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */