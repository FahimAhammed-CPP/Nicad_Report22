package c.b0.f0;

import android.content.Context;
import android.text.TextUtils;
import c.w.a.c;
import c.w.a.f.f;

public class i implements c.c {
  public i(Context paramContext) {}
  
  public c a(c.b paramb) {
    Context context = this.a;
    String str = paramb.b;
    c.a a = paramb.c;
    if (a != null) {
      if (context != null) {
        if (!TextUtils.isEmpty(str))
          return (c)new f(context, str, a, true); 
        throw new IllegalArgumentException("Must set a non-null database name to a configuration that uses the no backup directory.");
      } 
      throw new IllegalArgumentException("Must set a non-null context to create the configuration.");
    } 
    throw new IllegalArgumentException("Must set a callback to create the configuration.");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */