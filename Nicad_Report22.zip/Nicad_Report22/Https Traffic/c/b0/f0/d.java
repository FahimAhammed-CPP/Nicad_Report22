package c.b0.f0;

import c.b0.f0.c0.z.k;
import d.c.c.d.a.a;

public class d implements Runnable {
  public b e;
  
  public String f;
  
  public a<Boolean> g;
  
  public d(b paramb, String paramString, a<Boolean> parama) {
    this.e = paramb;
    this.f = paramString;
    this.g = parama;
  }
  
  public void run() {
    boolean bool;
    try {
      bool = ((Boolean)((k)this.g).get()).booleanValue();
    } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
      bool = true;
    } 
    this.e.a(this.f, bool);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */