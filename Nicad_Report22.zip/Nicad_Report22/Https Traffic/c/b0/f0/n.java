package c.b0.f0;

import c.u.t.a;
import c.w.a.b;
import c.w.a.f.c;

public class n extends a {
  public n(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
  }
  
  public void a(b paramb) {
    ((c)paramb).e.execSQL("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */