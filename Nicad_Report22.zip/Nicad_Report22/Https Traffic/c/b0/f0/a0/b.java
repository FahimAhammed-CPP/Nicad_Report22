package c.b0.f0.a0;

import androidx.work.impl.WorkDatabase;
import c.b0.f0.b0.t;

public class b implements Runnable {
  public b(c paramc, WorkDatabase paramWorkDatabase, String paramString) {}
  
  public void run() {
    t t = this.e.q().i(this.f);
    if (t != null && t.b())
      synchronized (this.g.h) {
        this.g.k.put(this.f, t);
        this.g.l.add(t);
        c c1 = this.g;
        c1.m.b(c1.l);
        return;
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */