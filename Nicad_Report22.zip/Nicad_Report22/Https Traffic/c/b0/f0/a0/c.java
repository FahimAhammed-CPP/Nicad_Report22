package c.b0.f0.a0;

import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.work.impl.foreground.SystemForegroundService;
import c.b0.f0.b;
import c.b0.f0.b0.t;
import c.b0.f0.c0.m;
import c.b0.f0.t;
import c.b0.f0.z.b;
import c.b0.h;
import c.b0.o;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class c implements b, b {
  public static final String o = o.e("SystemFgDispatcher");
  
  public Context e;
  
  public t f;
  
  public final c.b0.f0.c0.a0.a g;
  
  public final Object h;
  
  public String i;
  
  public final Map<String, h> j;
  
  public final Map<String, t> k;
  
  public final Set<t> l;
  
  public final c.b0.f0.z.c m;
  
  public a n;
  
  public c(Context paramContext) {
    this.e = paramContext;
    this.h = new Object();
    t t1 = t.b(this.e);
    this.f = t1;
    c.b0.f0.c0.a0.a a1 = t1.d;
    this.g = a1;
    this.i = null;
    this.j = new LinkedHashMap<String, h>();
    this.l = new HashSet<t>();
    this.k = new HashMap<String, t>();
    this.m = new c.b0.f0.z.c(this.e, a1, this);
    this.f.f.b(this);
  }
  
  public static Intent b(Context paramContext, String paramString, h paramh) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_NOTIFY");
    intent.putExtra("KEY_NOTIFICATION_ID", paramh.a);
    intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", paramh.b);
    intent.putExtra("KEY_NOTIFICATION", (Parcelable)paramh.c);
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public static Intent c(Context paramContext, String paramString, h paramh) {
    Intent intent = new Intent(paramContext, SystemForegroundService.class);
    intent.setAction("ACTION_START_FOREGROUND");
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    intent.putExtra("KEY_NOTIFICATION_ID", paramh.a);
    intent.putExtra("KEY_FOREGROUND_SERVICE_TYPE", paramh.b);
    intent.putExtra("KEY_NOTIFICATION", (Parcelable)paramh.c);
    intent.putExtra("KEY_WORKSPEC_ID", paramString);
    return intent;
  }
  
  public void a(String paramString, boolean paramBoolean) {
    synchronized (this.h) {
      t t1 = this.k.remove(paramString);
      if (t1 != null) {
        paramBoolean = this.l.remove(t1);
      } else {
        paramBoolean = false;
      } 
      if (paramBoolean)
        this.m.b(this.l); 
      h h = this.j.remove(paramString);
      if (paramString.equals(this.i) && this.j.size() > 0) {
        Iterator<Map.Entry> iterator = this.j.entrySet().iterator();
        for (null = iterator.next(); iterator.hasNext(); null = iterator.next());
        this.i = (String)null.getKey();
        if (this.n != null) {
          null = null.getValue();
          a a1 = this.n;
          int i = ((h)null).a;
          int j = ((h)null).b;
          Notification notification = ((h)null).c;
          ((SystemForegroundService)a1).d(i, j, notification);
          a1 = this.n;
          i = ((h)null).a;
          null = a1;
          ((SystemForegroundService)null).f.post(new e((SystemForegroundService)null, i));
        } 
      } 
      null = this.n;
      if (h != null && null != null) {
        o.c().a(o, String.format("Removing Notification (id: %s, workSpecId: %s ,notificationType: %s)", new Object[] { Integer.valueOf(h.a), paramString, Integer.valueOf(h.b) }), new Throwable[0]);
        int i = h.a;
        SystemForegroundService systemForegroundService = (SystemForegroundService)null;
        systemForegroundService.f.post(new e(systemForegroundService, i));
      } 
      return;
    } 
  }
  
  public void d(List<String> paramList) {
    if (!paramList.isEmpty())
      for (String str : paramList) {
        o.c().a(o, String.format("Constraints unmet for WorkSpec %s", new Object[] { str }), new Throwable[0]);
        t t1 = this.f;
        c.b0.f0.c0.a0.a a1 = t1.d;
        m m = new m(t1, str, true);
        ((c.b0.f0.c0.a0.c)a1).a.execute((Runnable)m);
      }  
  }
  
  public void e(List<String> paramList) {}
  
  public final void f(Intent paramIntent) {
    int i = 0;
    int j = paramIntent.getIntExtra("KEY_NOTIFICATION_ID", 0);
    int k = paramIntent.getIntExtra("KEY_FOREGROUND_SERVICE_TYPE", 0);
    String str = paramIntent.getStringExtra("KEY_WORKSPEC_ID");
    Notification notification = (Notification)paramIntent.getParcelableExtra("KEY_NOTIFICATION");
    o.c().a(o, String.format("Notifying with (id: %s, workSpecId: %s, notificationType: %s)", new Object[] { Integer.valueOf(j), str, Integer.valueOf(k) }), new Throwable[0]);
    if (notification != null && this.n != null) {
      h h = new h(j, notification, k);
      this.j.put(str, h);
      if (TextUtils.isEmpty(this.i)) {
        this.i = str;
        ((SystemForegroundService)this.n).d(j, k, notification);
        return;
      } 
      SystemForegroundService systemForegroundService = (SystemForegroundService)this.n;
      systemForegroundService.f.post(new d(systemForegroundService, j, notification));
      if (k != 0 && Build.VERSION.SDK_INT >= 29) {
        Iterator iterator = this.j.entrySet().iterator();
        while (iterator.hasNext())
          i |= ((h)((Map.Entry)iterator.next()).getValue()).b; 
        h h1 = this.j.get(this.i);
        if (h1 != null) {
          a a1 = this.n;
          j = h1.a;
          Notification notification1 = h1.c;
          ((SystemForegroundService)a1).d(j, i, notification1);
        } 
      } 
    } 
  }
  
  public void g() {
    this.n = null;
    synchronized (this.h) {
      this.m.c();
      this.f.f.e(this);
      return;
    } 
  }
  
  public static interface a {}
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\f0\a0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */