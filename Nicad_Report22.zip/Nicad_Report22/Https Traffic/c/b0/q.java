package c.b0;

import androidx.work.ListenableWorker;
import androidx.work.OverwritingInputMerger;

public final class q extends c0 {
  public q(a parama) {
    super(parama.a, parama.b, parama.c);
  }
  
  public static final class a extends c0.a<a, q> {
    public a(Class<? extends ListenableWorker> param1Class) {
      super(param1Class);
      this.b.d = OverwritingInputMerger.class.getName();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */