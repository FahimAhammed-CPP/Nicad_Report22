package c.b0;

import android.os.Build;
import androidx.work.ListenableWorker;
import c.b0.f0.b0.t;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public abstract class c0 {
  public UUID a;
  
  public t b;
  
  public Set<String> c;
  
  public c0(UUID paramUUID, t paramt, Set<String> paramSet) {
    this.a = paramUUID;
    this.b = paramt;
    this.c = paramSet;
  }
  
  public String a() {
    return this.a.toString();
  }
  
  public static abstract class a<B extends a<?, ?>, W extends c0> {
    public UUID a = UUID.randomUUID();
    
    public t b;
    
    public Set<String> c = new HashSet<String>();
    
    public a(Class<? extends ListenableWorker> param1Class) {
      this.b = new t(this.a.toString(), param1Class.getName());
      String str = param1Class.getName();
      this.c.add(str);
    }
    
    public final W a() {
      boolean bool;
      q q = new q((q.a)this);
      d d = this.b.j;
      if ((Build.VERSION.SDK_INT >= 24 && d.a()) || d.d || d.b || d.c) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!this.b.q || !bool) {
        this.a = UUID.randomUUID();
        t t1 = new t(this.b);
        this.b = t1;
        t1.a = this.a.toString();
        return (W)q;
      } 
      throw new IllegalArgumentException("Expedited jobs only support network and storage constraints");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */