package c.b0;

public final class t extends v {
  public t(r paramr) {}
  
  public String toString() {
    return "IN_PROGRESS";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */