package c.b0;

public enum a0 {
  e, f, g, h, i, j;
  
  static {
    a0 a01 = new a0("ENQUEUED", 0);
    e = a01;
    a0 a02 = new a0("RUNNING", 1);
    f = a02;
    a0 a03 = new a0("SUCCEEDED", 2);
    g = a03;
    a0 a04 = new a0("FAILED", 3);
    h = a04;
    a0 a05 = new a0("BLOCKED", 4);
    i = a05;
    a0 a06 = new a0("CANCELLED", 5);
    j = a06;
    k = new a0[] { a01, a02, a03, a04, a05, a06 };
  }
  
  public boolean a() {
    return (this == g || this == h || this == j);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\c\b0\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */