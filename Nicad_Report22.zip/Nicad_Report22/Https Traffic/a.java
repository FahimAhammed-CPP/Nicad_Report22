import android.view.View;
import android.webkit.WebView;
import h.c.a.a;
import hpandro.kotlin.infosec.http.activity.TaskActivity;

public final class a implements View.OnClickListener {
  public a(int paramInt, Object paramObject) {}
  
  public final void onClick(View paramView) {
    int i = this.e;
    if (i != 0) {
      if (i == 1) {
        WebView webView = (WebView)((TaskActivity)this.f).x(2131231171);
        a.a(webView);
        webView.reload();
        return;
      } 
      throw null;
    } 
    ((TaskActivity)this.f).finish();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */