package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v4.media.MediaDescriptionCompat;

public abstract class MediaSessionCompat {
  public static void a(Bundle paramBundle) {
    if (paramBundle != null)
      paramBundle.setClassLoader(MediaSessionCompat.class.getClassLoader()); 
  }
  
  public static final class QueueItem implements Parcelable {
    public static final Parcelable.Creator<QueueItem> CREATOR = new a();
    
    public final MediaDescriptionCompat e;
    
    public final long f;
    
    public QueueItem(Parcel param1Parcel) {
      this.e = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(param1Parcel);
      this.f = param1Parcel.readLong();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = d.a.a.a.a.p("MediaSession.QueueItem {Description=");
      stringBuilder.append(this.e);
      stringBuilder.append(", Id=");
      stringBuilder.append(this.f);
      stringBuilder.append(" }");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.e.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeLong(this.f);
    }
    
    public static final class a implements Parcelable.Creator<QueueItem> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new MediaSessionCompat.QueueItem(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new MediaSessionCompat.QueueItem[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<QueueItem> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new MediaSessionCompat.QueueItem(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaSessionCompat.QueueItem[param1Int];
    }
  }
  
  public static final class ResultReceiverWrapper implements Parcelable {
    public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new a();
    
    public ResultReceiver e;
    
    public ResultReceiverWrapper(Parcel param1Parcel) {
      this.e = (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(param1Parcel);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.e.writeToParcel(param1Parcel, param1Int);
    }
    
    public static final class a implements Parcelable.Creator<ResultReceiverWrapper> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new MediaSessionCompat.ResultReceiverWrapper(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new MediaSessionCompat.ResultReceiverWrapper[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<ResultReceiverWrapper> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new MediaSessionCompat.ResultReceiverWrapper(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaSessionCompat.ResultReceiverWrapper[param1Int];
    }
  }
  
  public static final class Token implements Parcelable {
    public static final Parcelable.Creator<Token> CREATOR = new a();
    
    public final Object e;
    
    public Token(Object param1Object) {
      this.e = param1Object;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Token))
        return false; 
      Token token = (Token)param1Object;
      param1Object = this.e;
      if (param1Object == null)
        return (token.e == null); 
      Object object = token.e;
      return (object == null) ? false : param1Object.equals(object);
    }
    
    public int hashCode() {
      Object object = this.e;
      return (object == null) ? 0 : object.hashCode();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeParcelable((Parcelable)this.e, param1Int);
    }
    
    public static final class a implements Parcelable.Creator<Token> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new MediaSessionCompat.Token(param2Parcel.readParcelable(null));
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new MediaSessionCompat.Token[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<Token> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new MediaSessionCompat.Token(param1Parcel.readParcelable(null));
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new MediaSessionCompat.Token[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\android\support\v4\media\session\MediaSessionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */