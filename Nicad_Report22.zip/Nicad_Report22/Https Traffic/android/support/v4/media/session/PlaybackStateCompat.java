package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
  
  public final int e;
  
  public final long f;
  
  public final long g;
  
  public final float h;
  
  public final long i;
  
  public final int j;
  
  public final CharSequence k;
  
  public final long l;
  
  public List<CustomAction> m;
  
  public final long n;
  
  public final Bundle o;
  
  public PlaybackStateCompat(Parcel paramParcel) {
    this.e = paramParcel.readInt();
    this.f = paramParcel.readLong();
    this.h = paramParcel.readFloat();
    this.l = paramParcel.readLong();
    this.g = paramParcel.readLong();
    this.i = paramParcel.readLong();
    this.k = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.m = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.n = paramParcel.readLong();
    this.o = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
    this.j = paramParcel.readInt();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
    stringBuilder.append("state=");
    stringBuilder.append(this.e);
    stringBuilder.append(", position=");
    stringBuilder.append(this.f);
    stringBuilder.append(", buffered position=");
    stringBuilder.append(this.g);
    stringBuilder.append(", speed=");
    stringBuilder.append(this.h);
    stringBuilder.append(", updated=");
    stringBuilder.append(this.l);
    stringBuilder.append(", actions=");
    stringBuilder.append(this.i);
    stringBuilder.append(", error code=");
    stringBuilder.append(this.j);
    stringBuilder.append(", error message=");
    stringBuilder.append(this.k);
    stringBuilder.append(", custom actions=");
    stringBuilder.append(this.m);
    stringBuilder.append(", active item id=");
    stringBuilder.append(this.n);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.e);
    paramParcel.writeLong(this.f);
    paramParcel.writeFloat(this.h);
    paramParcel.writeLong(this.l);
    paramParcel.writeLong(this.g);
    paramParcel.writeLong(this.i);
    TextUtils.writeToParcel(this.k, paramParcel, paramInt);
    paramParcel.writeTypedList(this.m);
    paramParcel.writeLong(this.n);
    paramParcel.writeBundle(this.o);
    paramParcel.writeInt(this.j);
  }
  
  public static final class CustomAction implements Parcelable {
    public static final Parcelable.Creator<CustomAction> CREATOR = new a();
    
    public final String e;
    
    public final CharSequence f;
    
    public final int g;
    
    public final Bundle h;
    
    public CustomAction(Parcel param1Parcel) {
      this.e = param1Parcel.readString();
      this.f = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      this.g = param1Parcel.readInt();
      this.h = param1Parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = d.a.a.a.a.p("Action:mName='");
      stringBuilder.append(this.f);
      stringBuilder.append(", mIcon=");
      stringBuilder.append(this.g);
      stringBuilder.append(", mExtras=");
      stringBuilder.append(this.h);
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.e);
      TextUtils.writeToParcel(this.f, param1Parcel, param1Int);
      param1Parcel.writeInt(this.g);
      param1Parcel.writeBundle(this.h);
    }
    
    public static final class a implements Parcelable.Creator<CustomAction> {
      public Object createFromParcel(Parcel param2Parcel) {
        return new PlaybackStateCompat.CustomAction(param2Parcel);
      }
      
      public Object[] newArray(int param2Int) {
        return (Object[])new PlaybackStateCompat.CustomAction[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<CustomAction> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new PlaybackStateCompat.CustomAction(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new PlaybackStateCompat.CustomAction[param1Int];
    }
  }
  
  public static final class a implements Parcelable.Creator<PlaybackStateCompat> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new PlaybackStateCompat(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new PlaybackStateCompat[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\android\support\v4\media\session\PlaybackStateCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */