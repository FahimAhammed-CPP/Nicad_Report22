package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import c.a0.b;
import c.a0.c;

public class ParcelImpl implements Parcelable {
  public static final Parcelable.Creator<ParcelImpl> CREATOR = new a();
  
  public final c e;
  
  public ParcelImpl(Parcel paramParcel) {
    this.e = (new b(paramParcel)).k();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    (new b(paramParcel)).o(this.e);
  }
  
  public static final class a implements Parcelable.Creator<ParcelImpl> {
    public Object createFromParcel(Parcel param1Parcel) {
      return new ParcelImpl(param1Parcel);
    }
    
    public Object[] newArray(int param1Int) {
      return (Object[])new ParcelImpl[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\versionedparcelable\ParcelImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */