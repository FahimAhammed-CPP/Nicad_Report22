package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.appcompat.app.AlertController;
import c.b.c.i;
import c.h.j.f;
import c.h.j.g;
import c.h.j.i;
import c.h.j.j;
import c.h.j.u;
import c.h.k.e;
import java.util.concurrent.atomic.AtomicInteger;

public class NestedScrollView extends FrameLayout implements i, f {
  public static final a E = new a();
  
  public static final int[] F = new int[] { 16843130 };
  
  public final j A;
  
  public final g B;
  
  public float C;
  
  public b D;
  
  public long e;
  
  public final Rect f = new Rect();
  
  public OverScroller g = new OverScroller(getContext());
  
  public EdgeEffect h;
  
  public EdgeEffect i;
  
  public int j;
  
  public boolean k = true;
  
  public boolean l = false;
  
  public View m = null;
  
  public boolean n = false;
  
  public VelocityTracker o;
  
  public boolean p;
  
  public boolean q = true;
  
  public int r;
  
  public int s;
  
  public int t;
  
  public int u = -1;
  
  public final int[] v = new int[2];
  
  public final int[] w = new int[2];
  
  public int x;
  
  public int y;
  
  public c z;
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 2130903648);
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.r = viewConfiguration.getScaledTouchSlop();
    this.s = viewConfiguration.getScaledMinimumFlingVelocity();
    this.t = viewConfiguration.getScaledMaximumFlingVelocity();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, F, 2130903648, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.A = new j();
    this.B = new g((View)this);
    setNestedScrollingEnabled(true);
    u.n((View)this, E);
  }
  
  private float getVerticalScrollFactorCompat() {
    if (this.C == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.C = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.C;
  }
  
  public static int i(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt2 >= paramInt3 || paramInt1 < 0) ? 0 : ((paramInt2 + paramInt1 > paramInt3) ? (paramInt3 - paramInt2) : paramInt1);
  }
  
  public static boolean s(View paramView1, View paramView2) {
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    return (viewParent instanceof ViewGroup && s((View)viewParent, paramView2));
  }
  
  public final void A(View paramView) {
    paramView.getDrawingRect(this.f);
    offsetDescendantRectToMyCoords(paramView, this.f);
    int k = j(this.f);
    if (k != 0)
      scrollBy(0, k); 
  }
  
  public final void B(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.e > 250L) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int k = view.getHeight();
      int m = layoutParams.topMargin;
      int n = layoutParams.bottomMargin;
      int i1 = getHeight();
      int i2 = getPaddingTop();
      int i3 = getPaddingBottom();
      paramInt1 = getScrollY();
      paramInt2 = Math.max(0, Math.min(paramInt2 + paramInt1, Math.max(0, k + m + n - i1 - i2 - i3)));
      this.g.startScroll(getScrollX(), paramInt1, 0, paramInt2 - paramInt1, paramInt3);
      y(paramBoolean);
    } else {
      if (!this.g.isFinished())
        g(); 
      scrollBy(paramInt1, paramInt2);
    } 
    this.e = AnimationUtils.currentAnimationTimeMillis();
  }
  
  public boolean C(int paramInt1, int paramInt2) {
    return this.B.i(paramInt1, paramInt2);
  }
  
  public void a(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    j j1 = this.A;
    if (paramInt2 == 1) {
      j1.b = paramInt1;
    } else {
      j1.a = paramInt1;
    } 
    C(2, paramInt2);
  }
  
  public void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void b(View paramView, int paramInt) {
    j j1 = this.A;
    if (paramInt == 1) {
      j1.b = 0;
    } else {
      j1.a = 0;
    } 
    this.B.j(paramInt);
  }
  
  public void c(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    k(paramInt1, paramInt2, paramArrayOfint, null, paramInt3);
  }
  
  public int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  public int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  public int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public void computeScroll() {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Landroid/widget/OverScroller;
    //   4: invokevirtual isFinished : ()Z
    //   7: ifeq -> 11
    //   10: return
    //   11: aload_0
    //   12: getfield g : Landroid/widget/OverScroller;
    //   15: invokevirtual computeScrollOffset : ()Z
    //   18: pop
    //   19: aload_0
    //   20: getfield g : Landroid/widget/OverScroller;
    //   23: invokevirtual getCurrY : ()I
    //   26: istore_2
    //   27: iload_2
    //   28: aload_0
    //   29: getfield y : I
    //   32: isub
    //   33: istore_1
    //   34: aload_0
    //   35: iload_2
    //   36: putfield y : I
    //   39: aload_0
    //   40: getfield w : [I
    //   43: astore #6
    //   45: iconst_0
    //   46: istore_3
    //   47: aload #6
    //   49: iconst_1
    //   50: iconst_0
    //   51: iastore
    //   52: aload_0
    //   53: iconst_0
    //   54: iload_1
    //   55: aload #6
    //   57: aconst_null
    //   58: iconst_1
    //   59: invokevirtual k : (II[I[II)Z
    //   62: pop
    //   63: iload_1
    //   64: aload_0
    //   65: getfield w : [I
    //   68: iconst_1
    //   69: iaload
    //   70: isub
    //   71: istore_2
    //   72: aload_0
    //   73: invokevirtual getScrollRange : ()I
    //   76: istore #4
    //   78: iload_2
    //   79: istore_1
    //   80: iload_2
    //   81: ifeq -> 160
    //   84: aload_0
    //   85: invokevirtual getScrollY : ()I
    //   88: istore_1
    //   89: aload_0
    //   90: iconst_0
    //   91: iload_2
    //   92: aload_0
    //   93: invokevirtual getScrollX : ()I
    //   96: iload_1
    //   97: iconst_0
    //   98: iload #4
    //   100: iconst_0
    //   101: iconst_0
    //   102: invokevirtual w : (IIIIIIII)Z
    //   105: pop
    //   106: aload_0
    //   107: invokevirtual getScrollY : ()I
    //   110: iload_1
    //   111: isub
    //   112: istore_1
    //   113: iload_2
    //   114: iload_1
    //   115: isub
    //   116: istore_2
    //   117: aload_0
    //   118: getfield w : [I
    //   121: astore #6
    //   123: aload #6
    //   125: iconst_1
    //   126: iconst_0
    //   127: iastore
    //   128: aload_0
    //   129: getfield v : [I
    //   132: astore #7
    //   134: aload_0
    //   135: getfield B : Lc/h/j/g;
    //   138: iconst_0
    //   139: iload_1
    //   140: iconst_0
    //   141: iload_2
    //   142: aload #7
    //   144: iconst_1
    //   145: aload #6
    //   147: invokevirtual f : (IIII[II[I)Z
    //   150: pop
    //   151: iload_2
    //   152: aload_0
    //   153: getfield w : [I
    //   156: iconst_1
    //   157: iaload
    //   158: isub
    //   159: istore_1
    //   160: iload_1
    //   161: ifeq -> 261
    //   164: aload_0
    //   165: invokevirtual getOverScrollMode : ()I
    //   168: istore #5
    //   170: iload #5
    //   172: ifeq -> 190
    //   175: iload_3
    //   176: istore_2
    //   177: iload #5
    //   179: iconst_1
    //   180: if_icmpne -> 192
    //   183: iload_3
    //   184: istore_2
    //   185: iload #4
    //   187: ifle -> 192
    //   190: iconst_1
    //   191: istore_2
    //   192: iload_2
    //   193: ifeq -> 257
    //   196: aload_0
    //   197: invokevirtual n : ()V
    //   200: iload_1
    //   201: ifge -> 232
    //   204: aload_0
    //   205: getfield h : Landroid/widget/EdgeEffect;
    //   208: invokevirtual isFinished : ()Z
    //   211: ifeq -> 257
    //   214: aload_0
    //   215: getfield h : Landroid/widget/EdgeEffect;
    //   218: aload_0
    //   219: getfield g : Landroid/widget/OverScroller;
    //   222: invokevirtual getCurrVelocity : ()F
    //   225: f2i
    //   226: invokevirtual onAbsorb : (I)V
    //   229: goto -> 257
    //   232: aload_0
    //   233: getfield i : Landroid/widget/EdgeEffect;
    //   236: invokevirtual isFinished : ()Z
    //   239: ifeq -> 257
    //   242: aload_0
    //   243: getfield i : Landroid/widget/EdgeEffect;
    //   246: aload_0
    //   247: getfield g : Landroid/widget/OverScroller;
    //   250: invokevirtual getCurrVelocity : ()F
    //   253: f2i
    //   254: invokevirtual onAbsorb : (I)V
    //   257: aload_0
    //   258: invokevirtual g : ()V
    //   261: aload_0
    //   262: getfield g : Landroid/widget/OverScroller;
    //   265: invokevirtual isFinished : ()Z
    //   268: ifne -> 281
    //   271: getstatic c/h/j/u.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   274: astore #6
    //   276: aload_0
    //   277: invokevirtual postInvalidateOnAnimation : ()V
    //   280: return
    //   281: aload_0
    //   282: getfield B : Lc/h/j/g;
    //   285: iconst_1
    //   286: invokevirtual j : (I)V
    //   289: return
  }
  
  public int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  public int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  public int computeVerticalScrollRange() {
    int m = getChildCount();
    int k = getHeight() - getPaddingBottom() - getPaddingTop();
    if (m == 0)
      return k; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    m = view.getBottom() + layoutParams.bottomMargin;
    int n = getScrollY();
    int i1 = Math.max(0, m - k);
    if (n < 0)
      return m - n; 
    k = m;
    if (n > i1)
      k = m + n - i1; 
    return k;
  }
  
  public void d(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    u(paramInt4, paramInt5, paramArrayOfint);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || o(paramKeyEvent));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.B.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.B.b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return k(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.B.e(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    if (this.h != null) {
      int k = getScrollY();
      boolean bool = this.h.isFinished();
      byte b1 = 0;
      if (!bool) {
        boolean bool1;
        int i4 = paramCanvas.save();
        int m = getWidth();
        int i3 = getHeight();
        int i2 = Math.min(0, k);
        if (getClipToPadding()) {
          bool1 = getPaddingLeft();
          m -= getPaddingRight() + bool1;
          bool1 = getPaddingLeft() + 0;
        } else {
          bool1 = false;
        } 
        int i1 = i3;
        int n = i2;
        if (getClipToPadding()) {
          n = getPaddingTop();
          i1 = i3 - getPaddingBottom() + n;
          n = i2 + getPaddingTop();
        } 
        paramCanvas.translate(bool1, n);
        this.h.setSize(m, i1);
        if (this.h.draw(paramCanvas)) {
          AtomicInteger atomicInteger = u.a;
          postInvalidateOnAnimation();
        } 
        paramCanvas.restoreToCount(i4);
      } 
      if (!this.i.isFinished()) {
        int i5 = paramCanvas.save();
        int i1 = getWidth();
        int i3 = getHeight();
        int i4 = Math.max(getScrollRange(), k) + i3;
        int n = b1;
        int m = i1;
        if (getClipToPadding()) {
          m = getPaddingLeft();
          m = i1 - getPaddingRight() + m;
          n = 0 + getPaddingLeft();
        } 
        int i2 = i4;
        i1 = i3;
        if (getClipToPadding()) {
          i1 = getPaddingTop();
          i1 = i3 - getPaddingBottom() + i1;
          i2 = i4 - getPaddingBottom();
        } 
        paramCanvas.translate((n - m), i2);
        paramCanvas.rotate(180.0F, m, 0.0F);
        this.i.setSize(m, i1);
        if (this.i.draw(paramCanvas)) {
          AtomicInteger atomicInteger = u.a;
          postInvalidateOnAnimation();
        } 
        paramCanvas.restoreToCount(i5);
      } 
    } 
  }
  
  public void e(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    u(paramInt4, paramInt5, null);
  }
  
  public boolean f(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return ((paramInt1 & 0x2) != 0);
  }
  
  public final void g() {
    this.g.abortAnimation();
    this.B.j(1);
  }
  
  public float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    int k = getVerticalFadingEdgeLength();
    int m = getHeight();
    int n = getPaddingBottom();
    m = view.getBottom() + layoutParams.bottomMargin - getScrollY() - m - n;
    return (m < k) ? (m / k) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(getHeight() * 0.5F);
  }
  
  public int getNestedScrollAxes() {
    return this.A.a();
  }
  
  public int getScrollRange() {
    int m = getChildCount();
    int k = 0;
    if (m > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      k = Math.max(0, view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin - getHeight() - getPaddingTop() - getPaddingBottom());
    } 
    return k;
  }
  
  public float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int k = getVerticalFadingEdgeLength();
    int m = getScrollY();
    return (m < k) ? (m / k) : 1.0F;
  }
  
  public boolean h(int paramInt) {
    View view2 = findFocus();
    View view1 = view2;
    if (view2 == this)
      view1 = null; 
    view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int k = getMaxScrollAmount();
    if (view2 != null && t(view2, k, getHeight())) {
      view2.getDrawingRect(this.f);
      offsetDescendantRectToMyCoords(view2, this.f);
      l(j(this.f));
      view2.requestFocus(paramInt);
    } else {
      int m;
      if (paramInt == 33 && getScrollY() < k) {
        m = getScrollY();
      } else {
        m = k;
        if (paramInt == 130) {
          m = k;
          if (getChildCount() > 0) {
            view2 = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view2.getLayoutParams();
            m = view2.getBottom();
            int n = layoutParams.bottomMargin;
            int i1 = getScrollY();
            m = Math.min(m + n - getHeight() + i1 - getPaddingBottom(), k);
          } 
        } 
      } 
      if (m == 0)
        return false; 
      if (paramInt != 130)
        m = -m; 
      l(m);
    } 
    if (view1 != null && view1.isFocused() && (t(view1, 0, getHeight()) ^ true) != 0) {
      paramInt = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(paramInt);
    } 
    return true;
  }
  
  public boolean hasNestedScrollingParent() {
    return r(0);
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.B.d;
  }
  
  public int j(Rect paramRect) {
    int k = getChildCount();
    boolean bool = false;
    if (k == 0)
      return 0; 
    int i1 = getHeight();
    int m = getScrollY();
    int n = m + i1;
    int i2 = getVerticalFadingEdgeLength();
    k = m;
    if (paramRect.top > 0)
      k = m + i2; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    if (paramRect.bottom < view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
      m = n - i2;
    } else {
      m = n;
    } 
    i2 = paramRect.bottom;
    if (i2 > m && paramRect.top > k) {
      if (paramRect.height() > i1) {
        k = paramRect.top - k;
      } else {
        k = paramRect.bottom - m;
      } 
      return Math.min(k + 0, view.getBottom() + layoutParams.bottomMargin - n);
    } 
    n = bool;
    if (paramRect.top < k) {
      n = bool;
      if (i2 < m) {
        if (paramRect.height() > i1) {
          k = 0 - m - paramRect.bottom;
        } else {
          k = 0 - k - paramRect.top;
        } 
        n = Math.max(k, -getScrollY());
      } 
    } 
    return n;
  }
  
  public boolean k(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return this.B.c(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  public final void l(int paramInt) {
    if (paramInt != 0) {
      if (this.q) {
        B(0, paramInt, 250, false);
        return;
      } 
      scrollBy(0, paramInt);
    } 
  }
  
  public final void m() {
    this.n = false;
    x();
    this.B.j(0);
    EdgeEffect edgeEffect = this.h;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      this.i.onRelease();
    } 
  }
  
  public void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramInt2 = getPaddingLeft();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + paramInt2, layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  public void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramInt3 = getPaddingLeft();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + paramInt3 + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public final void n() {
    if (getOverScrollMode() != 2) {
      if (this.h == null) {
        Context context = getContext();
        this.h = new EdgeEffect(context);
        this.i = new EdgeEffect(context);
        return;
      } 
    } else {
      this.h = null;
      this.i = null;
    } 
  }
  
  public boolean o(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Landroid/graphics/Rect;
    //   4: invokevirtual setEmpty : ()V
    //   7: aload_0
    //   8: invokevirtual getChildCount : ()I
    //   11: istore_2
    //   12: iconst_0
    //   13: istore #6
    //   15: iload_2
    //   16: ifle -> 75
    //   19: aload_0
    //   20: iconst_0
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: astore #7
    //   26: aload #7
    //   28: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   31: checkcast android/widget/FrameLayout$LayoutParams
    //   34: astore #8
    //   36: aload #7
    //   38: invokevirtual getHeight : ()I
    //   41: aload #8
    //   43: getfield topMargin : I
    //   46: iadd
    //   47: aload #8
    //   49: getfield bottomMargin : I
    //   52: iadd
    //   53: aload_0
    //   54: invokevirtual getHeight : ()I
    //   57: aload_0
    //   58: invokevirtual getPaddingTop : ()I
    //   61: isub
    //   62: aload_0
    //   63: invokevirtual getPaddingBottom : ()I
    //   66: isub
    //   67: if_icmple -> 75
    //   70: iconst_1
    //   71: istore_2
    //   72: goto -> 77
    //   75: iconst_0
    //   76: istore_2
    //   77: iload_2
    //   78: ifne -> 150
    //   81: aload_0
    //   82: invokevirtual isFocused : ()Z
    //   85: ifeq -> 148
    //   88: aload_1
    //   89: invokevirtual getKeyCode : ()I
    //   92: iconst_4
    //   93: if_icmpeq -> 148
    //   96: aload_0
    //   97: invokevirtual findFocus : ()Landroid/view/View;
    //   100: astore #7
    //   102: aload #7
    //   104: astore_1
    //   105: aload #7
    //   107: aload_0
    //   108: if_acmpne -> 113
    //   111: aconst_null
    //   112: astore_1
    //   113: invokestatic getInstance : ()Landroid/view/FocusFinder;
    //   116: aload_0
    //   117: aload_1
    //   118: sipush #130
    //   121: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   124: astore_1
    //   125: aload_1
    //   126: ifnull -> 146
    //   129: aload_1
    //   130: aload_0
    //   131: if_acmpeq -> 146
    //   134: aload_1
    //   135: sipush #130
    //   138: invokevirtual requestFocus : (I)Z
    //   141: ifeq -> 146
    //   144: iconst_1
    //   145: ireturn
    //   146: iconst_0
    //   147: ireturn
    //   148: iconst_0
    //   149: ireturn
    //   150: aload_1
    //   151: invokevirtual getAction : ()I
    //   154: ifne -> 421
    //   157: aload_1
    //   158: invokevirtual getKeyCode : ()I
    //   161: istore_3
    //   162: bipush #33
    //   164: istore_2
    //   165: iload_3
    //   166: bipush #19
    //   168: if_icmpeq -> 399
    //   171: iload_3
    //   172: bipush #20
    //   174: if_icmpeq -> 376
    //   177: iload_3
    //   178: bipush #62
    //   180: if_icmpeq -> 185
    //   183: iconst_0
    //   184: ireturn
    //   185: aload_1
    //   186: invokevirtual isShiftPressed : ()Z
    //   189: ifeq -> 195
    //   192: goto -> 199
    //   195: sipush #130
    //   198: istore_2
    //   199: iload_2
    //   200: sipush #130
    //   203: if_icmpne -> 211
    //   206: iconst_1
    //   207: istore_3
    //   208: goto -> 213
    //   211: iconst_0
    //   212: istore_3
    //   213: aload_0
    //   214: invokevirtual getHeight : ()I
    //   217: istore #4
    //   219: iload_3
    //   220: ifeq -> 312
    //   223: aload_0
    //   224: getfield f : Landroid/graphics/Rect;
    //   227: aload_0
    //   228: invokevirtual getScrollY : ()I
    //   231: iload #4
    //   233: iadd
    //   234: putfield top : I
    //   237: aload_0
    //   238: invokevirtual getChildCount : ()I
    //   241: istore_3
    //   242: iload_3
    //   243: ifle -> 343
    //   246: aload_0
    //   247: iload_3
    //   248: iconst_1
    //   249: isub
    //   250: invokevirtual getChildAt : (I)Landroid/view/View;
    //   253: astore_1
    //   254: aload_1
    //   255: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   258: checkcast android/widget/FrameLayout$LayoutParams
    //   261: astore #7
    //   263: aload_1
    //   264: invokevirtual getBottom : ()I
    //   267: istore_3
    //   268: aload #7
    //   270: getfield bottomMargin : I
    //   273: istore #5
    //   275: aload_0
    //   276: invokevirtual getPaddingBottom : ()I
    //   279: iload_3
    //   280: iload #5
    //   282: iadd
    //   283: iadd
    //   284: istore_3
    //   285: aload_0
    //   286: getfield f : Landroid/graphics/Rect;
    //   289: astore_1
    //   290: aload_1
    //   291: getfield top : I
    //   294: iload #4
    //   296: iadd
    //   297: iload_3
    //   298: if_icmple -> 343
    //   301: aload_1
    //   302: iload_3
    //   303: iload #4
    //   305: isub
    //   306: putfield top : I
    //   309: goto -> 343
    //   312: aload_0
    //   313: getfield f : Landroid/graphics/Rect;
    //   316: aload_0
    //   317: invokevirtual getScrollY : ()I
    //   320: iload #4
    //   322: isub
    //   323: putfield top : I
    //   326: aload_0
    //   327: getfield f : Landroid/graphics/Rect;
    //   330: astore_1
    //   331: aload_1
    //   332: getfield top : I
    //   335: ifge -> 343
    //   338: aload_1
    //   339: iconst_0
    //   340: putfield top : I
    //   343: aload_0
    //   344: getfield f : Landroid/graphics/Rect;
    //   347: astore_1
    //   348: aload_1
    //   349: getfield top : I
    //   352: istore_3
    //   353: iload #4
    //   355: iload_3
    //   356: iadd
    //   357: istore #4
    //   359: aload_1
    //   360: iload #4
    //   362: putfield bottom : I
    //   365: aload_0
    //   366: iload_2
    //   367: iload_3
    //   368: iload #4
    //   370: invokevirtual z : (III)Z
    //   373: pop
    //   374: iconst_0
    //   375: ireturn
    //   376: aload_1
    //   377: invokevirtual isAltPressed : ()Z
    //   380: ifne -> 391
    //   383: aload_0
    //   384: sipush #130
    //   387: invokevirtual h : (I)Z
    //   390: ireturn
    //   391: aload_0
    //   392: sipush #130
    //   395: invokevirtual q : (I)Z
    //   398: ireturn
    //   399: aload_1
    //   400: invokevirtual isAltPressed : ()Z
    //   403: ifne -> 413
    //   406: aload_0
    //   407: bipush #33
    //   409: invokevirtual h : (I)Z
    //   412: ireturn
    //   413: aload_0
    //   414: bipush #33
    //   416: invokevirtual q : (I)Z
    //   419: istore #6
    //   421: iload #6
    //   423: ireturn
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.l = false;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) != 0) {
      if (paramMotionEvent.getAction() != 8)
        return false; 
      if (!this.n) {
        float f1 = paramMotionEvent.getAxisValue(9);
        if (f1 != 0.0F) {
          int m = (int)(f1 * getVerticalScrollFactorCompat());
          int k = getScrollRange();
          int n = getScrollY();
          m = n - m;
          if (m < 0) {
            k = 0;
          } else if (m <= k) {
            k = m;
          } 
          if (k != n) {
            super.scrollTo(getScrollX(), k);
            return true;
          } 
        } 
      } 
    } 
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getAction : ()I
    //   4: istore_2
    //   5: iload_2
    //   6: iconst_2
    //   7: if_icmpne -> 19
    //   10: aload_0
    //   11: getfield n : Z
    //   14: ifeq -> 19
    //   17: iconst_1
    //   18: ireturn
    //   19: iload_2
    //   20: sipush #255
    //   23: iand
    //   24: istore_2
    //   25: iload_2
    //   26: ifeq -> 275
    //   29: iload_2
    //   30: iconst_1
    //   31: if_icmpeq -> 217
    //   34: iload_2
    //   35: iconst_2
    //   36: if_icmpeq -> 61
    //   39: iload_2
    //   40: iconst_3
    //   41: if_icmpeq -> 217
    //   44: iload_2
    //   45: bipush #6
    //   47: if_icmpeq -> 53
    //   50: goto -> 448
    //   53: aload_0
    //   54: aload_1
    //   55: invokevirtual v : (Landroid/view/MotionEvent;)V
    //   58: goto -> 448
    //   61: aload_0
    //   62: getfield u : I
    //   65: istore_2
    //   66: iload_2
    //   67: iconst_m1
    //   68: if_icmpne -> 74
    //   71: goto -> 448
    //   74: aload_1
    //   75: iload_2
    //   76: invokevirtual findPointerIndex : (I)I
    //   79: istore_3
    //   80: iload_3
    //   81: iconst_m1
    //   82: if_icmpne -> 129
    //   85: new java/lang/StringBuilder
    //   88: dup
    //   89: invokespecial <init> : ()V
    //   92: astore_1
    //   93: aload_1
    //   94: ldc_w 'Invalid pointerId='
    //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: pop
    //   101: aload_1
    //   102: iload_2
    //   103: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   106: pop
    //   107: aload_1
    //   108: ldc_w ' in onInterceptTouchEvent'
    //   111: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   114: pop
    //   115: ldc_w 'NestedScrollView'
    //   118: aload_1
    //   119: invokevirtual toString : ()Ljava/lang/String;
    //   122: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   125: pop
    //   126: goto -> 448
    //   129: aload_1
    //   130: iload_3
    //   131: invokevirtual getY : (I)F
    //   134: f2i
    //   135: istore_2
    //   136: iload_2
    //   137: aload_0
    //   138: getfield j : I
    //   141: isub
    //   142: invokestatic abs : (I)I
    //   145: aload_0
    //   146: getfield r : I
    //   149: if_icmple -> 448
    //   152: iconst_2
    //   153: aload_0
    //   154: invokevirtual getNestedScrollAxes : ()I
    //   157: iand
    //   158: ifne -> 448
    //   161: aload_0
    //   162: iconst_1
    //   163: putfield n : Z
    //   166: aload_0
    //   167: iload_2
    //   168: putfield j : I
    //   171: aload_0
    //   172: getfield o : Landroid/view/VelocityTracker;
    //   175: ifnonnull -> 185
    //   178: aload_0
    //   179: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   182: putfield o : Landroid/view/VelocityTracker;
    //   185: aload_0
    //   186: getfield o : Landroid/view/VelocityTracker;
    //   189: aload_1
    //   190: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   193: aload_0
    //   194: iconst_0
    //   195: putfield x : I
    //   198: aload_0
    //   199: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   202: astore_1
    //   203: aload_1
    //   204: ifnull -> 448
    //   207: aload_1
    //   208: iconst_1
    //   209: invokeinterface requestDisallowInterceptTouchEvent : (Z)V
    //   214: goto -> 448
    //   217: aload_0
    //   218: iconst_0
    //   219: putfield n : Z
    //   222: aload_0
    //   223: iconst_m1
    //   224: putfield u : I
    //   227: aload_0
    //   228: invokevirtual x : ()V
    //   231: aload_0
    //   232: getfield g : Landroid/widget/OverScroller;
    //   235: aload_0
    //   236: invokevirtual getScrollX : ()I
    //   239: aload_0
    //   240: invokevirtual getScrollY : ()I
    //   243: iconst_0
    //   244: iconst_0
    //   245: iconst_0
    //   246: aload_0
    //   247: invokevirtual getScrollRange : ()I
    //   250: invokevirtual springBack : (IIIIII)Z
    //   253: ifeq -> 264
    //   256: getstatic c/h/j/u.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   259: astore_1
    //   260: aload_0
    //   261: invokevirtual postInvalidateOnAnimation : ()V
    //   264: aload_0
    //   265: getfield B : Lc/h/j/g;
    //   268: iconst_0
    //   269: invokevirtual j : (I)V
    //   272: goto -> 448
    //   275: aload_1
    //   276: invokevirtual getY : ()F
    //   279: f2i
    //   280: istore_3
    //   281: aload_1
    //   282: invokevirtual getX : ()F
    //   285: f2i
    //   286: istore_2
    //   287: aload_0
    //   288: invokevirtual getChildCount : ()I
    //   291: ifle -> 354
    //   294: aload_0
    //   295: invokevirtual getScrollY : ()I
    //   298: istore #4
    //   300: aload_0
    //   301: iconst_0
    //   302: invokevirtual getChildAt : (I)Landroid/view/View;
    //   305: astore #5
    //   307: iload_3
    //   308: aload #5
    //   310: invokevirtual getTop : ()I
    //   313: iload #4
    //   315: isub
    //   316: if_icmplt -> 354
    //   319: iload_3
    //   320: aload #5
    //   322: invokevirtual getBottom : ()I
    //   325: iload #4
    //   327: isub
    //   328: if_icmpge -> 354
    //   331: iload_2
    //   332: aload #5
    //   334: invokevirtual getLeft : ()I
    //   337: if_icmplt -> 354
    //   340: iload_2
    //   341: aload #5
    //   343: invokevirtual getRight : ()I
    //   346: if_icmpge -> 354
    //   349: iconst_1
    //   350: istore_2
    //   351: goto -> 356
    //   354: iconst_0
    //   355: istore_2
    //   356: iload_2
    //   357: ifne -> 372
    //   360: aload_0
    //   361: iconst_0
    //   362: putfield n : Z
    //   365: aload_0
    //   366: invokevirtual x : ()V
    //   369: goto -> 448
    //   372: aload_0
    //   373: iload_3
    //   374: putfield j : I
    //   377: aload_0
    //   378: aload_1
    //   379: iconst_0
    //   380: invokevirtual getPointerId : (I)I
    //   383: putfield u : I
    //   386: aload_0
    //   387: getfield o : Landroid/view/VelocityTracker;
    //   390: astore #5
    //   392: aload #5
    //   394: ifnonnull -> 407
    //   397: aload_0
    //   398: invokestatic obtain : ()Landroid/view/VelocityTracker;
    //   401: putfield o : Landroid/view/VelocityTracker;
    //   404: goto -> 412
    //   407: aload #5
    //   409: invokevirtual clear : ()V
    //   412: aload_0
    //   413: getfield o : Landroid/view/VelocityTracker;
    //   416: aload_1
    //   417: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
    //   420: aload_0
    //   421: getfield g : Landroid/widget/OverScroller;
    //   424: invokevirtual computeScrollOffset : ()Z
    //   427: pop
    //   428: aload_0
    //   429: aload_0
    //   430: getfield g : Landroid/widget/OverScroller;
    //   433: invokevirtual isFinished : ()Z
    //   436: iconst_1
    //   437: ixor
    //   438: putfield n : Z
    //   441: aload_0
    //   442: iconst_2
    //   443: iconst_0
    //   444: invokevirtual C : (II)Z
    //   447: pop
    //   448: aload_0
    //   449: getfield n : Z
    //   452: ireturn
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt1 = 0;
    this.k = false;
    View view = this.m;
    if (view != null && s(view, (View)this))
      A(this.m); 
    this.m = null;
    if (!this.l) {
      if (this.z != null) {
        scrollTo(getScrollX(), this.z.e);
        this.z = null;
      } 
      if (getChildCount() > 0) {
        view = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        paramInt1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } 
      int k = getPaddingTop();
      int m = getPaddingBottom();
      paramInt3 = getScrollY();
      paramInt1 = i(paramInt3, paramInt4 - paramInt2 - k - m, paramInt1);
      if (paramInt1 != paramInt3)
        scrollTo(getScrollX(), paramInt1); 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.l = true;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.p)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int k = view.getMeasuredHeight();
      paramInt2 = getMeasuredHeight() - getPaddingTop() - getPaddingBottom() - layoutParams.topMargin - layoutParams.bottomMargin;
      if (k < paramInt2) {
        k = getPaddingLeft();
        view.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingRight() + k + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
      } 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      dispatchNestedFling(0.0F, paramFloat2, true);
      p((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    k(paramInt1, paramInt2, paramArrayOfint, null, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    u(paramInt4, 0, null);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.A.a = paramInt;
    C(2, 0);
  }
  
  public void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  public boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int k;
    View view;
    if (paramInt == 2) {
      k = 130;
    } else {
      k = paramInt;
      if (paramInt == 1)
        k = 33; 
    } 
    if (paramRect == null) {
      view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, null, k);
    } else {
      view = FocusFinder.getInstance().findNextFocusFromRect((ViewGroup)this, paramRect, k);
    } 
    return (view == null) ? false : (((true ^ t(view, 0, getHeight())) != 0) ? false : view.requestFocus(k, paramRect));
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof c)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    c c1 = (c)paramParcelable;
    super.onRestoreInstanceState(c1.getSuperState());
    this.z = c1;
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    c c1 = new c(super.onSaveInstanceState());
    c1.e = getScrollY();
    return (Parcelable)c1;
  }
  
  public void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    b b1 = this.D;
    if (b1 != null) {
      i i1 = (i)b1;
      AlertController.c((View)this, i1.a, i1.b);
    } 
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view != null) {
      if (this == view)
        return; 
      if (t(view, 0, paramInt4)) {
        view.getDrawingRect(this.f);
        offsetDescendantRectToMyCoords(view, this.f);
        l(j(this.f));
      } 
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) != 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    this.A.a = 0;
    this.B.j(0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    AtomicInteger atomicInteger;
    if (this.o == null)
      this.o = VelocityTracker.obtain(); 
    int k = paramMotionEvent.getActionMasked();
    if (k == 0)
      this.x = 0; 
    MotionEvent motionEvent = MotionEvent.obtain(paramMotionEvent);
    motionEvent.offsetLocation(0.0F, this.x);
    if (k != 0) {
      if (k != 1) {
        if (k != 2) {
          if (k != 3) {
            if (k != 5) {
              if (k == 6) {
                v(paramMotionEvent);
                this.j = (int)paramMotionEvent.getY(paramMotionEvent.findPointerIndex(this.u));
              } 
            } else {
              k = paramMotionEvent.getActionIndex();
              this.j = (int)paramMotionEvent.getY(k);
              this.u = paramMotionEvent.getPointerId(k);
            } 
          } else {
            if (this.n && getChildCount() > 0 && this.g.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
              atomicInteger = u.a;
              postInvalidateOnAnimation();
            } 
            this.u = -1;
            m();
          } 
        } else {
          StringBuilder stringBuilder;
          int m = atomicInteger.findPointerIndex(this.u);
          if (m == -1) {
            stringBuilder = d.a.a.a.a.p("Invalid pointerId=");
            stringBuilder.append(this.u);
            stringBuilder.append(" in onTouchEvent");
            Log.e("NestedScrollView", stringBuilder.toString());
          } else {
            int i1 = (int)stringBuilder.getY(m);
            int n = this.j - i1;
            k = n;
            if (!this.n) {
              k = n;
              if (Math.abs(n) > this.r) {
                ViewParent viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
                this.n = true;
                if (n > 0) {
                  k = n - this.r;
                } else {
                  k = n + this.r;
                } 
              } 
            } 
            n = k;
            if (this.n) {
              k = n;
              if (k(0, n, this.w, this.v, 0)) {
                k = n - this.w[1];
                this.x += this.v[1];
              } 
              this.j = i1 - this.v[1];
              int i2 = getScrollY();
              i1 = getScrollRange();
              n = getOverScrollMode();
              if (n == 0 || (n == 1 && i1 > 0)) {
                n = 1;
              } else {
                n = 0;
              } 
              if (w(0, k, 0, getScrollY(), 0, i1, 0, 0) && !r(0))
                this.o.clear(); 
              int i3 = getScrollY() - i2;
              int[] arrayOfInt1 = this.w;
              arrayOfInt1[1] = 0;
              int[] arrayOfInt2 = this.v;
              this.B.f(0, i3, 0, k - i3, arrayOfInt2, 0, arrayOfInt1);
              i3 = this.j;
              arrayOfInt1 = this.v;
              this.j = i3 - arrayOfInt1[1];
              this.x += arrayOfInt1[1];
              if (n != 0) {
                k -= this.w[1];
                n();
                n = i2 + k;
                if (n < 0) {
                  this.h.onPull(k / getHeight(), stringBuilder.getX(m) / getWidth());
                  if (!this.i.isFinished())
                    this.i.onRelease(); 
                } else if (n > i1) {
                  this.i.onPull(k / getHeight(), 1.0F - stringBuilder.getX(m) / getWidth());
                  if (!this.h.isFinished())
                    this.h.onRelease(); 
                } 
                EdgeEffect edgeEffect = this.h;
                if (edgeEffect != null && (!edgeEffect.isFinished() || !this.i.isFinished())) {
                  AtomicInteger atomicInteger1 = u.a;
                  postInvalidateOnAnimation();
                } 
              } 
            } 
          } 
        } 
      } else {
        VelocityTracker velocityTracker1 = this.o;
        velocityTracker1.computeCurrentVelocity(1000, this.t);
        k = (int)velocityTracker1.getYVelocity(this.u);
        if (Math.abs(k) >= this.s) {
          k = -k;
          float f1 = k;
          if (!dispatchNestedPreFling(0.0F, f1)) {
            dispatchNestedFling(0.0F, f1, true);
            p(k);
          } 
        } else if (this.g.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
          atomicInteger = u.a;
          postInvalidateOnAnimation();
        } 
        this.u = -1;
        m();
      } 
    } else {
      if (getChildCount() == 0)
        return false; 
      int m = this.g.isFinished() ^ true;
      this.n = m;
      if (m != 0) {
        ViewParent viewParent = getParent();
        if (viewParent != null)
          viewParent.requestDisallowInterceptTouchEvent(true); 
      } 
      if (!this.g.isFinished())
        g(); 
      this.j = (int)atomicInteger.getY();
      this.u = atomicInteger.getPointerId(0);
      C(2, 0);
    } 
    VelocityTracker velocityTracker = this.o;
    if (velocityTracker != null)
      velocityTracker.addMovement(motionEvent); 
    motionEvent.recycle();
    return true;
  }
  
  public void p(int paramInt) {
    if (getChildCount() > 0) {
      this.g.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      y(true);
    } 
  }
  
  public boolean q(int paramInt) {
    int k;
    if (paramInt == 130) {
      k = 1;
    } else {
      k = 0;
    } 
    int m = getHeight();
    Rect rect = this.f;
    rect.top = 0;
    rect.bottom = m;
    if (k) {
      k = getChildCount();
      if (k > 0) {
        View view = getChildAt(k - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        Rect rect2 = this.f;
        k = view.getBottom();
        int n = layoutParams.bottomMargin;
        rect2.bottom = getPaddingBottom() + k + n;
        Rect rect1 = this.f;
        rect1.top = rect1.bottom - m;
      } 
    } 
    rect = this.f;
    return z(paramInt, rect.top, rect.bottom);
  }
  
  public boolean r(int paramInt) {
    return (this.B.g(paramInt) != null);
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.k) {
      A(paramView2);
    } else {
      this.m = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    boolean bool;
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    int k = j(paramRect);
    if (k != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramBoolean) {
        scrollBy(0, k);
        return bool;
      } 
      B(0, k, 250, false);
    } 
    return bool;
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean)
      x(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    this.k = true;
    super.requestLayout();
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i4 = getWidth();
      int i5 = getPaddingLeft();
      int i6 = getPaddingRight();
      int i7 = view.getWidth();
      int i8 = layoutParams.leftMargin;
      int i9 = layoutParams.rightMargin;
      int k = getHeight();
      int m = getPaddingTop();
      int n = getPaddingBottom();
      int i1 = view.getHeight();
      int i2 = layoutParams.topMargin;
      int i3 = layoutParams.bottomMargin;
      paramInt1 = i(paramInt1, i4 - i5 - i6, i7 + i8 + i9);
      paramInt2 = i(paramInt2, k - m - n, i1 + i2 + i3);
      if (paramInt1 != getScrollX() || paramInt2 != getScrollY())
        super.scrollTo(paramInt1, paramInt2); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.p) {
      this.p = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    g g1 = this.B;
    if (g1.d) {
      View view = g1.c;
      AtomicInteger atomicInteger = u.a;
      view.stopNestedScroll();
    } 
    g1.d = paramBoolean;
  }
  
  public void setOnScrollChangeListener(b paramb) {
    this.D = paramb;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.q = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public boolean startNestedScroll(int paramInt) {
    return this.B.i(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    this.B.j(0);
  }
  
  public final boolean t(View paramView, int paramInt1, int paramInt2) {
    paramView.getDrawingRect(this.f);
    offsetDescendantRectToMyCoords(paramView, this.f);
    return (this.f.bottom + paramInt1 >= getScrollY() && this.f.top - paramInt1 <= getScrollY() + paramInt2);
  }
  
  public final void u(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    int k = getScrollY();
    scrollBy(0, paramInt1);
    k = getScrollY() - k;
    if (paramArrayOfint != null)
      paramArrayOfint[1] = paramArrayOfint[1] + k; 
    this.B.d(0, k, 0, paramInt1 - k, null, paramInt2, paramArrayOfint);
  }
  
  public final void v(MotionEvent paramMotionEvent) {
    int k = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(k) == this.u) {
      if (k == 0) {
        k = 1;
      } else {
        k = 0;
      } 
      this.j = (int)paramMotionEvent.getY(k);
      this.u = paramMotionEvent.getPointerId(k);
      VelocityTracker velocityTracker = this.o;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  public boolean w(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
    boolean bool1;
    int n = getOverScrollMode();
    int k = computeHorizontalScrollRange();
    int m = computeHorizontalScrollExtent();
    boolean bool2 = false;
    if (k > m) {
      k = 1;
    } else {
      k = 0;
    } 
    if (computeVerticalScrollRange() > computeVerticalScrollExtent()) {
      m = 1;
    } else {
      m = 0;
    } 
    if (n == 0 || (n == 1 && k != 0)) {
      k = 1;
    } else {
      k = 0;
    } 
    if (n == 0 || (n == 1 && m != 0)) {
      m = 1;
    } else {
      m = 0;
    } 
    paramInt3 += paramInt1;
    if (k == 0) {
      paramInt1 = 0;
    } else {
      paramInt1 = paramInt7;
    } 
    paramInt4 += paramInt2;
    if (m == 0) {
      paramInt2 = 0;
    } else {
      paramInt2 = paramInt8;
    } 
    paramInt7 = -paramInt1;
    paramInt1 += paramInt5;
    paramInt5 = -paramInt2;
    paramInt2 += paramInt6;
    if (paramInt3 > paramInt1) {
      null = true;
    } else if (paramInt3 < paramInt7) {
      null = true;
      paramInt1 = paramInt7;
    } else {
      null = false;
      paramInt1 = paramInt3;
    } 
    if (paramInt4 > paramInt2) {
      bool1 = true;
    } else if (paramInt4 < paramInt5) {
      bool1 = true;
      paramInt2 = paramInt5;
    } else {
      bool1 = false;
      paramInt2 = paramInt4;
    } 
    if (bool1 && !r(1))
      this.g.springBack(paramInt1, paramInt2, 0, 0, 0, getScrollRange()); 
    onOverScrolled(paramInt1, paramInt2, null, bool1);
    if (!null) {
      null = bool2;
      return bool1 ? true : null;
    } 
    return true;
  }
  
  public final void x() {
    VelocityTracker velocityTracker = this.o;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.o = null;
    } 
  }
  
  public final void y(boolean paramBoolean) {
    if (paramBoolean) {
      C(2, 1);
    } else {
      this.B.j(1);
    } 
    this.y = getScrollY();
    AtomicInteger atomicInteger = u.a;
    postInvalidateOnAnimation();
  }
  
  public final boolean z(int paramInt1, int paramInt2, int paramInt3) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getHeight : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getScrollY : ()I
    //   10: istore #10
    //   12: iload #4
    //   14: iload #10
    //   16: iadd
    //   17: istore #11
    //   19: iload_1
    //   20: bipush #33
    //   22: if_icmpne -> 31
    //   25: iconst_1
    //   26: istore #6
    //   28: goto -> 34
    //   31: iconst_0
    //   32: istore #6
    //   34: aload_0
    //   35: iconst_2
    //   36: invokevirtual getFocusables : (I)Ljava/util/ArrayList;
    //   39: astore #18
    //   41: aload #18
    //   43: invokeinterface size : ()I
    //   48: istore #12
    //   50: aconst_null
    //   51: astore #16
    //   53: iconst_0
    //   54: istore #7
    //   56: iconst_0
    //   57: istore #8
    //   59: iload #7
    //   61: iload #12
    //   63: if_icmpge -> 285
    //   66: aload #18
    //   68: iload #7
    //   70: invokeinterface get : (I)Ljava/lang/Object;
    //   75: checkcast android/view/View
    //   78: astore #17
    //   80: aload #17
    //   82: invokevirtual getTop : ()I
    //   85: istore #9
    //   87: aload #17
    //   89: invokevirtual getBottom : ()I
    //   92: istore #13
    //   94: aload #16
    //   96: astore #15
    //   98: iload #8
    //   100: istore #5
    //   102: iload_2
    //   103: iload #13
    //   105: if_icmpge -> 268
    //   108: aload #16
    //   110: astore #15
    //   112: iload #8
    //   114: istore #5
    //   116: iload #9
    //   118: iload_3
    //   119: if_icmpge -> 268
    //   122: iload_2
    //   123: iload #9
    //   125: if_icmpge -> 140
    //   128: iload #13
    //   130: iload_3
    //   131: if_icmpge -> 140
    //   134: iconst_1
    //   135: istore #4
    //   137: goto -> 143
    //   140: iconst_0
    //   141: istore #4
    //   143: aload #16
    //   145: ifnonnull -> 159
    //   148: aload #17
    //   150: astore #15
    //   152: iload #4
    //   154: istore #5
    //   156: goto -> 268
    //   159: iload #6
    //   161: ifeq -> 174
    //   164: iload #9
    //   166: aload #16
    //   168: invokevirtual getTop : ()I
    //   171: if_icmplt -> 189
    //   174: iload #6
    //   176: ifne -> 195
    //   179: iload #13
    //   181: aload #16
    //   183: invokevirtual getBottom : ()I
    //   186: if_icmple -> 195
    //   189: iconst_1
    //   190: istore #9
    //   192: goto -> 198
    //   195: iconst_0
    //   196: istore #9
    //   198: iload #8
    //   200: ifeq -> 232
    //   203: aload #16
    //   205: astore #15
    //   207: iload #8
    //   209: istore #5
    //   211: iload #4
    //   213: ifeq -> 268
    //   216: aload #16
    //   218: astore #15
    //   220: iload #8
    //   222: istore #5
    //   224: iload #9
    //   226: ifeq -> 268
    //   229: goto -> 260
    //   232: iload #4
    //   234: ifeq -> 247
    //   237: aload #17
    //   239: astore #15
    //   241: iconst_1
    //   242: istore #5
    //   244: goto -> 268
    //   247: aload #16
    //   249: astore #15
    //   251: iload #8
    //   253: istore #5
    //   255: iload #9
    //   257: ifeq -> 268
    //   260: aload #17
    //   262: astore #15
    //   264: iload #8
    //   266: istore #5
    //   268: iload #7
    //   270: iconst_1
    //   271: iadd
    //   272: istore #7
    //   274: aload #15
    //   276: astore #16
    //   278: iload #5
    //   280: istore #8
    //   282: goto -> 59
    //   285: aload #16
    //   287: astore #15
    //   289: aload #16
    //   291: ifnonnull -> 297
    //   294: aload_0
    //   295: astore #15
    //   297: iload_2
    //   298: iload #10
    //   300: if_icmplt -> 315
    //   303: iload_3
    //   304: iload #11
    //   306: if_icmpgt -> 315
    //   309: iconst_0
    //   310: istore #14
    //   312: goto -> 341
    //   315: iload #6
    //   317: ifeq -> 328
    //   320: iload_2
    //   321: iload #10
    //   323: isub
    //   324: istore_2
    //   325: goto -> 333
    //   328: iload_3
    //   329: iload #11
    //   331: isub
    //   332: istore_2
    //   333: aload_0
    //   334: iload_2
    //   335: invokevirtual l : (I)V
    //   338: iconst_1
    //   339: istore #14
    //   341: aload #15
    //   343: aload_0
    //   344: invokevirtual findFocus : ()Landroid/view/View;
    //   347: if_acmpeq -> 357
    //   350: aload #15
    //   352: iload_1
    //   353: invokevirtual requestFocus : (I)Z
    //   356: pop
    //   357: iload #14
    //   359: ireturn
  }
  
  public static class a extends c.h.j.b {
    public void c(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      boolean bool;
      this.a.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityEvent.setClassName(ScrollView.class.getName());
      if (nestedScrollView.getScrollRange() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      param1AccessibilityEvent.setScrollable(bool);
      param1AccessibilityEvent.setScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setScrollY(nestedScrollView.getScrollY());
      param1AccessibilityEvent.setMaxScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setMaxScrollY(nestedScrollView.getScrollRange());
    }
    
    public void d(View param1View, c.h.j.m0.b param1b) {
      this.a.onInitializeAccessibilityNodeInfo(param1View, param1b.a);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      String str = ScrollView.class.getName();
      param1b.a.setClassName(str);
      if (nestedScrollView.isEnabled()) {
        int i = nestedScrollView.getScrollRange();
        if (i > 0) {
          param1b.a.setScrollable(true);
          if (nestedScrollView.getScrollY() > 0) {
            param1b.a(c.h.j.m0.b.a.i);
            param1b.a(c.h.j.m0.b.a.m);
          } 
          if (nestedScrollView.getScrollY() < i) {
            param1b.a(c.h.j.m0.b.a.h);
            param1b.a(c.h.j.m0.b.a.n);
          } 
        } 
      } 
    }
    
    public boolean g(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.g(param1View, param1Int, param1Bundle))
        return true; 
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      if (!nestedScrollView.isEnabled())
        return false; 
      if (param1Int != 4096)
        if (param1Int != 8192 && param1Int != 16908344) {
          if (param1Int != 16908346)
            return false; 
        } else {
          param1Int = nestedScrollView.getHeight();
          int k = nestedScrollView.getPaddingBottom();
          int m = nestedScrollView.getPaddingTop();
          param1Int = Math.max(nestedScrollView.getScrollY() - param1Int - k - m, 0);
          if (param1Int != nestedScrollView.getScrollY()) {
            nestedScrollView.B(0 - nestedScrollView.getScrollX(), param1Int - nestedScrollView.getScrollY(), 250, true);
            return true;
          } 
          return false;
        }  
      param1Int = nestedScrollView.getHeight();
      int i = nestedScrollView.getPaddingBottom();
      int j = nestedScrollView.getPaddingTop();
      param1Int = Math.min(nestedScrollView.getScrollY() + param1Int - i - j, nestedScrollView.getScrollRange());
      if (param1Int != nestedScrollView.getScrollY()) {
        nestedScrollView.B(0 - nestedScrollView.getScrollX(), param1Int - nestedScrollView.getScrollY(), 250, true);
        return true;
      } 
      return false;
    }
  }
  
  public static interface b {}
  
  public static class c extends View.BaseSavedState {
    public static final Parcelable.Creator<c> CREATOR = (Parcelable.Creator<c>)new e();
    
    public int e;
    
    public c(Parcel param1Parcel) {
      super(param1Parcel);
      this.e = param1Parcel.readInt();
    }
    
    public c(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = d.a.a.a.a.p("HorizontalScrollView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" scrollPosition=");
      stringBuilder.append(this.e);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.e);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\core\widget\NestedScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */