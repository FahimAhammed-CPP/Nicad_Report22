package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.lang.reflect.InvocationTargetException;

public class IconCompat extends CustomVersionedParcelable {
  public static final PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;
  
  public int a = -1;
  
  public Object b;
  
  public byte[] c = null;
  
  public Parcelable d = null;
  
  public int e = 0;
  
  public int f = 0;
  
  public ColorStateList g = null;
  
  public PorterDuff.Mode h = k;
  
  public String i = null;
  
  public String j;
  
  public IconCompat() {}
  
  public IconCompat(int paramInt) {
    this.a = paramInt;
  }
  
  public static Bitmap a(Bitmap paramBitmap, boolean paramBoolean) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f1 = i;
    float f2 = 0.5F * f1;
    float f3 = 0.9166667F * f2;
    if (paramBoolean) {
      float f = 0.010416667F * f1;
      paint.setColor(0);
      paint.setShadowLayer(f, 0.0F, f1 * 0.020833334F, 1023410176);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.setShadowLayer(f, 0.0F, 0.0F, 503316480);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.clearShadowLayer();
    } 
    paint.setColor(-16777216);
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, tileMode, tileMode);
    Matrix matrix = new Matrix();
    matrix.setTranslate((-(paramBitmap.getWidth() - i) / 2), (-(paramBitmap.getHeight() - i) / 2));
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f2, f2, f3, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public static IconCompat b(Resources paramResources, String paramString, int paramInt) {
    if (paramInt != 0) {
      IconCompat iconCompat = new IconCompat(2);
      iconCompat.e = paramInt;
      iconCompat.b = paramString;
      iconCompat.j = paramString;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Drawable resource ID must not be 0");
  }
  
  public int c() {
    int i = this.a;
    if (i == -1) {
      i = Build.VERSION.SDK_INT;
      Icon icon = (Icon)this.b;
      if (i >= 28)
        return icon.getResId(); 
      try {
        return ((Integer)icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon resource", illegalAccessException);
        return 0;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon resource", invocationTargetException);
        return 0;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon resource", noSuchMethodException);
        return 0;
      } 
    } 
    if (i == 2)
      return this.e; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int d() {
    int i = this.a;
    if (i == -1) {
      i = Build.VERSION.SDK_INT;
      Icon icon = (Icon)this.b;
      if (i >= 28)
        return icon.getType(); 
      try {
        return ((Integer)icon.getClass().getMethod("getType", new Class[0]).invoke(icon, new Object[0])).intValue();
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to get icon type ");
        stringBuilder.append(icon);
        Log.e("IconCompat", stringBuilder.toString(), illegalAccessException);
        return -1;
      } catch (InvocationTargetException invocationTargetException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to get icon type ");
        stringBuilder.append(icon);
        Log.e("IconCompat", stringBuilder.toString(), invocationTargetException);
        return -1;
      } catch (NoSuchMethodException noSuchMethodException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to get icon type ");
        stringBuilder.append(icon);
        Log.e("IconCompat", stringBuilder.toString(), noSuchMethodException);
        return -1;
      } 
    } 
    return i;
  }
  
  public Uri e() {
    int i = this.a;
    if (i == -1) {
      i = Build.VERSION.SDK_INT;
      Icon icon = (Icon)this.b;
      if (i >= 28)
        return icon.getUri(); 
      try {
        return (Uri)icon.getClass().getMethod("getUri", new Class[0]).invoke(icon, new Object[0]);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon uri", illegalAccessException);
        return null;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon uri", invocationTargetException);
        return null;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon uri", noSuchMethodException);
        return null;
      } 
    } 
    if (i == 4 || i == 6)
      return Uri.parse((String)this.b); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getUri() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  @Deprecated
  public Icon f() {
    return g(null);
  }
  
  public Icon g(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : I
    //   4: istore_2
    //   5: aconst_null
    //   6: astore #4
    //   8: aconst_null
    //   9: astore_3
    //   10: iload_2
    //   11: tableswitch default -> 56, -1 -> 663, 0 -> 56, 1 -> 617, 2 -> 420, 3 -> 398, 4 -> 384, 5 -> 344, 6 -> 66
    //   56: new java/lang/IllegalArgumentException
    //   59: dup
    //   60: ldc 'Unknown type'
    //   62: invokespecial <init> : (Ljava/lang/String;)V
    //   65: athrow
    //   66: getstatic android/os/Build$VERSION.SDK_INT : I
    //   69: bipush #30
    //   71: if_icmplt -> 85
    //   74: aload_0
    //   75: invokevirtual e : ()Landroid/net/Uri;
    //   78: invokestatic createWithAdaptiveBitmapContentUri : (Landroid/net/Uri;)Landroid/graphics/drawable/Icon;
    //   81: astore_1
    //   82: goto -> 628
    //   85: aload_1
    //   86: ifnull -> 316
    //   89: aload_0
    //   90: invokevirtual e : ()Landroid/net/Uri;
    //   93: astore #4
    //   95: aload #4
    //   97: invokevirtual getScheme : ()Ljava/lang/String;
    //   100: astore #5
    //   102: ldc_w 'content'
    //   105: aload #5
    //   107: invokevirtual equals : (Ljava/lang/Object;)Z
    //   110: ifne -> 196
    //   113: ldc_w 'file'
    //   116: aload #5
    //   118: invokevirtual equals : (Ljava/lang/Object;)Z
    //   121: ifeq -> 127
    //   124: goto -> 196
    //   127: new java/io/FileInputStream
    //   130: dup
    //   131: new java/io/File
    //   134: dup
    //   135: aload_0
    //   136: getfield b : Ljava/lang/Object;
    //   139: checkcast java/lang/String
    //   142: invokespecial <init> : (Ljava/lang/String;)V
    //   145: invokespecial <init> : (Ljava/io/File;)V
    //   148: astore_1
    //   149: goto -> 250
    //   152: astore_1
    //   153: new java/lang/StringBuilder
    //   156: dup
    //   157: invokespecial <init> : ()V
    //   160: astore #5
    //   162: aload #5
    //   164: ldc_w 'Unable to load image from path: '
    //   167: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: pop
    //   171: aload #5
    //   173: aload #4
    //   175: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   178: pop
    //   179: ldc 'IconCompat'
    //   181: aload #5
    //   183: invokevirtual toString : ()Ljava/lang/String;
    //   186: aload_1
    //   187: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   190: pop
    //   191: aload_3
    //   192: astore_1
    //   193: goto -> 250
    //   196: aload_1
    //   197: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   200: aload #4
    //   202: invokevirtual openInputStream : (Landroid/net/Uri;)Ljava/io/InputStream;
    //   205: astore_1
    //   206: goto -> 250
    //   209: astore_1
    //   210: new java/lang/StringBuilder
    //   213: dup
    //   214: invokespecial <init> : ()V
    //   217: astore #5
    //   219: aload #5
    //   221: ldc_w 'Unable to load image from URI: '
    //   224: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   227: pop
    //   228: aload #5
    //   230: aload #4
    //   232: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   235: pop
    //   236: ldc 'IconCompat'
    //   238: aload #5
    //   240: invokevirtual toString : ()Ljava/lang/String;
    //   243: aload_1
    //   244: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   247: pop
    //   248: aload_3
    //   249: astore_1
    //   250: aload_1
    //   251: ifnull -> 288
    //   254: getstatic android/os/Build$VERSION.SDK_INT : I
    //   257: bipush #26
    //   259: if_icmplt -> 273
    //   262: aload_1
    //   263: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   266: invokestatic createWithAdaptiveBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   269: astore_1
    //   270: goto -> 628
    //   273: aload_1
    //   274: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   277: iconst_0
    //   278: invokestatic a : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
    //   281: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   284: astore_1
    //   285: goto -> 628
    //   288: ldc_w 'Cannot load adaptive icon from uri: '
    //   291: invokestatic p : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   294: astore_1
    //   295: aload_1
    //   296: aload_0
    //   297: invokevirtual e : ()Landroid/net/Uri;
    //   300: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   303: pop
    //   304: new java/lang/IllegalStateException
    //   307: dup
    //   308: aload_1
    //   309: invokevirtual toString : ()Ljava/lang/String;
    //   312: invokespecial <init> : (Ljava/lang/String;)V
    //   315: athrow
    //   316: ldc_w 'Context is required to resolve the file uri of the icon: '
    //   319: invokestatic p : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   322: astore_1
    //   323: aload_1
    //   324: aload_0
    //   325: invokevirtual e : ()Landroid/net/Uri;
    //   328: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   331: pop
    //   332: new java/lang/IllegalArgumentException
    //   335: dup
    //   336: aload_1
    //   337: invokevirtual toString : ()Ljava/lang/String;
    //   340: invokespecial <init> : (Ljava/lang/String;)V
    //   343: athrow
    //   344: getstatic android/os/Build$VERSION.SDK_INT : I
    //   347: bipush #26
    //   349: if_icmplt -> 366
    //   352: aload_0
    //   353: getfield b : Ljava/lang/Object;
    //   356: checkcast android/graphics/Bitmap
    //   359: invokestatic createWithAdaptiveBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   362: astore_1
    //   363: goto -> 628
    //   366: aload_0
    //   367: getfield b : Ljava/lang/Object;
    //   370: checkcast android/graphics/Bitmap
    //   373: iconst_0
    //   374: invokestatic a : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
    //   377: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   380: astore_1
    //   381: goto -> 628
    //   384: aload_0
    //   385: getfield b : Ljava/lang/Object;
    //   388: checkcast java/lang/String
    //   391: invokestatic createWithContentUri : (Ljava/lang/String;)Landroid/graphics/drawable/Icon;
    //   394: astore_1
    //   395: goto -> 628
    //   398: aload_0
    //   399: getfield b : Ljava/lang/Object;
    //   402: checkcast [B
    //   405: aload_0
    //   406: getfield e : I
    //   409: aload_0
    //   410: getfield f : I
    //   413: invokestatic createWithData : ([BII)Landroid/graphics/drawable/Icon;
    //   416: astore_1
    //   417: goto -> 628
    //   420: iload_2
    //   421: iconst_m1
    //   422: if_icmpne -> 531
    //   425: getstatic android/os/Build$VERSION.SDK_INT : I
    //   428: istore_2
    //   429: aload_0
    //   430: getfield b : Ljava/lang/Object;
    //   433: checkcast android/graphics/drawable/Icon
    //   436: astore_1
    //   437: iload_2
    //   438: bipush #28
    //   440: if_icmplt -> 451
    //   443: aload_1
    //   444: invokevirtual getResPackage : ()Ljava/lang/String;
    //   447: astore_1
    //   448: goto -> 571
    //   451: aload_1
    //   452: invokevirtual getClass : ()Ljava/lang/Class;
    //   455: ldc_w 'getResPackage'
    //   458: iconst_0
    //   459: anewarray java/lang/Class
    //   462: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   465: aload_1
    //   466: iconst_0
    //   467: anewarray java/lang/Object
    //   470: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   473: checkcast java/lang/String
    //   476: astore_1
    //   477: goto -> 571
    //   480: astore_1
    //   481: ldc 'IconCompat'
    //   483: ldc_w 'Unable to get icon package'
    //   486: aload_1
    //   487: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   490: pop
    //   491: aload #4
    //   493: astore_1
    //   494: goto -> 571
    //   497: astore_1
    //   498: ldc 'IconCompat'
    //   500: ldc_w 'Unable to get icon package'
    //   503: aload_1
    //   504: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   507: pop
    //   508: aload #4
    //   510: astore_1
    //   511: goto -> 571
    //   514: astore_1
    //   515: ldc 'IconCompat'
    //   517: ldc_w 'Unable to get icon package'
    //   520: aload_1
    //   521: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   524: pop
    //   525: aload #4
    //   527: astore_1
    //   528: goto -> 571
    //   531: iload_2
    //   532: iconst_2
    //   533: if_icmpne -> 583
    //   536: aload_0
    //   537: getfield j : Ljava/lang/String;
    //   540: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   543: ifeq -> 566
    //   546: aload_0
    //   547: getfield b : Ljava/lang/Object;
    //   550: checkcast java/lang/String
    //   553: ldc_w ':'
    //   556: iconst_m1
    //   557: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   560: iconst_0
    //   561: aaload
    //   562: astore_1
    //   563: goto -> 571
    //   566: aload_0
    //   567: getfield j : Ljava/lang/String;
    //   570: astore_1
    //   571: aload_1
    //   572: aload_0
    //   573: getfield e : I
    //   576: invokestatic createWithResource : (Ljava/lang/String;I)Landroid/graphics/drawable/Icon;
    //   579: astore_1
    //   580: goto -> 628
    //   583: new java/lang/StringBuilder
    //   586: dup
    //   587: invokespecial <init> : ()V
    //   590: astore_1
    //   591: aload_1
    //   592: ldc_w 'called getResPackage() on '
    //   595: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   598: pop
    //   599: aload_1
    //   600: aload_0
    //   601: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   604: pop
    //   605: new java/lang/IllegalStateException
    //   608: dup
    //   609: aload_1
    //   610: invokevirtual toString : ()Ljava/lang/String;
    //   613: invokespecial <init> : (Ljava/lang/String;)V
    //   616: athrow
    //   617: aload_0
    //   618: getfield b : Ljava/lang/Object;
    //   621: checkcast android/graphics/Bitmap
    //   624: invokestatic createWithBitmap : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
    //   627: astore_1
    //   628: aload_0
    //   629: getfield g : Landroid/content/res/ColorStateList;
    //   632: astore_3
    //   633: aload_3
    //   634: ifnull -> 643
    //   637: aload_1
    //   638: aload_3
    //   639: invokevirtual setTintList : (Landroid/content/res/ColorStateList;)Landroid/graphics/drawable/Icon;
    //   642: pop
    //   643: aload_0
    //   644: getfield h : Landroid/graphics/PorterDuff$Mode;
    //   647: astore_3
    //   648: aload_3
    //   649: getstatic androidx/core/graphics/drawable/IconCompat.k : Landroid/graphics/PorterDuff$Mode;
    //   652: if_acmpeq -> 661
    //   655: aload_1
    //   656: aload_3
    //   657: invokevirtual setTintMode : (Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/drawable/Icon;
    //   660: pop
    //   661: aload_1
    //   662: areturn
    //   663: aload_0
    //   664: getfield b : Ljava/lang/Object;
    //   667: checkcast android/graphics/drawable/Icon
    //   670: areturn
    // Exception table:
    //   from	to	target	type
    //   127	149	152	java/io/FileNotFoundException
    //   196	206	209	java/lang/Exception
    //   451	477	514	java/lang/IllegalAccessException
    //   451	477	497	java/lang/reflect/InvocationTargetException
    //   451	477	480	java/lang/NoSuchMethodException
  }
  
  public String toString() {
    String str;
    if (this.a == -1)
      return String.valueOf(this.b); 
    StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
    switch (this.a) {
      default:
        str = "UNKNOWN";
        break;
      case 6:
        str = "URI_MASKABLE";
        break;
      case 5:
        str = "BITMAP_MASKABLE";
        break;
      case 4:
        str = "URI";
        break;
      case 3:
        str = "DATA";
        break;
      case 2:
        str = "RESOURCE";
        break;
      case 1:
        str = "BITMAP";
        break;
    } 
    stringBuilder.append(str);
    switch (this.a) {
      case 4:
      case 6:
        stringBuilder.append(" uri=");
        stringBuilder.append(this.b);
        break;
      case 3:
        stringBuilder.append(" len=");
        stringBuilder.append(this.e);
        if (this.f != 0) {
          stringBuilder.append(" off=");
          stringBuilder.append(this.f);
        } 
        break;
      case 2:
        stringBuilder.append(" pkg=");
        stringBuilder.append(this.j);
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(c()) }));
        break;
      case 1:
      case 5:
        stringBuilder.append(" size=");
        stringBuilder.append(((Bitmap)this.b).getWidth());
        stringBuilder.append("x");
        stringBuilder.append(((Bitmap)this.b).getHeight());
        break;
    } 
    if (this.g != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.g);
    } 
    if (this.h != k) {
      stringBuilder.append(" mode=");
      stringBuilder.append(this.h);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */