package androidx.media;

import c.a0.a;
import c.a0.c;
import java.util.Objects;

public final class AudioAttributesCompatParcelizer {
  public static AudioAttributesCompat read(a parama) {
    c c;
    AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
    AudioAttributesImpl audioAttributesImpl = audioAttributesCompat.a;
    if (!parama.h(1)) {
      c = audioAttributesImpl;
    } else {
      c = c.k();
    } 
    audioAttributesCompat.a = (AudioAttributesImpl)c;
    return audioAttributesCompat;
  }
  
  public static void write(AudioAttributesCompat paramAudioAttributesCompat, a parama) {
    Objects.requireNonNull(parama);
    AudioAttributesImpl audioAttributesImpl = paramAudioAttributesCompat.a;
    parama.l(1);
    parama.o(audioAttributesImpl);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\media\AudioAttributesCompatParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */