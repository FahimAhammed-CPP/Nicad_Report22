package androidx.activity;

import c.a.a;
import c.a.d;
import c.a.e;
import c.p.e;
import c.p.f;
import c.p.g;
import c.p.h;
import c.p.j;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {
  public final Runnable a;
  
  public final ArrayDeque<d> b = new ArrayDeque<d>();
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  public void a(h paramh, d paramd) {
    e e = paramh.l();
    if (((j)e).b == e.b.e)
      return; 
    LifecycleOnBackPressedCancellable lifecycleOnBackPressedCancellable = new LifecycleOnBackPressedCancellable(this, e, paramd);
    paramd.b.add(lifecycleOnBackPressedCancellable);
  }
  
  public void b() {
    Iterator<d> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      d d = iterator.next();
      if (d.a) {
        d.a();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  public class LifecycleOnBackPressedCancellable implements f, a {
    public final e e;
    
    public final d f;
    
    public a g;
    
    public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, e param1e, d param1d) {
      this.e = param1e;
      this.f = param1d;
      param1e.a((g)this);
    }
    
    public void cancel() {
      ((j)this.e).a.k(this);
      this.f.b.remove(this);
      a a1 = this.g;
      if (a1 != null) {
        a1.cancel();
        this.g = null;
      } 
    }
    
    public void d(h param1h, e.a param1a) {
      e e1;
      if (param1a == e.a.ON_START) {
        OnBackPressedDispatcher onBackPressedDispatcher = this.h;
        d d1 = this.f;
        onBackPressedDispatcher.b.add(d1);
        e1 = new e(onBackPressedDispatcher, d1);
        d1.b.add(e1);
        this.g = (a)e1;
        return;
      } 
      if (e1 == e.a.ON_STOP) {
        a a1 = this.g;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (e1 == e.a.ON_DESTROY) {
        cancel();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */