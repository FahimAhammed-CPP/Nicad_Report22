package androidx.activity;

import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import c.p.e;
import c.p.f;
import c.p.h;
import java.lang.reflect.Field;

public final class ImmLeaksCleaner implements f {
  public static int f;
  
  public static Field g;
  
  public static Field h;
  
  public static Field i;
  
  public Activity e;
  
  public ImmLeaksCleaner(Activity paramActivity) {
    this.e = paramActivity;
  }
  
  public void d(h paramh, e.a parama) {
    if (parama != e.a.ON_DESTROY)
      return; 
    if (f == 0)
      try {
        f = 2;
        Field field = InputMethodManager.class.getDeclaredField("mServedView");
        h = field;
        field.setAccessible(true);
        field = InputMethodManager.class.getDeclaredField("mNextServedView");
        i = field;
        field.setAccessible(true);
        field = InputMethodManager.class.getDeclaredField("mH");
        g = field;
        field.setAccessible(true);
        f = 1;
      } catch (NoSuchFieldException noSuchFieldException) {} 
    if (f == 1) {
      InputMethodManager inputMethodManager = (InputMethodManager)this.e.getSystemService("input_method");
      try {
        Object object = g.get(inputMethodManager);
        if (object == null)
          return; 
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        try {
          View view = (View)h.get(inputMethodManager);
          if (view == null) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          if (view.isAttachedToWindow()) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          try {
            i.set(inputMethodManager, null);
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            inputMethodManager.isActive();
            return;
          } catch (IllegalAccessException illegalAccessException) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
        } catch (IllegalAccessException illegalAccessException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } catch (ClassCastException classCastException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } finally {}
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        throw inputMethodManager;
      } catch (IllegalAccessException illegalAccessException) {
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\activity\ImmLeaksCleaner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */