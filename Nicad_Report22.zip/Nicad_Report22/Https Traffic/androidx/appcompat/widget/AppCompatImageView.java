package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import c.b.h.f2;
import c.b.h.h2;
import c.b.h.o;
import c.b.h.x;

public class AppCompatImageView extends ImageView {
  public final o e;
  
  public final x f;
  
  public AppCompatImageView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public AppCompatImageView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    f2.a((View)this, getContext());
    o o1 = new o((View)this);
    this.e = o1;
    o1.d(paramAttributeSet, paramInt);
    x x1 = new x(this);
    this.f = x1;
    x1.b(paramAttributeSet, paramInt);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    o o1 = this.e;
    if (o1 != null)
      o1.a(); 
    x x1 = this.f;
    if (x1 != null)
      x1.a(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    o o1 = this.e;
    return (o1 != null) ? o1.b() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    o o1 = this.e;
    return (o1 != null) ? o1.c() : null;
  }
  
  public ColorStateList getSupportImageTintList() {
    x x1 = this.f;
    if (x1 != null) {
      h2 h2 = x1.b;
      if (h2 != null)
        return h2.a; 
    } 
    return null;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    x x1 = this.f;
    if (x1 != null) {
      h2 h2 = x1.b;
      if (h2 != null)
        return h2.b; 
    } 
    return null;
  }
  
  public boolean hasOverlappingRendering() {
    return ((this.f.a.getBackground() instanceof android.graphics.drawable.RippleDrawable ^ true) != 0 && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    o o1 = this.e;
    if (o1 != null)
      o1.e(); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    o o1 = this.e;
    if (o1 != null)
      o1.f(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    x x1 = this.f;
    if (x1 != null)
      x1.a(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    super.setImageDrawable(paramDrawable);
    x x1 = this.f;
    if (x1 != null)
      x1.a(); 
  }
  
  public void setImageResource(int paramInt) {
    x x1 = this.f;
    if (x1 != null)
      x1.c(paramInt); 
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    x x1 = this.f;
    if (x1 != null)
      x1.a(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    o o1 = this.e;
    if (o1 != null)
      o1.h(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    o o1 = this.e;
    if (o1 != null)
      o1.i(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    x x1 = this.f;
    if (x1 != null)
      x1.d(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    x x1 = this.f;
    if (x1 != null)
      x1.e(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\appcompat\widget\AppCompatImageView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */