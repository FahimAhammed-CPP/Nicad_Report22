package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import c.b.c.b1;
import c.b.g.l;
import c.b.g.n.l;
import c.b.g.n.o;
import c.b.g.n.y;
import c.b.h.a1;
import c.b.h.b1;
import c.b.h.m;
import c.b.h.n2;
import c.h.j.b0;
import c.h.j.c0;
import c.h.j.d0;
import c.h.j.h;
import c.h.j.i;
import c.h.j.j;
import c.h.j.l0;
import c.h.j.u;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class ActionBarOverlayLayout extends ViewGroup implements a1, h, i {
  public static final int[] J = new int[] { 2130903043, 16842841 };
  
  public l0 A;
  
  public l0 B;
  
  public d C;
  
  public OverScroller D;
  
  public ViewPropertyAnimator E;
  
  public final AnimatorListenerAdapter F;
  
  public final Runnable G;
  
  public final Runnable H;
  
  public final j I;
  
  public int e;
  
  public int f = 0;
  
  public ContentFrameLayout g;
  
  public ActionBarContainer h;
  
  public b1 i;
  
  public Drawable j;
  
  public boolean k;
  
  public boolean l;
  
  public boolean m;
  
  public boolean n;
  
  public boolean o;
  
  public int p;
  
  public int q;
  
  public final Rect r = new Rect();
  
  public final Rect s = new Rect();
  
  public final Rect t = new Rect();
  
  public final Rect u = new Rect();
  
  public final Rect v = new Rect();
  
  public final Rect w = new Rect();
  
  public final Rect x = new Rect();
  
  public l0 y;
  
  public l0 z;
  
  public ActionBarOverlayLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    l0 l01 = l0.b;
    this.y = l01;
    this.z = l01;
    this.A = l01;
    this.B = l01;
    this.F = new a(this);
    this.G = new b(this);
    this.H = new c(this);
    j(paramContext);
    this.I = new j();
  }
  
  public void a(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    if (paramInt2 == 0)
      onNestedScrollAccepted(paramView1, paramView2, paramInt1); 
  }
  
  public void b(View paramView, int paramInt) {
    if (paramInt == 0)
      onStopNestedScroll(paramView); 
  }
  
  public void c(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    if (paramInt3 == 0)
      onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint); 
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof e;
  }
  
  public void d(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    if (this.j != null && !this.k) {
      byte b;
      if (this.h.getVisibility() == 0) {
        float f = this.h.getBottom();
        b = (int)(this.h.getTranslationY() + f + 0.5F);
      } else {
        b = 0;
      } 
      this.j.setBounds(0, b, getWidth(), this.j.getIntrinsicHeight() + b);
      this.j.draw(paramCanvas);
    } 
  }
  
  public void e(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public boolean f(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return (paramInt2 == 0 && onStartNestedScroll(paramView1, paramView2, paramInt1));
  }
  
  public boolean fitSystemWindows(Rect paramRect) {
    return super.fitSystemWindows(paramRect);
  }
  
  public final boolean g(View paramView, Rect paramRect, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast androidx/appcompat/widget/ActionBarOverlayLayout$e
    //   7: astore_1
    //   8: iload_3
    //   9: ifeq -> 43
    //   12: aload_1
    //   13: getfield leftMargin : I
    //   16: istore #7
    //   18: aload_2
    //   19: getfield left : I
    //   22: istore #8
    //   24: iload #7
    //   26: iload #8
    //   28: if_icmpeq -> 43
    //   31: aload_1
    //   32: iload #8
    //   34: putfield leftMargin : I
    //   37: iconst_1
    //   38: istore #9
    //   40: goto -> 46
    //   43: iconst_0
    //   44: istore #9
    //   46: iload #9
    //   48: istore_3
    //   49: iload #4
    //   51: ifeq -> 84
    //   54: aload_1
    //   55: getfield topMargin : I
    //   58: istore #7
    //   60: aload_2
    //   61: getfield top : I
    //   64: istore #8
    //   66: iload #9
    //   68: istore_3
    //   69: iload #7
    //   71: iload #8
    //   73: if_icmpeq -> 84
    //   76: aload_1
    //   77: iload #8
    //   79: putfield topMargin : I
    //   82: iconst_1
    //   83: istore_3
    //   84: iload_3
    //   85: istore #4
    //   87: iload #6
    //   89: ifeq -> 123
    //   92: aload_1
    //   93: getfield rightMargin : I
    //   96: istore #7
    //   98: aload_2
    //   99: getfield right : I
    //   102: istore #8
    //   104: iload_3
    //   105: istore #4
    //   107: iload #7
    //   109: iload #8
    //   111: if_icmpeq -> 123
    //   114: aload_1
    //   115: iload #8
    //   117: putfield rightMargin : I
    //   120: iconst_1
    //   121: istore #4
    //   123: iload #5
    //   125: ifeq -> 155
    //   128: aload_1
    //   129: getfield bottomMargin : I
    //   132: istore #7
    //   134: aload_2
    //   135: getfield bottom : I
    //   138: istore #8
    //   140: iload #7
    //   142: iload #8
    //   144: if_icmpeq -> 155
    //   147: aload_1
    //   148: iload #8
    //   150: putfield bottomMargin : I
    //   153: iconst_1
    //   154: ireturn
    //   155: iload #4
    //   157: ireturn
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new e(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new e(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new e(paramLayoutParams);
  }
  
  public int getActionBarHideOffset() {
    ActionBarContainer actionBarContainer = this.h;
    return (actionBarContainer != null) ? -((int)actionBarContainer.getTranslationY()) : 0;
  }
  
  public int getNestedScrollAxes() {
    return this.I.a();
  }
  
  public CharSequence getTitle() {
    m();
    return ((n2)this.i).a.getTitle();
  }
  
  public boolean h() {
    m();
    Toolbar toolbar = ((n2)this.i).a;
    if (toolbar.getVisibility() == 0) {
      ActionMenuView actionMenuView = toolbar.e;
      if (actionMenuView != null && actionMenuView.w)
        return true; 
    } 
    return false;
  }
  
  public void i() {
    removeCallbacks(this.G);
    removeCallbacks(this.H);
    ViewPropertyAnimator viewPropertyAnimator = this.E;
    if (viewPropertyAnimator != null)
      viewPropertyAnimator.cancel(); 
  }
  
  public final void j(Context paramContext) {
    TypedArray typedArray = getContext().getTheme().obtainStyledAttributes(J);
    boolean bool2 = false;
    this.e = typedArray.getDimensionPixelSize(0, 0);
    Drawable drawable = typedArray.getDrawable(1);
    this.j = drawable;
    if (drawable == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    setWillNotDraw(bool1);
    typedArray.recycle();
    boolean bool1 = bool2;
    if ((paramContext.getApplicationInfo()).targetSdkVersion < 19)
      bool1 = true; 
    this.k = bool1;
    this.D = new OverScroller(paramContext);
  }
  
  public void k(int paramInt) {
    m();
    if (paramInt != 2) {
      if (paramInt != 5) {
        if (paramInt != 109)
          return; 
        setOverlayMode(true);
        return;
      } 
      Objects.requireNonNull((n2)this.i);
      Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
      return;
    } 
    Objects.requireNonNull((n2)this.i);
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public boolean l() {
    m();
    return ((n2)this.i).a.o();
  }
  
  public void m() {
    if (this.g == null) {
      b1 b11;
      this.g = (ContentFrameLayout)findViewById(2131230770);
      this.h = (ActionBarContainer)findViewById(2131230771);
      View view = findViewById(2131230769);
      if (view instanceof b1) {
        b11 = (b1)view;
      } else if (b11 instanceof Toolbar) {
        b11 = ((Toolbar)b11).getWrapper();
      } else {
        StringBuilder stringBuilder = d.a.a.a.a.p("Can't make a decor toolbar out of ");
        stringBuilder.append(b11.getClass().getSimpleName());
        throw new IllegalStateException(stringBuilder.toString());
      } 
      this.i = b11;
      return;
    } 
  }
  
  public void n(Menu paramMenu, y.a parama) {
    m();
    n2 n2 = (n2)this.i;
    if (n2.n == null) {
      m m1 = new m(n2.a.getContext());
      n2.n = m1;
      m1.m = 2131230781;
    } 
    m m = n2.n;
    m.i = parama;
    Toolbar toolbar = n2.a;
    l l1 = (l)paramMenu;
    if (l1 == null && toolbar.e == null)
      return; 
    toolbar.f();
    l l2 = toolbar.e.t;
    if (l2 == l1)
      return; 
    if (l2 != null) {
      l2.u((y)toolbar.N);
      l2.u(toolbar.O);
    } 
    if (toolbar.O == null)
      toolbar.O = new Toolbar.d(toolbar); 
    m.v = true;
    if (l1 != null) {
      l1.b((y)m, toolbar.n);
      l1.b(toolbar.O, toolbar.n);
    } else {
      m.c(toolbar.n, null);
      Toolbar.d d1 = toolbar.O;
      l2 = d1.e;
      if (l2 != null) {
        o o = d1.f;
        if (o != null)
          l2.d(o); 
      } 
      d1.e = null;
      m.h(true);
      toolbar.O.h(true);
    } 
    toolbar.e.setPopupTheme(toolbar.o);
    toolbar.e.setPresenter(m);
    toolbar.N = m;
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    m();
    l0 l01 = l0.i(paramWindowInsets, null);
    Rect rect = new Rect(l01.c(), l01.e(), l01.d(), l01.b());
    boolean bool1 = g((View)this.h, rect, true, true, false, true);
    rect = this.r;
    AtomicInteger atomicInteger = u.a;
    WindowInsets windowInsets = l01.g();
    if (windowInsets != null) {
      l0.i(computeSystemWindowInsets(windowInsets, rect), (View)this);
    } else {
      rect.setEmpty();
    } 
    rect = this.r;
    int k = rect.left;
    int m = rect.top;
    int n = rect.right;
    int i1 = rect.bottom;
    l0 l02 = l01.a.i(k, m, n, i1);
    this.y = l02;
    boolean bool2 = this.z.equals(l02);
    boolean bool = true;
    if (!bool2) {
      this.z = this.y;
      bool1 = true;
    } 
    if (!this.s.equals(this.r)) {
      this.s.set(this.r);
      bool1 = bool;
    } 
    if (bool1)
      requestLayout(); 
    return (l01.a.a().a()).a.b().g();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    j(getContext());
    AtomicInteger atomicInteger = u.a;
    requestApplyInsets();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    i();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = getChildCount();
    paramInt3 = getPaddingLeft();
    paramInt4 = getPaddingTop();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      View view = getChildAt(paramInt1);
      if (view.getVisibility() != 8) {
        e e = (e)view.getLayoutParams();
        int k = view.getMeasuredWidth();
        int m = view.getMeasuredHeight();
        int n = e.leftMargin + paramInt3;
        int i1 = e.topMargin + paramInt4;
        view.layout(n, i1, k + n, m + i1);
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    m();
    measureChildWithMargins((View)this.h, paramInt1, 0, paramInt2, 0);
    e e2 = (e)this.h.getLayoutParams();
    int i3 = Math.max(0, this.h.getMeasuredWidth() + e2.leftMargin + e2.rightMargin);
    int i2 = Math.max(0, this.h.getMeasuredHeight() + e2.topMargin + e2.bottomMargin);
    int i1 = View.combineMeasuredStates(0, this.h.getMeasuredState());
    AtomicInteger atomicInteger = u.a;
    if ((getWindowSystemUiVisibility() & 0x100) != 0) {
      m = 1;
    } else {
      m = 0;
    } 
    if (m) {
      int i4 = this.e;
      k = i4;
      if (this.m) {
        k = i4;
        if (this.h.getTabContainer() != null)
          k = i4 + this.e; 
      } 
    } else if (this.h.getVisibility() != 8) {
      k = this.h.getMeasuredHeight();
    } else {
      k = 0;
    } 
    this.t.set(this.r);
    l0 l01 = this.y;
    this.A = l01;
    if (!this.l && !m) {
      Rect rect = this.t;
      rect.top += k;
      rect.bottom += 0;
      this.A = l01.a.i(0, k, 0, 0);
    } else {
      d0 d0;
      b0 b0;
      c.h.d.b b = c.h.d.b.a(l01.c(), this.A.e() + k, this.A.d(), this.A.b() + 0);
      l01 = this.A;
      k = Build.VERSION.SDK_INT;
      if (k >= 30) {
        d0 = new d0(l01);
      } else {
        c0 c0;
        if (k >= 29) {
          c0 = new c0((l0)d0);
        } else {
          b0 = new b0((l0)c0);
        } 
      } 
      b0.c(b);
      this.A = b0.a();
    } 
    g((View)this.g, this.t, true, true, true, true);
    if (!this.B.equals(this.A)) {
      l01 = this.A;
      this.B = l01;
      u.c((View)this.g, l01);
    } 
    measureChildWithMargins((View)this.g, paramInt1, 0, paramInt2, 0);
    e e1 = (e)this.g.getLayoutParams();
    int k = Math.max(i3, this.g.getMeasuredWidth() + e1.leftMargin + e1.rightMargin);
    int m = Math.max(i2, this.g.getMeasuredHeight() + e1.topMargin + e1.bottomMargin);
    int n = View.combineMeasuredStates(i1, this.g.getMeasuredState());
    i1 = getPaddingLeft();
    i2 = getPaddingRight();
    i3 = getPaddingTop();
    m = Math.max(getPaddingBottom() + i3 + m, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i2 + i1 + k, getSuggestedMinimumWidth()), paramInt1, n), View.resolveSizeAndState(m, paramInt2, n << 16));
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    boolean bool1 = this.n;
    boolean bool = false;
    if (bool1) {
      if (!paramBoolean)
        return false; 
      this.D.fling(0, 0, 0, (int)paramFloat2, 0, 0, -2147483648, 2147483647);
      if (this.D.getFinalY() > this.h.getHeight())
        bool = true; 
      if (bool) {
        i();
        this.H.run();
      } else {
        i();
        this.G.run();
      } 
      this.o = true;
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {}
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt1 = this.p + paramInt2;
    this.p = paramInt1;
    setActionBarHideOffset(paramInt1);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.I.a = paramInt;
    this.p = getActionBarHideOffset();
    i();
    d d1 = this.C;
    if (d1 != null) {
      b1 b11 = (b1)d1;
      l l = b11.t;
      if (l != null) {
        l.a();
        b11.t = null;
      } 
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) == 0 || this.h.getVisibility() != 0) ? false : this.n;
  }
  
  public void onStopNestedScroll(View paramView) {
    if (this.n && !this.o)
      if (this.p <= this.h.getHeight()) {
        i();
        postDelayed(this.G, 600L);
      } else {
        i();
        postDelayed(this.H, 600L);
      }  
    d d1 = this.C;
    if (d1 != null)
      Objects.requireNonNull((b1)d1); 
  }
  
  public void onWindowSystemUiVisibilityChanged(int paramInt) {
    boolean bool1;
    boolean bool2;
    super.onWindowSystemUiVisibilityChanged(paramInt);
    m();
    int k = this.q;
    this.q = paramInt;
    if ((paramInt & 0x4) == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((paramInt & 0x100) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    d d1 = this.C;
    if (d1 != null) {
      b1 b11;
      ((b1)d1).p = bool2 ^ true;
      if (bool1 || !bool2) {
        b11 = (b1)d1;
        if (b11.q) {
          b11.q = false;
          b11.v(true);
        } 
      } else {
        b11 = b11;
        if (!b11.q) {
          b11.q = true;
          b11.v(true);
        } 
      } 
    } 
    if (((k ^ paramInt) & 0x100) != 0 && this.C != null) {
      AtomicInteger atomicInteger = u.a;
      requestApplyInsets();
    } 
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    this.f = paramInt;
    d d1 = this.C;
    if (d1 != null)
      ((b1)d1).o = paramInt; 
  }
  
  public void setActionBarHideOffset(int paramInt) {
    i();
    paramInt = Math.max(0, Math.min(paramInt, this.h.getHeight()));
    this.h.setTranslationY(-paramInt);
  }
  
  public void setActionBarVisibilityCallback(d paramd) {
    this.C = paramd;
    if (getWindowToken() != null) {
      paramd = this.C;
      int k = this.f;
      ((b1)paramd).o = k;
      k = this.q;
      if (k != 0) {
        onWindowSystemUiVisibilityChanged(k);
        AtomicInteger atomicInteger = u.a;
        requestApplyInsets();
      } 
    } 
  }
  
  public void setHasNonEmbeddedTabs(boolean paramBoolean) {
    this.m = paramBoolean;
  }
  
  public void setHideOnContentScrollEnabled(boolean paramBoolean) {
    if (paramBoolean != this.n) {
      this.n = paramBoolean;
      if (!paramBoolean) {
        i();
        setActionBarHideOffset(0);
      } 
    } 
  }
  
  public void setIcon(int paramInt) {
    Drawable drawable;
    m();
    n2 n2 = (n2)this.i;
    if (paramInt != 0) {
      drawable = c.b.d.a.a.a(n2.a(), paramInt);
    } else {
      drawable = null;
    } 
    n2.e = drawable;
    n2.j();
  }
  
  public void setIcon(Drawable paramDrawable) {
    m();
    n2 n2 = (n2)this.i;
    n2.e = paramDrawable;
    n2.j();
  }
  
  public void setLogo(int paramInt) {
    Drawable drawable;
    m();
    n2 n2 = (n2)this.i;
    if (paramInt != 0) {
      drawable = c.b.d.a.a.a(n2.a(), paramInt);
    } else {
      drawable = null;
    } 
    n2.f = drawable;
    n2.j();
  }
  
  public void setOverlayMode(boolean paramBoolean) {
    this.l = paramBoolean;
    if (paramBoolean && (getContext().getApplicationInfo()).targetSdkVersion < 19) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.k = paramBoolean;
  }
  
  public void setShowingForActionMode(boolean paramBoolean) {}
  
  public void setUiOptions(int paramInt) {}
  
  public void setWindowCallback(Window.Callback paramCallback) {
    m();
    ((n2)this.i).l = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    m();
    ((n2)this.i).f(paramCharSequence);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public class a extends AnimatorListenerAdapter {
    public a(ActionBarOverlayLayout this$0) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.E = null;
      actionBarOverlayLayout.o = false;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.E = null;
      actionBarOverlayLayout.o = false;
    }
  }
  
  public class b implements Runnable {
    public b(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.e.i();
      ActionBarOverlayLayout actionBarOverlayLayout = this.e;
      actionBarOverlayLayout.E = actionBarOverlayLayout.h.animate().translationY(0.0F).setListener((Animator.AnimatorListener)this.e.F);
    }
  }
  
  public class c implements Runnable {
    public c(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.e.i();
      ActionBarOverlayLayout actionBarOverlayLayout = this.e;
      actionBarOverlayLayout.E = actionBarOverlayLayout.h.animate().translationY(-this.e.h.getHeight()).setListener((Animator.AnimatorListener)this.e.F);
    }
  }
  
  public static interface d {}
  
  public static class e extends ViewGroup.MarginLayoutParams {
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\appcompat\widget\ActionBarOverlayLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */