package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import c.b.g.n.b0;
import c.b.g.n.l;
import c.b.g.n.o;
import c.b.g.n.v;
import c.b.g.n.z;
import c.b.h.d;
import c.b.h.e;
import c.b.h.j1;
import c.b.h.u0;

public class ActionMenuItemView extends u0 implements z.a, View.OnClickListener, ActionMenuView.a {
  public o i;
  
  public CharSequence j;
  
  public Drawable k;
  
  public l.b l;
  
  public j1 m;
  
  public b n;
  
  public boolean o;
  
  public boolean p;
  
  public int q;
  
  public int r;
  
  public int s;
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    Resources resources = paramContext.getResources();
    this.o = p();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, c.b.b.c, 0, 0);
    this.q = typedArray.getDimensionPixelSize(0, 0);
    typedArray.recycle();
    this.s = (int)((resources.getDisplayMetrics()).density * 32.0F + 0.5F);
    setOnClickListener(this);
    this.r = -1;
    setSaveEnabled(false);
  }
  
  public boolean a() {
    return g();
  }
  
  public boolean b() {
    return (g() && this.i.getIcon() == null);
  }
  
  public void f(o paramo, int paramInt) {
    this.i = paramo;
    setIcon(paramo.getIcon());
    setTitle(paramo.getTitleCondensed());
    setId(paramo.a);
    if (paramo.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setEnabled(paramo.isEnabled());
    if (paramo.hasSubMenu() && this.m == null)
      this.m = new a(this); 
  }
  
  public boolean g() {
    return TextUtils.isEmpty(getText()) ^ true;
  }
  
  public o getItemData() {
    return this.i;
  }
  
  public void onClick(View paramView) {
    l.b b1 = this.l;
    if (b1 != null)
      b1.a(this.i); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.o = p();
    q();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool = g();
    if (bool) {
      int k = this.r;
      if (k >= 0)
        super.setPadding(k, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
    } 
    super.onMeasure(paramInt1, paramInt2);
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int j = getMeasuredWidth();
    if (i == Integer.MIN_VALUE) {
      paramInt1 = Math.min(paramInt1, this.q);
    } else {
      paramInt1 = this.q;
    } 
    if (i != 1073741824 && this.q > 0 && j < paramInt1)
      super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2); 
    if (!bool && this.k != null)
      super.setPadding((getMeasuredWidth() - this.k.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    super.onRestoreInstanceState(null);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.i.hasSubMenu()) {
      j1 j11 = this.m;
      if (j11 != null && j11.onTouch((View)this, paramMotionEvent))
        return true; 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public final boolean p() {
    Configuration configuration = getContext().getResources().getConfiguration();
    int i = configuration.screenWidthDp;
    int j = configuration.screenHeightDp;
    return (i >= 480 || (i >= 640 && j >= 480) || configuration.orientation == 2);
  }
  
  public final void q() {
    // Byte code:
    //   0: aload_0
    //   1: getfield j : Ljava/lang/CharSequence;
    //   4: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   7: istore_3
    //   8: iconst_1
    //   9: istore_2
    //   10: iload_2
    //   11: istore_1
    //   12: aload_0
    //   13: getfield k : Landroid/graphics/drawable/Drawable;
    //   16: ifnull -> 66
    //   19: aload_0
    //   20: getfield i : Lc/b/g/n/o;
    //   23: getfield y : I
    //   26: iconst_4
    //   27: iand
    //   28: iconst_4
    //   29: if_icmpne -> 37
    //   32: iconst_1
    //   33: istore_1
    //   34: goto -> 39
    //   37: iconst_0
    //   38: istore_1
    //   39: iload_1
    //   40: ifeq -> 64
    //   43: iload_2
    //   44: istore_1
    //   45: aload_0
    //   46: getfield o : Z
    //   49: ifne -> 66
    //   52: aload_0
    //   53: getfield p : Z
    //   56: ifeq -> 64
    //   59: iload_2
    //   60: istore_1
    //   61: goto -> 66
    //   64: iconst_0
    //   65: istore_1
    //   66: iload_3
    //   67: iconst_1
    //   68: ixor
    //   69: iload_1
    //   70: iand
    //   71: istore_1
    //   72: aconst_null
    //   73: astore #5
    //   75: iload_1
    //   76: ifeq -> 88
    //   79: aload_0
    //   80: getfield j : Ljava/lang/CharSequence;
    //   83: astore #4
    //   85: goto -> 91
    //   88: aconst_null
    //   89: astore #4
    //   91: aload_0
    //   92: aload #4
    //   94: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   97: aload_0
    //   98: getfield i : Lc/b/g/n/o;
    //   101: getfield q : Ljava/lang/CharSequence;
    //   104: astore #4
    //   106: aload #4
    //   108: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   111: ifeq -> 142
    //   114: iload_1
    //   115: ifeq -> 124
    //   118: aconst_null
    //   119: astore #4
    //   121: goto -> 133
    //   124: aload_0
    //   125: getfield i : Lc/b/g/n/o;
    //   128: getfield e : Ljava/lang/CharSequence;
    //   131: astore #4
    //   133: aload_0
    //   134: aload #4
    //   136: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   139: goto -> 148
    //   142: aload_0
    //   143: aload #4
    //   145: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   148: aload_0
    //   149: getfield i : Lc/b/g/n/o;
    //   152: getfield r : Ljava/lang/CharSequence;
    //   155: astore #4
    //   157: aload #4
    //   159: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   162: ifeq -> 192
    //   165: iload_1
    //   166: ifeq -> 176
    //   169: aload #5
    //   171: astore #4
    //   173: goto -> 185
    //   176: aload_0
    //   177: getfield i : Lc/b/g/n/o;
    //   180: getfield e : Ljava/lang/CharSequence;
    //   183: astore #4
    //   185: aload_0
    //   186: aload #4
    //   188: invokestatic f : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   191: return
    //   192: aload_0
    //   193: aload #4
    //   195: invokestatic f : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   198: return
  }
  
  public void setCheckable(boolean paramBoolean) {}
  
  public void setChecked(boolean paramBoolean) {}
  
  public void setExpandedFormat(boolean paramBoolean) {
    if (this.p != paramBoolean) {
      this.p = paramBoolean;
      o o1 = this.i;
      if (o1 != null)
        o1.n.p(); 
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.k = paramDrawable;
    if (paramDrawable != null) {
      int m = paramDrawable.getIntrinsicWidth();
      int n = paramDrawable.getIntrinsicHeight();
      int k = this.s;
      int i = m;
      int j = n;
      if (m > k) {
        float f = k / m;
        j = (int)(n * f);
        i = k;
      } 
      if (j > k) {
        float f = k / j;
        i = (int)(i * f);
      } else {
        k = j;
      } 
      paramDrawable.setBounds(0, 0, i, k);
    } 
    setCompoundDrawables(paramDrawable, null, null, null);
    q();
  }
  
  public void setItemInvoker(l.b paramb) {
    this.l = paramb;
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.r = paramInt1;
    super.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setPopupCallback(b paramb) {
    this.n = paramb;
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.j = paramCharSequence;
    q();
  }
  
  public class a extends j1 {
    public a(ActionMenuItemView this$0) {
      super((View)this$0);
    }
    
    public b0 b() {
      ActionMenuItemView.b b = this.n.n;
      v v2 = null;
      v v1 = v2;
      if (b != null) {
        d d = ((e)b).a.z;
        v1 = v2;
        if (d != null)
          v1 = d.a(); 
      } 
      return (b0)v1;
    }
    
    public boolean c() {
      ActionMenuItemView actionMenuItemView = this.n;
      l.b b = actionMenuItemView.l;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (b != null) {
        bool1 = bool2;
        if (b.a(actionMenuItemView.i)) {
          b0 b0 = b();
          bool1 = bool2;
          if (b0 != null) {
            bool1 = bool2;
            if (b0.b())
              bool1 = true; 
          } 
        } 
      } 
      return bool1;
    }
  }
  
  public static abstract class b {}
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\appcompat\view\menu\ActionMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */