package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import c.b.b;
import c.b.c.h;
import c.b.c.l;
import c.b.c.o;

public class AlertController {
  public NestedScrollView A;
  
  public int B = 0;
  
  public Drawable C;
  
  public ImageView D;
  
  public TextView E;
  
  public TextView F;
  
  public View G;
  
  public ListAdapter H;
  
  public int I = -1;
  
  public int J;
  
  public int K;
  
  public int L;
  
  public int M;
  
  public int N;
  
  public int O;
  
  public boolean P;
  
  public Handler Q;
  
  public final View.OnClickListener R = (View.OnClickListener)new h(this);
  
  public final Context a;
  
  public final o b;
  
  public final Window c;
  
  public final int d;
  
  public CharSequence e;
  
  public CharSequence f;
  
  public ListView g;
  
  public View h;
  
  public int i;
  
  public int j;
  
  public int k;
  
  public int l;
  
  public int m;
  
  public boolean n = false;
  
  public Button o;
  
  public CharSequence p;
  
  public Message q;
  
  public Drawable r;
  
  public Button s;
  
  public CharSequence t;
  
  public Message u;
  
  public Drawable v;
  
  public Button w;
  
  public CharSequence x;
  
  public Message y;
  
  public Drawable z;
  
  public AlertController(Context paramContext, o paramo, Window paramWindow) {
    this.a = paramContext;
    this.b = paramo;
    this.c = paramWindow;
    this.Q = (Handler)new l((DialogInterface)paramo);
    TypedArray typedArray = paramContext.obtainStyledAttributes(null, b.e, 2130903080, 0);
    this.J = typedArray.getResourceId(0, 0);
    this.K = typedArray.getResourceId(2, 0);
    this.L = typedArray.getResourceId(4, 0);
    this.M = typedArray.getResourceId(5, 0);
    this.N = typedArray.getResourceId(7, 0);
    this.O = typedArray.getResourceId(3, 0);
    this.P = typedArray.getBoolean(6, true);
    this.d = typedArray.getDimensionPixelSize(1, 0);
    typedArray.recycle();
    paramo.a().i(1);
  }
  
  public static boolean a(View paramView) {
    if (paramView.onCheckIsTextEditor())
      return true; 
    if (!(paramView instanceof ViewGroup))
      return false; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int i = viewGroup.getChildCount();
    while (i > 0) {
      int j = i - 1;
      i = j;
      if (a(viewGroup.getChildAt(j)))
        return true; 
    } 
    return false;
  }
  
  public static void c(View paramView1, View paramView2, View paramView3) {
    boolean bool = false;
    if (paramView2 != null) {
      byte b;
      if (paramView1.canScrollVertically(-1)) {
        b = 0;
      } else {
        b = 4;
      } 
      paramView2.setVisibility(b);
    } 
    if (paramView3 != null) {
      byte b;
      if (paramView1.canScrollVertically(1)) {
        b = bool;
      } else {
        b = 4;
      } 
      paramView3.setVisibility(b);
    } 
  }
  
  public final void b(Button paramButton) {
    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)paramButton.getLayoutParams();
    layoutParams.gravity = 1;
    layoutParams.weight = 0.5F;
    paramButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  public final ViewGroup d(View paramView1, View paramView2) {
    if (paramView1 == null) {
      paramView1 = paramView2;
      if (paramView2 instanceof ViewStub)
        paramView1 = ((ViewStub)paramView2).inflate(); 
      return (ViewGroup)paramView1;
    } 
    if (paramView2 != null) {
      ViewParent viewParent = paramView2.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(paramView2); 
    } 
    paramView2 = paramView1;
    if (paramView1 instanceof ViewStub)
      paramView2 = ((ViewStub)paramView1).inflate(); 
    return (ViewGroup)paramView2;
  }
  
  public static class RecycleListView extends ListView {
    public final int e;
    
    public final int f;
    
    public RecycleListView(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, b.u);
      this.f = typedArray.getDimensionPixelOffset(0, -1);
      this.e = typedArray.getDimensionPixelOffset(1, -1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\appcompat\app\AlertController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */