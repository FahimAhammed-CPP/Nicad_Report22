package androidx.viewpager2.adapter;

import c.p.e;
import c.p.f;
import c.p.h;

public class FragmentStateAdapter$2 implements f {
  public void d(h paramh, e.a parama) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */