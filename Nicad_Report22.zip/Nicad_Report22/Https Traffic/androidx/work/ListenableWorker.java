package androidx.work;

import android.content.Context;
import android.net.Network;
import android.net.Uri;
import androidx.annotation.Keep;
import c.b0.e0;
import c.b0.f0.c0.a0.c;
import c.b0.f0.c0.s;
import c.b0.f0.c0.t;
import c.b0.f0.c0.u;
import c.b0.f0.c0.z.m;
import c.b0.g;
import c.b0.h;
import c.b0.i;
import c.b0.y;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

public abstract class ListenableWorker {
  public Context e;
  
  public WorkerParameters f;
  
  public volatile boolean g;
  
  public boolean h;
  
  public boolean i;
  
  @Keep
  public ListenableWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    if (paramContext != null) {
      if (paramWorkerParameters != null) {
        this.e = paramContext;
        this.f = paramWorkerParameters;
        return;
      } 
      throw new IllegalArgumentException("WorkerParameters is null");
    } 
    throw new IllegalArgumentException("Application Context is null");
  }
  
  public final Context getApplicationContext() {
    return this.e;
  }
  
  public Executor getBackgroundExecutor() {
    return this.f.f;
  }
  
  public d.c.c.d.a.a<h> getForegroundInfoAsync() {
    m m = new m();
    m.l(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
    return (d.c.c.d.a.a<h>)m;
  }
  
  public final UUID getId() {
    return this.f.a;
  }
  
  public final g getInputData() {
    return this.f.b;
  }
  
  public final Network getNetwork() {
    return this.f.d.c;
  }
  
  public final int getRunAttemptCount() {
    return this.f.e;
  }
  
  public final Set<String> getTags() {
    return this.f.c;
  }
  
  public c.b0.f0.c0.a0.a getTaskExecutor() {
    return this.f.g;
  }
  
  public final List<String> getTriggeredContentAuthorities() {
    return this.f.d.a;
  }
  
  public final List<Uri> getTriggeredContentUris() {
    return this.f.d.b;
  }
  
  public e0 getWorkerFactory() {
    return this.f.h;
  }
  
  public boolean isRunInForeground() {
    return this.i;
  }
  
  public final boolean isStopped() {
    return this.g;
  }
  
  public final boolean isUsed() {
    return this.h;
  }
  
  public void onStopped() {}
  
  public final d.c.c.d.a.a<Void> setForegroundAsync(h paramh) {
    this.i = true;
    i i = this.f.j;
    Context context = getApplicationContext();
    UUID uUID = getId();
    return ((s)i).a(context, uUID, paramh);
  }
  
  public d.c.c.d.a.a<Void> setProgressAsync(g paramg) {
    y y = this.f.i;
    getApplicationContext();
    UUID uUID = getId();
    u u = (u)y;
    Objects.requireNonNull(u);
    m m = new m();
    c.b0.f0.c0.a0.a a = u.b;
    t t = new t(u, uUID, paramg, m);
    ((c)a).a.execute((Runnable)t);
    return (d.c.c.d.a.a<Void>)m;
  }
  
  public void setRunInForeground(boolean paramBoolean) {
    this.i = paramBoolean;
  }
  
  public final void setUsed() {
    this.h = true;
  }
  
  public abstract d.c.c.d.a.a<a> startWork();
  
  public final void stop() {
    this.g = true;
    onStopped();
  }
  
  public static abstract class a {}
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\ListenableWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */