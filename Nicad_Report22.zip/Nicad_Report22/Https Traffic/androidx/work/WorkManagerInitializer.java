package androidx.work;

import c.b0.b0;
import c.b0.o;
import c.x.b;

public final class WorkManagerInitializer implements b<b0> {
  public static final String a = o.e("WrkMgrInitializer");
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\WorkManagerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */