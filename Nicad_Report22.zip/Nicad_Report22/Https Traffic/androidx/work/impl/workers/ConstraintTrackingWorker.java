package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import c.b0.f0.b0.t;
import c.b0.f0.c0.z.m;
import c.b0.f0.t;
import c.b0.f0.z.b;
import c.b0.f0.z.c;
import c.b0.l;
import c.b0.m;
import c.b0.o;
import java.util.Collections;
import java.util.List;

public class ConstraintTrackingWorker extends ListenableWorker implements b {
  public static final String o = o.e("ConstraintTrkngWrkr");
  
  public WorkerParameters j;
  
  public final Object k;
  
  public volatile boolean l;
  
  public m<ListenableWorker.a> m;
  
  public ListenableWorker n;
  
  public ConstraintTrackingWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.j = paramWorkerParameters;
    this.k = new Object();
    this.l = false;
    this.m = new m();
  }
  
  public void a() {
    this.m.k(new l());
  }
  
  public void b() {
    this.m.k(new m());
  }
  
  public void d(List<String> paramList) {
    o.c().a(o, String.format("Constraints changed for %s", new Object[] { paramList }), new Throwable[0]);
    synchronized (this.k) {
      this.l = true;
      return;
    } 
  }
  
  public void e(List<String> paramList) {}
  
  public c.b0.f0.c0.a0.a getTaskExecutor() {
    return (t.b(getApplicationContext())).d;
  }
  
  public boolean isRunInForeground() {
    ListenableWorker listenableWorker = this.n;
    return (listenableWorker != null && listenableWorker.isRunInForeground());
  }
  
  public void onStopped() {
    super.onStopped();
    ListenableWorker listenableWorker = this.n;
    if (listenableWorker != null && !listenableWorker.isStopped())
      this.n.stop(); 
  }
  
  public d.c.c.d.a.a<ListenableWorker.a> startWork() {
    getBackgroundExecutor().execute(new a(this));
    return (d.c.c.d.a.a<ListenableWorker.a>)this.m;
  }
  
  public class a implements Runnable {
    public a(ConstraintTrackingWorker this$0) {}
    
    public void run() {
      ConstraintTrackingWorker constraintTrackingWorker = this.e;
      String str = constraintTrackingWorker.getInputData().b("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
      if (TextUtils.isEmpty(str)) {
        o.c().b(ConstraintTrackingWorker.o, "No worker to delegate to.", new Throwable[0]);
        constraintTrackingWorker.a();
        return;
      } 
      ListenableWorker listenableWorker = constraintTrackingWorker.getWorkerFactory().a(constraintTrackingWorker.getApplicationContext(), str, constraintTrackingWorker.j);
      constraintTrackingWorker.n = listenableWorker;
      if (listenableWorker == null) {
        o.c().a(ConstraintTrackingWorker.o, "No worker to delegate to.", new Throwable[0]);
        constraintTrackingWorker.a();
        return;
      } 
      t t = (t.b(constraintTrackingWorker.getApplicationContext())).c.q().i(constraintTrackingWorker.getId().toString());
      if (t == null) {
        constraintTrackingWorker.a();
        return;
      } 
      c c = new c(constraintTrackingWorker.getApplicationContext(), constraintTrackingWorker.getTaskExecutor(), constraintTrackingWorker);
      c.b(Collections.singletonList(t));
      if (c.a(constraintTrackingWorker.getId().toString())) {
        o.c().a(ConstraintTrackingWorker.o, String.format("Constraints met for delegate %s", new Object[] { str }), new Throwable[0]);
        try {
          return;
        } finally {
          c = null;
          o o = o.c();
          String str1 = ConstraintTrackingWorker.o;
          o.a(str1, String.format("Delegated worker %s threw exception in startWork.", new Object[] { str }), new Throwable[] { (Throwable)c });
        } 
      } 
      o.c().a(ConstraintTrackingWorker.o, String.format("Constraints not met for delegate %s. Requesting retry.", new Object[] { str }), new Throwable[0]);
      constraintTrackingWorker.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\impl\workers\ConstraintTrackingWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */