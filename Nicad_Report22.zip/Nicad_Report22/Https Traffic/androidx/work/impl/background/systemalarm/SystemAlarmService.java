package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import c.b0.f0.c0.n;
import c.b0.f0.y.b.g;
import c.b0.o;
import c.p.k;
import java.util.HashMap;
import java.util.WeakHashMap;

public class SystemAlarmService extends k implements g.a {
  public static final String h = o.e("SystemAlarmService");
  
  public g f;
  
  public boolean g;
  
  public final void c() {
    g g1 = new g((Context)this);
    this.f = g1;
    if (g1.n != null) {
      o.c().b(g.o, "A completion listener for SystemAlarmDispatcher already exists.", new Throwable[0]);
      return;
    } 
    g1.n = this;
  }
  
  public void d() {
    this.g = true;
    o.c().a(h, "All commands completed in dispatcher", new Throwable[0]);
    String str = n.a;
    null = new HashMap<Object, Object>();
    synchronized (n.b) {
      null.putAll(null);
      for (PowerManager.WakeLock wakeLock : null.keySet()) {
        if (wakeLock != null && wakeLock.isHeld()) {
          String str1 = String.format("WakeLock held for %s", new Object[] { null.get(wakeLock) });
          o.c().f(n.a, str1, new Throwable[0]);
        } 
      } 
      stopSelf();
      return;
    } 
  }
  
  public void onCreate() {
    super.onCreate();
    c();
    this.g = false;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.g = true;
    this.f.d();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.g) {
      o.c().d(h, "Re-initializing SystemAlarmDispatcher after a request to shut-down.", new Throwable[0]);
      this.f.d();
      c();
      this.g = false;
    } 
    if (paramIntent != null)
      this.f.b(paramIntent, paramInt2); 
    return 3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\impl\background\systemalarm\SystemAlarmService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */