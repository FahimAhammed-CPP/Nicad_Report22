package androidx.work.impl.background.systemjob;

import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build;
import android.os.PersistableBundle;
import android.text.TextUtils;
import androidx.work.WorkerParameters;
import c.b0.f0.b;
import c.b0.f0.c0.a0.a;
import c.b0.f0.c0.a0.c;
import c.b0.f0.c0.l;
import c.b0.f0.e;
import c.b0.f0.t;
import c.b0.o;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class SystemJobService extends JobService implements b {
  public static final String g = o.e("SystemJobService");
  
  public t e;
  
  public final Map<String, JobParameters> f = new HashMap<String, JobParameters>();
  
  public static String b(JobParameters paramJobParameters) {
    try {
      PersistableBundle persistableBundle = paramJobParameters.getExtras();
      if (persistableBundle != null && persistableBundle.containsKey("EXTRA_WORK_SPEC_ID"))
        return persistableBundle.getString("EXTRA_WORK_SPEC_ID"); 
    } catch (NullPointerException nullPointerException) {}
    return null;
  }
  
  public void a(String paramString, boolean paramBoolean) {
    o.c().a(g, String.format("%s executed on JobScheduler", new Object[] { paramString }), new Throwable[0]);
    synchronized (this.f) {
      JobParameters jobParameters = this.f.remove(paramString);
      if (jobParameters != null)
        jobFinished(jobParameters, paramBoolean); 
      return;
    } 
  }
  
  public void onCreate() {
    super.onCreate();
    try {
      t t1 = t.b(getApplicationContext());
      this.e = t1;
      t1.f.b(this);
      return;
    } catch (IllegalStateException illegalStateException) {
      if (Application.class.equals(getApplication().getClass())) {
        o.c().f(g, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.", new Throwable[0]);
        return;
      } 
      throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().");
    } 
  }
  
  public void onDestroy() {
    super.onDestroy();
    t t1 = this.e;
    if (t1 != null)
      t1.f.e(this); 
  }
  
  public boolean onStartJob(JobParameters paramJobParameters) {
    Map<String, JobParameters> map;
    l l;
    if (this.e == null) {
      o.c().a(g, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
      jobFinished(paramJobParameters, true);
      return false;
    } 
    String str = b(paramJobParameters);
    if (TextUtils.isEmpty(str)) {
      o.c().b(g, "WorkSpec id not found!", new Throwable[0]);
      return false;
    } 
    synchronized (this.f) {
      WorkerParameters.a a1;
      if (this.f.containsKey(str)) {
        o.c().a(g, String.format("Job is already being executed by SystemJobService: %s", new Object[] { str }), new Throwable[0]);
        return false;
      } 
      o.c().a(g, String.format("onStartJob for %s", new Object[] { str }), new Throwable[0]);
      this.f.put(str, paramJobParameters);
      map = null;
      int i = Build.VERSION.SDK_INT;
      if (i >= 24) {
        WorkerParameters.a a2 = new WorkerParameters.a();
        if (paramJobParameters.getTriggeredContentUris() != null)
          a2.b = Arrays.asList(paramJobParameters.getTriggeredContentUris()); 
        if (paramJobParameters.getTriggeredContentAuthorities() != null)
          a2.a = Arrays.asList(paramJobParameters.getTriggeredContentAuthorities()); 
        a1 = a2;
        if (i >= 28) {
          a2.c = paramJobParameters.getNetwork();
          a1 = a2;
        } 
      } 
      t t1 = this.e;
      a a = t1.d;
      l = new l(t1, str, a1);
      ((c)a).a.execute((Runnable)l);
      return true;
    } 
  }
  
  public boolean onStopJob(JobParameters paramJobParameters) {
    if (this.e == null) {
      o.c().a(g, "WorkManager is not initialized; requesting retry.", new Throwable[0]);
      return true;
    } 
    null = b(paramJobParameters);
    if (TextUtils.isEmpty(null)) {
      o.c().b(g, "WorkSpec id not found!", new Throwable[0]);
      return false;
    } 
    o.c().a(g, String.format("onStopJob for %s", new Object[] { null }), new Throwable[0]);
    synchronized (this.f) {
      this.f.remove(null);
      this.e.f(null);
      e e = this.e.f;
      synchronized (e.o) {
        boolean bool = e.m.contains(null);
        return bool ^ true;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\impl\background\systemjob\SystemJobService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */