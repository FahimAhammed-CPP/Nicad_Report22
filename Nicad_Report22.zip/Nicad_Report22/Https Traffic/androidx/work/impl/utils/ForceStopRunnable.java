package androidx.work.impl.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteAccessPermException;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteTableLockedException;
import android.text.TextUtils;
import android.util.Log;
import c.b0.c;
import c.b0.f0.c0.i;
import c.b0.f0.s;
import c.b0.f0.t;
import c.b0.o;
import c.h.b.h;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class ForceStopRunnable implements Runnable {
  public static final String h = o.e("ForceStopRunnable");
  
  public static final long i = TimeUnit.DAYS.toMillis(3650L);
  
  public final Context e;
  
  public final t f;
  
  public int g;
  
  public ForceStopRunnable(Context paramContext, t paramt) {
    this.e = paramContext.getApplicationContext();
    this.f = paramt;
    this.g = 0;
  }
  
  public static PendingIntent b(Context paramContext, int paramInt) {
    Intent intent = new Intent();
    intent.setComponent(new ComponentName(paramContext, BroadcastReceiver.class));
    intent.setAction("ACTION_FORCE_STOP_RESCHEDULE");
    return PendingIntent.getBroadcast(paramContext, -1, intent, paramInt);
  }
  
  public static void d(Context paramContext) {
    int i;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    if (h.Q()) {
      i = 167772160;
    } else {
      i = 134217728;
    } 
    PendingIntent pendingIntent = b(paramContext, i);
    long l1 = System.currentTimeMillis();
    long l2 = i;
    if (alarmManager != null)
      alarmManager.setExact(0, l1 + l2, pendingIntent); 
  }
  
  public void a() {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroid/content/Context;
    //   4: astore #6
    //   6: aload_0
    //   7: getfield f : Lc/b0/f0/t;
    //   10: astore #5
    //   12: getstatic c/b0/f0/y/c/b.i : Ljava/lang/String;
    //   15: astore #7
    //   17: aload #6
    //   19: ldc 'jobscheduler'
    //   21: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   24: checkcast android/app/job/JobScheduler
    //   27: astore #7
    //   29: aload #6
    //   31: aload #7
    //   33: invokestatic e : (Landroid/content/Context;Landroid/app/job/JobScheduler;)Ljava/util/List;
    //   36: astore #9
    //   38: aload #5
    //   40: getfield c : Landroidx/work/impl/WorkDatabase;
    //   43: invokevirtual n : ()Lc/b0/f0/b0/j;
    //   46: astore #6
    //   48: aload #6
    //   50: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   53: pop
    //   54: ldc 'SELECT DISTINCT work_spec_id FROM SystemIdInfo'
    //   56: iconst_0
    //   57: invokestatic d : (Ljava/lang/String;I)Lc/u/q;
    //   60: astore #8
    //   62: aload #6
    //   64: getfield a : Lc/u/l;
    //   67: invokevirtual b : ()V
    //   70: aload #6
    //   72: getfield a : Lc/u/l;
    //   75: aload #8
    //   77: iconst_0
    //   78: aconst_null
    //   79: invokestatic a : (Lc/u/l;Lc/w/a/e;ZLandroid/os/CancellationSignal;)Landroid/database/Cursor;
    //   82: astore #10
    //   84: new java/util/ArrayList
    //   87: dup
    //   88: aload #10
    //   90: invokeinterface getCount : ()I
    //   95: invokespecial <init> : (I)V
    //   98: astore #6
    //   100: aload #10
    //   102: invokeinterface moveToNext : ()Z
    //   107: ifeq -> 127
    //   110: aload #6
    //   112: aload #10
    //   114: iconst_0
    //   115: invokeinterface getString : (I)Ljava/lang/String;
    //   120: invokevirtual add : (Ljava/lang/Object;)Z
    //   123: pop
    //   124: goto -> 100
    //   127: aload #10
    //   129: invokeinterface close : ()V
    //   134: aload #8
    //   136: invokevirtual h : ()V
    //   139: aload #9
    //   141: ifnull -> 155
    //   144: aload #9
    //   146: invokeinterface size : ()I
    //   151: istore_1
    //   152: goto -> 157
    //   155: iconst_0
    //   156: istore_1
    //   157: new java/util/HashSet
    //   160: dup
    //   161: iload_1
    //   162: invokespecial <init> : (I)V
    //   165: astore #8
    //   167: aload #9
    //   169: ifnull -> 252
    //   172: aload #9
    //   174: invokeinterface isEmpty : ()Z
    //   179: ifne -> 252
    //   182: aload #9
    //   184: invokeinterface iterator : ()Ljava/util/Iterator;
    //   189: astore #9
    //   191: aload #9
    //   193: invokeinterface hasNext : ()Z
    //   198: ifeq -> 252
    //   201: aload #9
    //   203: invokeinterface next : ()Ljava/lang/Object;
    //   208: checkcast android/app/job/JobInfo
    //   211: astore #10
    //   213: aload #10
    //   215: invokestatic g : (Landroid/app/job/JobInfo;)Ljava/lang/String;
    //   218: astore #11
    //   220: aload #11
    //   222: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   225: ifne -> 239
    //   228: aload #8
    //   230: aload #11
    //   232: invokevirtual add : (Ljava/lang/Object;)Z
    //   235: pop
    //   236: goto -> 191
    //   239: aload #7
    //   241: aload #10
    //   243: invokevirtual getId : ()I
    //   246: invokestatic a : (Landroid/app/job/JobScheduler;I)V
    //   249: goto -> 191
    //   252: aload #6
    //   254: invokevirtual iterator : ()Ljava/util/Iterator;
    //   257: astore #7
    //   259: aload #7
    //   261: invokeinterface hasNext : ()Z
    //   266: istore #4
    //   268: iconst_1
    //   269: istore_3
    //   270: iload #4
    //   272: ifeq -> 313
    //   275: aload #8
    //   277: aload #7
    //   279: invokeinterface next : ()Ljava/lang/Object;
    //   284: checkcast java/lang/String
    //   287: invokevirtual contains : (Ljava/lang/Object;)Z
    //   290: ifne -> 259
    //   293: invokestatic c : ()Lc/b0/o;
    //   296: getstatic c/b0/f0/y/c/b.i : Ljava/lang/String;
    //   299: ldc 'Reconciling jobs'
    //   301: iconst_0
    //   302: anewarray java/lang/Throwable
    //   305: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   308: iconst_1
    //   309: istore_1
    //   310: goto -> 315
    //   313: iconst_0
    //   314: istore_1
    //   315: iload_1
    //   316: ifeq -> 400
    //   319: aload #5
    //   321: getfield c : Landroidx/work/impl/WorkDatabase;
    //   324: astore #5
    //   326: aload #5
    //   328: invokevirtual c : ()V
    //   331: aload #5
    //   333: invokevirtual q : ()Lc/b0/f0/b0/c0;
    //   336: astore #7
    //   338: aload #6
    //   340: invokevirtual iterator : ()Ljava/util/Iterator;
    //   343: astore #6
    //   345: aload #6
    //   347: invokeinterface hasNext : ()Z
    //   352: ifeq -> 377
    //   355: aload #7
    //   357: aload #6
    //   359: invokeinterface next : ()Ljava/lang/Object;
    //   364: checkcast java/lang/String
    //   367: ldc2_w -1
    //   370: invokevirtual l : (Ljava/lang/String;J)I
    //   373: pop
    //   374: goto -> 345
    //   377: aload #5
    //   379: invokevirtual k : ()V
    //   382: aload #5
    //   384: invokevirtual g : ()V
    //   387: goto -> 400
    //   390: astore #6
    //   392: aload #5
    //   394: invokevirtual g : ()V
    //   397: aload #6
    //   399: athrow
    //   400: aload_0
    //   401: getfield f : Lc/b0/f0/t;
    //   404: getfield c : Landroidx/work/impl/WorkDatabase;
    //   407: astore #5
    //   409: aload #5
    //   411: invokevirtual q : ()Lc/b0/f0/b0/c0;
    //   414: astore #6
    //   416: aload #5
    //   418: invokevirtual p : ()Lc/b0/f0/b0/r;
    //   421: astore #7
    //   423: aload #5
    //   425: invokevirtual c : ()V
    //   428: aload #6
    //   430: invokevirtual d : ()Ljava/util/List;
    //   433: astore #8
    //   435: aload #8
    //   437: checkcast java/util/ArrayList
    //   440: invokevirtual isEmpty : ()Z
    //   443: iconst_1
    //   444: ixor
    //   445: istore_2
    //   446: iload_2
    //   447: ifeq -> 520
    //   450: aload #8
    //   452: checkcast java/util/ArrayList
    //   455: invokevirtual iterator : ()Ljava/util/Iterator;
    //   458: astore #8
    //   460: aload #8
    //   462: invokeinterface hasNext : ()Z
    //   467: ifeq -> 520
    //   470: aload #8
    //   472: invokeinterface next : ()Ljava/lang/Object;
    //   477: checkcast c/b0/f0/b0/t
    //   480: astore #9
    //   482: aload #6
    //   484: getstatic c/b0/a0.e : Lc/b0/a0;
    //   487: iconst_1
    //   488: anewarray java/lang/String
    //   491: dup
    //   492: iconst_0
    //   493: aload #9
    //   495: getfield a : Ljava/lang/String;
    //   498: aastore
    //   499: invokevirtual p : (Lc/b0/a0;[Ljava/lang/String;)I
    //   502: pop
    //   503: aload #6
    //   505: aload #9
    //   507: getfield a : Ljava/lang/String;
    //   510: ldc2_w -1
    //   513: invokevirtual l : (Ljava/lang/String;J)I
    //   516: pop
    //   517: goto -> 460
    //   520: aload #7
    //   522: invokevirtual b : ()V
    //   525: aload #5
    //   527: invokevirtual k : ()V
    //   530: aload #5
    //   532: invokevirtual g : ()V
    //   535: iload_2
    //   536: ifne -> 551
    //   539: iload_1
    //   540: ifeq -> 546
    //   543: goto -> 551
    //   546: iconst_0
    //   547: istore_1
    //   548: goto -> 553
    //   551: iconst_1
    //   552: istore_1
    //   553: aload_0
    //   554: getfield f : Lc/b0/f0/t;
    //   557: getfield g : Lc/b0/f0/c0/h;
    //   560: getfield a : Landroidx/work/impl/WorkDatabase;
    //   563: invokevirtual m : ()Lc/b0/f0/b0/f;
    //   566: ldc_w 'reschedule_needed'
    //   569: invokevirtual a : (Ljava/lang/String;)Ljava/lang/Long;
    //   572: astore #5
    //   574: aload #5
    //   576: ifnull -> 594
    //   579: aload #5
    //   581: invokevirtual longValue : ()J
    //   584: lconst_1
    //   585: lcmp
    //   586: ifne -> 594
    //   589: iconst_1
    //   590: istore_2
    //   591: goto -> 596
    //   594: iconst_0
    //   595: istore_2
    //   596: iload_2
    //   597: ifeq -> 665
    //   600: invokestatic c : ()Lc/b0/o;
    //   603: getstatic androidx/work/impl/utils/ForceStopRunnable.h : Ljava/lang/String;
    //   606: ldc_w 'Rescheduling Workers.'
    //   609: iconst_0
    //   610: anewarray java/lang/Throwable
    //   613: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   616: aload_0
    //   617: getfield f : Lc/b0/f0/t;
    //   620: invokevirtual e : ()V
    //   623: aload_0
    //   624: getfield f : Lc/b0/f0/t;
    //   627: getfield g : Lc/b0/f0/c0/h;
    //   630: astore #5
    //   632: aload #5
    //   634: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   637: pop
    //   638: new c/b0/f0/b0/d
    //   641: dup
    //   642: ldc_w 'reschedule_needed'
    //   645: iconst_0
    //   646: invokespecial <init> : (Ljava/lang/String;Z)V
    //   649: astore #6
    //   651: aload #5
    //   653: getfield a : Landroidx/work/impl/WorkDatabase;
    //   656: invokevirtual m : ()Lc/b0/f0/b0/f;
    //   659: aload #6
    //   661: invokevirtual b : (Lc/b0/f0/b0/d;)V
    //   664: return
    //   665: ldc_w 536870912
    //   668: istore_2
    //   669: invokestatic Q : ()Z
    //   672: ifeq -> 679
    //   675: ldc_w 570425344
    //   678: istore_2
    //   679: aload_0
    //   680: getfield e : Landroid/content/Context;
    //   683: iload_2
    //   684: invokestatic b : (Landroid/content/Context;I)Landroid/app/PendingIntent;
    //   687: astore #5
    //   689: getstatic android/os/Build$VERSION.SDK_INT : I
    //   692: bipush #30
    //   694: if_icmplt -> 780
    //   697: aload #5
    //   699: ifnull -> 707
    //   702: aload #5
    //   704: invokevirtual cancel : ()V
    //   707: aload_0
    //   708: getfield e : Landroid/content/Context;
    //   711: ldc_w 'activity'
    //   714: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   717: checkcast android/app/ActivityManager
    //   720: aconst_null
    //   721: iconst_0
    //   722: iconst_0
    //   723: invokevirtual getHistoricalProcessExitReasons : (Ljava/lang/String;II)Ljava/util/List;
    //   726: astore #5
    //   728: aload #5
    //   730: ifnull -> 797
    //   733: aload #5
    //   735: invokeinterface isEmpty : ()Z
    //   740: ifne -> 797
    //   743: iconst_0
    //   744: istore_2
    //   745: iload_2
    //   746: aload #5
    //   748: invokeinterface size : ()I
    //   753: if_icmpge -> 797
    //   756: aload #5
    //   758: iload_2
    //   759: invokeinterface get : (I)Ljava/lang/Object;
    //   764: checkcast android/app/ApplicationExitInfo
    //   767: invokevirtual getReason : ()I
    //   770: bipush #10
    //   772: if_icmpne -> 932
    //   775: iload_3
    //   776: istore_2
    //   777: goto -> 832
    //   780: aload #5
    //   782: ifnonnull -> 797
    //   785: aload_0
    //   786: getfield e : Landroid/content/Context;
    //   789: invokestatic d : (Landroid/content/Context;)V
    //   792: iload_3
    //   793: istore_2
    //   794: goto -> 832
    //   797: iconst_0
    //   798: istore_2
    //   799: goto -> 832
    //   802: astore #5
    //   804: goto -> 809
    //   807: astore #5
    //   809: invokestatic c : ()Lc/b0/o;
    //   812: getstatic androidx/work/impl/utils/ForceStopRunnable.h : Ljava/lang/String;
    //   815: ldc_w 'Ignoring exception'
    //   818: iconst_1
    //   819: anewarray java/lang/Throwable
    //   822: dup
    //   823: iconst_0
    //   824: aload #5
    //   826: aastore
    //   827: invokevirtual f : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   830: iload_3
    //   831: istore_2
    //   832: iload_2
    //   833: ifeq -> 860
    //   836: invokestatic c : ()Lc/b0/o;
    //   839: getstatic androidx/work/impl/utils/ForceStopRunnable.h : Ljava/lang/String;
    //   842: ldc_w 'Application was force-stopped, rescheduling.'
    //   845: iconst_0
    //   846: anewarray java/lang/Throwable
    //   849: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   852: aload_0
    //   853: getfield f : Lc/b0/f0/t;
    //   856: invokevirtual e : ()V
    //   859: return
    //   860: iload_1
    //   861: ifeq -> 904
    //   864: invokestatic c : ()Lc/b0/o;
    //   867: getstatic androidx/work/impl/utils/ForceStopRunnable.h : Ljava/lang/String;
    //   870: ldc_w 'Found unfinished work, scheduling it.'
    //   873: iconst_0
    //   874: anewarray java/lang/Throwable
    //   877: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
    //   880: aload_0
    //   881: getfield f : Lc/b0/f0/t;
    //   884: astore #5
    //   886: aload #5
    //   888: getfield b : Lc/b0/c;
    //   891: aload #5
    //   893: getfield c : Landroidx/work/impl/WorkDatabase;
    //   896: aload #5
    //   898: getfield e : Ljava/util/List;
    //   901: invokestatic a : (Lc/b0/c;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V
    //   904: return
    //   905: astore #6
    //   907: aload #5
    //   909: invokevirtual g : ()V
    //   912: aload #6
    //   914: athrow
    //   915: astore #5
    //   917: aload #10
    //   919: invokeinterface close : ()V
    //   924: aload #8
    //   926: invokevirtual h : ()V
    //   929: aload #5
    //   931: athrow
    //   932: iload_2
    //   933: iconst_1
    //   934: iadd
    //   935: istore_2
    //   936: goto -> 745
    // Exception table:
    //   from	to	target	type
    //   84	100	915	finally
    //   100	124	915	finally
    //   331	345	390	finally
    //   345	374	390	finally
    //   377	382	390	finally
    //   428	446	905	finally
    //   450	460	905	finally
    //   460	517	905	finally
    //   520	530	905	finally
    //   669	675	807	java/lang/SecurityException
    //   669	675	802	java/lang/IllegalArgumentException
    //   679	697	807	java/lang/SecurityException
    //   679	697	802	java/lang/IllegalArgumentException
    //   702	707	807	java/lang/SecurityException
    //   702	707	802	java/lang/IllegalArgumentException
    //   707	728	807	java/lang/SecurityException
    //   707	728	802	java/lang/IllegalArgumentException
    //   733	743	807	java/lang/SecurityException
    //   733	743	802	java/lang/IllegalArgumentException
    //   745	775	807	java/lang/SecurityException
    //   745	775	802	java/lang/IllegalArgumentException
    //   785	792	807	java/lang/SecurityException
    //   785	792	802	java/lang/IllegalArgumentException
  }
  
  public boolean c() {
    c c = this.f.b;
    Objects.requireNonNull(c);
    if (TextUtils.isEmpty(null)) {
      o.c().a(h, "The default process name was not specified.", new Throwable[0]);
      return true;
    } 
    boolean bool = i.a(this.e, c);
    o.c().a(h, String.format("Is default app process = %s", new Object[] { Boolean.valueOf(bool) }), new Throwable[0]);
    return bool;
  }
  
  public void run() {
    try {
      boolean bool = c();
      if (!bool)
        return; 
      while (true) {
        IllegalStateException illegalStateException;
        s.a(this.e);
        o.c().a(h, "Performing cleanup operations.", new Throwable[0]);
        try {
          a();
          return;
        } catch (SQLiteCantOpenDatabaseException sQLiteCantOpenDatabaseException) {
        
        } catch (SQLiteDatabaseCorruptException sQLiteDatabaseCorruptException) {
        
        } catch (SQLiteDatabaseLockedException sQLiteDatabaseLockedException) {
        
        } catch (SQLiteTableLockedException sQLiteTableLockedException) {
        
        } catch (SQLiteConstraintException sQLiteConstraintException) {
        
        } catch (SQLiteAccessPermException sQLiteAccessPermException) {}
        int i = this.g + 1;
        this.g = i;
        if (i >= 3) {
          o.c().b(h, "The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", new Throwable[] { (Throwable)sQLiteAccessPermException });
          illegalStateException = new IllegalStateException("The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", (Throwable)sQLiteAccessPermException);
          Objects.requireNonNull(this.f.b);
          throw illegalStateException;
        } 
        long l = i;
        o.c().a(h, String.format("Retrying after %s", new Object[] { Long.valueOf(l * 300L) }), new Throwable[] { illegalStateException });
        i = this.g;
        l = i;
        try {
          Thread.sleep(l * 300L);
        } catch (InterruptedException interruptedException) {}
      } 
    } finally {
      this.f.d();
    } 
  }
  
  public static class BroadcastReceiver extends android.content.BroadcastReceiver {
    public static final String a = o.e("ForceStopRunnable$Rcvr");
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Intent != null && "ACTION_FORCE_STOP_RESCHEDULE".equals(param1Intent.getAction())) {
        o o = o.c();
        String str = a;
        if (o.a <= 2)
          Log.v(str, "Rescheduling alarm that keeps track of force-stops."); 
        ForceStopRunnable.d(param1Context);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\imp\\utils\ForceStopRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */