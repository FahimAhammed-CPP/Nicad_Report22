package androidx.work;

import android.content.Context;
import androidx.annotation.Keep;
import c.b0.f0.c0.z.m;

public abstract class Worker extends ListenableWorker {
  public m<ListenableWorker.a> j;
  
  @Keep
  public Worker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public abstract ListenableWorker.a doWork();
  
  public final d.c.c.d.a.a<ListenableWorker.a> startWork() {
    this.j = new m();
    getBackgroundExecutor().execute(new a(this));
    return (d.c.c.d.a.a<ListenableWorker.a>)this.j;
  }
  
  public class a implements Runnable {
    public a(Worker this$0) {}
    
    public void run() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.e.j.l(exception);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\work\Worker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */