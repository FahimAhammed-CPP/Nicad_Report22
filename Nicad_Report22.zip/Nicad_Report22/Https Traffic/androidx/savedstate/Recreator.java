package androidx.savedstate;

import android.os.Bundle;
import c.p.e;
import c.p.f;
import c.p.h;
import c.p.j;
import c.v.a;
import c.v.d;
import d.a.a.a.a;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;

public final class Recreator implements f {
  public final d e;
  
  public Recreator(d paramd) {
    this.e = paramd;
  }
  
  public void d(h paramh, e.a parama) {
    if (parama == e.a.ON_CREATE) {
      ((j)paramh.l()).a.k(this);
      a a1 = this.e.b();
      if (a1.c) {
        Bundle bundle1;
        Bundle bundle2 = a1.b;
        paramh = null;
        if (bundle2 != null) {
          bundle1 = bundle2.getBundle("androidx.savedstate.Restarter");
          a1.b.remove("androidx.savedstate.Restarter");
          if (a1.b.isEmpty())
            a1.b = null; 
        } 
        if (bundle1 == null)
          return; 
        ArrayList arrayList = bundle1.getStringArrayList("classes_to_restore");
        if (arrayList != null) {
          Iterator<String> iterator = arrayList.iterator();
          while (iterator.hasNext()) {
            String str = iterator.next();
            try {
              Class<? extends a.a> clazz = Class.forName(str, false, Recreator.class.getClassLoader()).asSubclass(a.a.class);
              try {
                Constructor<? extends a.a> constructor = clazz.getDeclaredConstructor(new Class[0]);
                constructor.setAccessible(true);
                try {
                  a.a a2 = constructor.newInstance(new Object[0]);
                  a2.a(this.e);
                } catch (Exception exception) {
                  throw new RuntimeException(a.f("Failed to instantiate ", str), exception);
                } 
              } catch (NoSuchMethodException noSuchMethodException) {
                StringBuilder stringBuilder = a.p("Class");
                stringBuilder.append(exception.getSimpleName());
                stringBuilder.append(" must have default constructor in order to be automatically recreated");
                throw new IllegalStateException(stringBuilder.toString(), noSuchMethodException);
              } 
            } catch (ClassNotFoundException classNotFoundException) {
              throw new RuntimeException(a.g("Class ", noSuchMethodException, " wasn't found"), classNotFoundException);
            } 
          } 
          return;
        } 
        throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
      } 
      throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
    } 
    throw new AssertionError("Next event must be ON_CREATE");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\savedstate\Recreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */