package androidx.drawerlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import c.b.c.g;
import c.h.j.u;
import c.j.b.h;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class DrawerLayout extends ViewGroup {
  public static final int[] G = new int[] { 16843828 };
  
  public static final int[] H = new int[] { 16842931 };
  
  public Drawable A;
  
  public Object B;
  
  public boolean C;
  
  public final ArrayList<View> D;
  
  public Rect E;
  
  public Matrix F;
  
  public final b e = new b();
  
  public float f;
  
  public int g;
  
  public int h = -1728053248;
  
  public float i;
  
  public Paint j = new Paint();
  
  public final h k;
  
  public final h l;
  
  public final f m;
  
  public final f n;
  
  public int o;
  
  public boolean p;
  
  public boolean q = true;
  
  public int r = 3;
  
  public int s = 3;
  
  public int t = 3;
  
  public int u = 3;
  
  public boolean v;
  
  public c w;
  
  public List<c> x;
  
  public float y;
  
  public float z;
  
  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, 0);
    setDescendantFocusability(262144);
    float f2 = (getResources().getDisplayMetrics()).density;
    this.g = (int)(64.0F * f2 + 0.5F);
    float f3 = 400.0F * f2;
    f f4 = new f(this, 3);
    this.m = f4;
    f f1 = new f(this, 5);
    this.n = f1;
    h h2 = h.j(this, 1.0F, f4);
    this.k = h2;
    h2.p = 1;
    h2.n = f3;
    f4.b = h2;
    h h1 = h.j(this, 1.0F, f1);
    this.l = h1;
    h1.p = 2;
    h1.n = f3;
    f1.b = h1;
    setFocusableInTouchMode(true);
    AtomicInteger atomicInteger = u.a;
    setImportantForAccessibility(1);
    u.n((View)this, new a(this));
    setMotionEventSplittingEnabled(false);
    if (getFitsSystemWindows()) {
      setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener)new c.k.a.a(this));
      setSystemUiVisibility(1280);
      TypedArray typedArray = paramContext.obtainStyledAttributes(G);
      try {
        this.A = typedArray.getDrawable(0);
      } finally {
        typedArray.recycle();
      } 
    } 
    this.f = f2 * 10.0F;
    this.D = new ArrayList<View>();
  }
  
  public static String k(int paramInt) {
    return ((paramInt & 0x3) == 3) ? "LEFT" : (((paramInt & 0x5) == 5) ? "RIGHT" : Integer.toHexString(paramInt));
  }
  
  public static boolean l(View paramView) {
    AtomicInteger atomicInteger = u.a;
    return (paramView.getImportantForAccessibility() != 4 && paramView.getImportantForAccessibility() != 2);
  }
  
  public boolean a(View paramView, int paramInt) {
    return ((j(paramView) & paramInt) == paramInt);
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    if (getDescendantFocusability() == 393216)
      return; 
    int k = getChildCount();
    boolean bool = false;
    int i = 0;
    int j = i;
    while (i < k) {
      View view = getChildAt(i);
      if (p(view)) {
        if (o(view)) {
          view.addFocusables(paramArrayList, paramInt1, paramInt2);
          j = 1;
        } 
      } else {
        this.D.add(view);
      } 
      i++;
    } 
    if (j == 0) {
      j = this.D.size();
      for (i = bool; i < j; i++) {
        View view = this.D.get(i);
        if (view.getVisibility() == 0)
          view.addFocusables(paramArrayList, paramInt1, paramInt2); 
      } 
    } 
    this.D.clear();
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (f() != null || p(paramView)) {
      AtomicInteger atomicInteger1 = u.a;
      paramView.setImportantForAccessibility(4);
      return;
    } 
    AtomicInteger atomicInteger = u.a;
    paramView.setImportantForAccessibility(1);
  }
  
  public void b(int paramInt) {
    View view = e(paramInt);
    if (view != null) {
      c(view, true);
      return;
    } 
    StringBuilder stringBuilder = d.a.a.a.a.p("No drawer view found with gravity ");
    stringBuilder.append(k(paramInt));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void c(View paramView, boolean paramBoolean) {
    if (p(paramView)) {
      d d = (d)paramView.getLayoutParams();
      if (this.q) {
        d.b = 0.0F;
        d.d = 0;
      } else if (paramBoolean) {
        d.d |= 0x4;
        if (a(paramView, 3)) {
          this.k.x(paramView, -paramView.getWidth(), paramView.getTop());
        } else {
          this.l.x(paramView, getWidth(), paramView.getTop());
        } 
      } else {
        r(paramView, 0.0F);
        int i = d.a;
        w(0, paramView);
        paramView.setVisibility(4);
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof d && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void computeScroll() {
    int j = getChildCount();
    float f1 = 0.0F;
    for (int i = 0; i < j; i++)
      f1 = Math.max(f1, ((d)getChildAt(i).getLayoutParams()).b); 
    this.i = f1;
    boolean bool1 = this.k.i(true);
    boolean bool2 = this.l.i(true);
    if (bool1 || bool2) {
      AtomicInteger atomicInteger = u.a;
      postInvalidateOnAnimation();
    } 
  }
  
  public void d(boolean paramBoolean) {
    int j;
    int m = getChildCount();
    int i = 0;
    int k = i;
    while (i < m) {
      int i1;
      View view = getChildAt(i);
      d d = (d)view.getLayoutParams();
      int i2 = k;
      if (p(view))
        if (paramBoolean && !d.c) {
          i2 = k;
        } else {
          int i3;
          i2 = view.getWidth();
          if (a(view, 3)) {
            i3 = this.k.x(view, -i2, view.getTop());
          } else {
            i3 = this.l.x(view, getWidth(), view.getTop());
          } 
          i1 = k | i3;
          d.c = false;
        }  
      int n = i + 1;
      j = i1;
    } 
    this.m.n();
    this.n.n();
    if (j != 0)
      invalidate(); 
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) == 0 || paramMotionEvent.getAction() == 10 || this.i <= 0.0F)
      return super.dispatchGenericMotionEvent(paramMotionEvent); 
    int i = getChildCount();
    if (i != 0) {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      while (--i >= 0) {
        View view = getChildAt(i);
        if (this.E == null)
          this.E = new Rect(); 
        view.getHitRect(this.E);
        if (this.E.contains((int)f1, (int)f2) && !m(view)) {
          boolean bool;
          if (!view.getMatrix().isIdentity()) {
            float f3 = (getScrollX() - view.getLeft());
            float f4 = (getScrollY() - view.getTop());
            MotionEvent motionEvent = MotionEvent.obtain(paramMotionEvent);
            motionEvent.offsetLocation(f3, f4);
            Matrix matrix = view.getMatrix();
            if (!matrix.isIdentity()) {
              if (this.F == null)
                this.F = new Matrix(); 
              matrix.invert(this.F);
              motionEvent.transform(this.F);
            } 
            bool = view.dispatchGenericMotionEvent(motionEvent);
            motionEvent.recycle();
          } else {
            float f3 = (getScrollX() - view.getLeft());
            float f4 = (getScrollY() - view.getTop());
            paramMotionEvent.offsetLocation(f3, f4);
            bool = view.dispatchGenericMotionEvent(paramMotionEvent);
            paramMotionEvent.offsetLocation(-f3, -f4);
          } 
          if (bool)
            return true; 
        } 
        i--;
      } 
    } 
    return false;
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    int n = getHeight();
    boolean bool1 = m(paramView);
    int i = getWidth();
    int m = paramCanvas.save();
    int k = 0;
    int j = i;
    if (bool1) {
      int i1 = getChildCount();
      k = 0;
      for (j = k; k < i1; j = i3) {
        View view = getChildAt(k);
        int i2 = i;
        int i3 = j;
        if (view != paramView) {
          i2 = i;
          i3 = j;
          if (view.getVisibility() == 0) {
            int i4;
            Drawable drawable = view.getBackground();
            if (drawable != null && drawable.getOpacity() == -1) {
              i4 = 1;
            } else {
              i4 = 0;
            } 
            i2 = i;
            i3 = j;
            if (i4) {
              i2 = i;
              i3 = j;
              if (p(view))
                if (view.getHeight() < n) {
                  i2 = i;
                  i3 = j;
                } else if (a(view, 3)) {
                  i4 = view.getRight();
                  i2 = i;
                  i3 = j;
                  if (i4 > j) {
                    i3 = i4;
                    i2 = i;
                  } 
                } else {
                  i4 = view.getLeft();
                  i2 = i;
                  i3 = j;
                  if (i4 < i) {
                    i2 = i4;
                    i3 = j;
                  } 
                }  
            } 
          } 
        } 
        k++;
        i = i2;
      } 
      paramCanvas.clipRect(j, 0, i, getHeight());
      k = j;
      j = i;
    } 
    boolean bool2 = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(m);
    float f1 = this.i;
    if (f1 > 0.0F && bool1) {
      i = this.h;
      int i1 = (int)(((0xFF000000 & i) >>> 24) * f1);
      this.j.setColor(i1 << 24 | i & 0xFFFFFF);
      paramCanvas.drawRect(k, 0.0F, j, getHeight(), this.j);
    } 
    return bool2;
  }
  
  public View e(int paramInt) {
    AtomicInteger atomicInteger = u.a;
    int i = Gravity.getAbsoluteGravity(paramInt, getLayoutDirection());
    int j = getChildCount();
    for (paramInt = 0; paramInt < j; paramInt++) {
      View view = getChildAt(paramInt);
      if ((j(view) & 0x7) == (i & 0x7))
        return view; 
    } 
    return null;
  }
  
  public View f() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if ((((d)view.getLayoutParams()).d & 0x1) == 1)
        return view; 
    } 
    return null;
  }
  
  public View g() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (p(view) && q(view))
        return view; 
    } 
    return null;
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new d(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new d(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof d) ? new d((d)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new d((ViewGroup.MarginLayoutParams)paramLayoutParams) : new d(paramLayoutParams)));
  }
  
  public float getDrawerElevation() {
    return this.f;
  }
  
  public Drawable getStatusBarBackgroundDrawable() {
    return this.A;
  }
  
  public int h(int paramInt) {
    AtomicInteger atomicInteger = u.a;
    int i = getLayoutDirection();
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 8388611) {
          if (paramInt == 8388613) {
            paramInt = this.u;
            if (paramInt != 3)
              return paramInt; 
            if (i == 0) {
              paramInt = this.s;
            } else {
              paramInt = this.r;
            } 
            if (paramInt != 3)
              return paramInt; 
          } 
        } else {
          paramInt = this.t;
          if (paramInt != 3)
            return paramInt; 
          if (i == 0) {
            paramInt = this.r;
          } else {
            paramInt = this.s;
          } 
          if (paramInt != 3)
            return paramInt; 
        } 
      } else {
        paramInt = this.s;
        if (paramInt != 3)
          return paramInt; 
        if (i == 0) {
          paramInt = this.u;
        } else {
          paramInt = this.t;
        } 
        if (paramInt != 3)
          return paramInt; 
      } 
    } else {
      paramInt = this.r;
      if (paramInt != 3)
        return paramInt; 
      if (i == 0) {
        paramInt = this.t;
      } else {
        paramInt = this.u;
      } 
      if (paramInt != 3)
        return paramInt; 
    } 
    return 0;
  }
  
  public int i(View paramView) {
    if (p(paramView))
      return h(((d)paramView.getLayoutParams()).a); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public int j(View paramView) {
    int i = ((d)paramView.getLayoutParams()).a;
    AtomicInteger atomicInteger = u.a;
    return Gravity.getAbsoluteGravity(i, getLayoutDirection());
  }
  
  public boolean m(View paramView) {
    return (((d)paramView.getLayoutParams()).a == 0);
  }
  
  public boolean n(int paramInt) {
    View view = e(paramInt);
    return (view != null) ? o(view) : false;
  }
  
  public boolean o(View paramView) {
    if (p(paramView))
      return ((((d)paramView.getLayoutParams()).d & 0x1) == 1); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.q = true;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.q = true;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.C && this.A != null) {
      boolean bool;
      Object object = this.B;
      if (object != null) {
        bool = ((WindowInsets)object).getSystemWindowInsetTop();
      } else {
        bool = false;
      } 
      if (bool) {
        this.A.setBounds(0, 0, getWidth(), bool);
        this.A.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: getfield k : Lc/j/b/h;
    //   10: aload_1
    //   11: invokevirtual w : (Landroid/view/MotionEvent;)Z
    //   14: istore #8
    //   16: aload_0
    //   17: getfield l : Lc/j/b/h;
    //   20: aload_1
    //   21: invokevirtual w : (Landroid/view/MotionEvent;)Z
    //   24: istore #9
    //   26: iconst_0
    //   27: istore #7
    //   29: iload #4
    //   31: ifeq -> 214
    //   34: iload #4
    //   36: iconst_1
    //   37: if_icmpeq -> 198
    //   40: iload #4
    //   42: iconst_2
    //   43: if_icmpeq -> 55
    //   46: iload #4
    //   48: iconst_3
    //   49: if_icmpeq -> 198
    //   52: goto -> 208
    //   55: aload_0
    //   56: getfield k : Lc/j/b/h;
    //   59: astore_1
    //   60: aload_1
    //   61: getfield d : [F
    //   64: arraylength
    //   65: istore #6
    //   67: iconst_0
    //   68: istore #4
    //   70: iload #4
    //   72: iload #6
    //   74: if_icmpge -> 173
    //   77: aload_1
    //   78: iload #4
    //   80: invokevirtual n : (I)Z
    //   83: ifne -> 89
    //   86: goto -> 150
    //   89: aload_1
    //   90: getfield f : [F
    //   93: iload #4
    //   95: faload
    //   96: aload_1
    //   97: getfield d : [F
    //   100: iload #4
    //   102: faload
    //   103: fsub
    //   104: fstore_2
    //   105: aload_1
    //   106: getfield g : [F
    //   109: iload #4
    //   111: faload
    //   112: aload_1
    //   113: getfield e : [F
    //   116: iload #4
    //   118: faload
    //   119: fsub
    //   120: fstore_3
    //   121: aload_1
    //   122: getfield b : I
    //   125: istore #5
    //   127: fload_3
    //   128: fload_3
    //   129: fmul
    //   130: fload_2
    //   131: fload_2
    //   132: fmul
    //   133: fadd
    //   134: iload #5
    //   136: iload #5
    //   138: imul
    //   139: i2f
    //   140: fcmpl
    //   141: ifle -> 150
    //   144: iconst_1
    //   145: istore #5
    //   147: goto -> 153
    //   150: iconst_0
    //   151: istore #5
    //   153: iload #5
    //   155: ifeq -> 164
    //   158: iconst_1
    //   159: istore #4
    //   161: goto -> 176
    //   164: iload #4
    //   166: iconst_1
    //   167: iadd
    //   168: istore #4
    //   170: goto -> 70
    //   173: iconst_0
    //   174: istore #4
    //   176: iload #4
    //   178: ifeq -> 208
    //   181: aload_0
    //   182: getfield m : Landroidx/drawerlayout/widget/DrawerLayout$f;
    //   185: invokevirtual n : ()V
    //   188: aload_0
    //   189: getfield n : Landroidx/drawerlayout/widget/DrawerLayout$f;
    //   192: invokevirtual n : ()V
    //   195: goto -> 208
    //   198: aload_0
    //   199: iconst_1
    //   200: invokevirtual d : (Z)V
    //   203: aload_0
    //   204: iconst_0
    //   205: putfield v : Z
    //   208: iconst_0
    //   209: istore #4
    //   211: goto -> 281
    //   214: aload_1
    //   215: invokevirtual getX : ()F
    //   218: fstore_2
    //   219: aload_1
    //   220: invokevirtual getY : ()F
    //   223: fstore_3
    //   224: aload_0
    //   225: fload_2
    //   226: putfield y : F
    //   229: aload_0
    //   230: fload_3
    //   231: putfield z : F
    //   234: aload_0
    //   235: getfield i : F
    //   238: fconst_0
    //   239: fcmpl
    //   240: ifle -> 273
    //   243: aload_0
    //   244: getfield k : Lc/j/b/h;
    //   247: fload_2
    //   248: f2i
    //   249: fload_3
    //   250: f2i
    //   251: invokevirtual l : (II)Landroid/view/View;
    //   254: astore_1
    //   255: aload_1
    //   256: ifnull -> 273
    //   259: aload_0
    //   260: aload_1
    //   261: invokevirtual m : (Landroid/view/View;)Z
    //   264: ifeq -> 273
    //   267: iconst_1
    //   268: istore #4
    //   270: goto -> 276
    //   273: iconst_0
    //   274: istore #4
    //   276: aload_0
    //   277: iconst_0
    //   278: putfield v : Z
    //   281: iload #8
    //   283: iload #9
    //   285: ior
    //   286: ifne -> 358
    //   289: iload #4
    //   291: ifne -> 358
    //   294: aload_0
    //   295: invokevirtual getChildCount : ()I
    //   298: istore #5
    //   300: iconst_0
    //   301: istore #4
    //   303: iload #4
    //   305: iload #5
    //   307: if_icmpge -> 343
    //   310: aload_0
    //   311: iload #4
    //   313: invokevirtual getChildAt : (I)Landroid/view/View;
    //   316: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   319: checkcast androidx/drawerlayout/widget/DrawerLayout$d
    //   322: getfield c : Z
    //   325: ifeq -> 334
    //   328: iconst_1
    //   329: istore #4
    //   331: goto -> 346
    //   334: iload #4
    //   336: iconst_1
    //   337: iadd
    //   338: istore #4
    //   340: goto -> 303
    //   343: iconst_0
    //   344: istore #4
    //   346: iload #4
    //   348: ifne -> 358
    //   351: aload_0
    //   352: getfield v : Z
    //   355: ifeq -> 361
    //   358: iconst_1
    //   359: istore #7
    //   361: iload #7
    //   363: ireturn
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4) {
      boolean bool;
      if (g() != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        paramKeyEvent.startTracking();
        return true;
      } 
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    View view;
    if (paramInt == 4) {
      view = g();
      boolean bool = false;
      if (view != null && i(view) == 0)
        d(false); 
      if (view != null)
        bool = true; 
      return bool;
    } 
    return super.onKeyUp(paramInt, (KeyEvent)view);
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.p = true;
    int i = paramInt3 - paramInt1;
    int j = getChildCount();
    for (paramInt3 = 0; paramInt3 < j; paramInt3++) {
      View view = getChildAt(paramInt3);
      if (view.getVisibility() != 8) {
        d d = (d)view.getLayoutParams();
        if (m(view)) {
          paramInt1 = d.leftMargin;
          int k = d.topMargin;
          int m = view.getMeasuredWidth();
          int n = d.topMargin;
          view.layout(paramInt1, k, m + paramInt1, view.getMeasuredHeight() + n);
        } else {
          float f1;
          int k;
          boolean bool;
          int m = view.getMeasuredWidth();
          int n = view.getMeasuredHeight();
          if (a(view, 3)) {
            paramInt1 = -m;
            f1 = m;
            k = paramInt1 + (int)(d.b * f1);
            f1 = (m + k) / f1;
          } else {
            f1 = m;
            k = i - (int)(d.b * f1);
            f1 = (i - k) / f1;
          } 
          if (f1 != d.b) {
            bool = true;
          } else {
            bool = false;
          } 
          paramInt1 = d.a & 0x70;
          if (paramInt1 != 16) {
            if (paramInt1 != 80) {
              paramInt1 = d.topMargin;
              view.layout(k, paramInt1, m + k, n + paramInt1);
            } else {
              paramInt1 = paramInt4 - paramInt2;
              view.layout(k, paramInt1 - d.bottomMargin - view.getMeasuredHeight(), m + k, paramInt1 - d.bottomMargin);
            } 
          } else {
            int i2 = paramInt4 - paramInt2;
            int i1 = (i2 - n) / 2;
            paramInt1 = d.topMargin;
            if (i1 >= paramInt1) {
              int i3 = d.bottomMargin;
              paramInt1 = i1;
              if (i1 + n > i2 - i3)
                paramInt1 = i2 - i3 - n; 
            } 
            view.layout(k, paramInt1, m + k, n + paramInt1);
          } 
          if (bool)
            u(view, f1); 
          if (d.b > 0.0F) {
            paramInt1 = 0;
          } else {
            paramInt1 = 4;
          } 
          if (view.getVisibility() != paramInt1)
            view.setVisibility(paramInt1); 
        } 
      } 
    } 
    this.p = false;
    this.q = false;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getMode : (I)I
    //   4: istore #10
    //   6: iload_2
    //   7: invokestatic getMode : (I)I
    //   10: istore #9
    //   12: iload_1
    //   13: invokestatic getSize : (I)I
    //   16: istore #5
    //   18: iload_2
    //   19: invokestatic getSize : (I)I
    //   22: istore #6
    //   24: iload #10
    //   26: ldc_w 1073741824
    //   29: if_icmpne -> 48
    //   32: iload #5
    //   34: istore #7
    //   36: iload #6
    //   38: istore #8
    //   40: iload #9
    //   42: ldc_w 1073741824
    //   45: if_icmpeq -> 117
    //   48: aload_0
    //   49: invokevirtual isInEditMode : ()Z
    //   52: ifeq -> 800
    //   55: iload #10
    //   57: ldc_w -2147483648
    //   60: if_icmpne -> 66
    //   63: goto -> 76
    //   66: iload #10
    //   68: ifne -> 76
    //   71: sipush #300
    //   74: istore #5
    //   76: iload #9
    //   78: ldc_w -2147483648
    //   81: if_icmpne -> 95
    //   84: iload #5
    //   86: istore #7
    //   88: iload #6
    //   90: istore #8
    //   92: goto -> 117
    //   95: iload #5
    //   97: istore #7
    //   99: iload #6
    //   101: istore #8
    //   103: iload #9
    //   105: ifne -> 117
    //   108: sipush #300
    //   111: istore #8
    //   113: iload #5
    //   115: istore #7
    //   117: aload_0
    //   118: iload #7
    //   120: iload #8
    //   122: invokevirtual setMeasuredDimension : (II)V
    //   125: aload_0
    //   126: getfield B : Ljava/lang/Object;
    //   129: astore #15
    //   131: iconst_0
    //   132: istore #10
    //   134: aload #15
    //   136: ifnull -> 157
    //   139: getstatic c/h/j/u.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   142: astore #15
    //   144: aload_0
    //   145: invokevirtual getFitsSystemWindows : ()Z
    //   148: ifeq -> 157
    //   151: iconst_1
    //   152: istore #9
    //   154: goto -> 160
    //   157: iconst_0
    //   158: istore #9
    //   160: getstatic c/h/j/u.a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   163: astore #15
    //   165: aload_0
    //   166: invokevirtual getLayoutDirection : ()I
    //   169: istore #12
    //   171: aload_0
    //   172: invokevirtual getChildCount : ()I
    //   175: istore #13
    //   177: iconst_0
    //   178: istore #6
    //   180: iload #6
    //   182: istore #5
    //   184: iconst_0
    //   185: istore #11
    //   187: iload #10
    //   189: iload #13
    //   191: if_icmpge -> 799
    //   194: aload_0
    //   195: iload #10
    //   197: invokevirtual getChildAt : (I)Landroid/view/View;
    //   200: astore #17
    //   202: aload #17
    //   204: invokevirtual getVisibility : ()I
    //   207: bipush #8
    //   209: if_icmpne -> 215
    //   212: goto -> 503
    //   215: aload #17
    //   217: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   220: checkcast androidx/drawerlayout/widget/DrawerLayout$d
    //   223: astore #18
    //   225: iload #9
    //   227: ifeq -> 449
    //   230: aload #18
    //   232: getfield a : I
    //   235: iload #12
    //   237: invokestatic getAbsoluteGravity : (II)I
    //   240: istore #14
    //   242: aload #17
    //   244: invokevirtual getFitsSystemWindows : ()Z
    //   247: ifeq -> 335
    //   250: aload_0
    //   251: getfield B : Ljava/lang/Object;
    //   254: checkcast android/view/WindowInsets
    //   257: astore #16
    //   259: iload #14
    //   261: iconst_3
    //   262: if_icmpne -> 291
    //   265: aload #16
    //   267: aload #16
    //   269: invokevirtual getSystemWindowInsetLeft : ()I
    //   272: aload #16
    //   274: invokevirtual getSystemWindowInsetTop : ()I
    //   277: iconst_0
    //   278: aload #16
    //   280: invokevirtual getSystemWindowInsetBottom : ()I
    //   283: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   286: astore #15
    //   288: goto -> 324
    //   291: aload #16
    //   293: astore #15
    //   295: iload #14
    //   297: iconst_5
    //   298: if_icmpne -> 324
    //   301: aload #16
    //   303: iconst_0
    //   304: aload #16
    //   306: invokevirtual getSystemWindowInsetTop : ()I
    //   309: aload #16
    //   311: invokevirtual getSystemWindowInsetRight : ()I
    //   314: aload #16
    //   316: invokevirtual getSystemWindowInsetBottom : ()I
    //   319: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   322: astore #15
    //   324: aload #17
    //   326: aload #15
    //   328: invokevirtual dispatchApplyWindowInsets : (Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    //   331: pop
    //   332: goto -> 449
    //   335: aload_0
    //   336: getfield B : Ljava/lang/Object;
    //   339: checkcast android/view/WindowInsets
    //   342: astore #16
    //   344: iload #14
    //   346: iconst_3
    //   347: if_icmpne -> 376
    //   350: aload #16
    //   352: aload #16
    //   354: invokevirtual getSystemWindowInsetLeft : ()I
    //   357: aload #16
    //   359: invokevirtual getSystemWindowInsetTop : ()I
    //   362: iconst_0
    //   363: aload #16
    //   365: invokevirtual getSystemWindowInsetBottom : ()I
    //   368: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   371: astore #15
    //   373: goto -> 409
    //   376: aload #16
    //   378: astore #15
    //   380: iload #14
    //   382: iconst_5
    //   383: if_icmpne -> 409
    //   386: aload #16
    //   388: iconst_0
    //   389: aload #16
    //   391: invokevirtual getSystemWindowInsetTop : ()I
    //   394: aload #16
    //   396: invokevirtual getSystemWindowInsetRight : ()I
    //   399: aload #16
    //   401: invokevirtual getSystemWindowInsetBottom : ()I
    //   404: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   407: astore #15
    //   409: aload #18
    //   411: aload #15
    //   413: invokevirtual getSystemWindowInsetLeft : ()I
    //   416: putfield leftMargin : I
    //   419: aload #18
    //   421: aload #15
    //   423: invokevirtual getSystemWindowInsetTop : ()I
    //   426: putfield topMargin : I
    //   429: aload #18
    //   431: aload #15
    //   433: invokevirtual getSystemWindowInsetRight : ()I
    //   436: putfield rightMargin : I
    //   439: aload #18
    //   441: aload #15
    //   443: invokevirtual getSystemWindowInsetBottom : ()I
    //   446: putfield bottomMargin : I
    //   449: aload_0
    //   450: aload #17
    //   452: invokevirtual m : (Landroid/view/View;)Z
    //   455: ifeq -> 506
    //   458: aload #17
    //   460: iload #7
    //   462: aload #18
    //   464: getfield leftMargin : I
    //   467: isub
    //   468: aload #18
    //   470: getfield rightMargin : I
    //   473: isub
    //   474: ldc_w 1073741824
    //   477: invokestatic makeMeasureSpec : (II)I
    //   480: iload #8
    //   482: aload #18
    //   484: getfield topMargin : I
    //   487: isub
    //   488: aload #18
    //   490: getfield bottomMargin : I
    //   493: isub
    //   494: ldc_w 1073741824
    //   497: invokestatic makeMeasureSpec : (II)I
    //   500: invokevirtual measure : (II)V
    //   503: goto -> 716
    //   506: aload_0
    //   507: aload #17
    //   509: invokevirtual p : (Landroid/view/View;)Z
    //   512: ifeq -> 725
    //   515: aload #17
    //   517: invokevirtual getElevation : ()F
    //   520: fstore_3
    //   521: aload_0
    //   522: getfield f : F
    //   525: fstore #4
    //   527: fload_3
    //   528: fload #4
    //   530: fcmpl
    //   531: ifeq -> 541
    //   534: aload #17
    //   536: fload #4
    //   538: invokevirtual setElevation : (F)V
    //   541: aload_0
    //   542: aload #17
    //   544: invokevirtual j : (Landroid/view/View;)I
    //   547: bipush #7
    //   549: iand
    //   550: istore #14
    //   552: iload #14
    //   554: iconst_3
    //   555: if_icmpne -> 561
    //   558: iconst_1
    //   559: istore #11
    //   561: iload #11
    //   563: ifeq -> 571
    //   566: iload #6
    //   568: ifne -> 584
    //   571: iload #11
    //   573: ifne -> 652
    //   576: iload #5
    //   578: ifne -> 584
    //   581: goto -> 652
    //   584: ldc_w 'Child drawer has absolute gravity '
    //   587: invokestatic p : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   590: astore #15
    //   592: aload #15
    //   594: iload #14
    //   596: invokestatic k : (I)Ljava/lang/String;
    //   599: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   602: pop
    //   603: aload #15
    //   605: ldc_w ' but this '
    //   608: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   611: pop
    //   612: aload #15
    //   614: ldc_w 'DrawerLayout'
    //   617: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   620: pop
    //   621: aload #15
    //   623: ldc_w ' already has a '
    //   626: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   629: pop
    //   630: aload #15
    //   632: ldc_w 'drawer view along that edge'
    //   635: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   638: pop
    //   639: new java/lang/IllegalStateException
    //   642: dup
    //   643: aload #15
    //   645: invokevirtual toString : ()Ljava/lang/String;
    //   648: invokespecial <init> : (Ljava/lang/String;)V
    //   651: athrow
    //   652: iload #11
    //   654: ifeq -> 663
    //   657: iconst_1
    //   658: istore #6
    //   660: goto -> 666
    //   663: iconst_1
    //   664: istore #5
    //   666: aload #17
    //   668: iload_1
    //   669: aload_0
    //   670: getfield g : I
    //   673: aload #18
    //   675: getfield leftMargin : I
    //   678: iadd
    //   679: aload #18
    //   681: getfield rightMargin : I
    //   684: iadd
    //   685: aload #18
    //   687: getfield width : I
    //   690: invokestatic getChildMeasureSpec : (III)I
    //   693: iload_2
    //   694: aload #18
    //   696: getfield topMargin : I
    //   699: aload #18
    //   701: getfield bottomMargin : I
    //   704: iadd
    //   705: aload #18
    //   707: getfield height : I
    //   710: invokestatic getChildMeasureSpec : (III)I
    //   713: invokevirtual measure : (II)V
    //   716: iload #10
    //   718: iconst_1
    //   719: iadd
    //   720: istore #10
    //   722: goto -> 184
    //   725: new java/lang/StringBuilder
    //   728: dup
    //   729: invokespecial <init> : ()V
    //   732: astore #15
    //   734: aload #15
    //   736: ldc_w 'Child '
    //   739: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   742: pop
    //   743: aload #15
    //   745: aload #17
    //   747: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   750: pop
    //   751: aload #15
    //   753: ldc_w ' at index '
    //   756: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   759: pop
    //   760: aload #15
    //   762: iload #10
    //   764: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   767: pop
    //   768: aload #15
    //   770: ldc_w ' does not have a valid layout_gravity - must be Gravity.LEFT, '
    //   773: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   776: pop
    //   777: aload #15
    //   779: ldc_w 'Gravity.RIGHT or Gravity.NO_GRAVITY'
    //   782: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   785: pop
    //   786: new java/lang/IllegalStateException
    //   789: dup
    //   790: aload #15
    //   792: invokevirtual toString : ()Ljava/lang/String;
    //   795: invokespecial <init> : (Ljava/lang/String;)V
    //   798: athrow
    //   799: return
    //   800: new java/lang/IllegalArgumentException
    //   803: dup
    //   804: ldc_w 'DrawerLayout must be measured with MeasureSpec.EXACTLY.'
    //   807: invokespecial <init> : (Ljava/lang/String;)V
    //   810: athrow
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof e)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    e e = (e)paramParcelable;
    super.onRestoreInstanceState(e.e);
    int i = e.g;
    if (i != 0) {
      View view = e(i);
      if (view != null)
        s(view, true); 
    } 
    i = e.h;
    if (i != 3)
      t(i, 3); 
    i = e.i;
    if (i != 3)
      t(i, 5); 
    i = e.j;
    if (i != 3)
      t(i, 8388611); 
    i = e.k;
    if (i != 3)
      t(i, 8388613); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {}
  
  public Parcelable onSaveInstanceState() {
    e e = new e(super.onSaveInstanceState());
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool1;
      d d = (d)getChildAt(i).getLayoutParams();
      int k = d.d;
      boolean bool2 = true;
      if (k == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (k != 2)
        bool2 = false; 
      if (bool1 || bool2) {
        e.g = d.a;
        break;
      } 
    } 
    e.h = this.r;
    e.i = this.s;
    e.j = this.t;
    e.k = this.u;
    return (Parcelable)e;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    View view;
    this.k.p(paramMotionEvent);
    this.l.p(paramMotionEvent);
    int i = paramMotionEvent.getAction() & 0xFF;
    boolean bool = false;
    if (i != 0) {
      if (i != 1) {
        if (i != 3)
          return true; 
        d(true);
        this.v = false;
        return true;
      } 
      float f2 = paramMotionEvent.getX();
      float f1 = paramMotionEvent.getY();
      view = this.k.l((int)f2, (int)f1);
      if (view != null && m(view)) {
        f2 -= this.y;
        f1 -= this.z;
        i = this.k.b;
        if (f1 * f1 + f2 * f2 < (i * i)) {
          view = f();
          if (view == null || i(view) == 2) {
            bool = true;
            d(bool);
            return true;
          } 
          d(bool);
          return true;
        } 
      } 
    } else {
      float f1 = view.getX();
      float f2 = view.getY();
      this.y = f1;
      this.z = f2;
      this.v = false;
      return true;
    } 
    bool = true;
    d(bool);
    return true;
  }
  
  public boolean p(View paramView) {
    int i = ((d)paramView.getLayoutParams()).a;
    AtomicInteger atomicInteger = u.a;
    i = Gravity.getAbsoluteGravity(i, paramView.getLayoutDirection());
    return ((i & 0x3) != 0) ? true : (((i & 0x5) != 0));
  }
  
  public boolean q(View paramView) {
    if (p(paramView))
      return (((d)paramView.getLayoutParams()).b > 0.0F); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void r(View paramView, float paramFloat) {
    float f1 = ((d)paramView.getLayoutParams()).b;
    float f2 = paramView.getWidth();
    int i = (int)(f1 * f2);
    i = (int)(f2 * paramFloat) - i;
    if (!a(paramView, 3))
      i = -i; 
    paramView.offsetLeftAndRight(i);
    u(paramView, paramFloat);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean)
      d(true); 
  }
  
  public void requestLayout() {
    if (!this.p)
      super.requestLayout(); 
  }
  
  public void s(View paramView, boolean paramBoolean) {
    if (p(paramView)) {
      d d = (d)paramView.getLayoutParams();
      if (this.q) {
        d.b = 1.0F;
        d.d = 1;
        v(paramView, true);
      } else if (paramBoolean) {
        d.d |= 0x2;
        if (a(paramView, 3)) {
          this.k.x(paramView, 0, paramView.getTop());
        } else {
          this.l.x(paramView, getWidth() - paramView.getWidth(), paramView.getTop());
        } 
      } else {
        r(paramView, 1.0F);
        int i = d.a;
        w(0, paramView);
        paramView.setVisibility(0);
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDrawerElevation(float paramFloat) {
    this.f = paramFloat;
    for (int i = 0; i < getChildCount(); i++) {
      View view = getChildAt(i);
      if (p(view)) {
        paramFloat = this.f;
        AtomicInteger atomicInteger = u.a;
        view.setElevation(paramFloat);
      } 
    } 
  }
  
  @Deprecated
  public void setDrawerListener(c paramc) {
    c c1 = this.w;
    if (c1 != null) {
      List<c> list = this.x;
      if (list != null)
        list.remove(c1); 
    } 
    if (paramc != null) {
      if (this.x == null)
        this.x = new ArrayList<c>(); 
      this.x.add(paramc);
    } 
    this.w = paramc;
  }
  
  public void setDrawerLockMode(int paramInt) {
    t(paramInt, 3);
    t(paramInt, 5);
  }
  
  public void setScrimColor(int paramInt) {
    this.h = paramInt;
    invalidate();
  }
  
  public void setStatusBarBackground(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      Context context = getContext();
      Object object = c.h.b.b.a;
      drawable = c.h.c.b.b(context, paramInt);
    } else {
      drawable = null;
    } 
    this.A = drawable;
    invalidate();
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    this.A = paramDrawable;
    invalidate();
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    this.A = (Drawable)new ColorDrawable(paramInt);
    invalidate();
  }
  
  public void t(int paramInt1, int paramInt2) {
    AtomicInteger atomicInteger = u.a;
    int i = Gravity.getAbsoluteGravity(paramInt2, getLayoutDirection());
    if (paramInt2 != 3) {
      if (paramInt2 != 5) {
        if (paramInt2 != 8388611) {
          if (paramInt2 == 8388613)
            this.u = paramInt1; 
        } else {
          this.t = paramInt1;
        } 
      } else {
        this.s = paramInt1;
      } 
    } else {
      this.r = paramInt1;
    } 
    if (paramInt1 != 0) {
      h h1;
      if (i == 3) {
        h1 = this.k;
      } else {
        h1 = this.l;
      } 
      h1.a();
    } 
    if (paramInt1 != 1) {
      if (paramInt1 != 2)
        return; 
      View view = e(i);
      if (view != null) {
        s(view, true);
        return;
      } 
    } else {
      View view = e(i);
      if (view != null)
        c(view, true); 
    } 
  }
  
  public void u(View paramView, float paramFloat) {
    d d = (d)paramView.getLayoutParams();
    if (paramFloat == d.b)
      return; 
    d.b = paramFloat;
    List<c> list = this.x;
    if (list != null) {
      int i = list.size();
      while (true) {
        if (--i >= 0) {
          g g = (g)this.x.get(i);
          Objects.requireNonNull(g);
          g.a(Math.min(1.0F, Math.max(0.0F, paramFloat)));
          continue;
        } 
        break;
      } 
    } 
  }
  
  public final void v(View paramView, boolean paramBoolean) {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if ((!paramBoolean && !p(view)) || (paramBoolean && view == paramView)) {
        AtomicInteger atomicInteger = u.a;
        view.setImportantForAccessibility(1);
      } else {
        AtomicInteger atomicInteger = u.a;
        view.setImportantForAccessibility(4);
      } 
    } 
  }
  
  public void w(int paramInt, View paramView) {
    int i;
    int k = this.k.a;
    int m = this.l.a;
    int j = 2;
    if (k == 1 || m == 1) {
      i = 1;
    } else {
      i = j;
      if (k != 2)
        if (m == 2) {
          i = j;
        } else {
          i = 0;
        }  
    } 
    if (paramView != null && paramInt == 0) {
      float f1 = ((d)paramView.getLayoutParams()).b;
      if (f1 == 0.0F) {
        d d = (d)paramView.getLayoutParams();
        if ((d.d & 0x1) == 1) {
          d.d = 0;
          List<c> list = this.x;
          if (list != null)
            for (paramInt = list.size() - 1; paramInt >= 0; paramInt--) {
              g g = (g)this.x.get(paramInt);
              g.a(0.0F);
              j = g.d;
              g.a.d(j);
            }  
          v(paramView, false);
          if (hasWindowFocus()) {
            paramView = getRootView();
            if (paramView != null)
              paramView.sendAccessibilityEvent(32); 
          } 
        } 
      } else if (f1 == 1.0F) {
        d d = (d)paramView.getLayoutParams();
        if ((d.d & 0x1) == 0) {
          d.d = 1;
          List<c> list = this.x;
          if (list != null)
            for (paramInt = list.size() - 1; paramInt >= 0; paramInt--) {
              g g = (g)this.x.get(paramInt);
              g.a(1.0F);
              j = g.e;
              g.a.d(j);
            }  
          v(paramView, true);
          if (hasWindowFocus())
            sendAccessibilityEvent(32); 
        } 
      } 
    } 
    if (i != this.o) {
      this.o = i;
      List<c> list = this.x;
      if (list != null)
        for (paramInt = list.size() - 1; paramInt >= 0; paramInt--)
          Objects.requireNonNull((g)this.x.get(paramInt));  
    } 
  }
  
  public class a extends c.h.j.b {
    public final Rect d = new Rect();
    
    public a(DrawerLayout this$0) {}
    
    public boolean a(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      DrawerLayout drawerLayout;
      AtomicInteger atomicInteger;
      if (param1AccessibilityEvent.getEventType() == 32) {
        param1AccessibilityEvent.getText();
        param1View = this.e.g();
        if (param1View != null) {
          int i = this.e.j(param1View);
          drawerLayout = this.e;
          Objects.requireNonNull(drawerLayout);
          atomicInteger = u.a;
          Gravity.getAbsoluteGravity(i, drawerLayout.getLayoutDirection());
        } 
        return true;
      } 
      return this.a.dispatchPopulateAccessibilityEvent((View)drawerLayout, (AccessibilityEvent)atomicInteger);
    }
    
    public void c(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(DrawerLayout.class.getName());
    }
    
    public void d(View param1View, c.h.j.m0.b param1b) {
      int[] arrayOfInt = DrawerLayout.G;
      this.a.onInitializeAccessibilityNodeInfo(param1View, param1b.a);
      String str = DrawerLayout.class.getName();
      param1b.a.setClassName(str);
      param1b.a.setFocusable(false);
      param1b.a.setFocused(false);
      c.h.j.m0.b.a a1 = c.h.j.m0.b.a.e;
      param1b.a.removeAction((AccessibilityNodeInfo.AccessibilityAction)a1.a);
      a1 = c.h.j.m0.b.a.f;
      param1b.a.removeAction((AccessibilityNodeInfo.AccessibilityAction)a1.a);
    }
    
    public boolean f(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      int[] arrayOfInt = DrawerLayout.G;
      return this.a.onRequestSendAccessibilityEvent(param1ViewGroup, param1View, param1AccessibilityEvent);
    }
  }
  
  public static final class b extends c.h.j.b {
    public void d(View param1View, c.h.j.m0.b param1b) {
      this.a.onInitializeAccessibilityNodeInfo(param1View, param1b.a);
      if (!DrawerLayout.l(param1View))
        param1b.p(null); 
    }
  }
  
  public static interface c {}
  
  public static class d extends ViewGroup.MarginLayoutParams {
    public int a = 0;
    
    public float b;
    
    public boolean c;
    
    public int d;
    
    public d(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public d(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, DrawerLayout.H);
      this.a = typedArray.getInt(0, 0);
      typedArray.recycle();
    }
    
    public d(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public d(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public d(d param1d) {
      super(param1d);
      this.a = param1d.a;
    }
  }
  
  public static class e extends c.j.a.c {
    public static final Parcelable.Creator<e> CREATOR = (Parcelable.Creator<e>)new c.k.a.b();
    
    public int g = 0;
    
    public int h;
    
    public int i;
    
    public int j;
    
    public int k;
    
    public e(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.g = param1Parcel.readInt();
      this.h = param1Parcel.readInt();
      this.i = param1Parcel.readInt();
      this.j = param1Parcel.readInt();
      this.k = param1Parcel.readInt();
    }
    
    public e(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeParcelable(this.e, param1Int);
      param1Parcel.writeInt(this.g);
      param1Parcel.writeInt(this.h);
      param1Parcel.writeInt(this.i);
      param1Parcel.writeInt(this.j);
      param1Parcel.writeInt(this.k);
    }
  }
  
  public class f extends h.a {
    public final int a;
    
    public h b;
    
    public final Runnable c = (Runnable)new c.k.a.c(this);
    
    public f(DrawerLayout this$0, int param1Int) {
      this.a = param1Int;
    }
    
    public int a(View param1View, int param1Int1, int param1Int2) {
      if (this.d.a(param1View, 3))
        return Math.max(-param1View.getWidth(), Math.min(param1Int1, 0)); 
      param1Int2 = this.d.getWidth();
      return Math.max(param1Int2 - param1View.getWidth(), Math.min(param1Int1, param1Int2));
    }
    
    public int b(View param1View, int param1Int1, int param1Int2) {
      return param1View.getTop();
    }
    
    public int c(View param1View) {
      return this.d.p(param1View) ? param1View.getWidth() : 0;
    }
    
    public void e(int param1Int1, int param1Int2) {
      View view;
      if ((param1Int1 & 0x1) == 1) {
        view = this.d.e(3);
      } else {
        view = this.d.e(5);
      } 
      if (view != null && this.d.i(view) == 0)
        this.b.b(view, param1Int2); 
    }
    
    public boolean f(int param1Int) {
      return false;
    }
    
    public void g(int param1Int1, int param1Int2) {
      this.d.postDelayed(this.c, 160L);
    }
    
    public void h(View param1View, int param1Int) {
      ((DrawerLayout.d)param1View.getLayoutParams()).c = false;
      m();
    }
    
    public void i(int param1Int) {
      this.d.w(param1Int, this.b.s);
    }
    
    public void j(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      float f1;
      param1Int2 = param1View.getWidth();
      if (this.d.a(param1View, 3)) {
        f1 = (param1Int1 + param1Int2);
      } else {
        f1 = (this.d.getWidth() - param1Int1);
      } 
      f1 /= param1Int2;
      this.d.u(param1View, f1);
      if (f1 == 0.0F) {
        param1Int1 = 4;
      } else {
        param1Int1 = 0;
      } 
      param1View.setVisibility(param1Int1);
      this.d.invalidate();
    }
    
    public void k(View param1View, float param1Float1, float param1Float2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   4: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
      //   7: pop
      //   8: aload_1
      //   9: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   12: checkcast androidx/drawerlayout/widget/DrawerLayout$d
      //   15: getfield b : F
      //   18: fstore_3
      //   19: aload_1
      //   20: invokevirtual getWidth : ()I
      //   23: istore #6
      //   25: aload_0
      //   26: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   29: aload_1
      //   30: iconst_3
      //   31: invokevirtual a : (Landroid/view/View;I)Z
      //   34: ifeq -> 76
      //   37: fload_2
      //   38: fconst_0
      //   39: fcmpl
      //   40: istore #4
      //   42: iload #4
      //   44: ifgt -> 70
      //   47: iload #4
      //   49: ifne -> 62
      //   52: fload_3
      //   53: ldc 0.5
      //   55: fcmpl
      //   56: ifle -> 62
      //   59: goto -> 70
      //   62: iload #6
      //   64: ineg
      //   65: istore #4
      //   67: goto -> 119
      //   70: iconst_0
      //   71: istore #4
      //   73: goto -> 119
      //   76: aload_0
      //   77: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   80: invokevirtual getWidth : ()I
      //   83: istore #5
      //   85: fload_2
      //   86: fconst_0
      //   87: fcmpg
      //   88: iflt -> 112
      //   91: iload #5
      //   93: istore #4
      //   95: fload_2
      //   96: fconst_0
      //   97: fcmpl
      //   98: ifne -> 119
      //   101: iload #5
      //   103: istore #4
      //   105: fload_3
      //   106: ldc 0.5
      //   108: fcmpl
      //   109: ifle -> 119
      //   112: iload #5
      //   114: iload #6
      //   116: isub
      //   117: istore #4
      //   119: aload_0
      //   120: getfield b : Lc/j/b/h;
      //   123: iload #4
      //   125: aload_1
      //   126: invokevirtual getTop : ()I
      //   129: invokevirtual v : (II)Z
      //   132: pop
      //   133: aload_0
      //   134: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   137: invokevirtual invalidate : ()V
      //   140: return
    }
    
    public boolean l(View param1View, int param1Int) {
      return (this.d.p(param1View) && this.d.a(param1View, this.a) && this.d.i(param1View) == 0);
    }
    
    public final void m() {
      int i = this.a;
      byte b = 3;
      if (i == 3)
        b = 5; 
      View view = this.d.e(b);
      if (view != null)
        this.d.c(view, true); 
    }
    
    public void n() {
      this.d.removeCallbacks(this.c);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\drawerlayout\widget\DrawerLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */