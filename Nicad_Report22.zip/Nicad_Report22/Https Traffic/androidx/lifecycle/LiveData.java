package androidx.lifecycle;

import c.c.a.a.b;
import c.c.a.b.e;
import c.p.e;
import c.p.f;
import c.p.h;
import c.p.m;
import c.p.p;
import java.util.Map;
import java.util.Objects;

public abstract class LiveData<T> {
  public static final Object j = new Object();
  
  public final Object a = new Object();
  
  public e<p<? super T>, a> b = new e();
  
  public int c = 0;
  
  public volatile Object d;
  
  public volatile Object e;
  
  public int f;
  
  public boolean g;
  
  public boolean h;
  
  public final Runnable i;
  
  public LiveData() {
    Object object = j;
    this.e = object;
    this.i = (Runnable)new m(this);
    this.d = object;
    this.f = -1;
  }
  
  public static void a(String paramString) {
    if ((b.d()).a.b())
      return; 
    throw new IllegalStateException(d.a.a.a.a.g("Cannot invoke ", paramString, " on a background thread"));
  }
  
  public final void b(a parama) {
    if (!parama.f)
      return; 
    if (!parama.i()) {
      parama.h(false);
      return;
    } 
    int i = parama.g;
    int j = this.f;
    if (i >= j)
      return; 
    parama.g = j;
    parama.e.a(this.d);
  }
  
  public void c(a parama) {
    if (this.g) {
      this.h = true;
      return;
    } 
    this.g = true;
    while (true) {
      a a1;
      this.h = false;
      if (parama != null) {
        b(parama);
        a1 = null;
      } else {
        e.a a2 = this.b.d();
        while (true) {
          a1 = parama;
          if (a2.hasNext()) {
            b((a)((Map.Entry)a2.next()).getValue());
            if (this.h) {
              a1 = parama;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      parama = a1;
      if (!this.h) {
        this.g = false;
        return;
      } 
    } 
  }
  
  public abstract void d(T paramT);
  
  public class LifecycleBoundObserver extends a implements f {
    public void d(h param1h, e.a param1a) {
      throw null;
    }
    
    public boolean i() {
      throw null;
    }
  }
  
  public abstract class a {
    public final p<? super T> e;
    
    public boolean f;
    
    public int g;
    
    public void h(boolean param1Boolean) {
      boolean bool;
      if (param1Boolean == this.f)
        return; 
      this.f = param1Boolean;
      LiveData liveData = this.h;
      int i = liveData.c;
      byte b = 1;
      if (i == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!param1Boolean)
        b = -1; 
      liveData.c = i + b;
      if (bool && param1Boolean)
        Objects.requireNonNull(liveData); 
      liveData = this.h;
      if (liveData.c == 0 && !this.f)
        Objects.requireNonNull(liveData); 
      if (this.f)
        this.h.c(this); 
    }
    
    public abstract boolean i();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */