package androidx.lifecycle;

import c.p.d;
import c.p.e;
import c.p.f;
import c.p.h;
import c.p.n;

public class CompositeGeneratedAdaptersObserver implements f {
  public final d[] e;
  
  public CompositeGeneratedAdaptersObserver(d[] paramArrayOfd) {
    this.e = paramArrayOfd;
  }
  
  public void d(h paramh, e.a parama) {
    n n = new n();
    d[] arrayOfD = this.e;
    int j = arrayOfD.length;
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++)
      arrayOfD[i].a(paramh, parama, false, n); 
    arrayOfD = this.e;
    j = arrayOfD.length;
    for (i = bool; i < j; i++)
      arrayOfD[i].a(paramh, parama, true, n); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */