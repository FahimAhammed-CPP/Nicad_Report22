package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import c.u.d;
import c.u.e;
import java.util.HashMap;

public class MultiInstanceInvalidationService extends Service {
  public int e = 0;
  
  public final HashMap<Integer, String> f = new HashMap<Integer, String>();
  
  public final RemoteCallbackList<d> g = new a(this);
  
  public final e h = new b(this);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.h;
  }
  
  public class a extends RemoteCallbackList<d> {
    public a(MultiInstanceInvalidationService this$0) {}
    
    public void onCallbackDied(IInterface param1IInterface, Object param1Object) {
      d d = (d)param1IInterface;
      this.a.f.remove(Integer.valueOf(((Integer)param1Object).intValue()));
    }
  }
  
  public class b extends e {
    public b(MultiInstanceInvalidationService this$0) {}
    
    public int U(d param1d, String param1String) {
      if (param1String == null)
        return 0; 
      synchronized (this.e.g) {
        MultiInstanceInvalidationService multiInstanceInvalidationService2 = this.e;
        int i = multiInstanceInvalidationService2.e + 1;
        multiInstanceInvalidationService2.e = i;
        if (multiInstanceInvalidationService2.g.register((IInterface)param1d, Integer.valueOf(i))) {
          this.e.f.put(Integer.valueOf(i), param1String);
          return i;
        } 
        MultiInstanceInvalidationService multiInstanceInvalidationService1 = this.e;
        multiInstanceInvalidationService1.e--;
        return 0;
      } 
    }
    
    public void b0(d param1d, int param1Int) {
      synchronized (this.e.g) {
        this.e.g.unregister((IInterface)param1d);
        this.e.f.remove(Integer.valueOf(param1Int));
        return;
      } 
    }
    
    public void y(int param1Int, String[] param1ArrayOfString) {
      synchronized (this.e.g) {
        String str = this.e.f.get(Integer.valueOf(param1Int));
        if (str == null) {
          Log.w("ROOM", "Remote invalidation client ID not registered");
          return;
        } 
        int j = this.e.g.beginBroadcast();
        int i = 0;
        while (i < j) {
          try {
            int k = ((Integer)this.e.g.getBroadcastCookie(i)).intValue();
            String str1 = this.e.f.get(Integer.valueOf(k));
            if (param1Int != k) {
              boolean bool = str.equals(str1);
              if (bool)
                try {
                  ((d)this.e.g.getBroadcastItem(i)).h1(param1ArrayOfString);
                } catch (RemoteException remoteException) {
                  Log.w("ROOM", "Error invoking a remote callback", (Throwable)remoteException);
                }  
            } 
          } finally {
            this.e.g.finishBroadcast();
          } 
        } 
        this.e.g.finishBroadcast();
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\room\MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */