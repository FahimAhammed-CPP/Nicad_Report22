package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import c.h.b.h;
import c.t.b.c0;
import c.t.b.m0;
import c.t.b.n0;
import c.t.b.u;
import c.t.b.w;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import java.util.Objects;

public class StaggeredGridLayoutManager extends RecyclerView.l {
  public int A;
  
  public int B;
  
  public d C;
  
  public int D;
  
  public boolean E;
  
  public boolean F;
  
  public e G;
  
  public int H;
  
  public final Rect I;
  
  public final b J;
  
  public boolean K;
  
  public int[] L;
  
  public final Runnable M;
  
  public int q = -1;
  
  public f[] r;
  
  public c0 s;
  
  public c0 t;
  
  public int u;
  
  public int v;
  
  public final w w;
  
  public boolean x;
  
  public boolean y;
  
  public BitSet z;
  
  public StaggeredGridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    boolean bool = false;
    this.x = false;
    this.y = false;
    this.A = -1;
    this.B = Integer.MIN_VALUE;
    this.C = new d();
    this.D = 2;
    this.I = new Rect();
    this.J = new b(this);
    this.K = true;
    this.M = new a(this);
    RecyclerView.l.b b1 = RecyclerView.l.M(paramContext, paramAttributeSet, paramInt1, paramInt2);
    paramInt1 = b1.a;
    if (paramInt1 == 0 || paramInt1 == 1) {
      c(null);
      if (paramInt1 != this.u) {
        this.u = paramInt1;
        c0 c01 = this.s;
        this.s = this.t;
        this.t = c01;
        E0();
      } 
      paramInt1 = b1.b;
      c(null);
      if (paramInt1 != this.q) {
        this.C.a();
        E0();
        this.q = paramInt1;
        this.z = new BitSet(this.q);
        this.r = new f[this.q];
        for (paramInt1 = bool; paramInt1 < this.q; paramInt1++)
          this.r[paramInt1] = new f(this, paramInt1); 
        E0();
      } 
      boolean bool1 = b1.c;
      c(null);
      e e1 = this.G;
      if (e1 != null && e1.l != bool1)
        e1.l = bool1; 
      this.x = bool1;
      E0();
      this.w = new w();
      this.s = c0.a(this, this.u);
      this.t = c0.a(this, 1 - this.u);
      return;
    } 
    throw new IllegalArgumentException("invalid orientation.");
  }
  
  public int F0(int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    return o1(paramInt, paramr, paramv);
  }
  
  public int G0(int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    return o1(paramInt, paramr, paramv);
  }
  
  public void J0(Rect paramRect, int paramInt1, int paramInt2) {
    int i = I();
    i = J() + i;
    int j = K();
    j = H() + j;
    if (this.u == 1) {
      paramInt2 = RecyclerView.l.g(paramInt2, paramRect.height() + j, F());
      i = RecyclerView.l.g(paramInt1, this.v * this.q + i, G());
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      paramInt1 = RecyclerView.l.g(paramInt1, paramRect.width() + i, G());
      i = RecyclerView.l.g(paramInt2, this.v * this.q + j, F());
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    RecyclerView.e(this.b, paramInt2, paramInt1);
  }
  
  public int N(RecyclerView.r paramr, RecyclerView.v paramv) {
    return (this.u == 0) ? this.q : super.N(paramr, paramv);
  }
  
  public boolean P0() {
    return (this.G == null);
  }
  
  public boolean Q() {
    return (this.D != 0);
  }
  
  public boolean Q0() {
    if (x() != 0 && this.D != 0) {
      int i;
      if (!this.h)
        return false; 
      if (this.y) {
        i = a1();
        Z0();
      } else {
        i = Z0();
        a1();
      } 
      if (i == 0 && e1() != null) {
        this.C.a();
        this.g = true;
        E0();
        return true;
      } 
    } 
    return false;
  }
  
  public final int R0(RecyclerView.v paramv) {
    return (x() == 0) ? 0 : h.k(paramv, this.s, W0(this.K ^ true), V0(this.K ^ true), this, this.K);
  }
  
  public final int S0(RecyclerView.v paramv) {
    return (x() == 0) ? 0 : h.l(paramv, this.s, W0(this.K ^ true), V0(this.K ^ true), this, this.K, this.y);
  }
  
  public final int T0(RecyclerView.v paramv) {
    return (x() == 0) ? 0 : h.m(paramv, this.s, W0(this.K ^ true), V0(this.K ^ true), this, this.K);
  }
  
  public final int U0(RecyclerView.r paramr, w paramw, RecyclerView.v paramv) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge Z and I\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.useAs(TypeTransformer.java:868)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:806)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void V(int paramInt) {
    super.V(paramInt);
    for (int i = 0; i < this.q; i++) {
      f f1 = this.r[i];
      int j = f1.b;
      if (j != Integer.MIN_VALUE)
        f1.b = j + paramInt; 
      j = f1.c;
      if (j != Integer.MIN_VALUE)
        f1.c = j + paramInt; 
    } 
  }
  
  public View V0(boolean paramBoolean) {
    int j = this.s.k();
    int k = this.s.g();
    int i = x() - 1;
    View view;
    for (view = null; i >= 0; view = view1) {
      View view2 = w(i);
      int m = this.s.e(view2);
      int n = this.s.b(view2);
      View view1 = view;
      if (n > j)
        if (m >= k) {
          view1 = view;
        } else if (n > k) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i--;
    } 
    return view;
  }
  
  public void W(int paramInt) {
    super.W(paramInt);
    for (int i = 0; i < this.q; i++) {
      f f1 = this.r[i];
      int j = f1.b;
      if (j != Integer.MIN_VALUE)
        f1.b = j + paramInt; 
      j = f1.c;
      if (j != Integer.MIN_VALUE)
        f1.c = j + paramInt; 
    } 
  }
  
  public View W0(boolean paramBoolean) {
    int j = this.s.k();
    int k = this.s.g();
    int m = x();
    View view = null;
    int i = 0;
    while (i < m) {
      View view2 = w(i);
      int n = this.s.e(view2);
      View view1 = view;
      if (this.s.b(view2) > j)
        if (n >= k) {
          view1 = view;
        } else if (n < j) {
          if (!paramBoolean)
            return view2; 
          view1 = view;
          if (view == null)
            view1 = view2; 
        } else {
          return view2;
        }  
      i++;
      view = view1;
    } 
    return view;
  }
  
  public final void X0(RecyclerView.r paramr, RecyclerView.v paramv, boolean paramBoolean) {
    int i = b1(-2147483648);
    if (i == Integer.MIN_VALUE)
      return; 
    i = this.s.g() - i;
    if (i > 0) {
      i -= -o1(-i, paramr, paramv);
      if (paramBoolean && i > 0)
        this.s.p(i); 
    } 
  }
  
  public final void Y0(RecyclerView.r paramr, RecyclerView.v paramv, boolean paramBoolean) {
    int i = c1(2147483647);
    if (i == Integer.MAX_VALUE)
      return; 
    i -= this.s.k();
    if (i > 0) {
      i -= o1(i, paramr, paramv);
      if (paramBoolean && i > 0)
        this.s.p(-i); 
    } 
  }
  
  public int Z0() {
    return (x() == 0) ? 0 : L(w(0));
  }
  
  public int a1() {
    int i = x();
    return (i == 0) ? 0 : L(w(i - 1));
  }
  
  public void b0(RecyclerView paramRecyclerView, RecyclerView.r paramr) {
    a0();
    Runnable runnable = this.M;
    RecyclerView recyclerView = this.b;
    if (recyclerView != null)
      recyclerView.removeCallbacks(runnable); 
    for (int i = 0; i < this.q; i++)
      this.r[i].d(); 
    paramRecyclerView.requestLayout();
  }
  
  public final int b1(int paramInt) {
    int j = this.r[0].h(paramInt);
    int i = 1;
    while (i < this.q) {
      int m = this.r[i].h(paramInt);
      int k = j;
      if (m > j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  public void c(String paramString) {
    if (this.G == null) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.g(paramString); 
    } 
  }
  
  public View c0(View paramView, int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual x : ()I
    //   4: ifne -> 9
    //   7: aconst_null
    //   8: areturn
    //   9: aload_0
    //   10: aload_1
    //   11: invokevirtual r : (Landroid/view/View;)Landroid/view/View;
    //   14: astore_1
    //   15: aload_1
    //   16: ifnonnull -> 21
    //   19: aconst_null
    //   20: areturn
    //   21: aload_0
    //   22: invokevirtual n1 : ()V
    //   25: iload_2
    //   26: iconst_1
    //   27: if_icmpeq -> 132
    //   30: iload_2
    //   31: iconst_2
    //   32: if_icmpeq -> 111
    //   35: iload_2
    //   36: bipush #17
    //   38: if_icmpeq -> 95
    //   41: iload_2
    //   42: bipush #33
    //   44: if_icmpeq -> 84
    //   47: iload_2
    //   48: bipush #66
    //   50: if_icmpeq -> 74
    //   53: iload_2
    //   54: sipush #130
    //   57: if_icmpeq -> 63
    //   60: goto -> 105
    //   63: aload_0
    //   64: getfield u : I
    //   67: iconst_1
    //   68: if_icmpne -> 105
    //   71: goto -> 150
    //   74: aload_0
    //   75: getfield u : I
    //   78: ifne -> 105
    //   81: goto -> 150
    //   84: aload_0
    //   85: getfield u : I
    //   88: iconst_1
    //   89: if_icmpne -> 105
    //   92: goto -> 155
    //   95: aload_0
    //   96: getfield u : I
    //   99: ifne -> 105
    //   102: goto -> 155
    //   105: ldc -2147483648
    //   107: istore_2
    //   108: goto -> 157
    //   111: aload_0
    //   112: getfield u : I
    //   115: iconst_1
    //   116: if_icmpne -> 122
    //   119: goto -> 150
    //   122: aload_0
    //   123: invokevirtual f1 : ()Z
    //   126: ifeq -> 150
    //   129: goto -> 155
    //   132: aload_0
    //   133: getfield u : I
    //   136: iconst_1
    //   137: if_icmpne -> 143
    //   140: goto -> 155
    //   143: aload_0
    //   144: invokevirtual f1 : ()Z
    //   147: ifeq -> 155
    //   150: iconst_1
    //   151: istore_2
    //   152: goto -> 157
    //   155: iconst_m1
    //   156: istore_2
    //   157: iload_2
    //   158: ldc -2147483648
    //   160: if_icmpne -> 165
    //   163: aconst_null
    //   164: areturn
    //   165: aload_1
    //   166: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   169: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   172: astore #9
    //   174: aload #9
    //   176: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   179: pop
    //   180: aload #9
    //   182: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   185: astore #9
    //   187: iload_2
    //   188: iconst_1
    //   189: if_icmpne -> 201
    //   192: aload_0
    //   193: invokevirtual a1 : ()I
    //   196: istore #5
    //   198: goto -> 207
    //   201: aload_0
    //   202: invokevirtual Z0 : ()I
    //   205: istore #5
    //   207: aload_0
    //   208: iload #5
    //   210: aload #4
    //   212: invokevirtual r1 : (ILandroidx/recyclerview/widget/RecyclerView$v;)V
    //   215: aload_0
    //   216: iload_2
    //   217: invokevirtual p1 : (I)V
    //   220: aload_0
    //   221: getfield w : Lc/t/b/w;
    //   224: astore #10
    //   226: aload #10
    //   228: aload #10
    //   230: getfield d : I
    //   233: iload #5
    //   235: iadd
    //   236: putfield c : I
    //   239: aload #10
    //   241: aload_0
    //   242: getfield s : Lc/t/b/c0;
    //   245: invokevirtual l : ()I
    //   248: i2f
    //   249: ldc_w 0.33333334
    //   252: fmul
    //   253: f2i
    //   254: putfield b : I
    //   257: aload_0
    //   258: getfield w : Lc/t/b/w;
    //   261: astore #10
    //   263: aload #10
    //   265: iconst_1
    //   266: putfield h : Z
    //   269: iconst_0
    //   270: istore #7
    //   272: aload #10
    //   274: iconst_0
    //   275: putfield a : Z
    //   278: aload_0
    //   279: aload_3
    //   280: aload #10
    //   282: aload #4
    //   284: invokevirtual U0 : (Landroidx/recyclerview/widget/RecyclerView$r;Lc/t/b/w;Landroidx/recyclerview/widget/RecyclerView$v;)I
    //   287: pop
    //   288: aload_0
    //   289: aload_0
    //   290: getfield y : Z
    //   293: putfield E : Z
    //   296: aload #9
    //   298: iload #5
    //   300: iload_2
    //   301: invokevirtual i : (II)Landroid/view/View;
    //   304: astore_3
    //   305: aload_3
    //   306: ifnull -> 316
    //   309: aload_3
    //   310: aload_1
    //   311: if_acmpeq -> 316
    //   314: aload_3
    //   315: areturn
    //   316: aload_0
    //   317: iload_2
    //   318: invokevirtual i1 : (I)Z
    //   321: ifeq -> 371
    //   324: aload_0
    //   325: getfield q : I
    //   328: iconst_1
    //   329: isub
    //   330: istore #6
    //   332: iload #6
    //   334: iflt -> 417
    //   337: aload_0
    //   338: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   341: iload #6
    //   343: aaload
    //   344: iload #5
    //   346: iload_2
    //   347: invokevirtual i : (II)Landroid/view/View;
    //   350: astore_3
    //   351: aload_3
    //   352: ifnull -> 362
    //   355: aload_3
    //   356: aload_1
    //   357: if_acmpeq -> 362
    //   360: aload_3
    //   361: areturn
    //   362: iload #6
    //   364: iconst_1
    //   365: isub
    //   366: istore #6
    //   368: goto -> 332
    //   371: iconst_0
    //   372: istore #6
    //   374: iload #6
    //   376: aload_0
    //   377: getfield q : I
    //   380: if_icmpge -> 417
    //   383: aload_0
    //   384: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   387: iload #6
    //   389: aaload
    //   390: iload #5
    //   392: iload_2
    //   393: invokevirtual i : (II)Landroid/view/View;
    //   396: astore_3
    //   397: aload_3
    //   398: ifnull -> 408
    //   401: aload_3
    //   402: aload_1
    //   403: if_acmpeq -> 408
    //   406: aload_3
    //   407: areturn
    //   408: iload #6
    //   410: iconst_1
    //   411: iadd
    //   412: istore #6
    //   414: goto -> 374
    //   417: aload_0
    //   418: getfield x : Z
    //   421: istore #8
    //   423: iload_2
    //   424: iconst_m1
    //   425: if_icmpne -> 434
    //   428: iconst_1
    //   429: istore #5
    //   431: goto -> 437
    //   434: iconst_0
    //   435: istore #5
    //   437: iload #8
    //   439: iconst_1
    //   440: ixor
    //   441: iload #5
    //   443: if_icmpne -> 452
    //   446: iconst_1
    //   447: istore #5
    //   449: goto -> 455
    //   452: iconst_0
    //   453: istore #5
    //   455: iload #5
    //   457: ifeq -> 470
    //   460: aload #9
    //   462: invokevirtual e : ()I
    //   465: istore #6
    //   467: goto -> 477
    //   470: aload #9
    //   472: invokevirtual f : ()I
    //   475: istore #6
    //   477: aload_0
    //   478: iload #6
    //   480: invokevirtual s : (I)Landroid/view/View;
    //   483: astore_3
    //   484: aload_3
    //   485: ifnull -> 495
    //   488: aload_3
    //   489: aload_1
    //   490: if_acmpeq -> 495
    //   493: aload_3
    //   494: areturn
    //   495: iload #7
    //   497: istore #6
    //   499: aload_0
    //   500: iload_2
    //   501: invokevirtual i1 : (I)Z
    //   504: ifeq -> 585
    //   507: aload_0
    //   508: getfield q : I
    //   511: iconst_1
    //   512: isub
    //   513: istore_2
    //   514: iload_2
    //   515: iflt -> 650
    //   518: iload_2
    //   519: aload #9
    //   521: getfield e : I
    //   524: if_icmpne -> 530
    //   527: goto -> 578
    //   530: iload #5
    //   532: ifeq -> 549
    //   535: aload_0
    //   536: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   539: iload_2
    //   540: aaload
    //   541: invokevirtual e : ()I
    //   544: istore #6
    //   546: goto -> 560
    //   549: aload_0
    //   550: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   553: iload_2
    //   554: aaload
    //   555: invokevirtual f : ()I
    //   558: istore #6
    //   560: aload_0
    //   561: iload #6
    //   563: invokevirtual s : (I)Landroid/view/View;
    //   566: astore_3
    //   567: aload_3
    //   568: ifnull -> 578
    //   571: aload_3
    //   572: aload_1
    //   573: if_acmpeq -> 578
    //   576: aload_3
    //   577: areturn
    //   578: iload_2
    //   579: iconst_1
    //   580: isub
    //   581: istore_2
    //   582: goto -> 514
    //   585: iload #6
    //   587: aload_0
    //   588: getfield q : I
    //   591: if_icmpge -> 650
    //   594: iload #5
    //   596: ifeq -> 613
    //   599: aload_0
    //   600: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   603: iload #6
    //   605: aaload
    //   606: invokevirtual e : ()I
    //   609: istore_2
    //   610: goto -> 624
    //   613: aload_0
    //   614: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   617: iload #6
    //   619: aaload
    //   620: invokevirtual f : ()I
    //   623: istore_2
    //   624: aload_0
    //   625: iload_2
    //   626: invokevirtual s : (I)Landroid/view/View;
    //   629: astore_3
    //   630: aload_3
    //   631: ifnull -> 641
    //   634: aload_3
    //   635: aload_1
    //   636: if_acmpeq -> 641
    //   639: aload_3
    //   640: areturn
    //   641: iload #6
    //   643: iconst_1
    //   644: iadd
    //   645: istore #6
    //   647: goto -> 585
    //   650: aconst_null
    //   651: areturn
  }
  
  public final int c1(int paramInt) {
    int j = this.r[0].k(paramInt);
    int i = 1;
    while (i < this.q) {
      int m = this.r[i].k(paramInt);
      int k = j;
      if (m < j)
        k = m; 
      i++;
      j = k;
    } 
    return j;
  }
  
  public boolean d() {
    return (this.u == 0);
  }
  
  public void d0(AccessibilityEvent paramAccessibilityEvent) {
    RecyclerView.r r = this.b.f;
    e0(paramAccessibilityEvent);
    if (x() > 0) {
      View view1 = W0(false);
      View view2 = V0(false);
      if (view1 != null) {
        if (view2 == null)
          return; 
        int i = L(view1);
        int j = L(view2);
        if (i < j) {
          paramAccessibilityEvent.setFromIndex(i);
          paramAccessibilityEvent.setToIndex(j);
          return;
        } 
        paramAccessibilityEvent.setFromIndex(j);
        paramAccessibilityEvent.setToIndex(i);
      } 
    } 
  }
  
  public final void d1(int paramInt1, int paramInt2, int paramInt3) {
    if (this.y) {
      int j = a1();
    } else {
      int j = Z0();
    } 
    if (paramInt3 == 8) {
      if (paramInt1 < paramInt2) {
        int j = paramInt2 + 1;
      } else {
        int j = paramInt1 + 1;
        int k = paramInt2;
        this.C.d(k);
      } 
    } else {
      int j = paramInt1 + paramInt2;
    } 
    int i = paramInt1;
    this.C.d(i);
  }
  
  public boolean e() {
    return (this.u == 1);
  }
  
  public View e1() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual x : ()I
    //   4: iconst_1
    //   5: isub
    //   6: istore_1
    //   7: new java/util/BitSet
    //   10: dup
    //   11: aload_0
    //   12: getfield q : I
    //   15: invokespecial <init> : (I)V
    //   18: astore #7
    //   20: aload #7
    //   22: iconst_0
    //   23: aload_0
    //   24: getfield q : I
    //   27: iconst_1
    //   28: invokevirtual set : (IIZ)V
    //   31: aload_0
    //   32: getfield u : I
    //   35: istore_2
    //   36: iconst_m1
    //   37: istore #5
    //   39: iload_2
    //   40: iconst_1
    //   41: if_icmpne -> 56
    //   44: aload_0
    //   45: invokevirtual f1 : ()Z
    //   48: ifeq -> 56
    //   51: iconst_1
    //   52: istore_2
    //   53: goto -> 58
    //   56: iconst_m1
    //   57: istore_2
    //   58: aload_0
    //   59: getfield y : Z
    //   62: ifeq -> 70
    //   65: iconst_m1
    //   66: istore_3
    //   67: goto -> 76
    //   70: iload_1
    //   71: iconst_1
    //   72: iadd
    //   73: istore_3
    //   74: iconst_0
    //   75: istore_1
    //   76: iload_1
    //   77: istore #4
    //   79: iload_1
    //   80: iload_3
    //   81: if_icmpge -> 90
    //   84: iconst_1
    //   85: istore #5
    //   87: iload_1
    //   88: istore #4
    //   90: iload #4
    //   92: iload_3
    //   93: if_icmpeq -> 480
    //   96: aload_0
    //   97: iload #4
    //   99: invokevirtual w : (I)Landroid/view/View;
    //   102: astore #8
    //   104: aload #8
    //   106: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   109: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   112: astore #9
    //   114: aload #7
    //   116: aload #9
    //   118: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   121: getfield e : I
    //   124: invokevirtual get : (I)Z
    //   127: ifeq -> 300
    //   130: aload #9
    //   132: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   135: astore #10
    //   137: aload_0
    //   138: getfield y : Z
    //   141: ifeq -> 215
    //   144: aload #10
    //   146: getfield c : I
    //   149: istore_1
    //   150: iload_1
    //   151: ldc -2147483648
    //   153: if_icmpeq -> 159
    //   156: goto -> 170
    //   159: aload #10
    //   161: invokevirtual b : ()V
    //   164: aload #10
    //   166: getfield c : I
    //   169: istore_1
    //   170: iload_1
    //   171: aload_0
    //   172: getfield s : Lc/t/b/c0;
    //   175: invokevirtual g : ()I
    //   178: if_icmpge -> 278
    //   181: aload #10
    //   183: getfield a : Ljava/util/ArrayList;
    //   186: astore #11
    //   188: aload #10
    //   190: aload #11
    //   192: aload #11
    //   194: invokevirtual size : ()I
    //   197: iconst_1
    //   198: isub
    //   199: invokevirtual get : (I)Ljava/lang/Object;
    //   202: checkcast android/view/View
    //   205: invokevirtual j : (Landroid/view/View;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   208: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   211: pop
    //   212: goto -> 273
    //   215: aload #10
    //   217: getfield b : I
    //   220: istore_1
    //   221: iload_1
    //   222: ldc -2147483648
    //   224: if_icmpeq -> 230
    //   227: goto -> 241
    //   230: aload #10
    //   232: invokevirtual c : ()V
    //   235: aload #10
    //   237: getfield b : I
    //   240: istore_1
    //   241: iload_1
    //   242: aload_0
    //   243: getfield s : Lc/t/b/c0;
    //   246: invokevirtual k : ()I
    //   249: if_icmple -> 278
    //   252: aload #10
    //   254: aload #10
    //   256: getfield a : Ljava/util/ArrayList;
    //   259: iconst_0
    //   260: invokevirtual get : (I)Ljava/lang/Object;
    //   263: checkcast android/view/View
    //   266: invokevirtual j : (Landroid/view/View;)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$c;
    //   269: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   272: pop
    //   273: iconst_1
    //   274: istore_1
    //   275: goto -> 280
    //   278: iconst_0
    //   279: istore_1
    //   280: iload_1
    //   281: ifeq -> 287
    //   284: aload #8
    //   286: areturn
    //   287: aload #7
    //   289: aload #9
    //   291: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   294: getfield e : I
    //   297: invokevirtual clear : (I)V
    //   300: iload #4
    //   302: iload #5
    //   304: iadd
    //   305: istore_1
    //   306: iload_1
    //   307: iload_3
    //   308: if_icmpeq -> 470
    //   311: aload_0
    //   312: iload_1
    //   313: invokevirtual w : (I)Landroid/view/View;
    //   316: astore #10
    //   318: aload_0
    //   319: getfield y : Z
    //   322: ifeq -> 364
    //   325: aload_0
    //   326: getfield s : Lc/t/b/c0;
    //   329: aload #8
    //   331: invokevirtual b : (Landroid/view/View;)I
    //   334: istore_1
    //   335: aload_0
    //   336: getfield s : Lc/t/b/c0;
    //   339: aload #10
    //   341: invokevirtual b : (Landroid/view/View;)I
    //   344: istore #6
    //   346: iload_1
    //   347: iload #6
    //   349: if_icmpge -> 355
    //   352: aload #8
    //   354: areturn
    //   355: iload_1
    //   356: iload #6
    //   358: if_icmpne -> 405
    //   361: goto -> 400
    //   364: aload_0
    //   365: getfield s : Lc/t/b/c0;
    //   368: aload #8
    //   370: invokevirtual e : (Landroid/view/View;)I
    //   373: istore_1
    //   374: aload_0
    //   375: getfield s : Lc/t/b/c0;
    //   378: aload #10
    //   380: invokevirtual e : (Landroid/view/View;)I
    //   383: istore #6
    //   385: iload_1
    //   386: iload #6
    //   388: if_icmple -> 394
    //   391: aload #8
    //   393: areturn
    //   394: iload_1
    //   395: iload #6
    //   397: if_icmpne -> 405
    //   400: iconst_1
    //   401: istore_1
    //   402: goto -> 407
    //   405: iconst_0
    //   406: istore_1
    //   407: iload_1
    //   408: ifeq -> 470
    //   411: aload #10
    //   413: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   416: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   419: astore #10
    //   421: aload #9
    //   423: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   426: getfield e : I
    //   429: aload #10
    //   431: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   434: getfield e : I
    //   437: isub
    //   438: ifge -> 446
    //   441: iconst_1
    //   442: istore_1
    //   443: goto -> 448
    //   446: iconst_0
    //   447: istore_1
    //   448: iload_2
    //   449: ifge -> 458
    //   452: iconst_1
    //   453: istore #6
    //   455: goto -> 461
    //   458: iconst_0
    //   459: istore #6
    //   461: iload_1
    //   462: iload #6
    //   464: if_icmpeq -> 470
    //   467: aload #8
    //   469: areturn
    //   470: iload #4
    //   472: iload #5
    //   474: iadd
    //   475: istore #4
    //   477: goto -> 90
    //   480: aconst_null
    //   481: areturn
  }
  
  public boolean f(RecyclerView.m paramm) {
    return paramm instanceof c;
  }
  
  public boolean f1() {
    return (E() == 1);
  }
  
  public void g0(RecyclerView.r paramr, RecyclerView.v paramv, View paramView, c.h.j.m0.b paramb) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof c)) {
      f0(paramView, paramb);
      return;
    } 
    c c = (c)layoutParams;
    int j = this.u;
    int i = -1;
    if (j == 0) {
      f1 = c.e;
      if (f1 != null)
        i = f1.e; 
      paramb.n(c.h.j.m0.b.c.a(i, 1, -1, -1, false, false));
      return;
    } 
    f f1 = ((c)f1).e;
    if (f1 != null)
      i = f1.e; 
    paramb.n(c.h.j.m0.b.c.a(-1, -1, i, 1, false, false));
  }
  
  public final void g1(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    Rect rect1 = this.I;
    RecyclerView recyclerView = this.b;
    if (recyclerView == null) {
      rect1.set(0, 0, 0, 0);
    } else {
      rect1.set(recyclerView.J(paramView));
    } 
    c c = (c)paramView.getLayoutParams();
    int i = c.leftMargin;
    Rect rect2 = this.I;
    paramInt1 = t1(paramInt1, i + rect2.left, c.rightMargin + rect2.right);
    i = c.topMargin;
    rect2 = this.I;
    paramInt2 = t1(paramInt2, i + rect2.top, c.bottomMargin + rect2.bottom);
    if (paramBoolean) {
      paramBoolean = O0(paramView, paramInt1, paramInt2, c);
    } else {
      paramBoolean = M0(paramView, paramInt1, paramInt2, c);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  public void h(int paramInt1, int paramInt2, RecyclerView.v paramv, RecyclerView.l.a parama) {
    if (this.u != 0)
      paramInt1 = paramInt2; 
    if (x() != 0) {
      if (paramInt1 == 0)
        return; 
      j1(paramInt1, paramv);
      int[] arrayOfInt = this.L;
      if (arrayOfInt == null || arrayOfInt.length < this.q)
        this.L = new int[this.q]; 
      paramInt2 = 0;
      for (paramInt1 = paramInt2; paramInt2 < this.q; paramInt1 = i) {
        w w1 = this.w;
        if (w1.d == -1) {
          i = w1.f;
          j = this.r[paramInt2].k(i);
        } else {
          i = this.r[paramInt2].h(w1.g);
          j = this.w.g;
        } 
        int j = i - j;
        int i = paramInt1;
        if (j >= 0) {
          this.L[paramInt1] = j;
          i = paramInt1 + 1;
        } 
        paramInt2++;
      } 
      Arrays.sort(this.L, 0, paramInt1);
      paramInt2 = 0;
      while (paramInt2 < paramInt1) {
        int i = this.w.c;
        if (i >= 0 && i < paramv.b()) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i != 0) {
          i = this.w.c;
          int j = this.L[paramInt2];
          ((u.a)parama).a(i, j);
          w w1 = this.w;
          w1.c += w1.d;
          paramInt2++;
        } 
      } 
    } 
  }
  
  public final void h1(RecyclerView.r paramr, RecyclerView.v paramv, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield J : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   4: astore #13
    //   6: aload_0
    //   7: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   10: ifnonnull -> 21
    //   13: aload_0
    //   14: getfield A : I
    //   17: iconst_m1
    //   18: if_icmpeq -> 39
    //   21: aload_2
    //   22: invokevirtual b : ()I
    //   25: ifne -> 39
    //   28: aload_0
    //   29: aload_1
    //   30: invokevirtual y0 : (Landroidx/recyclerview/widget/RecyclerView$r;)V
    //   33: aload #13
    //   35: invokevirtual b : ()V
    //   38: return
    //   39: aload #13
    //   41: getfield e : Z
    //   44: istore #12
    //   46: iconst_1
    //   47: istore #9
    //   49: iload #12
    //   51: ifeq -> 78
    //   54: aload_0
    //   55: getfield A : I
    //   58: iconst_m1
    //   59: if_icmpne -> 78
    //   62: aload_0
    //   63: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   66: ifnull -> 72
    //   69: goto -> 78
    //   72: iconst_0
    //   73: istore #7
    //   75: goto -> 81
    //   78: iconst_1
    //   79: istore #7
    //   81: iload #7
    //   83: ifeq -> 1141
    //   86: aload #13
    //   88: invokevirtual b : ()V
    //   91: aload_0
    //   92: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   95: astore #14
    //   97: aload #14
    //   99: ifnull -> 434
    //   102: aload #14
    //   104: getfield g : I
    //   107: istore #6
    //   109: iload #6
    //   111: ifle -> 280
    //   114: iload #6
    //   116: aload_0
    //   117: getfield q : I
    //   120: if_icmpne -> 240
    //   123: iconst_0
    //   124: istore #6
    //   126: iload #6
    //   128: aload_0
    //   129: getfield q : I
    //   132: if_icmpge -> 280
    //   135: aload_0
    //   136: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   139: iload #6
    //   141: aaload
    //   142: invokevirtual d : ()V
    //   145: aload_0
    //   146: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   149: astore #14
    //   151: aload #14
    //   153: getfield h : [I
    //   156: iload #6
    //   158: iaload
    //   159: istore #10
    //   161: iload #10
    //   163: istore #8
    //   165: iload #10
    //   167: ldc -2147483648
    //   169: if_icmpeq -> 208
    //   172: aload #14
    //   174: getfield m : Z
    //   177: ifeq -> 192
    //   180: aload_0
    //   181: getfield s : Lc/t/b/c0;
    //   184: invokevirtual g : ()I
    //   187: istore #8
    //   189: goto -> 201
    //   192: aload_0
    //   193: getfield s : Lc/t/b/c0;
    //   196: invokevirtual k : ()I
    //   199: istore #8
    //   201: iload #10
    //   203: iload #8
    //   205: iadd
    //   206: istore #8
    //   208: aload_0
    //   209: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   212: iload #6
    //   214: aaload
    //   215: astore #14
    //   217: aload #14
    //   219: iload #8
    //   221: putfield b : I
    //   224: aload #14
    //   226: iload #8
    //   228: putfield c : I
    //   231: iload #6
    //   233: iconst_1
    //   234: iadd
    //   235: istore #6
    //   237: goto -> 126
    //   240: aload #14
    //   242: aconst_null
    //   243: putfield h : [I
    //   246: aload #14
    //   248: iconst_0
    //   249: putfield g : I
    //   252: aload #14
    //   254: iconst_0
    //   255: putfield i : I
    //   258: aload #14
    //   260: aconst_null
    //   261: putfield j : [I
    //   264: aload #14
    //   266: aconst_null
    //   267: putfield k : Ljava/util/List;
    //   270: aload #14
    //   272: aload #14
    //   274: getfield f : I
    //   277: putfield e : I
    //   280: aload_0
    //   281: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   284: astore #14
    //   286: aload_0
    //   287: aload #14
    //   289: getfield n : Z
    //   292: putfield F : Z
    //   295: aload #14
    //   297: getfield l : Z
    //   300: istore #12
    //   302: aload_0
    //   303: aconst_null
    //   304: invokevirtual c : (Ljava/lang/String;)V
    //   307: aload_0
    //   308: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   311: astore #14
    //   313: aload #14
    //   315: ifnull -> 335
    //   318: aload #14
    //   320: getfield l : Z
    //   323: iload #12
    //   325: if_icmpeq -> 335
    //   328: aload #14
    //   330: iload #12
    //   332: putfield l : Z
    //   335: aload_0
    //   336: iload #12
    //   338: putfield x : Z
    //   341: aload_0
    //   342: invokevirtual E0 : ()V
    //   345: aload_0
    //   346: invokevirtual n1 : ()V
    //   349: aload_0
    //   350: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   353: astore #14
    //   355: aload #14
    //   357: getfield e : I
    //   360: istore #6
    //   362: iload #6
    //   364: iconst_m1
    //   365: if_icmpeq -> 387
    //   368: aload_0
    //   369: iload #6
    //   371: putfield A : I
    //   374: aload #13
    //   376: aload #14
    //   378: getfield m : Z
    //   381: putfield c : Z
    //   384: goto -> 396
    //   387: aload #13
    //   389: aload_0
    //   390: getfield y : Z
    //   393: putfield c : Z
    //   396: aload #14
    //   398: getfield i : I
    //   401: iconst_1
    //   402: if_icmple -> 447
    //   405: aload_0
    //   406: getfield C : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   409: astore #15
    //   411: aload #15
    //   413: aload #14
    //   415: getfield j : [I
    //   418: putfield a : [I
    //   421: aload #15
    //   423: aload #14
    //   425: getfield k : Ljava/util/List;
    //   428: putfield b : Ljava/util/List;
    //   431: goto -> 447
    //   434: aload_0
    //   435: invokevirtual n1 : ()V
    //   438: aload #13
    //   440: aload_0
    //   441: getfield y : Z
    //   444: putfield c : Z
    //   447: aload_2
    //   448: getfield f : Z
    //   451: ifne -> 976
    //   454: aload_0
    //   455: getfield A : I
    //   458: istore #6
    //   460: iload #6
    //   462: iconst_m1
    //   463: if_icmpne -> 469
    //   466: goto -> 976
    //   469: iload #6
    //   471: iflt -> 965
    //   474: iload #6
    //   476: aload_2
    //   477: invokevirtual b : ()I
    //   480: if_icmplt -> 486
    //   483: goto -> 965
    //   486: aload_0
    //   487: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   490: astore #14
    //   492: aload #14
    //   494: ifnull -> 537
    //   497: aload #14
    //   499: getfield e : I
    //   502: iconst_m1
    //   503: if_icmpeq -> 537
    //   506: aload #14
    //   508: getfield g : I
    //   511: iconst_1
    //   512: if_icmpge -> 518
    //   515: goto -> 537
    //   518: aload #13
    //   520: ldc -2147483648
    //   522: putfield b : I
    //   525: aload #13
    //   527: aload_0
    //   528: getfield A : I
    //   531: putfield a : I
    //   534: goto -> 959
    //   537: aload_0
    //   538: aload_0
    //   539: getfield A : I
    //   542: invokevirtual s : (I)Landroid/view/View;
    //   545: astore #14
    //   547: aload #14
    //   549: ifnull -> 795
    //   552: aload_0
    //   553: getfield y : Z
    //   556: ifeq -> 568
    //   559: aload_0
    //   560: invokevirtual a1 : ()I
    //   563: istore #6
    //   565: goto -> 574
    //   568: aload_0
    //   569: invokevirtual Z0 : ()I
    //   572: istore #6
    //   574: aload #13
    //   576: iload #6
    //   578: putfield a : I
    //   581: aload_0
    //   582: getfield B : I
    //   585: ldc -2147483648
    //   587: if_icmpeq -> 658
    //   590: aload #13
    //   592: getfield c : Z
    //   595: ifeq -> 628
    //   598: aload #13
    //   600: aload_0
    //   601: getfield s : Lc/t/b/c0;
    //   604: invokevirtual g : ()I
    //   607: aload_0
    //   608: getfield B : I
    //   611: isub
    //   612: aload_0
    //   613: getfield s : Lc/t/b/c0;
    //   616: aload #14
    //   618: invokevirtual b : (Landroid/view/View;)I
    //   621: isub
    //   622: putfield b : I
    //   625: goto -> 959
    //   628: aload #13
    //   630: aload_0
    //   631: getfield s : Lc/t/b/c0;
    //   634: invokevirtual k : ()I
    //   637: aload_0
    //   638: getfield B : I
    //   641: iadd
    //   642: aload_0
    //   643: getfield s : Lc/t/b/c0;
    //   646: aload #14
    //   648: invokevirtual e : (Landroid/view/View;)I
    //   651: isub
    //   652: putfield b : I
    //   655: goto -> 959
    //   658: aload_0
    //   659: getfield s : Lc/t/b/c0;
    //   662: aload #14
    //   664: invokevirtual c : (Landroid/view/View;)I
    //   667: aload_0
    //   668: getfield s : Lc/t/b/c0;
    //   671: invokevirtual l : ()I
    //   674: if_icmple -> 716
    //   677: aload #13
    //   679: getfield c : Z
    //   682: ifeq -> 697
    //   685: aload_0
    //   686: getfield s : Lc/t/b/c0;
    //   689: invokevirtual g : ()I
    //   692: istore #6
    //   694: goto -> 706
    //   697: aload_0
    //   698: getfield s : Lc/t/b/c0;
    //   701: invokevirtual k : ()I
    //   704: istore #6
    //   706: aload #13
    //   708: iload #6
    //   710: putfield b : I
    //   713: goto -> 959
    //   716: aload_0
    //   717: getfield s : Lc/t/b/c0;
    //   720: aload #14
    //   722: invokevirtual e : (Landroid/view/View;)I
    //   725: aload_0
    //   726: getfield s : Lc/t/b/c0;
    //   729: invokevirtual k : ()I
    //   732: isub
    //   733: istore #6
    //   735: iload #6
    //   737: ifge -> 751
    //   740: aload #13
    //   742: iload #6
    //   744: ineg
    //   745: putfield b : I
    //   748: goto -> 959
    //   751: aload_0
    //   752: getfield s : Lc/t/b/c0;
    //   755: invokevirtual g : ()I
    //   758: aload_0
    //   759: getfield s : Lc/t/b/c0;
    //   762: aload #14
    //   764: invokevirtual b : (Landroid/view/View;)I
    //   767: isub
    //   768: istore #6
    //   770: iload #6
    //   772: ifge -> 785
    //   775: aload #13
    //   777: iload #6
    //   779: putfield b : I
    //   782: goto -> 959
    //   785: aload #13
    //   787: ldc -2147483648
    //   789: putfield b : I
    //   792: goto -> 959
    //   795: aload_0
    //   796: getfield A : I
    //   799: istore #6
    //   801: aload #13
    //   803: iload #6
    //   805: putfield a : I
    //   808: aload_0
    //   809: getfield B : I
    //   812: istore #8
    //   814: iload #8
    //   816: ldc -2147483648
    //   818: if_icmpne -> 904
    //   821: aload_0
    //   822: invokevirtual x : ()I
    //   825: ifne -> 838
    //   828: aload_0
    //   829: getfield y : Z
    //   832: ifeq -> 865
    //   835: goto -> 871
    //   838: iload #6
    //   840: aload_0
    //   841: invokevirtual Z0 : ()I
    //   844: if_icmpge -> 853
    //   847: iconst_1
    //   848: istore #12
    //   850: goto -> 856
    //   853: iconst_0
    //   854: istore #12
    //   856: iload #12
    //   858: aload_0
    //   859: getfield y : Z
    //   862: if_icmpeq -> 871
    //   865: iconst_m1
    //   866: istore #6
    //   868: goto -> 874
    //   871: iconst_1
    //   872: istore #6
    //   874: iload #6
    //   876: iconst_1
    //   877: if_icmpne -> 886
    //   880: iconst_1
    //   881: istore #12
    //   883: goto -> 889
    //   886: iconst_0
    //   887: istore #12
    //   889: aload #13
    //   891: iload #12
    //   893: putfield c : Z
    //   896: aload #13
    //   898: invokevirtual a : ()V
    //   901: goto -> 953
    //   904: aload #13
    //   906: getfield c : Z
    //   909: ifeq -> 934
    //   912: aload #13
    //   914: aload #13
    //   916: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   919: getfield s : Lc/t/b/c0;
    //   922: invokevirtual g : ()I
    //   925: iload #8
    //   927: isub
    //   928: putfield b : I
    //   931: goto -> 953
    //   934: aload #13
    //   936: aload #13
    //   938: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   941: getfield s : Lc/t/b/c0;
    //   944: invokevirtual k : ()I
    //   947: iload #8
    //   949: iadd
    //   950: putfield b : I
    //   953: aload #13
    //   955: iconst_1
    //   956: putfield d : Z
    //   959: iconst_1
    //   960: istore #6
    //   962: goto -> 979
    //   965: aload_0
    //   966: iconst_m1
    //   967: putfield A : I
    //   970: aload_0
    //   971: ldc -2147483648
    //   973: putfield B : I
    //   976: iconst_0
    //   977: istore #6
    //   979: iload #6
    //   981: ifeq -> 987
    //   984: goto -> 1135
    //   987: aload_0
    //   988: getfield E : Z
    //   991: ifeq -> 1056
    //   994: aload_2
    //   995: invokevirtual b : ()I
    //   998: istore #11
    //   1000: aload_0
    //   1001: invokevirtual x : ()I
    //   1004: istore #6
    //   1006: iload #6
    //   1008: iconst_1
    //   1009: isub
    //   1010: istore #8
    //   1012: iload #8
    //   1014: iflt -> 1118
    //   1017: aload_0
    //   1018: aload_0
    //   1019: iload #8
    //   1021: invokevirtual w : (I)Landroid/view/View;
    //   1024: invokevirtual L : (Landroid/view/View;)I
    //   1027: istore #10
    //   1029: iload #8
    //   1031: istore #6
    //   1033: iload #10
    //   1035: iflt -> 1006
    //   1038: iload #8
    //   1040: istore #6
    //   1042: iload #10
    //   1044: iload #11
    //   1046: if_icmpge -> 1006
    //   1049: iload #10
    //   1051: istore #6
    //   1053: goto -> 1121
    //   1056: aload_2
    //   1057: invokevirtual b : ()I
    //   1060: istore #10
    //   1062: aload_0
    //   1063: invokevirtual x : ()I
    //   1066: istore #11
    //   1068: iconst_0
    //   1069: istore #6
    //   1071: iload #6
    //   1073: iload #11
    //   1075: if_icmpge -> 1118
    //   1078: aload_0
    //   1079: aload_0
    //   1080: iload #6
    //   1082: invokevirtual w : (I)Landroid/view/View;
    //   1085: invokevirtual L : (Landroid/view/View;)I
    //   1088: istore #8
    //   1090: iload #8
    //   1092: iflt -> 1109
    //   1095: iload #8
    //   1097: iload #10
    //   1099: if_icmpge -> 1109
    //   1102: iload #8
    //   1104: istore #6
    //   1106: goto -> 1121
    //   1109: iload #6
    //   1111: iconst_1
    //   1112: iadd
    //   1113: istore #6
    //   1115: goto -> 1071
    //   1118: iconst_0
    //   1119: istore #6
    //   1121: aload #13
    //   1123: iload #6
    //   1125: putfield a : I
    //   1128: aload #13
    //   1130: ldc -2147483648
    //   1132: putfield b : I
    //   1135: aload #13
    //   1137: iconst_1
    //   1138: putfield e : Z
    //   1141: aload_0
    //   1142: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   1145: ifnonnull -> 1192
    //   1148: aload_0
    //   1149: getfield A : I
    //   1152: iconst_m1
    //   1153: if_icmpne -> 1192
    //   1156: aload #13
    //   1158: getfield c : Z
    //   1161: aload_0
    //   1162: getfield E : Z
    //   1165: if_icmpne -> 1179
    //   1168: aload_0
    //   1169: invokevirtual f1 : ()Z
    //   1172: aload_0
    //   1173: getfield F : Z
    //   1176: if_icmpeq -> 1192
    //   1179: aload_0
    //   1180: getfield C : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   1183: invokevirtual a : ()V
    //   1186: aload #13
    //   1188: iconst_1
    //   1189: putfield d : Z
    //   1192: aload_0
    //   1193: invokevirtual x : ()I
    //   1196: ifle -> 1631
    //   1199: aload_0
    //   1200: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   1203: astore #14
    //   1205: aload #14
    //   1207: ifnull -> 1219
    //   1210: aload #14
    //   1212: getfield g : I
    //   1215: iconst_1
    //   1216: if_icmpge -> 1631
    //   1219: aload #13
    //   1221: getfield d : Z
    //   1224: ifeq -> 1295
    //   1227: iconst_0
    //   1228: istore #6
    //   1230: iload #6
    //   1232: aload_0
    //   1233: getfield q : I
    //   1236: if_icmpge -> 1631
    //   1239: aload_0
    //   1240: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1243: iload #6
    //   1245: aaload
    //   1246: invokevirtual d : ()V
    //   1249: aload #13
    //   1251: getfield b : I
    //   1254: istore #7
    //   1256: iload #7
    //   1258: ldc -2147483648
    //   1260: if_icmpeq -> 1286
    //   1263: aload_0
    //   1264: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1267: iload #6
    //   1269: aaload
    //   1270: astore #14
    //   1272: aload #14
    //   1274: iload #7
    //   1276: putfield b : I
    //   1279: aload #14
    //   1281: iload #7
    //   1283: putfield c : I
    //   1286: iload #6
    //   1288: iconst_1
    //   1289: iadd
    //   1290: istore #6
    //   1292: goto -> 1230
    //   1295: iload #7
    //   1297: ifne -> 1374
    //   1300: aload_0
    //   1301: getfield J : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1304: getfield f : [I
    //   1307: ifnonnull -> 1313
    //   1310: goto -> 1374
    //   1313: iconst_0
    //   1314: istore #6
    //   1316: iload #6
    //   1318: aload_0
    //   1319: getfield q : I
    //   1322: if_icmpge -> 1631
    //   1325: aload_0
    //   1326: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1329: iload #6
    //   1331: aaload
    //   1332: astore #14
    //   1334: aload #14
    //   1336: invokevirtual d : ()V
    //   1339: aload_0
    //   1340: getfield J : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1343: getfield f : [I
    //   1346: iload #6
    //   1348: iaload
    //   1349: istore #7
    //   1351: aload #14
    //   1353: iload #7
    //   1355: putfield b : I
    //   1358: aload #14
    //   1360: iload #7
    //   1362: putfield c : I
    //   1365: iload #6
    //   1367: iconst_1
    //   1368: iadd
    //   1369: istore #6
    //   1371: goto -> 1316
    //   1374: iconst_0
    //   1375: istore #7
    //   1377: iload #7
    //   1379: aload_0
    //   1380: getfield q : I
    //   1383: if_icmpge -> 1535
    //   1386: aload_0
    //   1387: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1390: iload #7
    //   1392: aaload
    //   1393: astore #14
    //   1395: aload_0
    //   1396: getfield y : Z
    //   1399: istore #12
    //   1401: aload #13
    //   1403: getfield b : I
    //   1406: istore #10
    //   1408: iload #12
    //   1410: ifeq -> 1425
    //   1413: aload #14
    //   1415: ldc -2147483648
    //   1417: invokevirtual h : (I)I
    //   1420: istore #6
    //   1422: goto -> 1434
    //   1425: aload #14
    //   1427: ldc -2147483648
    //   1429: invokevirtual k : (I)I
    //   1432: istore #6
    //   1434: aload #14
    //   1436: invokevirtual d : ()V
    //   1439: iload #6
    //   1441: ldc -2147483648
    //   1443: if_icmpne -> 1449
    //   1446: goto -> 1526
    //   1449: iload #12
    //   1451: ifeq -> 1470
    //   1454: iload #6
    //   1456: aload #14
    //   1458: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1461: getfield s : Lc/t/b/c0;
    //   1464: invokevirtual g : ()I
    //   1467: if_icmplt -> 1526
    //   1470: iload #12
    //   1472: ifne -> 1494
    //   1475: iload #6
    //   1477: aload #14
    //   1479: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1482: getfield s : Lc/t/b/c0;
    //   1485: invokevirtual k : ()I
    //   1488: if_icmple -> 1494
    //   1491: goto -> 1526
    //   1494: iload #6
    //   1496: istore #8
    //   1498: iload #10
    //   1500: ldc -2147483648
    //   1502: if_icmpeq -> 1512
    //   1505: iload #6
    //   1507: iload #10
    //   1509: iadd
    //   1510: istore #8
    //   1512: aload #14
    //   1514: iload #8
    //   1516: putfield c : I
    //   1519: aload #14
    //   1521: iload #8
    //   1523: putfield b : I
    //   1526: iload #7
    //   1528: iconst_1
    //   1529: iadd
    //   1530: istore #7
    //   1532: goto -> 1377
    //   1535: aload_0
    //   1536: getfield J : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   1539: astore #14
    //   1541: aload_0
    //   1542: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1545: astore #15
    //   1547: aload #14
    //   1549: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1552: pop
    //   1553: aload #15
    //   1555: arraylength
    //   1556: istore #7
    //   1558: aload #14
    //   1560: getfield f : [I
    //   1563: astore #16
    //   1565: aload #16
    //   1567: ifnull -> 1578
    //   1570: aload #16
    //   1572: arraylength
    //   1573: iload #7
    //   1575: if_icmpge -> 1594
    //   1578: aload #14
    //   1580: aload #14
    //   1582: getfield g : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
    //   1585: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   1588: arraylength
    //   1589: newarray int
    //   1591: putfield f : [I
    //   1594: iconst_0
    //   1595: istore #6
    //   1597: iload #6
    //   1599: iload #7
    //   1601: if_icmpge -> 1631
    //   1604: aload #14
    //   1606: getfield f : [I
    //   1609: iload #6
    //   1611: aload #15
    //   1613: iload #6
    //   1615: aaload
    //   1616: ldc -2147483648
    //   1618: invokevirtual k : (I)I
    //   1621: iastore
    //   1622: iload #6
    //   1624: iconst_1
    //   1625: iadd
    //   1626: istore #6
    //   1628: goto -> 1597
    //   1631: aload_0
    //   1632: aload_1
    //   1633: invokevirtual p : (Landroidx/recyclerview/widget/RecyclerView$r;)V
    //   1636: aload_0
    //   1637: getfield w : Lc/t/b/w;
    //   1640: iconst_0
    //   1641: putfield a : Z
    //   1644: aload_0
    //   1645: getfield t : Lc/t/b/c0;
    //   1648: invokevirtual l : ()I
    //   1651: istore #6
    //   1653: aload_0
    //   1654: iload #6
    //   1656: aload_0
    //   1657: getfield q : I
    //   1660: idiv
    //   1661: putfield v : I
    //   1664: aload_0
    //   1665: iload #6
    //   1667: aload_0
    //   1668: getfield t : Lc/t/b/c0;
    //   1671: invokevirtual i : ()I
    //   1674: invokestatic makeMeasureSpec : (II)I
    //   1677: putfield H : I
    //   1680: aload_0
    //   1681: aload #13
    //   1683: getfield a : I
    //   1686: aload_2
    //   1687: invokevirtual r1 : (ILandroidx/recyclerview/widget/RecyclerView$v;)V
    //   1690: aload #13
    //   1692: getfield c : Z
    //   1695: ifeq -> 1753
    //   1698: aload_0
    //   1699: iconst_m1
    //   1700: invokevirtual p1 : (I)V
    //   1703: aload_0
    //   1704: aload_1
    //   1705: aload_0
    //   1706: getfield w : Lc/t/b/w;
    //   1709: aload_2
    //   1710: invokevirtual U0 : (Landroidx/recyclerview/widget/RecyclerView$r;Lc/t/b/w;Landroidx/recyclerview/widget/RecyclerView$v;)I
    //   1713: pop
    //   1714: aload_0
    //   1715: iconst_1
    //   1716: invokevirtual p1 : (I)V
    //   1719: aload_0
    //   1720: getfield w : Lc/t/b/w;
    //   1723: astore #14
    //   1725: aload #14
    //   1727: aload #13
    //   1729: getfield a : I
    //   1732: aload #14
    //   1734: getfield d : I
    //   1737: iadd
    //   1738: putfield c : I
    //   1741: aload_0
    //   1742: aload_1
    //   1743: aload #14
    //   1745: aload_2
    //   1746: invokevirtual U0 : (Landroidx/recyclerview/widget/RecyclerView$r;Lc/t/b/w;Landroidx/recyclerview/widget/RecyclerView$v;)I
    //   1749: pop
    //   1750: goto -> 1805
    //   1753: aload_0
    //   1754: iconst_1
    //   1755: invokevirtual p1 : (I)V
    //   1758: aload_0
    //   1759: aload_1
    //   1760: aload_0
    //   1761: getfield w : Lc/t/b/w;
    //   1764: aload_2
    //   1765: invokevirtual U0 : (Landroidx/recyclerview/widget/RecyclerView$r;Lc/t/b/w;Landroidx/recyclerview/widget/RecyclerView$v;)I
    //   1768: pop
    //   1769: aload_0
    //   1770: iconst_m1
    //   1771: invokevirtual p1 : (I)V
    //   1774: aload_0
    //   1775: getfield w : Lc/t/b/w;
    //   1778: astore #14
    //   1780: aload #14
    //   1782: aload #13
    //   1784: getfield a : I
    //   1787: aload #14
    //   1789: getfield d : I
    //   1792: iadd
    //   1793: putfield c : I
    //   1796: aload_0
    //   1797: aload_1
    //   1798: aload #14
    //   1800: aload_2
    //   1801: invokevirtual U0 : (Landroidx/recyclerview/widget/RecyclerView$r;Lc/t/b/w;Landroidx/recyclerview/widget/RecyclerView$v;)I
    //   1804: pop
    //   1805: aload_0
    //   1806: getfield t : Lc/t/b/c0;
    //   1809: invokevirtual i : ()I
    //   1812: ldc_w 1073741824
    //   1815: if_icmpne -> 1821
    //   1818: goto -> 2153
    //   1821: fconst_0
    //   1822: fstore #4
    //   1824: aload_0
    //   1825: invokevirtual x : ()I
    //   1828: istore #8
    //   1830: iconst_0
    //   1831: istore #6
    //   1833: iload #6
    //   1835: iload #8
    //   1837: if_icmpge -> 1901
    //   1840: aload_0
    //   1841: iload #6
    //   1843: invokevirtual w : (I)Landroid/view/View;
    //   1846: astore #14
    //   1848: aload_0
    //   1849: getfield t : Lc/t/b/c0;
    //   1852: aload #14
    //   1854: invokevirtual c : (Landroid/view/View;)I
    //   1857: i2f
    //   1858: fstore #5
    //   1860: fload #5
    //   1862: fload #4
    //   1864: fcmpg
    //   1865: ifge -> 1871
    //   1868: goto -> 1892
    //   1871: aload #14
    //   1873: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1876: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   1879: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1882: pop
    //   1883: fload #4
    //   1885: fload #5
    //   1887: invokestatic max : (FF)F
    //   1890: fstore #4
    //   1892: iload #6
    //   1894: iconst_1
    //   1895: iadd
    //   1896: istore #6
    //   1898: goto -> 1833
    //   1901: aload_0
    //   1902: getfield v : I
    //   1905: istore #10
    //   1907: fload #4
    //   1909: aload_0
    //   1910: getfield q : I
    //   1913: i2f
    //   1914: fmul
    //   1915: invokestatic round : (F)I
    //   1918: istore #7
    //   1920: iload #7
    //   1922: istore #6
    //   1924: aload_0
    //   1925: getfield t : Lc/t/b/c0;
    //   1928: invokevirtual i : ()I
    //   1931: ldc -2147483648
    //   1933: if_icmpne -> 1950
    //   1936: iload #7
    //   1938: aload_0
    //   1939: getfield t : Lc/t/b/c0;
    //   1942: invokevirtual l : ()I
    //   1945: invokestatic min : (II)I
    //   1948: istore #6
    //   1950: aload_0
    //   1951: iload #6
    //   1953: aload_0
    //   1954: getfield q : I
    //   1957: idiv
    //   1958: putfield v : I
    //   1961: aload_0
    //   1962: iload #6
    //   1964: aload_0
    //   1965: getfield t : Lc/t/b/c0;
    //   1968: invokevirtual i : ()I
    //   1971: invokestatic makeMeasureSpec : (II)I
    //   1974: putfield H : I
    //   1977: aload_0
    //   1978: getfield v : I
    //   1981: iload #10
    //   1983: if_icmpne -> 1989
    //   1986: goto -> 2153
    //   1989: iconst_0
    //   1990: istore #6
    //   1992: iload #6
    //   1994: iload #8
    //   1996: if_icmpge -> 2153
    //   1999: aload_0
    //   2000: iload #6
    //   2002: invokevirtual w : (I)Landroid/view/View;
    //   2005: astore #14
    //   2007: aload #14
    //   2009: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   2012: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$c
    //   2015: astore #15
    //   2017: aload #15
    //   2019: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2022: pop
    //   2023: aload_0
    //   2024: invokevirtual f1 : ()Z
    //   2027: ifeq -> 2087
    //   2030: aload_0
    //   2031: getfield u : I
    //   2034: iconst_1
    //   2035: if_icmpne -> 2087
    //   2038: aload_0
    //   2039: getfield q : I
    //   2042: istore #7
    //   2044: aload #15
    //   2046: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   2049: getfield e : I
    //   2052: istore #11
    //   2054: aload #14
    //   2056: iload #7
    //   2058: iconst_1
    //   2059: isub
    //   2060: iload #11
    //   2062: isub
    //   2063: ineg
    //   2064: aload_0
    //   2065: getfield v : I
    //   2068: imul
    //   2069: iload #7
    //   2071: iconst_1
    //   2072: isub
    //   2073: iload #11
    //   2075: isub
    //   2076: ineg
    //   2077: iload #10
    //   2079: imul
    //   2080: isub
    //   2081: invokevirtual offsetLeftAndRight : (I)V
    //   2084: goto -> 2144
    //   2087: aload #15
    //   2089: getfield e : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   2092: getfield e : I
    //   2095: istore #11
    //   2097: aload_0
    //   2098: getfield v : I
    //   2101: iload #11
    //   2103: imul
    //   2104: istore #7
    //   2106: iload #11
    //   2108: iload #10
    //   2110: imul
    //   2111: istore #11
    //   2113: aload_0
    //   2114: getfield u : I
    //   2117: iconst_1
    //   2118: if_icmpne -> 2134
    //   2121: aload #14
    //   2123: iload #7
    //   2125: iload #11
    //   2127: isub
    //   2128: invokevirtual offsetLeftAndRight : (I)V
    //   2131: goto -> 2144
    //   2134: aload #14
    //   2136: iload #7
    //   2138: iload #11
    //   2140: isub
    //   2141: invokevirtual offsetTopAndBottom : (I)V
    //   2144: iload #6
    //   2146: iconst_1
    //   2147: iadd
    //   2148: istore #6
    //   2150: goto -> 1992
    //   2153: aload_0
    //   2154: invokevirtual x : ()I
    //   2157: ifle -> 2198
    //   2160: aload_0
    //   2161: getfield y : Z
    //   2164: ifeq -> 2184
    //   2167: aload_0
    //   2168: aload_1
    //   2169: aload_2
    //   2170: iconst_1
    //   2171: invokevirtual X0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;Z)V
    //   2174: aload_0
    //   2175: aload_1
    //   2176: aload_2
    //   2177: iconst_0
    //   2178: invokevirtual Y0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;Z)V
    //   2181: goto -> 2198
    //   2184: aload_0
    //   2185: aload_1
    //   2186: aload_2
    //   2187: iconst_1
    //   2188: invokevirtual Y0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;Z)V
    //   2191: aload_0
    //   2192: aload_1
    //   2193: aload_2
    //   2194: iconst_0
    //   2195: invokevirtual X0 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;Z)V
    //   2198: iload_3
    //   2199: ifeq -> 2283
    //   2202: aload_2
    //   2203: getfield f : Z
    //   2206: ifne -> 2283
    //   2209: aload_0
    //   2210: getfield D : I
    //   2213: ifeq -> 2236
    //   2216: aload_0
    //   2217: invokevirtual x : ()I
    //   2220: ifle -> 2236
    //   2223: aload_0
    //   2224: invokevirtual e1 : ()Landroid/view/View;
    //   2227: ifnull -> 2236
    //   2230: iconst_1
    //   2231: istore #6
    //   2233: goto -> 2239
    //   2236: iconst_0
    //   2237: istore #6
    //   2239: iload #6
    //   2241: ifeq -> 2283
    //   2244: aload_0
    //   2245: getfield M : Ljava/lang/Runnable;
    //   2248: astore #14
    //   2250: aload_0
    //   2251: getfield b : Landroidx/recyclerview/widget/RecyclerView;
    //   2254: astore #15
    //   2256: aload #15
    //   2258: ifnull -> 2269
    //   2261: aload #15
    //   2263: aload #14
    //   2265: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   2268: pop
    //   2269: aload_0
    //   2270: invokevirtual Q0 : ()Z
    //   2273: ifeq -> 2283
    //   2276: iload #9
    //   2278: istore #6
    //   2280: goto -> 2286
    //   2283: iconst_0
    //   2284: istore #6
    //   2286: aload_2
    //   2287: getfield f : Z
    //   2290: ifeq -> 2300
    //   2293: aload_0
    //   2294: getfield J : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   2297: invokevirtual b : ()V
    //   2300: aload_0
    //   2301: aload #13
    //   2303: getfield c : Z
    //   2306: putfield E : Z
    //   2309: aload_0
    //   2310: aload_0
    //   2311: invokevirtual f1 : ()Z
    //   2314: putfield F : Z
    //   2317: iload #6
    //   2319: ifeq -> 2336
    //   2322: aload_0
    //   2323: getfield J : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$b;
    //   2326: invokevirtual b : ()V
    //   2329: aload_0
    //   2330: aload_1
    //   2331: aload_2
    //   2332: iconst_0
    //   2333: invokevirtual h1 : (Landroidx/recyclerview/widget/RecyclerView$r;Landroidx/recyclerview/widget/RecyclerView$v;Z)V
    //   2336: return
  }
  
  public void i0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    d1(paramInt1, paramInt2, 1);
  }
  
  public final boolean i1(int paramInt) {
    boolean bool;
    if (this.u == 0) {
      if (paramInt == -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return (bool != this.y);
    } 
    if (paramInt == -1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool == this.y) {
      bool = true;
    } else {
      bool = false;
    } 
    return (bool == f1());
  }
  
  public int j(RecyclerView.v paramv) {
    return R0(paramv);
  }
  
  public void j0(RecyclerView paramRecyclerView) {
    this.C.a();
    E0();
  }
  
  public void j1(int paramInt, RecyclerView.v paramv) {
    int i;
    byte b1;
    if (paramInt > 0) {
      i = a1();
      b1 = 1;
    } else {
      i = Z0();
      b1 = -1;
    } 
    this.w.a = true;
    r1(i, paramv);
    p1(b1);
    w w1 = this.w;
    w1.c = i + w1.d;
    w1.b = Math.abs(paramInt);
  }
  
  public int k(RecyclerView.v paramv) {
    return S0(paramv);
  }
  
  public void k0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    d1(paramInt1, paramInt2, 8);
  }
  
  public final void k1(RecyclerView.r paramr, w paramw) {
    if (paramw.a) {
      if (paramw.i)
        return; 
      if (paramw.b == 0) {
        if (paramw.e == -1) {
          l1(paramr, paramw.g);
          return;
        } 
        m1(paramr, paramw.f);
        return;
      } 
      int k = paramw.e;
      int j = 1;
      int i = 1;
      if (k == -1) {
        int n = paramw.f;
        for (j = this.r[0].k(n); i < this.q; j = k) {
          int i1 = this.r[i].k(n);
          k = j;
          if (i1 > j)
            k = i1; 
          i++;
        } 
        i = n - j;
        if (i < 0) {
          i = paramw.g;
        } else {
          i = paramw.g - Math.min(i, paramw.b);
        } 
        l1(paramr, i);
        return;
      } 
      int m = paramw.g;
      k = this.r[0].h(m);
      i = j;
      for (j = k; i < this.q; j = k) {
        int n = this.r[i].h(m);
        k = j;
        if (n < j)
          k = n; 
        i++;
      } 
      i = j - paramw.g;
      if (i < 0) {
        i = paramw.f;
      } else {
        j = paramw.f;
        i = Math.min(i, paramw.b) + j;
      } 
      m1(paramr, i);
    } 
  }
  
  public int l(RecyclerView.v paramv) {
    return T0(paramv);
  }
  
  public void l0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    d1(paramInt1, paramInt2, 2);
  }
  
  public final void l1(RecyclerView.r paramr, int paramInt) {
    int i = x() - 1;
    while (i >= 0) {
      View view = w(i);
      if (this.s.e(view) >= paramInt && this.s.o(view) >= paramInt) {
        c c = (c)view.getLayoutParams();
        Objects.requireNonNull(c);
        if (c.e.a.size() == 1)
          return; 
        c.e.l();
        A0(view, paramr);
        i--;
      } 
    } 
  }
  
  public int m(RecyclerView.v paramv) {
    return R0(paramv);
  }
  
  public final void m1(RecyclerView.r paramr, int paramInt) {
    while (x() > 0) {
      View view = w(0);
      if (this.s.b(view) <= paramInt && this.s.n(view) <= paramInt) {
        c c = (c)view.getLayoutParams();
        Objects.requireNonNull(c);
        if (c.e.a.size() == 1)
          return; 
        c.e.m();
        A0(view, paramr);
      } 
    } 
  }
  
  public int n(RecyclerView.v paramv) {
    return S0(paramv);
  }
  
  public void n0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    d1(paramInt1, paramInt2, 4);
  }
  
  public final void n1() {
    if (this.u == 1 || !f1()) {
      this.y = this.x;
      return;
    } 
    this.y = this.x ^ true;
  }
  
  public int o(RecyclerView.v paramv) {
    return T0(paramv);
  }
  
  public void o0(RecyclerView.r paramr, RecyclerView.v paramv) {
    h1(paramr, paramv, true);
  }
  
  public int o1(int paramInt, RecyclerView.r paramr, RecyclerView.v paramv) {
    if (x() != 0) {
      if (paramInt == 0)
        return 0; 
      j1(paramInt, paramv);
      int i = U0(paramr, this.w, paramv);
      if (this.w.b >= i)
        if (paramInt < 0) {
          paramInt = -i;
        } else {
          paramInt = i;
        }  
      this.s.p(-paramInt);
      this.E = this.y;
      w w1 = this.w;
      w1.b = 0;
      k1(paramr, w1);
      return paramInt;
    } 
    return 0;
  }
  
  public void p0(RecyclerView.v paramv) {
    this.A = -1;
    this.B = Integer.MIN_VALUE;
    this.G = null;
    this.J.b();
  }
  
  public final void p1(int paramInt) {
    boolean bool1;
    w w1 = this.w;
    w1.e = paramInt;
    boolean bool2 = this.y;
    boolean bool = true;
    if (paramInt == -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool2 == bool1) {
      paramInt = bool;
    } else {
      paramInt = -1;
    } 
    w1.d = paramInt;
  }
  
  public final void q1(int paramInt1, int paramInt2) {
    for (int i = 0; i < this.q; i++) {
      if (!(this.r[i]).a.isEmpty())
        s1(this.r[i], paramInt1, paramInt2); 
    } 
  }
  
  public final void r1(int paramInt, RecyclerView.v paramv) {
    w w1 = this.w;
    boolean bool2 = false;
    w1.b = 0;
    w1.c = paramInt;
    RecyclerView recyclerView = this.b;
    if (recyclerView != null && recyclerView.k) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    if (paramInt != 0) {
      w1.f = this.s.k() - 0;
      this.w.g = this.s.g() + 0;
    } else {
      w1.g = this.s.f() + 0;
      this.w.f = 0;
    } 
    w1 = this.w;
    w1.h = false;
    w1.a = true;
    boolean bool1 = bool2;
    if (this.s.i() == 0) {
      bool1 = bool2;
      if (this.s.f() == 0)
        bool1 = true; 
    } 
    w1.i = bool1;
  }
  
  public final void s1(f paramf, int paramInt1, int paramInt2) {
    int i = paramf.d;
    if (paramInt1 == -1) {
      paramInt1 = paramf.b;
      if (paramInt1 == Integer.MIN_VALUE) {
        paramf.c();
        paramInt1 = paramf.b;
      } 
      if (paramInt1 + i <= paramInt2) {
        this.z.set(paramf.e, false);
        return;
      } 
    } else {
      paramInt1 = paramf.c;
      if (paramInt1 == Integer.MIN_VALUE) {
        paramf.b();
        paramInt1 = paramf.c;
      } 
      if (paramInt1 - i >= paramInt2)
        this.z.set(paramf.e, false); 
    } 
  }
  
  public RecyclerView.m t() {
    return (this.u == 0) ? new c(-2, -1) : new c(-1, -2);
  }
  
  public void t0(Parcelable paramParcelable) {
    if (paramParcelable instanceof e) {
      this.G = (e)paramParcelable;
      E0();
    } 
  }
  
  public final int t1(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == 0 && paramInt3 == 0)
      return paramInt1; 
    int i = View.MeasureSpec.getMode(paramInt1);
    return (i == Integer.MIN_VALUE || i == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, View.MeasureSpec.getSize(paramInt1) - paramInt2 - paramInt3), i) : paramInt1;
  }
  
  public RecyclerView.m u(Context paramContext, AttributeSet paramAttributeSet) {
    return new c(paramContext, paramAttributeSet);
  }
  
  public Parcelable u0() {
    // Byte code:
    //   0: aload_0
    //   1: getfield G : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: new androidx/recyclerview/widget/StaggeredGridLayoutManager$e
    //   14: dup
    //   15: aload #4
    //   17: invokespecial <init> : (Landroidx/recyclerview/widget/StaggeredGridLayoutManager$e;)V
    //   20: areturn
    //   21: new androidx/recyclerview/widget/StaggeredGridLayoutManager$e
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: astore #5
    //   30: aload #5
    //   32: aload_0
    //   33: getfield x : Z
    //   36: putfield l : Z
    //   39: aload #5
    //   41: aload_0
    //   42: getfield E : Z
    //   45: putfield m : Z
    //   48: aload #5
    //   50: aload_0
    //   51: getfield F : Z
    //   54: putfield n : Z
    //   57: aload_0
    //   58: getfield C : Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d;
    //   61: astore #4
    //   63: iconst_0
    //   64: istore_2
    //   65: aload #4
    //   67: ifnull -> 110
    //   70: aload #4
    //   72: getfield a : [I
    //   75: astore #6
    //   77: aload #6
    //   79: ifnull -> 110
    //   82: aload #5
    //   84: aload #6
    //   86: putfield j : [I
    //   89: aload #5
    //   91: aload #6
    //   93: arraylength
    //   94: putfield i : I
    //   97: aload #5
    //   99: aload #4
    //   101: getfield b : Ljava/util/List;
    //   104: putfield k : Ljava/util/List;
    //   107: goto -> 116
    //   110: aload #5
    //   112: iconst_0
    //   113: putfield i : I
    //   116: aload_0
    //   117: invokevirtual x : ()I
    //   120: istore_1
    //   121: iconst_m1
    //   122: istore_3
    //   123: iload_1
    //   124: ifle -> 312
    //   127: aload_0
    //   128: getfield E : Z
    //   131: ifeq -> 142
    //   134: aload_0
    //   135: invokevirtual a1 : ()I
    //   138: istore_1
    //   139: goto -> 147
    //   142: aload_0
    //   143: invokevirtual Z0 : ()I
    //   146: istore_1
    //   147: aload #5
    //   149: iload_1
    //   150: putfield e : I
    //   153: aload_0
    //   154: getfield y : Z
    //   157: ifeq -> 170
    //   160: aload_0
    //   161: iconst_1
    //   162: invokevirtual V0 : (Z)Landroid/view/View;
    //   165: astore #4
    //   167: goto -> 177
    //   170: aload_0
    //   171: iconst_1
    //   172: invokevirtual W0 : (Z)Landroid/view/View;
    //   175: astore #4
    //   177: aload #4
    //   179: ifnonnull -> 187
    //   182: iload_3
    //   183: istore_1
    //   184: goto -> 194
    //   187: aload_0
    //   188: aload #4
    //   190: invokevirtual L : (Landroid/view/View;)I
    //   193: istore_1
    //   194: aload #5
    //   196: iload_1
    //   197: putfield f : I
    //   200: aload_0
    //   201: getfield q : I
    //   204: istore_1
    //   205: aload #5
    //   207: iload_1
    //   208: putfield g : I
    //   211: aload #5
    //   213: iload_1
    //   214: newarray int
    //   216: putfield h : [I
    //   219: iload_2
    //   220: aload_0
    //   221: getfield q : I
    //   224: if_icmpge -> 330
    //   227: aload_0
    //   228: getfield E : Z
    //   231: ifeq -> 265
    //   234: aload_0
    //   235: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   238: iload_2
    //   239: aaload
    //   240: ldc -2147483648
    //   242: invokevirtual h : (I)I
    //   245: istore_3
    //   246: iload_3
    //   247: istore_1
    //   248: iload_3
    //   249: ldc -2147483648
    //   251: if_icmpeq -> 297
    //   254: aload_0
    //   255: getfield s : Lc/t/b/c0;
    //   258: invokevirtual g : ()I
    //   261: istore_1
    //   262: goto -> 293
    //   265: aload_0
    //   266: getfield r : [Landroidx/recyclerview/widget/StaggeredGridLayoutManager$f;
    //   269: iload_2
    //   270: aaload
    //   271: ldc -2147483648
    //   273: invokevirtual k : (I)I
    //   276: istore_3
    //   277: iload_3
    //   278: istore_1
    //   279: iload_3
    //   280: ldc -2147483648
    //   282: if_icmpeq -> 297
    //   285: aload_0
    //   286: getfield s : Lc/t/b/c0;
    //   289: invokevirtual k : ()I
    //   292: istore_1
    //   293: iload_3
    //   294: iload_1
    //   295: isub
    //   296: istore_1
    //   297: aload #5
    //   299: getfield h : [I
    //   302: iload_2
    //   303: iload_1
    //   304: iastore
    //   305: iload_2
    //   306: iconst_1
    //   307: iadd
    //   308: istore_2
    //   309: goto -> 219
    //   312: aload #5
    //   314: iconst_m1
    //   315: putfield e : I
    //   318: aload #5
    //   320: iconst_m1
    //   321: putfield f : I
    //   324: aload #5
    //   326: iconst_0
    //   327: putfield g : I
    //   330: aload #5
    //   332: areturn
  }
  
  public RecyclerView.m v(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new c((ViewGroup.MarginLayoutParams)paramLayoutParams) : new c(paramLayoutParams);
  }
  
  public void v0(int paramInt) {
    if (paramInt == 0)
      Q0(); 
  }
  
  public int z(RecyclerView.r paramr, RecyclerView.v paramv) {
    return (this.u == 1) ? this.q : super.z(paramr, paramv);
  }
  
  public class a implements Runnable {
    public a(StaggeredGridLayoutManager this$0) {}
    
    public void run() {
      this.e.Q0();
    }
  }
  
  public class b {
    public int a;
    
    public int b;
    
    public boolean c;
    
    public boolean d;
    
    public boolean e;
    
    public int[] f;
    
    public b(StaggeredGridLayoutManager this$0) {
      b();
    }
    
    public void a() {
      int i;
      if (this.c) {
        i = this.g.s.g();
      } else {
        i = this.g.s.k();
      } 
      this.b = i;
    }
    
    public void b() {
      this.a = -1;
      this.b = Integer.MIN_VALUE;
      this.c = false;
      this.d = false;
      this.e = false;
      int[] arrayOfInt = this.f;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
    }
  }
  
  public static class c extends RecyclerView.m {
    public StaggeredGridLayoutManager.f e;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  public static class d {
    public int[] a;
    
    public List<a> b;
    
    public void a() {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.b = null;
    }
    
    public void b(int param1Int) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null) {
        arrayOfInt = new int[Math.max(param1Int, 10) + 1];
        this.a = arrayOfInt;
        Arrays.fill(arrayOfInt, -1);
        return;
      } 
      if (param1Int >= arrayOfInt.length) {
        int i;
        for (i = arrayOfInt.length; i <= param1Int; i *= 2);
        int[] arrayOfInt1 = new int[i];
        this.a = arrayOfInt1;
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
        arrayOfInt1 = this.a;
        Arrays.fill(arrayOfInt1, arrayOfInt.length, arrayOfInt1.length, -1);
      } 
    }
    
    public a c(int param1Int) {
      List<a> list = this.b;
      if (list == null)
        return null; 
      for (int i = list.size() - 1; i >= 0; i--) {
        a a = this.b.get(i);
        if (a.e == param1Int)
          return a; 
      } 
      return null;
    }
    
    public int d(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : [I
      //   4: astore #4
      //   6: aload #4
      //   8: ifnonnull -> 13
      //   11: iconst_m1
      //   12: ireturn
      //   13: iload_1
      //   14: aload #4
      //   16: arraylength
      //   17: if_icmplt -> 22
      //   20: iconst_m1
      //   21: ireturn
      //   22: aload_0
      //   23: getfield b : Ljava/util/List;
      //   26: ifnonnull -> 34
      //   29: iconst_m1
      //   30: istore_2
      //   31: goto -> 144
      //   34: aload_0
      //   35: iload_1
      //   36: invokevirtual c : (I)Landroidx/recyclerview/widget/StaggeredGridLayoutManager$d$a;
      //   39: astore #4
      //   41: aload #4
      //   43: ifnull -> 58
      //   46: aload_0
      //   47: getfield b : Ljava/util/List;
      //   50: aload #4
      //   52: invokeinterface remove : (Ljava/lang/Object;)Z
      //   57: pop
      //   58: aload_0
      //   59: getfield b : Ljava/util/List;
      //   62: invokeinterface size : ()I
      //   67: istore_3
      //   68: iconst_0
      //   69: istore_2
      //   70: iload_2
      //   71: iload_3
      //   72: if_icmpge -> 105
      //   75: aload_0
      //   76: getfield b : Ljava/util/List;
      //   79: iload_2
      //   80: invokeinterface get : (I)Ljava/lang/Object;
      //   85: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
      //   88: getfield e : I
      //   91: iload_1
      //   92: if_icmplt -> 98
      //   95: goto -> 107
      //   98: iload_2
      //   99: iconst_1
      //   100: iadd
      //   101: istore_2
      //   102: goto -> 70
      //   105: iconst_m1
      //   106: istore_2
      //   107: iload_2
      //   108: iconst_m1
      //   109: if_icmpeq -> 29
      //   112: aload_0
      //   113: getfield b : Ljava/util/List;
      //   116: iload_2
      //   117: invokeinterface get : (I)Ljava/lang/Object;
      //   122: checkcast androidx/recyclerview/widget/StaggeredGridLayoutManager$d$a
      //   125: astore #4
      //   127: aload_0
      //   128: getfield b : Ljava/util/List;
      //   131: iload_2
      //   132: invokeinterface remove : (I)Ljava/lang/Object;
      //   137: pop
      //   138: aload #4
      //   140: getfield e : I
      //   143: istore_2
      //   144: iload_2
      //   145: iconst_m1
      //   146: if_icmpne -> 171
      //   149: aload_0
      //   150: getfield a : [I
      //   153: astore #4
      //   155: aload #4
      //   157: iload_1
      //   158: aload #4
      //   160: arraylength
      //   161: iconst_m1
      //   162: invokestatic fill : ([IIII)V
      //   165: aload_0
      //   166: getfield a : [I
      //   169: arraylength
      //   170: ireturn
      //   171: aload_0
      //   172: getfield a : [I
      //   175: astore #4
      //   177: iload_2
      //   178: iconst_1
      //   179: iadd
      //   180: istore_2
      //   181: aload #4
      //   183: iload_1
      //   184: iload_2
      //   185: iconst_m1
      //   186: invokestatic fill : ([IIII)V
      //   189: iload_2
      //   190: ireturn
    }
    
    public void e(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int i = param1Int1 + param1Int2;
        b(i);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, param1Int1, arrayOfInt, i, arrayOfInt.length - param1Int1 - param1Int2);
        Arrays.fill(this.a, param1Int1, i, -1);
        List<a> list = this.b;
        if (list == null)
          return; 
        for (i = list.size() - 1; i >= 0; i--) {
          a a = this.b.get(i);
          int j = a.e;
          if (j >= param1Int1)
            a.e = j + param1Int2; 
        } 
      } 
    }
    
    public void f(int param1Int1, int param1Int2) {
      int[] arrayOfInt = this.a;
      if (arrayOfInt != null) {
        if (param1Int1 >= arrayOfInt.length)
          return; 
        int j = param1Int1 + param1Int2;
        b(j);
        arrayOfInt = this.a;
        System.arraycopy(arrayOfInt, j, arrayOfInt, param1Int1, arrayOfInt.length - param1Int1 - param1Int2);
        arrayOfInt = this.a;
        Arrays.fill(arrayOfInt, arrayOfInt.length - param1Int2, arrayOfInt.length, -1);
        List<a> list = this.b;
        if (list == null)
          return; 
        for (int i = list.size() - 1; i >= 0; i--) {
          a a = this.b.get(i);
          int k = a.e;
          if (k >= param1Int1)
            if (k < j) {
              this.b.remove(i);
            } else {
              a.e = k - param1Int2;
            }  
        } 
      } 
    }
    
    public static class a implements Parcelable {
      public static final Parcelable.Creator<a> CREATOR = (Parcelable.Creator<a>)new m0();
      
      public int e;
      
      public int f;
      
      public int[] g;
      
      public boolean h;
      
      public a(Parcel param2Parcel) {
        this.e = param2Parcel.readInt();
        this.f = param2Parcel.readInt();
        int i = param2Parcel.readInt();
        boolean bool = true;
        if (i != 1)
          bool = false; 
        this.h = bool;
        i = param2Parcel.readInt();
        if (i > 0) {
          int[] arrayOfInt = new int[i];
          this.g = arrayOfInt;
          param2Parcel.readIntArray(arrayOfInt);
        } 
      }
      
      public int describeContents() {
        return 0;
      }
      
      public String toString() {
        StringBuilder stringBuilder = d.a.a.a.a.p("FullSpanItem{mPosition=");
        stringBuilder.append(this.e);
        stringBuilder.append(", mGapDir=");
        stringBuilder.append(this.f);
        stringBuilder.append(", mHasUnwantedGapAfter=");
        stringBuilder.append(this.h);
        stringBuilder.append(", mGapPerSpan=");
        stringBuilder.append(Arrays.toString(this.g));
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
      }
    }
  }
  
  public static class a implements Parcelable {
    public static final Parcelable.Creator<a> CREATOR = (Parcelable.Creator<a>)new m0();
    
    public int e;
    
    public int f;
    
    public int[] g;
    
    public boolean h;
    
    public a(Parcel param1Parcel) {
      this.e = param1Parcel.readInt();
      this.f = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      boolean bool = true;
      if (i != 1)
        bool = false; 
      this.h = bool;
      i = param1Parcel.readInt();
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.g = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = d.a.a.a.a.p("FullSpanItem{mPosition=");
      stringBuilder.append(this.e);
      stringBuilder.append(", mGapDir=");
      stringBuilder.append(this.f);
      stringBuilder.append(", mHasUnwantedGapAfter=");
      stringBuilder.append(this.h);
      stringBuilder.append(", mGapPerSpan=");
      stringBuilder.append(Arrays.toString(this.g));
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
  
  public static class e implements Parcelable {
    public static final Parcelable.Creator<e> CREATOR = (Parcelable.Creator<e>)new n0();
    
    public int e;
    
    public int f;
    
    public int g;
    
    public int[] h;
    
    public int i;
    
    public int[] j;
    
    public List<StaggeredGridLayoutManager.d.a> k;
    
    public boolean l;
    
    public boolean m;
    
    public boolean n;
    
    public e() {}
    
    public e(Parcel param1Parcel) {
      this.e = param1Parcel.readInt();
      this.f = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      this.g = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.h = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      this.i = i;
      if (i > 0) {
        int[] arrayOfInt = new int[i];
        this.j = arrayOfInt;
        param1Parcel.readIntArray(arrayOfInt);
      } 
      i = param1Parcel.readInt();
      boolean bool2 = false;
      if (i == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.l = bool1;
      if (param1Parcel.readInt() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.m = bool1;
      boolean bool1 = bool2;
      if (param1Parcel.readInt() == 1)
        bool1 = true; 
      this.n = bool1;
      this.k = param1Parcel.readArrayList(StaggeredGridLayoutManager.d.a.class.getClassLoader());
    }
    
    public e(e param1e) {
      this.g = param1e.g;
      this.e = param1e.e;
      this.f = param1e.f;
      this.h = param1e.h;
      this.i = param1e.i;
      this.j = param1e.j;
      this.l = param1e.l;
      this.m = param1e.m;
      this.n = param1e.n;
      this.k = param1e.k;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
  
  public class f {
    public ArrayList<View> a = new ArrayList<View>();
    
    public int b = Integer.MIN_VALUE;
    
    public int c = Integer.MIN_VALUE;
    
    public int d = 0;
    
    public final int e;
    
    public f(StaggeredGridLayoutManager this$0, int param1Int) {
      this.e = param1Int;
    }
    
    public void a(View param1View) {
      StaggeredGridLayoutManager.c c = j(param1View);
      c.e = this;
      this.a.add(param1View);
      this.c = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.b = Integer.MIN_VALUE; 
      if (c.c() || c.b()) {
        int i = this.d;
        this.d = this.f.s.c(param1View) + i;
      } 
    }
    
    public void b() {
      ArrayList<View> arrayList = this.a;
      View view = arrayList.get(arrayList.size() - 1);
      StaggeredGridLayoutManager.c c = j(view);
      this.c = this.f.s.b(view);
      Objects.requireNonNull(c);
    }
    
    public void c() {
      View view = this.a.get(0);
      StaggeredGridLayoutManager.c c = j(view);
      this.b = this.f.s.e(view);
      Objects.requireNonNull(c);
    }
    
    public void d() {
      this.a.clear();
      this.b = Integer.MIN_VALUE;
      this.c = Integer.MIN_VALUE;
      this.d = 0;
    }
    
    public int e() {
      return this.f.x ? g(this.a.size() - 1, -1, true) : g(0, this.a.size(), true);
    }
    
    public int f() {
      return this.f.x ? g(0, this.a.size(), true) : g(this.a.size() - 1, -1, true);
    }
    
    public int g(int param1Int1, int param1Int2, boolean param1Boolean) {
      byte b;
      int i = this.f.s.k();
      int j = this.f.s.g();
      if (param1Int2 > param1Int1) {
        b = 1;
      } else {
        b = -1;
      } 
      while (param1Int1 != param1Int2) {
        boolean bool1;
        View view = this.a.get(param1Int1);
        int k = this.f.s.e(view);
        int m = this.f.s.b(view);
        boolean bool2 = false;
        if (param1Boolean ? (k <= j) : (k < j)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (param1Boolean ? (m >= i) : (m > i))
          bool2 = true; 
        if (bool1 && bool2 && (k < i || m > j))
          return this.f.L(view); 
        param1Int1 += b;
      } 
      return -1;
    }
    
    public int h(int param1Int) {
      int i = this.c;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      b();
      return this.c;
    }
    
    public View i(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #5
      //   3: aconst_null
      //   4: astore #4
      //   6: iload_2
      //   7: iconst_m1
      //   8: if_icmpne -> 123
      //   11: aload_0
      //   12: getfield a : Ljava/util/ArrayList;
      //   15: invokevirtual size : ()I
      //   18: istore_3
      //   19: iconst_0
      //   20: istore_2
      //   21: aload #4
      //   23: astore #5
      //   25: iload_2
      //   26: iload_3
      //   27: if_icmpge -> 238
      //   30: aload_0
      //   31: getfield a : Ljava/util/ArrayList;
      //   34: iload_2
      //   35: invokevirtual get : (I)Ljava/lang/Object;
      //   38: checkcast android/view/View
      //   41: astore #6
      //   43: aload_0
      //   44: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   47: astore #7
      //   49: aload #7
      //   51: getfield x : Z
      //   54: ifeq -> 72
      //   57: aload #4
      //   59: astore #5
      //   61: aload #7
      //   63: aload #6
      //   65: invokevirtual L : (Landroid/view/View;)I
      //   68: iload_1
      //   69: if_icmple -> 238
      //   72: aload_0
      //   73: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   76: astore #5
      //   78: aload #5
      //   80: getfield x : Z
      //   83: ifne -> 100
      //   86: aload #5
      //   88: aload #6
      //   90: invokevirtual L : (Landroid/view/View;)I
      //   93: iload_1
      //   94: if_icmplt -> 100
      //   97: aload #4
      //   99: areturn
      //   100: aload #4
      //   102: astore #5
      //   104: aload #6
      //   106: invokevirtual hasFocusable : ()Z
      //   109: ifeq -> 238
      //   112: iload_2
      //   113: iconst_1
      //   114: iadd
      //   115: istore_2
      //   116: aload #6
      //   118: astore #4
      //   120: goto -> 21
      //   123: aload_0
      //   124: getfield a : Ljava/util/ArrayList;
      //   127: invokevirtual size : ()I
      //   130: iconst_1
      //   131: isub
      //   132: istore_2
      //   133: aload #5
      //   135: astore #4
      //   137: aload #4
      //   139: astore #5
      //   141: iload_2
      //   142: iflt -> 238
      //   145: aload_0
      //   146: getfield a : Ljava/util/ArrayList;
      //   149: iload_2
      //   150: invokevirtual get : (I)Ljava/lang/Object;
      //   153: checkcast android/view/View
      //   156: astore #6
      //   158: aload_0
      //   159: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   162: astore #7
      //   164: aload #7
      //   166: getfield x : Z
      //   169: ifeq -> 187
      //   172: aload #4
      //   174: astore #5
      //   176: aload #7
      //   178: aload #6
      //   180: invokevirtual L : (Landroid/view/View;)I
      //   183: iload_1
      //   184: if_icmpge -> 238
      //   187: aload_0
      //   188: getfield f : Landroidx/recyclerview/widget/StaggeredGridLayoutManager;
      //   191: astore #5
      //   193: aload #5
      //   195: getfield x : Z
      //   198: ifne -> 215
      //   201: aload #5
      //   203: aload #6
      //   205: invokevirtual L : (Landroid/view/View;)I
      //   208: iload_1
      //   209: if_icmpgt -> 215
      //   212: aload #4
      //   214: areturn
      //   215: aload #4
      //   217: astore #5
      //   219: aload #6
      //   221: invokevirtual hasFocusable : ()Z
      //   224: ifeq -> 238
      //   227: iload_2
      //   228: iconst_1
      //   229: isub
      //   230: istore_2
      //   231: aload #6
      //   233: astore #4
      //   235: goto -> 137
      //   238: aload #5
      //   240: areturn
    }
    
    public StaggeredGridLayoutManager.c j(View param1View) {
      return (StaggeredGridLayoutManager.c)param1View.getLayoutParams();
    }
    
    public int k(int param1Int) {
      int i = this.b;
      if (i != Integer.MIN_VALUE)
        return i; 
      if (this.a.size() == 0)
        return param1Int; 
      c();
      return this.b;
    }
    
    public void l() {
      int i = this.a.size();
      View view = this.a.remove(i - 1);
      StaggeredGridLayoutManager.c c = j(view);
      c.e = null;
      if (c.c() || c.b())
        this.d -= this.f.s.c(view); 
      if (i == 1)
        this.b = Integer.MIN_VALUE; 
      this.c = Integer.MIN_VALUE;
    }
    
    public void m() {
      View view = this.a.remove(0);
      StaggeredGridLayoutManager.c c = j(view);
      c.e = null;
      if (this.a.size() == 0)
        this.c = Integer.MIN_VALUE; 
      if (c.c() || c.b())
        this.d -= this.f.s.c(view); 
      this.b = Integer.MIN_VALUE;
    }
    
    public void n(View param1View) {
      StaggeredGridLayoutManager.c c = j(param1View);
      c.e = this;
      this.a.add(0, param1View);
      this.b = Integer.MIN_VALUE;
      if (this.a.size() == 1)
        this.c = Integer.MIN_VALUE; 
      if (c.c() || c.b()) {
        int i = this.d;
        this.d = this.f.s.c(param1View) + i;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Https Traffic-dex2jar.jar!\androidx\recyclerview\widget\StaggeredGridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */